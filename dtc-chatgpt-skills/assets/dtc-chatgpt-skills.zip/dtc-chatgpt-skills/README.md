# 15 DTC Skills for ChatGPT

Fifteen ChatGPT skills for the people who run DTC ad accounts: media buyers, creative
strategists, and founders doing both jobs themselves.

Each skill is one `SKILL.md` file. You paste the screen you already have open, an Ads
Manager row set, a product page, a pile of reviews, a supplier invoice, and it hands
back one thing you can act on. Nothing connects to your ad account or your store.

Built by the team at RISE DTC.

## The one rule every skill follows

No invented numbers. Every figure a skill prints is computed from a number you gave it,
with the arithmetic shown so you can redo it by hand. When an input is missing, the skill
prints `[NEEDS: the thing it is missing]` and carries on with what it can answer. It never
fills the gap with a plausible value, an industry benchmark, or an average.

## The fifteen

### Research
| skill | you paste | you get back |
|---|---|---|
| `competitor-researcher` | ad library listings and page text for 1 to 3 competitors | their claims word for word, their offer beside yours, the angles their longest running ads hold, and the angles nobody occupies |
| `customer-researcher` | 15 or more reviews, survey answers, tickets or return reasons | the customer language bank: benefits, objections, before and after states, ten ad ready phrases, each counted and quoted |
| `angle-gap-mapper` | the name and primary text of the live ads | each ad's angle with counts, plus the angles from a fixed list that no live ad occupies |

### Creative
| skill | you paste | you get back |
|---|---|---|
| `ad-brief-generator` | one angle, the product facts, the format you are shooting | a shot-by-shot brief with a claim boundary block naming exactly what your facts allow |
| `hook-generator` | one angle, the product facts, the audience in a sentence | up to twelve opening lines, each tagged with the device it used and the fact it rests on |
| `winner-iteration-planner` | the winning ad, its visual, and what you already tried | six next variants, each changing one named element, cheapest to shoot first |
| `ugc-script-writer` | one angle, the product facts, the creator, a target length | one five beat script, every beat carrying its spoken line, action, overlay and seconds |

### Media buying
| skill | you paste | you get back |
|---|---|---|
| `utm-tag-auditor` | your tracking links | a PASS or BREAK per link naming the exact defect, with the corrected link printed |
| `ad-account-hygiene-auditor` | the campaign and ad set list off the Ads Manager screen | a 24 point verdict, the wasted spend summed from your own rows, and a fix list naming the exact ad set |
| `budget-step-planner` | one campaign's current budget and its 7 and 30 day rows | the next daily budget, the days to hold it untouched, and the condition that puts it back |

### Conversion
| skill | you paste | you get back |
|---|---|---|
| `message-match-checker` | the ad, and the page down to the first buy button | every promise the ad makes classed ANSWERED, PARTIAL or UNANSWERED, with the page line quoted |
| `cro-auditor` | the page text top to bottom, plus the ad sending traffic to it | a 48 point PASS / FAIL / CANNOT CHECK table with the page line quoted and one fix per FAIL |

### The money
| skill | you paste | you get back |
|---|---|---|
| `break-even-and-affordable-cpa` | your order economics off Shopify, an invoice and a processor statement | contribution margin, break-even ROAS, break-even CPA, the same three after returns, and the CPA you can afford |
| `roas-vs-mer-reader` | per channel spend and reported revenue, plus backend revenue | per channel ROAS, MER on the backend figure, and the overlap gap in dollars |
| `scale-or-kill-judge` | the per ad spend and purchase rows for one window | SCALE, HOLD, CUT or NOT ENOUGH SPEND for every ad, and what the thin ones need before they can be read |

Fifteen folders. Count them.

## Install

Three routes. Route 1 is the real install and needs a ChatGPT Business, Enterprise or Edu
seat. Route 2 works on every plan including Free, and needs no setup at all. Route 3 is for
people already working in a terminal.

### Route 1, ChatGPT Business, Enterprise or Edu

Per OpenAI's help center, "Skills are available to eligible ChatGPT Business, Enterprise,
Healthcare, and Edu users". Free, Plus and Pro accounts do not have the Skills upload yet.
If yours does not, use Route 2.

1. Unzip the kit.
2. In ChatGPT, open the sidebar, go to **Plugins**, open the **Skills** tab, then **Create**.
3. Choose **Upload from your computer** and upload one skill folder. Each folder is one
   skill, so upload them one at a time, as many as you want.
4. ChatGPT scans every upload. Some come back marked **Needs Review**.

Then type `@scale-or-kill-judge` in a chat and paste your rows underneath. You can also just
ask for the job in plain words: a skill triggers on its own when your request matches its
description.

### Route 2, any ChatGPT plan, including Free, Plus and Pro

No setup at all.

1. Open the skill folder you want and its `SKILL.md` file.
2. Copy the whole file and paste it into a new chat.
3. Paste your own numbers or copy underneath it and send.

Every file is written to work as a standalone prompt. On Plus and above you can instead paste
the file into a Project's instructions, so every chat inside that project carries the skill.

### Route 3, Codex or Claude Code

```
cp -R dtc-chatgpt-skills/* ~/.agents/skills/
```

That is the Codex path. Codex invokes a skill with `$scale-or-kill-judge`. For Claude Code,
copy to `~/.claude/skills/` instead:

```
cp -R dtc-chatgpt-skills/* ~/.claude/skills/
```

Both pick the folders up on the next start.

## Where to start

Run `break-even-and-affordable-cpa` first, on any account you are about to touch. It gives
you the cost per purchase the brand can actually afford, which is the number three of the
other skills ask you for. Then `scale-or-kill-judge` with that number and last week's rows.

If the account is new to you, run `ad-account-hygiene-auditor` before anything else.

## The fixtures

Every skill ships a `fixtures/` folder holding one or two pastes made up for testing. Run a
skill on its fixture first to see the shape of the output before you feed it a real account.
The brands in the fixtures are invented. No client data is anywhere in this kit.

## What these will not do

- They do not connect to Meta, Google, TikTok, Shopify or anything else. You paste, they read.
- They do not predict what a change will do to your CPA or your ROAS. They read what happened.
- They do not fill a missing input with a benchmark. They name the missing field.
- They do not grade your account or your page. They print what passed, what failed, and what could not be checked from the paste.

## Questions

RISE DTC built these for its own media buyers and creative strategists. If you want one
tuned to your account, or a skill for a problem that is not here, that is what the team does.

risedtc.com
