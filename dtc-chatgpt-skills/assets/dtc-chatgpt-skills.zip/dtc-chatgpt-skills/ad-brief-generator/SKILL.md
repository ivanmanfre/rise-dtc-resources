---
name: ad-brief-generator
description: "Use when you have picked an angle and need a brief the editor or creator can shoot from without asking a question. Takes the angle, the product facts the account can stand behind, and the format you are shooting, and returns a shot-by-shot brief with a claim boundary block naming exactly what the supplied facts allow. Triggers on \"write me an ad brief\", \"turn this angle into a shoot brief\", \"brief for the UGC video\", \"what can we actually claim in this ad\", \"brief this angle for the client without overclaiming\"."
---

# RISE DTC ChatGPT Skills, 04 of 15: the ad brief

## What this does

Turns one angle and a list of product facts into a shot-by-shot brief, with a claim boundary block that names every claim the supplied facts allow and refuses every line that would say more than the facts support.

**The line only this skill produces:** a claim boundary block generated from this shoot's own supplied facts, with every brief line traced back to one named fact or printed as `[NEEDS: the fact behind this claim]` in the line's place. Nothing here judges an ad that already ran; it exists before the shoot.

## Required input

1. **The angle you picked.** One of the eight in the table below, which is the same fixed list the angle gap map skill in this kit assigns ads to: PROBLEM/SOLUTION, MECHANISM, SOCIAL PROOF, COMPARISON, OFFER, IDENTITY, URGENCY/SCARCITY, FOUNDER/ORIGIN. A plain description of the angle in your own words is also accepted; it gets matched to one of the eight before anything is written.
2. **Product facts the account can stand behind**, each on its own line, typed or pasted off the product page. At minimum: what it is, what it does, price, what is in the box. Optional, only if you actually have them: guarantee terms, a founder detail, review or rating data, a named comparison point.
3. **The format you are shooting.** One of: UGC talking-to-camera video, static image, carousel.

Never supply a claim nobody can back with a fact you are willing to name. If you want a line in the brief, the fact behind it goes in this list first.

## What it refuses

**Refusal 1, no line without a fact.** Every brief line traces to one supplied fact. Where no supplied fact supports a slot, the slot prints these two lines and no source field, because there is no source to name:

```
[NEEDS: the fact behind this claim]
attempted: <what this slot needed to say>
```

**Refusal 2, cannot brief an angle with nothing behind it.** Each angle has one minimum required fact type (table below). If that fact type is absent from the supplied facts:

```
CANNOT BRIEF THIS ANGLE
angle: <angle>
required fact type: <fact type>
facts supplied that support it: 0

<Angle> claims need a fact this shoot does not have. Supply the missing fact
type, or pick a different angle from the facts you actually supplied.
```

## Angle to required fact type

| Angle | Minimum required fact type |
|---|---|
| PROBLEM/SOLUTION | what it does |
| MECHANISM | a material or process fact |
| SOCIAL PROOF | a review or rating fact |
| COMPARISON | what it does, plus a described alternative |
| OFFER | a price or guarantee fact |
| IDENTITY | an audience description |
| URGENCY/SCARCITY | a stock or date fact |
| FOUNDER/ORIGIN | a founder detail |

## Method

**Step 1, state the population.** "The product facts you supplied, counted once each, plus the angle and the format."

**Step 2, gate the angle.** Check the required fact type for the picked angle against the supplied facts. Absent, fires Refusal 2 and stops. Present, continue.

**Step 3, build the claim boundary block.** For every supplied fact, restate it as one allowed claim sentence. This block is the only source of content the brief may draw from. Print the fact types you were not given, by name, as NOT ALLOWED.

**Step 4, build the shot list.** Five fixed slots, in this order, regardless of format:

1. **HOOK.** Draws from the picked angle's primary allowed claim. The primary allowed claim is the first claim in the supplied fact list that the angle's own definition names, read in the order the facts were supplied. If two claims qualify, it is the one that needs no second fact to stand.
2. **PROBLEM/CONTEXT.** Draws from a "what it does" fact restated as the problem it removes. Absent, Refusal 1.
3. **PRODUCT IN USE.** Draws from a "what it is" or material/process fact. Absent, Refusal 1.
4. **PROOF/DIFFERENTIATOR.** Draws from a review, guarantee, or comparison fact. Absent, Refusal 1.
5. **CTA.** Draws from the price fact. Absent, Refusal 1.

For each slot, write one line and name the fact it rests on. A slot with no supporting fact prints Refusal 1's two lines instead of a line and a source, and the brief still ships with the other slots filled.

**Step 5, format direction.** Append one line of shooting or layout direction per slot, matched to the stated format. This line is craft direction, not a claim, and carries no new fact.

**Step 6, list unused facts.** Any supplied fact not used in a slot is printed under "facts not used," so nothing supplied silently disappears from the record.

## Output format

There are two output shapes. Which one you print is decided at Step 2.

**Shape 1, the brief** (Step 2 gate passed):

```
# Ad brief: <angle>
Format: <UGC video | static image | carousel>

## Claim boundary block
ALLOWED:
- <fact 1, restated as a claim>
- <fact 2, restated as a claim>
NOT ALLOWED (not supplied): <fact types absent, or "none, every optional type was supplied">

## Shot list
1. HOOK (<direction>)
   line: "<line>"          source: <fact used>
2. PROBLEM/CONTEXT (<direction>)
   line: "<line>"          source: <fact used>
3. PRODUCT IN USE (<direction>)
   line: "<line>"          source: <fact used>
4. PROOF/DIFFERENTIATOR (<direction>)
   line: "<line>"          source: <fact used>
5. CTA (<direction>)
   line: "<line>"          source: <fact used>

Any slot with no supporting fact prints these two lines in place of its line
and source, and nothing else:
   [NEEDS: the fact behind this claim]
   attempted: <what this slot needed to say>

## Facts not used
- <fact>
(or: "None. Every supplied fact appears in a slot.")
```

**Shape 2, the angle gate refusal** (Step 2 gate failed, Refusal 2). This is the whole output. No claim boundary block, no shot list, no facts-not-used section:

```
CANNOT BRIEF THIS ANGLE
angle: <angle>
required fact type: <fact type>
facts supplied that support it: 0

<Angle> claims need a fact this shoot does not have. Supply the missing fact
type, or pick a different angle from the facts you actually supplied.
```

## Worked case

This worked case IS the fixture run at `fixtures/marrow-ash-mechanism-brief.md`, re-run literally against the method above and checked line by line before shipping.

Population: 4 supplied facts (what it is, what it does, price, what's in the box), angle MECHANISM, format UGC talking-to-camera video.

Angle: MECHANISM. Required fact type: a material or process fact. The supplied fact "15 lb weighted blanket, glass micro-bead fill sewn into individual channels, cotton duvet cover" (what it is) carries a material and process fact. Refusal 2 does not fire, so the run prints Shape 1.

Primary allowed claim, under Step 4's rule: the MECHANISM angle names a component, material or process and how it works. Reading the supplied facts in the order given, the first claim that names one is the "what it is" fact, the glass micro-bead fill sewn into individual channels. It stands without a second fact, so it is the primary allowed claim and the HOOK rests on it.

Claim boundary block, from the four supplied facts (what it is, what it does, price, what's in the box). No guarantee, review, comparison or founder fact was supplied, so those types are printed under NOT ALLOWED.

Shot list:
1. HOOK, from the primary allowed claim (the glass micro-bead fill sewn into individual channels): filled, source named.
2. PROBLEM/CONTEXT, from the "what it does" fact (evenly distributes pressure to reduce nighttime movement): filled, source named.
3. PRODUCT IN USE, from the "what it is" fact: filled, source named.
4. PROOF/DIFFERENTIATOR: no review, guarantee, or comparison fact was supplied. Refusal 1 fires here, and the slot prints exactly two lines, `[NEEDS: the fact behind this claim]` and `attempted: a proof or differentiator claim for the mechanism`. No source field is printed, because there is no fact to name.
5. CTA, from the price fact ($129): filled, source named.

Facts used: 3 of 4 (what it is, twice across slots 1 and 3, what it does, price). Facts not used: 1 of 4, "what's in the box" (blanket, duvet cover, care card) is not called by any of the five slots in this brief and is printed under facts not used, not silently dropped. Slots filled: 4 of 5. Slots refused: 1 of 5. 4 + 1 = 5, the fixed slot count.

**On the second fixture** (`fixtures/marrow-ash-social-proof-no-reviews.md`): it exercises Refusal 2 directly. The angle picked is SOCIAL PROOF, whose required fact type is a review or rating fact, and none of the 4 supplied facts carries one. The run stops at the Step 2 gate and prints Shape 2 only, so the claim boundary block and the shot list are never reached.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a claim, a number, a date, a guarantee term or a founder detail the supplied facts did not carry.
- Never print a `source:` field on a refused slot. A refused slot is the two Refusal 1 lines and nothing else.
- Never soften Refusal 2 into a brief built on a guessed fact.
- Never write "in the brand's voice." This skill writes a neutral draft brief for you to rewrite in the brand's own words. No voice sample is collected here.
- Never predict a click rate, a cost per purchase or a return on ad spend. This writes a brief, it does not forecast performance.
- No self-audit step. If a slot is compliant it says so by simply printing a filled line; nothing sweeps the finished brief a second time to check itself.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.

<!-- ported from 01-existing/the-dtc-growth-team/creative/creative-02-ad-brief-writer, 2026-09-06; fixes applied: Output format refused-slot shape made identical to the two-line shape in What it refuses (no source field), CANNOT BRIEF THIS ANGLE added to the Output format as the second labelled output shape, Step 4 primary allowed claim defined (first qualifying claim in the supplied order, tie to the one needing no second fact), cross-unit reference to unit 01 replaced with the eight angles printed in this file -->
