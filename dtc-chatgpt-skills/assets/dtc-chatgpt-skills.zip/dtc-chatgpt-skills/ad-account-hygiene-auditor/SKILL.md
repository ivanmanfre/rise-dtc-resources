---
name: ad-account-hygiene-auditor
description: "Use when you inherit an ad account, or review one you run, and need to know what is structurally broken before you touch a budget. Takes the campaign and ad set list as it reads on the Ads Manager screen and returns a fixed 24 point hygiene verdict, the PASS FAIL CANNOT CHECK count, the wasted spend summed from your own rows, and a fix list naming the exact campaign or ad set. Triggers on \"audit this ad account\", \"I inherited this account, what is wrong with it\", \"clean up my campaign structure\", \"where is my spend being wasted\", \"is my account naming a mess\"."
---

# RISE DTC ChatGPT Skills, 13 of 15: the account hygiene audit

## What this does

Walks one fixed list of 24 hygiene checks against the rows you paste, in four blocks of six: STRUCTURE, NAMING, BUDGET, OVERLAP AND WASTE. Every check returns exactly one of PASS, FAIL, or CANNOT CHECK FROM PASTE, and every CANNOT CHECK names the column you would copy to make it readable.

This reads structure and waste. Whether a purchase was worth its cost belongs to a unit economics read, and to MER across the account rather than platform ROAS per ad set. One job per skill.

**The line only this skill produces:** the 24 point verdict table, the count line PASS n / FAIL n / CANNOT CHECK n of 24, the wasted spend total summed only from rows you pasted with the arithmetic printed, and a fix list in block order naming the exact campaign or ad set.

## Required input

1. **The window**, one date range, stated once, for example "Sep 1 to Sep 7". Every spend and purchase figure is read on that window.
2. **The campaign and ad set list**, copied off the Ads Manager screen, with whatever columns you have: campaign name, ad set name, status or delivery, daily or lifetime budget, amount spent, purchases, and the audience line if it shows. A pasted CSV block is fine. No API, no pixel, no connected account.
3. **Your spend floor**, one number: the minimum window spend an ad set has to reach before you are willing to read it.

## What it refuses

**Refusal 1, no floor of my own.** State no spend floor and B6 returns `CANNOT CHECK FROM PASTE` with `[NEEDS: the minimum window spend you want an ad set to reach before you read it]`. This skill never picks the floor for you.

**Refusal 2, a missing column is never inferred.** A blank Purchases cell is not zero purchases. A budget is not spend. A missing audience line is not broad targeting. Each returns `CANNOT CHECK FROM PASTE` plus `[NEEDS: <the column to copy>]`, never a plausible value.

**Refusal 3, no fix is ever priced.** Never an estimate of what a fix would save, never a budget number you did not supply, never a grade, never the words well structured.

## The 24 checks, fixed order

| ID | Check | PASS requires |
|---|---|---|
| S1 | Campaign has ad sets | No campaign row with no ad set under it |
| S2 | Ad set has a campaign | No ad set row without a campaign above it |
| S3 | One budget level per campaign | Campaign budget for all its ad sets, or ad set budgets for all |
| S4 | Status on every row | No blank Status or Delivery cell |
| S5 | Active campaign has an active ad set | True of every campaign marked active |
| S6 | No active ad set under a paused campaign | True of every campaign marked paused |
| N1 | Campaign name carries a funnel stage | A stage word: TOF, prospecting, MOF, retargeting, RT, BOF, retention |
| N2 | No scratch token in a campaign name | None of test, temp, untitled, draft, new, final, v2 |
| N3 | One separator convention | The same separator character in every campaign name |
| N4 | Ad set name states its audience | No bare number, no "adset n", no placeholder |
| N5 | No shared names | No two campaigns and no two ad sets carry the same name |
| N6 | No copy artefact in a name | No "Copy of", " - Copy", trailing ellipsis, duplicate suffix |
| B1 | Ad set budget printed where it belongs | Every active ad set off a campaign budget prints its own figure |
| B2 | Paused campaign holds no budget | No campaign budget and no ad set budgets under it |
| B3 | Daily commitment can be summed | Every campaign prints a budget at one level |
| B4 | No ad set holds most of the spend | largest ad set spend / total window spend is 0.50 or less |
| B5 | No campaign holds most of the spend | largest campaign spend / total window spend is 0.50 or less |
| B6 | Every active ad set cleared your floor | Window spend at or above the floor you stated |
| W1 | No duplicated audience | No two targeting lines resolve to the same audience, whatever the wording |
| W2 | Audience line on every ad set | A targeting line printed on every ad set row |
| W3 | Spend returned a purchase | Purchases of 1 or more on every active ad set with spend above zero |
| W4 | No spend inside a paused campaign | Every paused campaign shows zero window spend |
| W5 | Purchase count on every spending row | A number, a printed 0 included, in the Purchases cell |
| W6 | Prospecting exclusions visible | An Exclusions clause on each prospecting ad set |

Six per block, four blocks, 24 checks. W6 returns CANNOT CHECK whenever the audience column is the truncated Ads Manager summary, because a missing exclusion clause there is a display limit and not evidence of a missing exclusion.

## Method

**Step 1, state the population.** Count the campaign rows and the ad set rows, print both with the window and the floor, above any verdict.

**Step 2, sum the window spend.** Add the spend cells across every ad set row as one printed addition. That total is the denominator for B4, B5 and the waste share. If a spending row has no spend cell, the total is not computed and B4, B5 and the waste total return CANNOT CHECK with the missing rows named.

**Step 3, walk all 24 in ID order.** Each returns PASS, FAIL, or CANNOT CHECK FROM PASTE. A FAIL names every row that failed it. A CANNOT CHECK carries a `[NEEDS: …]` line. No check is skipped, merged, or reordered.

**Step 4, the two concentration divisions.** Print each in full: `largest ad set spend / total = <decimal> = <percent>`, then the same for the largest campaign. Rounding is half up, shares to a whole percent.

**Step 5, the wasted spend total.** One rule: wasted spend is the sum of window spend on ad set rows that returned zero purchases in the window. Each row enters once. A row with one or more purchases never enters, whatever else is wrong with it. Print the addition, then the share as a division. Spend that is wrong for a different reason, sitting inside a paused campaign for example, gets its own line and is not added again.

**Step 6, the count line.** `PASS n / FAIL n / CANNOT CHECK n of 24`. The three add to 24 or the walk is rerun.

**Step 7, the fix list.** Block order, S then N then B then W, one line per FAIL, each naming the exact string from the paste. No fix carries a saving, a projection, or a budget number you did not supply.

## Output format

```
Read: <n> campaign rows and <n> ad set rows, window <window>. Spend floor: $<floor>
Total window spend: $<a> + $<b> + ... = $<total>

## Verdict
| ID | Verdict | Rows named |
| S1 | PASS | |
| S6 | FAIL | "<ad set>", "<ad set>" |
| B6 | CANNOT CHECK FROM PASTE | [NEEDS: <column>] |
(all 24, in ID order)

PASS <n> / FAIL <n> / CANNOT CHECK <n> of 24

## Wasted spend
$<x> ("<ad set>") + $<y> ("<ad set>") = $<total>
share: <total> / <window total> = <decimal> = <percent>

## Fixes, in block order
- [<ID>] <fix naming the exact campaign or ad set>
```

## Worked case

This IS the fixture at `fixtures/halden-provisions-account.md`, re-run literally against the method above.

Read: 3 campaign rows and 9 ad set rows, window Sep 1 to Sep 7. Spend floor: $100.
Total window spend: $1,240 + $860 + $410 + $380 + $295 + $210 + $0 + $185 + $95 = $3,675

| ID | Verdict | Rows named |
|---|---|---|
| S1 | PASS | |
| S2 | PASS | |
| S3 | PASS | "TOF \| Prospecting \| Sep" carries all three; the other two use ad set budgets on all three |
| S4 | PASS | |
| S5 | PASS | |
| S6 | FAIL | "test_new_creative_SEPT" is paused, holds active "Broad 25-54" and "Winter Gifting - LAL 3%" |
| N1 | FAIL | "test_new_creative_SEPT" |
| N2 | FAIL | "test_new_creative_SEPT" carries test and new |
| N3 | FAIL | " \| ", none, and "_" across the three campaign names |
| N4 | FAIL | "adset 1" |
| N5 | FAIL | "Broad 25-54" names two ad sets, with different audience lines |
| N6 | PASS | |
| B1 | PASS | |
| B2 | FAIL | "test_new_creative_SEPT" paused, holding $50 + $50 + $50 = $150/day |
| B3 | PASS | daily commitment $400 + $140 + $150 = $690/day |
| B4 | PASS | 1,240 / 3,675 = 0.34 = 34%, at or under 0.50 |
| B5 | FAIL | "TOF \| Prospecting \| Sep" $1,240 + $860 + $410 = $2,510; 2,510 / 3,675 = 0.68 = 68% |
| B6 | FAIL | "Winter Gifting - LAL 3%" active, spent $95 against your $100 floor |
| W1 | FAIL | "RT 30d ATC" and "RT ATC 30 day", both in "Retargeting", same 30 day cart audience |
| W2 | PASS | |
| W3 | FAIL | "Email list - non purchasers" $210 / 0, "Broad 25-54" (test_new_creative_SEPT) $185 / 0 |
| W4 | FAIL | "test_new_creative_SEPT" carries $0 + $185 + $95 = $280 of window spend |
| W5 | PASS | |
| W6 | CANNOT CHECK FROM PASTE | [NEEDS: the Exclusions line from each prospecting ad set] |

PASS 11 / FAIL 12 / CANNOT CHECK 1 of 24

Wasted spend: $210 ("Email list - non purchasers") + $185 ("Broad 25-54", under "test_new_creative_SEPT") = $395. Share: 395 / 3,675 = 0.11 = 11%. The $185 row also sits inside the paused campaign and is not added twice. The $95 row returned 3 purchases, so it does not enter.

Fixes, in block order:
- [S6] Turn off "Broad 25-54" and "Winter Gifting - LAL 3%", or turn "test_new_creative_SEPT" back on.
- [N1, N2] Rename "test_new_creative_SEPT" to carry a funnel stage and drop test and new.
- [N3] Pick one separator, apply it to all three campaign names.
- [N4] Rename "adset 1" to its own audience line, US, 18-65+, broad.
- [N5] Rename one of the two "Broad 25-54" ad sets. They target different people.
- [B2] Zero the ad set budgets under paused "test_new_creative_SEPT" or reactivate it.
- [B5] Decide whether 68% of window spend in "TOF | Prospecting | Sep" is intended. No target share is supplied here.
- [B6] "Winter Gifting - LAL 3%" spent $95 against your $100 floor. Raise it to the floor or turn it off.
- [W1] Consolidate "RT 30d ATC" and "RT ATC 30 day", or exclude one from the other.
- [W3] "Email list - non purchasers" and "Broad 25-54" (test_new_creative_SEPT) hold the $395 above.
- [W4] $280 of window spend sits inside paused "test_new_creative_SEPT".
- [W6] Paste the Exclusions line for the three prospecting ad sets.

On fixture-b, `fixtures/thorn-and-meridian-names-only.md`, the paste carries campaign name, ad set name and delivery only, and states no floor. STRUCTURE returns five PASS with S3 CANNOT CHECK, `[NEEDS: the Budget column]`. NAMING returns N2 and N6 PASS, and FAIL on N1 ("sale_sept" has no stage token), N3 (" - " against "_"), N4 ("adset 3") and N5 ("US Broad 25-54" names two ad sets). All twelve BUDGET and OVERLAP AND WASTE checks return CANNOT CHECK FROM PASTE, carrying `[NEEDS: the Amount Spent and Purchases columns for Sep 1 to Sep 7, per ad set]`, `[NEEDS: the Budget column]`, `[NEEDS: the Audience column, per ad set]`, and on B6 also the floor NEEDS line. Count: PASS 7 / FAIL 4 / CANNOT CHECK 13 of 24. Wasted spend: not summable, `[NEEDS: the Amount Spent and Purchases columns]`.

## Hard guardrails

- Never invent a number or a fact the paste did not carry. Where a value is absent, print `[NEEDS: <what to supply>]`, never a plausible value.
- Never read a blank Purchases cell as zero, a budget as spend, or a missing audience line as broad targeting.
- Never estimate what a fix would save, in dollars, percent, or purchases.
- Never recommend a budget number, a spend floor, or a target concentration share the reader did not supply.
- Never predict a click rate, a cost per purchase, or a ROAS outcome.
- Never grade the account, never call it well structured, healthy, or clean.
- Never skip, merge, or reorder a check. All 24 print every run, the passes included.
- Never count a row into the wasted spend total twice, and never add a row with one or more purchases to it.
- No client or brand names from the RISE roster. Fixture brands are invented.
- No em dashes anywhere in the output. No exclamation marks.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize, AI-powered, cutting-edge, holistic.

<!-- self-check: fixture-a re-run by hand. 1240+860+410+380+295+210+0+185+95 = 3675. B4 1240/3675 = 0.3374 -> 34%. B5 2510/3675 = 0.6830 -> 68%. B3 400 + (60+45+35=140) + (50+50+50=150) = 690. Waste 210+185 = 395; 395/3675 = 0.1075 -> 11%; the 185 row not double counted against the 280 paused line, the 95 row excluded (3 purchases). Tally 11+12+1 = 24. Fixture-b tally 7+4+13 = 24. Fixed list counted in the checklist table: 6+6+6+6 = 24, matching the printed count. grep over all three files: em dashes 0, banned words 0 outside the banned list itself, exclamation marks 0 in output lines (the only "!" in the file is this HTML comment delimiter). -->
