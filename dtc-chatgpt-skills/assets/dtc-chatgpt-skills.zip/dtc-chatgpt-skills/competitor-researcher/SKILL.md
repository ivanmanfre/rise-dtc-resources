---
name: competitor-researcher
description: "Use when you can see a competitor's ad library listings and product page and want to know what they claim, what they hold, and where the space is open. Takes pasted ad listings and page text for 1 to 3 competitors plus your own product facts, and returns their claims word for word, their offer next to yours, the angles their longest running ads hold, and the angles nobody occupies. Triggers on \"what are my competitors claiming\", \"read these competitor ads\", \"competitor angle gap\", \"which angle is nobody running\", \"compare their offer to ours\"."
---

# RISE DTC ChatGPT Skills, 01 of 15: the competitor read

## What this does

Reads what you can see of 1 to 3 competitors, the ad library listings and the product page text, and sorts it into four things: every claim quoted as written, their offer next to yours field by field, which of eight fixed angles each ad occupies, and which angles and claim types nobody in the paste occupies.

It reads claims and positions, never performance. An ad library and a product page carry no spend, no revenue and no conversion rate, so this skill states none of those and never calls an ad good or bad. Where the library prints how long an ad has run, a long run counts as a held position: a fact about duration, silent on whether the ad works.

**The line only this skill produces:** the angles and claim types no pasted competitor occupies, plus the competitor claims your own facts cannot answer, each tagged with the fact that would answer it.

## Required input

1. **The date you read the library**, once. Run lengths count to this date.
2. **Ad library listings**, 1 to 3 competitors, up to 8 ads each: competitor, ad label, format, the copy exactly as it reads, the headline as shown, and the run length or first seen date if the library prints one.
3. **Each competitor's product page text**, as sentences: price and pack size, discount, bundle, guarantee, shipping, and the claim sentences on the page.
4. **Optional, your own brand's same facts**: price and pack size, discount, bundle, guarantee, shipping, and the claims you can stand behind.

All of it typed or pasted off your screen. No ad account, no API, no connected tool.

## What it refuses

**Refusal 1, nothing to read.** Zero ad listings and zero page text:

```
NOTHING PASTED TO READ
Ad listings: 0    Product page pastes: 0
No competitor text to quote, so no claim to table and no absence to report.
```

**Refusal 2, no run length, no hold.** A listing with no first seen date gets `[NEEDS: the first seen date this library shows]` as its status, is never counted HELD, and its angle reads occupied with the hold unreadable.

**Refusal 3, a quiet paste is not an absent offer.** A field your paste does not carry prints `[NEEDS: <field> for <competitor>, if the page carries one]`. Never "none", never "no guarantee": a sentence missing from a paste is no evidence about their page.

**Refusal 4, no quote, no row.** A claim summarised in your words ("they push hydration") gets `[NEEDS: the sentence as it appears]` and no row.

## The eight angles, fixed order

Also the tie-break order: a sentence matching two tests takes the lower number, and the losing angle stays unoccupied unless another ad occupies it.

| # | Angle | The test |
|---|---|---|
| 1 | MECHANISM | A component, dose, material or process inside this product. |
| 2 | SOCIAL PROOF | A review count, rating, quote, or what other buyers did. |
| 3 | PRICE/VALUE | A price, per unit cost, discount or bundle is the point of it. |
| 4 | IDENTITY | A person type, a job, a way of living the buyer joins. |
| 5 | US-VS-THEM | What a rival or category alternative does, where the paste also states what this product does. |
| 6 | URGENCY/OFFER | A deadline, date, countdown or stock level. |
| 7 | FOUNDER STORY | First person account of why the writer made the thing. |
| 8 | PROBLEM-AGITATE | The buyer's problem and its cost, no product fact in it. |

Eight angles. Angles go to ads only. A product page is a position, not an angle.

## The six claim types, fixed

| # | Claim type | The test |
|---|---|---|
| 1 | COMPOSITION | What is in it, a dose, a material, what is left out. |
| 2 | EFFECT | What it does, prevents or changes for the buyer. |
| 3 | COMMERCIAL TERMS | Price, per unit cost, discount, bundle, guarantee, shipping, deadline. |
| 4 | THIRD PARTY | What others did, said, rated or measured, a lab, a certification. |
| 5 | ORIGIN | Who made it, where, when or why. |
| 6 | AUDIENCE | Who it is for, as a person type or a job. |

Six types. A line matching none of them is not a claim: brand names, calls to action and empty slogans count as lines read and get no row.

## Method

**Rounding.** Divisions carried at full precision, rounded when printed, half up. Money to two decimals, shares to two decimals and a whole percent. Where the printed figure differs from the value behind it, print the unrounded quotient in brackets.

1. **Population.** Count ad listings, competitors, page pastes, own facts yes or no. Print the read date.
2. **Split every line.** Test each sentence against the six claim types. A match is a claim, the rest are lines read.
3. **Claims table.** One row per claim, quoted word for word, with competitor, where it appeared, and type. Print the claim count and the count of lines carrying no claim.
4. **Offer position.** Five fields per competitor and for you: price, discount, bundle, guarantee, shipping. With price and pack size, print the per unit division (`$45 / 30 = $1.50 a stick`). With a discount percent, print it applied (`$45 x 0.85 = $38.25`). Where a page states its own saving, reproduce it and say whether it lands. Missing field, Refusal 3.
5. **Angle per ad.** Read the copy sentence by sentence, then the headline. The first sentence that took a claim row decides the angle, on the tie-break order. Stop there. An ad whose lines all failed step 2 prints UNCLASSIFIABLE, never the nearest sounding angle.
6. **The hold rule.** Count days from the first seen date to your read date and print the subtraction. 60 or more: HELD. Under 60: RUNNING. None printed: Refusal 2. An angle is HELD when at least one ad on it is HELD.
7. **The gap list.** Angles no ad occupies. Angles occupied but held by nobody. Claim types no claim occupies. Then their claims your facts cannot answer, quoted with the source and tagged `[NEEDS: <the fact that would answer it>]`. With no own facts, that part prints only `[NEEDS: your price, pack size, discount, bundle, guarantee, shipping and claim list]`.
8. **Counts.** Angles occupied, held, unoccupied over 8. Claim types occupied over 6. Ads carrying a run length over total ads. Each as a division, a decimal and a percent.

## Output format

```
Read: <n> ad listings across <m> competitors, <p> product page pastes, own facts <supplied / not supplied>, library read <date>.

## Claims, word for word
| # | competitor | where | type | claim as written |
Claims: <n>.  Lines read carrying no claim: <n>.

## Offer position
| field | <competitor 1> | <competitor 2> | yours |
rows: price, discount, bundle, guarantee, shipping. Each cell a value or [NEEDS: …]

## Angles occupied
| ad | competitor | angle | run length | status |

## Gap list
### Angles nobody occupies
### Angles occupied, held by nobody
### Claim types nobody occupies
### Their claims your facts cannot answer
- "<claim>" (<competitor>, <where>)  [NEEDS: <fact that would answer it>]

## Counts
```

## Worked case

The fixture at `fixtures/saltcrest-and-fenwater-full-read.md`, re-run against the method and checked line by line.

Read: 7 ad listings across 2 competitors, 2 product page pastes, own facts supplied, library read 2026-09-05.

**Claims: 18.** Saltcrest 10 (5 in ads, 5 on the page), Fenwater 8 (3 in ads, 5 on the page). A3 carries two, its copy is two sentences. Lines read carrying no claim: 7, the seven ad headlines, none stating anything checkable.

| field | Saltcrest | Fenwater | Quarry Salt Co. (yours) |
|---|---|---|---|
| price | $45 / 30 = $1.50 a stick | $72 / 60 = $1.20, $30 / 20 = $1.50 | $39 / 30 = $1.30 a stick |
| discount | $45 x 0.85 = $38.25, / 30 = $1.28 (1.275 unrounded) | no percent stated | $39 x 0.90 = $35.10, / 30 = $1.17 |
| bundle | `[NEEDS: the bundle line, if the page has one]` | 60 pack, their $18 reproduces: 3 x $30 = $90, $90 - $72 = $18 | `[NEEDS: your bundle line, if you have one]` |
| guarantee | first box refunded, buyer keeps the sticks | `[NEEDS: the guarantee line, if the page has one]` | 30 day refund, unopened only |
| shipping | free over $60, 2 to 4 days | flat $5 every order | free over $50, else $6.95 |

| ad | angle | run length to 2026-09-05 | status |
|---|---|---|---|
| A1 Saltcrest | MECHANISM | from 2026-03-02 = 187 days | HELD |
| A2 Saltcrest | SOCIAL PROOF | from 2026-07-28 = 39 days | RUNNING |
| A3 Saltcrest | US-VS-THEM | from 2026-01-19 = 229 days | HELD |
| A4 Saltcrest | PRICE/VALUE | no date on the listing | `[NEEDS: the first seen date this library shows]` |
| B1 Fenwater | FOUNDER STORY | from 2026-05-11 = 117 days | HELD |
| B2 Fenwater | PRICE/VALUE | from 2026-08-14 = 22 days | RUNNING |
| B3 Fenwater | IDENTITY | from 2026-06-20 = 77 days | HELD |

Two tie-breaks decided a row. A4 says "20% off your first subscription order, this week only", which touches URGENCY/OFFER at 6, and PRICE/VALUE at 3 takes the sentence, so URGENCY/OFFER stays unoccupied. B3 touches PROBLEM-AGITATE at 8 with "who forget to drink water", and IDENTITY at 4 takes it.

**Gap list.** Angles nobody occupies: URGENCY/OFFER, PROBLEM-AGITATE. Angles occupied, held by nobody: SOCIAL PROOF (A2 at 39 days), PRICE/VALUE (B2 at 22 days, A4 unreadable). Claim types nobody occupies: EFFECT, since the 18 claims run composition 6, commercial terms 8, third party 2, origin 1, audience 1, and neither competitor states what the product does for the buyer.

Their claims your facts cannot answer:
- "1,000 mg sodium, 200 mg potassium, 60 mg magnesium per stick." (Saltcrest, page) `[NEEDS: your magnesium per stick, or a line saying there is none]`
- "Over 41,000 five star reviews from people who run in the heat." (Saltcrest, ad A2) `[NEEDS: your review count and average rating, off your review widget]`
- "No sugar, no citric acid, no artificial colors." (Saltcrest, page) `[NEEDS: whether your formula carries citric acid or added color]`
- "Third party tested for heavy metals, every batch." (Fenwater, page) `[NEEDS: your testing protocol, the lab, and how often you test]`

**Counts.** Angles occupied 6 / 8 = 0.75 = 75%. Held 4 / 8 = 0.50 = 50%. Unoccupied 2 / 8 = 0.25 = 25%. Claim types occupied 5 / 6 = 0.83 = 83%. Ads carrying a run length 6 / 7 = 0.86 = 86% (0.857142 unrounded).

**On fixture-b** (`fixtures/gullrock-ads-only.md`, three ads, no page, no dates, no own facts): three claims tabled, angles MECHANISM (G1), PRICE/VALUE (G2, over URGENCY/OFFER on the tie-break again), PROBLEM-AGITATE (G3). Every status is the Refusal 2 NEEDS, so held is 0 / 8 = 0.00 = 0% and no angle can be called open on duration. All five offer fields print the Refusal 3 NEEDS, and the last part of the gap list prints only the own-facts NEEDS line.

## Hard guardrails

- Never invent a number or a fact the paste did not carry. Print `[NEEDS: <what to supply>]` for every gap.
- Never state or estimate a competitor's spend, revenue, order volume, conversion rate or profit. None of it appears in an ad library or on a product page.
- Never rate a competitor's ad good, bad, strong or weak. Classify what it claims and which angle it runs, and stop.
- Never read a long run as proof an ad works. HELD is a duration reading.
- Never predict a click rate, a cost per purchase or a return on ad spend, theirs or yours.
- Never paraphrase a claim into the table, and never table a claim you did not paste word for word.
- Never treat a field missing from your paste as a field missing from their page.
- No client or brand names from the RISE DTC roster in any output.
- No em dashes. No exclamation marks.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize, AI-powered, cutting-edge, holistic.

<!-- self-check: fixture-a re-run by hand. Days to 2026-09-05 (day 248 of 365), from days 61, 209, 19, 131, 226, 171: 187, 39, 229, 117, 22, 77. Money: 45/30=1.50, 45x0.85=38.25, 38.25/30=1.275 printed 1.28, 39/30=1.30, 39x0.90=35.10, 35.10/30=1.17, 72/60=1.20, 30/20=1.50, 3x30=90, 90-72=18 matching the page. Claims 5+5+3+5=18, by type 6+8+2+1+1=18, non-claim headlines 7. Shares 6/8=0.75, 4/8=0.50, 2/8=0.25, 5/6=0.8333 printed 0.83, 6/7=0.857142 printed 0.86. Fixed lists counted in the file: 8 angle rows, 6 claim type rows, both counts stated. grep on all three files: em dashes 0, exclamation marks 0, banned words only in the guardrail line naming them. -->
