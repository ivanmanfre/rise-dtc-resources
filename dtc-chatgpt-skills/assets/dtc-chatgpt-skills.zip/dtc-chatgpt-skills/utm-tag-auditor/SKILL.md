---
name: utm-tag-auditor
description: "Use before you trust the source/medium breakdown in the account's ad platform report, to find the destination links that are quietly reporting as direct or unassigned traffic. Takes the destination URL of each live ad, copied from the Website URL or Final URL field, and returns a PASS or BREAK status per link naming the exact defect, with the corrected link printed. Triggers on \"why is so much of this account's traffic showing as direct\", \"check these UTM links\", \"are these ad links tagged right\", \"audit these destination URLs\", \"why isn't this campaign showing up in the report\", \"check this client's UTM tagging before the report goes out\"."
---

# RISE DTC ChatGPT Skills, 10 of 15: the UTM tag audit

## What this does

Reads the destination link behind every live ad pasted in and finds the ones
that will land in the report as direct or unassigned traffic instead of
under the campaign that paid for the click.

Out comes one file, `utm-audit.md`.

**The line only this unit produces:** per destination link, a PASS or BREAK
status naming the exact character, duplicate or missing parameter that breaks
it, with the corrected link printed.

This unit reads the link exactly as pasted. It does not open it, does not
check whether the page behind it exists, and does not judge whether the
campaign, source or medium values chosen are the right ones. It checks only
whether the link's own syntax will let those values survive into the report.

## Required input

1. **The destination URL of each live ad**, copied from the Website URL field
   on the ad in Ads Manager or the Final URL field in Google Ads. Up to 20
   links.
2. Optional: **the platform each link belongs to** (Meta, Google, TikTok,
   other), printed beside the link if supplied. Not needed to run the audit.

Never paste a shortened link (a bit.ly, a redirect domain, a QR-code target
page) in place of the destination URL. This unit reads the parameters on the
link as pasted, and a shortener hides them until someone follows it, which
this unit does not do.

## What it refuses

**Refusal 1, no invented value for an empty slot.** Refuses to guess the
intended source, medium or campaign value for a link whose parameters carry
none:

```
BREAK: MISSING PARAMETER
link: <link as pasted>
missing: utm_source | utm_medium (name whichever is absent or present-but-empty)
corrected link: <link with the empty slot printed as
  [NEEDS: the value you want this link to report as]>
```

**Refusal 2, no pick between two conflicting values.** Refuses to choose which
of two duplicated parameter values survives:

```
BREAK: DUPLICATE PARAMETER
link: <link as pasted>
parameter: utm_<x>   appears twice: "<value 1>" and "<value 2>"
corrected link: cannot be finished until you choose.
  [NEEDS: which value utm_<x> should carry, "<value 1>" or "<value 2>"]
```

**Refusal 3, no audit of a link that hides its own parameters.** Refuses to
treat a shortened or redirect link as auditable:

```
CANNOT AUDIT: SHORTENED LINK
link: <link as pasted>
This is a shortener or redirect domain, not the destination URL. Paste the
destination URL from the Website URL / Final URL field on the ad instead.
```

## Method

**Step 1, sort out the shortened links first.** Any link whose domain is a
known shortener or redirect service (bit.ly, tinyurl, t.co, lnkd.in, rebrand.ly,
or any domain that is not the brand's own storefront domain) fires Refusal 3
and is routed out before the rest of the method runs.

**Step 2, split base URL from query string.** The query string is everything
from the first `?` onward. A link with no `?` anywhere has no query string at
all, which is itself a defect, handled in Step 3.

**Step 3, check for CHARACTER defects.** Four shapes, and a link can carry
more than one:

- **missing query separator**: parameters are appended straight onto the path
  with no `?` (for example `.../dark-roast&utm_source=meta`), so none of what
  follows is read as a parameter by anything.
- **a second `?`**: a later `?` appears inside what should already be the
  query string.
- **a raw space** inside a parameter value.
- **a raw `&`, `#` or `?`** inside a parameter value, not percent-encoded,
  which breaks where the platform thinks one parameter ends and the next
  begins.

How to spot the raw `&` mechanically, without reading the value for sense:
split the query string on `&` and look at each segment. A segment that carries
no `=` is not a parameter, it is the tail of the value before it, and the `&`
in front of it is a raw `&` inside that value. In
`utm_campaign=oat&honey_launch` the segment `honey_launch` carries no `=`, so
the value is `oat&honey_launch` and the `&` is the defect.

Every character defect has a mechanical fix, and each fix is stated here in
full so that a literal run of the fix and the corrected link printed in the
output are the same string:

- **missing query separator**: insert `?` before the first parameter. Where the
  parameters were appended with a leading `&`, which is the commonest shape of
  this defect, that `&` is what the `?` replaces. It is not left sitting
  after the `?`. The corrected link carries exactly one separator between the
  path and the first parameter.
- **a second `?`**: replace it with `&`. Deleting it outright would run the
  value before it into the key after it, so the fix is a swap, not a deletion.
- **a raw space**: percent-encode it as `%20`.
- **a raw `&`, `#` or `?` inside a value**: percent-encode it (`%26`, `%23`,
  `%3F`).

None of these fixes require inventing a value, because the value is already
present in the string; only its punctuation is wrong. Print the fix.

**Step 4, check for DUPLICATE defects.** The same parameter key appears two or
more times in the query string.

- If every instance carries the **identical** value, this is not a defect.
  Print a `NOTE` line and leave the status untouched, because nothing about
  what gets reported changes.
- If the values **differ**, Refusal 2 fires for that parameter.

**Step 5, check for MISSING defects.** After Step 3's character fixes are
applied on paper, check whether `utm_source` and `utm_medium` are each present
with a non-empty value. `utm_campaign` is not checked here; a link missing
only `utm_campaign` still attributes to a source and medium, it just does not
group by campaign, which is a naming question this unit does not judge. A
missing or empty `utm_source` or `utm_medium` fires Refusal 1, once per
missing key.

Where Refusal 1 fires, the corrected link reinserts the missing parameter in
the canonical order `utm_source, utm_medium, utm_campaign, utm_content,
utm_term`. Every parameter already present in the link keeps its own relative
order; the newly reinserted parameter takes the slot in that canonical
sequence that falls between whichever present parameters bracket it there, or
at the front or back of the query string if nothing brackets it on that side.

**Step 6, one link can carry several defects.** A link is not stopped at its
first defect. Every applicable defect block from Steps 3 through 5 prints for
that link, and the link's overall status is `BREAK` if any block fired, `PASS`
if none did. Where a corrected link cannot be completed because one or more
`[NEEDS: ...]` tokens remain unanswered, print it with the tokens inline
rather than omitting the corrected-link line.

The defect blocks print in the order the checks ran: every CHARACTER block
first, then every DUPLICATE block, then every MISSING block. That is Step 3,
then Step 4, then Step 5, and it is the same order the Output format lists the
three block types in. A link carrying three defects prints them in that order
every time, so two literal runs of the same link produce the same file.

**Step 7, the counts.** State the population once, in words, above the
division: *every destination link pasted in that reached this step (the
CANNOT AUDIT links from Step 1 are routed out and printed separately, with
their own count, never folded into PASS or BREAK)*.

```
PASS:  <n> / <n>
BREAK: <n> / <n>
routed out (CANNOT AUDIT): <n>
```

Print `BREAK: 0 / <n>` when there are none. The row is never omitted for being
empty. The routed-out line is a bare count, not a share, because those links
are not in the population the two shares are counted over. It prints as `0`
when no link was routed out, and it is never omitted either.

## Output format

Write one file, `utm-audit.md`.

```
# UTM audit
Links read: <n>          Routed out as CANNOT AUDIT: <n>

## Per link
### Link <k>
platform: <given> | not given
pasted: <link>
status: PASS | BREAK

defects:
  - CHARACTER: <which shape>          fix: <mechanical correction>
  - DUPLICATE: <parameter>, "<value 1>" vs "<value 2>"
      [NEEDS: which value utm_<x> should carry, "<value 1>" or "<value 2>"]
  - MISSING: <utm_source | utm_medium>
      [NEEDS: the value you want this link to report as]
  (only the blocks that applied to this link print; PASS links print none.
   The blocks print in this order: CHARACTER, then DUPLICATE, then MISSING)

corrected link: <link, with any unresolved slot printed as its [NEEDS: ...] token>
  (this line prints only when status is BREAK. A PASS link's block ends at
  the defects line; there is nothing to correct, so no corrected link line
  prints at all)

## Routed out
### Link <k>
pasted: <link>
CANNOT AUDIT: SHORTENED LINK

## Counts
population: every destination link pasted in that reached the audit step
  (shortened links above are routed out and counted separately)
PASS:  <n> / <n>
BREAK: <n> / <n>
routed out (CANNOT AUDIT): <n>
```

## Edge cases

**A parameter value looks like a placeholder** (`utm_source=yoursourcehere`,
`utm_campaign=CAMPAIGN_NAME`). The slot is populated, so this is not a MISSING
defect. Print a `NOTE` line quoting the value verbatim. Judging whether a
present value is a real one is a semantic call this unit does not make; it
checks whether the slot is filled, not whether the fill is meaningful.

**A link has no query string and no parameters at all** (a bare URL). Both
`utm_source` and `utm_medium` are absent, so Step 5 fires Refusal 1 twice, once
per key, on the same link.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a source, medium or campaign value for a missing parameter.
- Never choose between two conflicting values in a duplicated parameter.
- Never open, follow, resolve or shorten a link. Everything here is read from
  the pasted text only.
- Never judge whether the page behind the link converts, loads or matches the
  ad. This unit checks syntax, nothing else.
- Never fold the CANNOT AUDIT links into the PASS or BREAK counts.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-fenwick-and-oar.md` run literally, line
by line, under the rules above. It is not a separate example.**

Nine links pasted for a brand called Fenwick & Oar.

```
Link 1: https://fenwickandoar.com/products/dark-roast?utm_source=meta&utm_medium=paid_social&utm_campaign=prospecting_broad
status: PASS
(no defects: query string present, utm_source and utm_medium both present and
non-empty, no duplicates, no raw characters)

Link 2: https://fenwickandoar.com/products/dark-roast&utm_source=meta&utm_medium=paid_social
status: BREAK
  - CHARACTER: missing query separator (no ? anywhere in the link, so
    "&utm_source=meta&utm_medium=paid_social" is read as part of the path)
    fix: insert ? before the first parameter, replacing the leading & it was
    appended with, so the path and the first parameter carry one separator
corrected link: https://fenwickandoar.com/products/dark-roast?utm_source=meta&utm_medium=paid_social

Link 3: https://fenwickandoar.com/products/subscription?utm_source=meta&utm_medium=paid_social&utm_source=facebook
status: BREAK
  - DUPLICATE: utm_source, "meta" vs "facebook"
    [NEEDS: which value utm_source should carry, "meta" or "facebook"]
corrected link: cannot be finished until the NEEDS above is answered.
  https://fenwickandoar.com/products/subscription?utm_source=[NEEDS: which value utm_source should carry, "meta" or "facebook"]&utm_medium=paid_social

Link 4: https://fenwickandoar.com/pages/gift-set?utm_source=google&utm_campaign=holiday
status: BREAK
  - MISSING: utm_medium
    [NEEDS: the value you want this link to report as]
corrected link: https://fenwickandoar.com/pages/gift-set?utm_source=google&utm_medium=[NEEDS: the value you want this link to report as]&utm_campaign=holiday
(utm_medium is the reinserted parameter; canonical order is utm_source, then
utm_medium, then utm_campaign, and the two present parameters, utm_source and
utm_campaign, bracket the slot utm_medium takes, so it lands between them)

Link 5: https://fenwickandoar.com/products/dark-roast?utm_source=meta&utm_medium=paid social&utm_campaign=prospecting
status: BREAK
  - CHARACTER: raw space inside a parameter value ("paid social")
    fix: percent-encode as paid%20social
corrected link: https://fenwickandoar.com/products/dark-roast?utm_source=meta&utm_medium=paid%20social&utm_campaign=prospecting

Link 6: https://fenwickandoar.com/products/sampler?utm_source=meta&utm_source=tiktok&utm_campaign=cross promo
status: BREAK
  - CHARACTER: raw space inside a parameter value ("cross promo")
    fix: percent-encode as cross%20promo
  - DUPLICATE: utm_source, "meta" vs "tiktok"
    [NEEDS: which value utm_source should carry, "meta" or "tiktok"]
  - MISSING: utm_medium
    [NEEDS: the value you want this link to report as]
corrected link: cannot be finished until the NEEDS above are answered.
  https://fenwickandoar.com/products/sampler?utm_source=[NEEDS: which value utm_source should carry, "meta" or "tiktok"]&utm_medium=[NEEDS: the value you want this link to report as]&utm_campaign=cross%20promo
(utm_medium is reinserted between utm_source and utm_campaign for the same
canonical-order reason as Link 4)

Link 7: https://fenwickandoar.com/products/cold-brew?variant=41822?utm_source=meta&utm_medium=paid_social
status: BREAK
  - CHARACTER: a second ? inside the query string (before utm_source)
    fix: replace the second ? with &
corrected link: https://fenwickandoar.com/products/cold-brew?variant=41822&utm_source=meta&utm_medium=paid_social

Link 8: https://fenwickandoar.com/collections/beans?utm_source=google&utm_medium=cpc&utm_campaign=oat&honey_launch
status: BREAK
  - CHARACTER: raw & inside a parameter value. Splitting the query string on &
    gives utm_source=google, utm_medium=cpc, utm_campaign=oat and
    honey_launch. The last segment carries no =, so it is the tail of
    utm_campaign's value and the & in front of it is raw
    fix: percent-encode as oat%26honey_launch
corrected link: https://fenwickandoar.com/collections/beans?utm_source=google&utm_medium=cpc&utm_campaign=oat%26honey_launch

Link 9: https://bit.ly/3xF9k2Q
Routed out: CANNOT AUDIT, SHORTENED LINK
```

Link 6 prints its three blocks CHARACTER, DUPLICATE, MISSING, which is Step 3
then Step 4 then Step 5, the order Step 6 fixes.

```
Counts
population: every destination link pasted in that reached the audit step
  (link 9 is routed out as CANNOT AUDIT and counted separately) = 8
PASS:  1 / 8
BREAK: 7 / 8
routed out (CANNOT AUDIT): 1
```

<!-- ported from 01-existing/the-dtc-growth-team/track/track-01-utm-tag-auditor, 2026-09-06; fixes applied: (1) Output format now states the corrected-link line prints only on BREAK, matching the worked case's PASS link which already omitted it; (2) Method Step 5 now states the canonical reinsertion order (utm_source, utm_medium, utm_campaign, utm_content, utm_term) for a newly reinserted missing parameter, with present parameters keeping relative order; worked case Links 4 and 6 already matched this order and needed no change, so an explanatory line was added to each instead -->
