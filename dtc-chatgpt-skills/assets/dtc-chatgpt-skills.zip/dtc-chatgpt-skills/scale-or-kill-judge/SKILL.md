---
name: scale-or-kill-judge
description: "Use when you are running an account and need a verdict on each live ad this week, ad by ad rather than on the account as a whole. Takes the per-ad spend and purchase rows you can read off Ads Manager for one window and returns SCALE, HOLD, CUT or NOT ENOUGH SPEND for every ad, never a guess where the row is too thin to read. Triggers on \"should I scale or kill this ad\", \"which ads do I turn off this week\", \"read my ad account and tell me what to do with each ad\", \"is this ad actually working\", \"rank my live ads\", \"what do I do with each ad on this client's account this week\"."
---

# RISE DTC ChatGPT Skills, 15 of 15: the scale-or-kill judge

## What this does

Reads the per-ad rows for one window you name and gives every live ad in the
paste exactly one verdict: SCALE, HOLD, CUT, or NOT ENOUGH SPEND.

**The line only this unit produces:** per ad, one of SCALE, HOLD, CUT or NOT
ENOUGH SPEND, with the additional spend the undecided ones need before they can
be read, priced at that ad's own cost per purchase.

The cost per purchase you can afford is an input to this skill and never an
output of it: where nobody has set that number for the brand yet, the break-even
and affordable CPA skill in this kit works it out from contribution margin, and
you bring its figure back here.

This is a reading of the rows you already have, on the window you name. It is
not a media-buying strategy and it does not tell you what to build next. No ad
in the paste is skipped because the row looks too thin to bother with. A thin
row gets NOT ENOUGH SPEND, which is a verdict, not a shrug.

## Required input

1. **The window**, one date range, stated once (for example "Aug 21 to Aug 27").
   Every row in the paste is read on this same window.
2. **Per-ad rows**, one row per live ad, for that window: ad name, spend,
   purchases, cost per purchase if the platform prints it (this unit recomputes
   it either way, shown as a division).
3. **The cost per purchase you can afford**, one number, stated once, that holds
   for every ad in this pass.

## What it refuses

**Refusal 1, nothing to judge.** If the paste carries zero ad rows, stop:

```
NO AD ROWS SUPPLIED
Nothing pasted for the window "<window>" carries a spend and purchase figure.
There is nothing here to give a verdict to.
```

**Refusal 2, never rules below the read minimum.** Below 10 purchases in the
stated window, cost per purchase moves too much per additional sale to tell CUT
from SCALE apart. This unit never guesses across that line:

```
NOT ENOUGH SPEND
ad: "<ad name>"
purchases this window: <n>          minimum to read: 10
this ad's own cost per purchase so far: $<spend> / <purchases> = $<per purchase>
additional spend needed: (10 - <purchases>) more purchases x $<per purchase> = $<amount>

This ad has not run long enough at this spend to tell CUT from SCALE apart.
More window will not fix this. More spend will.
```

The `$<per purchase>` on the additional-spend line is the same figure printed
one line above, and under the rounding convention below it is multiplied at full
precision, not at the two decimals it printed at. $310 over 7 purchases prints
as $44.29 and multiplies as 44.285714..., so three more purchases come to
$132.86 and not $132.87. Where the two differ, print the full-precision result
and print the quotient the line used in brackets after it, so the reader can
reproduce the cent:
`additional spend needed: (10 - 7) more purchases x $44.29 = $132.86
(multiplied at 44.285714..., the unrounded quotient of 310 / 7)`.

If purchases = 0, the per-purchase figure cannot be shown (nothing to divide
by). Print `$<spend> / 0 purchases = no cost per purchase yet` and the
additional-spend line as `[NEEDS: at least 1 purchase before a per-purchase
cost exists to price the remaining need against]`.

## Method

**The rounding convention, one convention, used everywhere in this unit.** Every
division is carried at full precision and rounded only at the moment it is
printed. A printed, rounded figure is never fed back into a later division or a
later multiplication. The later step uses the unrounded value, so a printed line
and the value behind it can differ in the last cent and the file is still
correct. Rounding is half-up. Money prints to two decimals, shares to two
decimals and a whole percent. Where a printed figure is reused in a later line,
that line names which value it used, so two literal runs land on the same cent.

**Step 1, read every row, flag the incomplete ones.** A row needs ad name,
spend and purchases to be judged at all. A row missing any of those three
prints in its own place in the output as:

```
[NEEDS: <the missing field>] for "<ad name or "unnamed row">"
```

and is excluded from every count and division below it.

**Step 2, population.** State it once, in words, above every count in this
unit: *every ad row you pasted for the window you named, counted once, minus
any row routed to `[NEEDS:]` in Step 1.*

**Step 3, the read gate.** For each remaining row: purchases < 10 routes
straight to NOT ENOUGH SPEND (Refusal 2). This never divides spend by a
purchase count below the minimum to produce a verdict; it only divides to show
the reader their own current per-purchase cost, printed as informational, not
as the basis for a verdict.

**Step 4, cost per purchase.** For every row with purchases >= 10:

```
cost per purchase = spend / purchases = $<spend> / <purchases> = $<per purchase>
```

**Step 5, the three read bands.** Let A = the cost per purchase you can afford.
Compare each ad's cost per purchase against it:

| Band | Rule | Verdict |
|---|---|---|
| Clearly under | cost per purchase <= 0.85 x A | SCALE |
| At the edge | 0.85 x A < cost per purchase <= A | HOLD |
| Over | cost per purchase > A | CUT |

Print the comparison in full: `$<per purchase> vs afford $<A>, 0.85x afford =
$<0.85A>`.

**Step 6, print all four classes, always.** SCALE, HOLD, CUT and NOT ENOUGH
SPEND each get their own header in the output even when a class has zero ads
in it. An empty class prints `(none this window)`, never a missing section.

**Step 7, the class counts.** Over the population stated in Step 2:

```
SCALE:            <n> / <total> = <decimal> = <percent>
HOLD:             <n> / <total> = <decimal> = <percent>
CUT:              <n> / <total> = <decimal> = <percent>
NOT ENOUGH SPEND:  <n> / <total> = <decimal> = <percent>
```

If `<total>` is 0 after Step 1 exclusions, Refusal 1 has already fired and this
step does not run.

## Output format

```
# Scale or kill, window: <window>
Cost per purchase you can afford: $<A>
Population: <the Step 2 sentence, filled in>

## SCALE
- "<ad name>"   $<per purchase> (<n> purchases, $<spend> spend)
(none this window)

## HOLD
- "<ad name>"   $<per purchase> (<n> purchases, $<spend> spend)

## CUT
- "<ad name>"   $<per purchase> (<n> purchases, $<spend> spend)

## NOT ENOUGH SPEND
<the Refusal 2 block per ad>

## Rows excluded, incomplete
[NEEDS: <field>] for "<ad name>"

## Counts
<the Step 7 divisions>
```

## Worked case

This worked case is the literal fixture run in
`fixtures/fen-and-rowe-week.md`, verified line by line against the rules
above.

Window: Aug 21 to Aug 27. Afford: $30.00. 0.85 x afford = $25.50.

- "Prospecting - UGC Hook A": spend $2,400, purchases 62 (>=10).
  cost per purchase = $2,400 / 62 = $38.71. $38.71 > $30.00 -> **CUT**.
- "Retargeting - Static B": spend $540, purchases 24 (>=10).
  cost per purchase = $540 / 24 = $22.50. $22.50 <= $25.50 -> **SCALE**.
- "Lookalike - Video C": spend $310, purchases 7 (<10) -> **NOT ENOUGH SPEND**.
  cost per purchase so far = $310 / 7 = $44.29.
  additional spend needed = (10 - 7) x $44.29 = $132.86
  (multiplied at 44.285714..., the unrounded quotient of 310 / 7, per the
  rounding convention. Multiplying the printed $44.29 instead would give
  $132.87, which is why the convention names which value the line uses.)
- "Interest - Wellness D": spend $870, purchases 30 (>=10).
  cost per purchase = $870 / 30 = $29.00. $25.50 < $29.00 <= $30.00 -> **HOLD**.

Counts, population = 4 ad rows pasted, 0 excluded, total = 4:
SCALE: 1 / 4 = 0.25 = 25%
HOLD: 1 / 4 = 0.25 = 25%
CUT: 1 / 4 = 0.25 = 25%
NOT ENOUGH SPEND: 1 / 4 = 0.25 = 25%

All four classes populated in this fixture; a second fixture,
`fixtures/fen-and-rowe-missing-field.md`, exercises the `[NEEDS:]` exclusion
path on a row missing its purchase count.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a number, an ad name, a date or a claim the input did not carry.
- Never rule SCALE, HOLD or CUT on a row below 10 purchases. Refusal 2 fires
  instead, every time, no exceptions for anyone who wants a faster answer.
- Never fold NOT ENOUGH SPEND into CUT or HOLD. It is its own verdict because
  the honest answer is that no verdict is readable yet.
- Never divide spend by zero purchases to produce a verdict-bearing number.
- Never state a benchmark cost per purchase that the reader did not supply as
  their own affordable figure.
- No em dashes. No exclamation marks.
- Audience word is DTC, never "ecom". Brand referenced only as RISE DTC where a
  brand name is needed at all.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `we don't X we Y`, `stop X start Y`, `less X more
  Y`). No "Most [group]" claims. No time-to-value claim, no price anchor, no
  effort claim.

<!-- ported from 01-existing/the-dtc-growth-team/decide/decide-01-scale-or-kill-judge, 2026-09-06; fixes applied: none (blind run passed with zero defects); framing only, plus one sentence in What this does naming where the affordable cost per purchase comes from -->
