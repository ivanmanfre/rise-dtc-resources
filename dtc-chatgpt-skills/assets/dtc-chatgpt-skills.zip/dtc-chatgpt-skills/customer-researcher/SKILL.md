---
name: customer-researcher
description: "Use when raw customer text sits in a review widget, a post purchase survey, a returns portal or an ad comment thread and you need your customers' own words before anyone writes copy. Takes 15 or more pasted items and returns the customer language bank: benefits, objections, before and after states, ten ad ready phrases, and the one thing customers name that your product page does not say, each counted and quoted verbatim. Triggers on \"pull the language out of my reviews\", \"what do my customers actually say\", \"voice of customer from these reviews\", \"why do people almost not buy\", \"what does my product page miss\"."
---

# RISE DTC ChatGPT Skills, 02 of 15: the customer language bank

## What this does

Reads the customer text you paste, item by item, and counts which words come
back. A phrase eleven people used and a phrase one person used look identical in
a doc. Counted, they stop looking identical, and you can see which line deserves
spend behind it.

It writes nothing new. Every line it returns is a span a customer typed, kept as
typed, tagged with its item number so you can go read the whole review.

**The line only this skill produces:** each benefit and each objection your
customers name, ranked by how many pasted items carried it, one verbatim quote
each, plus the highest ranked thing they name that your product page never says.

## Required input

1. **The items.** Raw customer text, pasted: reviews off any widget, post
   purchase survey answers, support tickets, return reasons off the returns
   portal, comments under an ad. Mixed sources read as one pile. Minimum 15.
2. **What each source is.** One line naming which block is reviews, which is
   returns, which is survey answers, so the read line can print the mix.
3. **Your product page text**, pasted, if you want block 5. Body, headline,
   bullets, FAQ. Optional: without it, blocks 1 to 4 still run.

Nothing here is connected. No widget login, no export, no API. If you can select
it on screen and paste it, this reads it.

## What it refuses

**Refusal 1, under the minimum.** Below 15 items, a count of 2 and a count of 1
are noise, and ranking noise reports it as a finding. The run stops:

```
NOT ENOUGH VOICE OF CUSTOMER
items pasted: <n>          minimum to rank: 15
more items needed: 15 - <n> = <n>
Paste more items, from any source. No block below this line runs.
```

**Refusal 2, no page pasted.** Block 5 compares customer words to page words.
With no page in the paste it prints `[NEEDS: your product page text, pasted]`
and never guesses what your page says.

**Refusal 3, a benefit nobody named.** Tell it customers love your shipping and
no item says so, it prints `NOT NAMED IN THE ITEMS: <the claim>`, no count, no
rank. It never quotes a customer for a thing that customer did not write.

## Method

**The five blocks, fixed order.** All five run on a full pass. Five, and this
table is the whole list:

| # | Block | Reads | Needs |
|---|---|---|---|
| 1 | Benefits in their words | every item | 15 items |
| 2 | Objections and hesitations | every item | 15 items |
| 3 | Before state and after state | every item | 15 items |
| 4 | Ten phrases for an ad | blocks 1 and 3 | 15 items |
| 5 | What the page does not say | block 1 and the page | the pasted page |

Divisions are carried at full precision and rounded when printed, half up.
Shares print to two decimals and a whole percent.

**Step 1, number and count.** Number items in paste order from 1. Print the mix
as a sum: `18 reviews + 4 return reasons = 22 items`. Under 15, Refusal 1 fires.

**Step 2, tally benefits.** An item counts toward a benefit only if it names
that benefit in words. No inference. "It blocks all the light" counts toward
blackout. "I sleep better" counts toward nothing, because better is not named as
anything. One item counts once per benefit however often it repeats it, and can
count toward several. Print every share as `<items> / <total> = <d> = <p>%`.

**Step 3, tally objections.** Same rule, applied to anything an item names as a
doubt, a reason they almost did not buy, almost returned it, or did return it. A
return reason is an item like any other, in the same denominator. An objection
is never subtracted from a benefit count. Both stand.

**Step 4, before and after.** Copy verbatim the phrase saying what life looked
like before and the phrase saying what changed, with item numbers. Mark items
carrying both as a pair. Never pair a before phrase from one item with an after
phrase from another. That is two customers made into one person who never
existed.

**Step 5, rank.** By item count, highest first. Ties break in order: (a) the
phrase naming a body part, a time, a number or a named situation beats the
general phrase; (b) the lower earliest item number goes first; (c) if one item
carries both, the one appearing earlier inside it goes first. Print `tie` on
every tied row. Benefits named by one item print under `Named once`.

**Step 6, the ten ad phrases.** Walk the ranked benefits top down, one phrase
per entry, from the earliest item that carried it. If that item already gave a
phrase, take the next item carrying the entry; if none, skip the entry. When the
list runs out before ten, fill from the before and after phrases in item order,
skipping used items. No two of the ten come from one item. A phrase may be a
shorter span cut out of the item: contiguous, no word changed, no two spans
joined, nothing tidied, typos kept. Cap each at 14 words as written.

**Step 7, the page gap.** Walk the ranked benefits from the top. For each,
search the pasted page for that thing in any wording, theirs or the page's. The
first with no matching line is the answer. Print it with its count, its quote,
and the closest page line, or state that none comes close.

## Output format

```
Read: <n> reviews + <n> survey answers + <n> return reasons = <n> items. Product page: pasted / not pasted.

## 1. Benefits, in their words
| rank | what they name | items | share | one verbatim quote |
| 1 | <label> | <n> | <n>/<t> = <d> = <p>% | "<quote>" (<item>) |
Named once: <label> (<item>)
Read but not counted: "<phrase>" (<item>), because <what it does not name>

## 2. Objections and hesitations
| rank | what they name | items | share | one verbatim quote |

## 3. Before and after, verbatim
<item> before "<phrase>" | after "<phrase>"
Same customer, both states: items <n>, <n>

## 4. Ten phrases for an ad
1. "<phrase>" (<item>, <label>)

## 5. What they name that your page does not say
<label>, <n> of <t> items (<p>%): "<quote>" (<item>)
Closest line on your page: "<page line>", or: no line on your page comes close.
```

## Worked case

The fixture at `fixtures/halden-rest-voice-of-customer.md`, re-run literally
against the method above and checked line by line.

Read: 18 reviews + 4 return reasons = 22 items. Product page: pasted.

**Block 1.** 17 items name a benefit. Item 12 and items 19 to 22 name none.

| rank | what they name | items | share | quote |
|---|---|---|---|---|
| 1 | Blocks all the light | 6 | 6/22 = 0.27 = 27% | "No light gets in at the nose" (1) |
| 2 | The weight feels calming | 4 | 4/22 = 0.18 = 18% | "feels like a hand resting there" (4) |
| 3 | No pressure on the eyes | 3 | 3/22 = 0.14 = 14% | "It doesnt press on my eyes" (2) |
| 4 tie | Falls asleep faster | 2 | 2/22 = 0.09 = 9% | "Asleep in maybe fifteen minutes" (8) |
| 5 tie | Works for side sleepers | 2 | 2/22 = 0.09 = 9% | "I'm a side sleeper" (3) |
| 6 tie | Stays on all night | 2 | 2/22 = 0.09 = 9% | "still on my face every morning" (15) |
| 7 tie | Helps a headache | 2 | 2/22 = 0.09 = 9% | "the weight over my eyes helps" (6) |
| 8 tie | Works on a plane or in a hotel | 2 | 2/22 = 0.09 = 9% | "First flight I have ever slept on" (7) |

Ranks 4 to 8 all hold 2 items and each phrase names a number, a time, a body
part or a situation, so test (a) separates none and test (b) orders by earliest
item: 1, 3, 3, 6, 7. Ranks 5 and 6 both start in item 3, so test (c) orders them
by position inside item 3, where "I'm a side sleeper" comes before "still on my
face". Named once: strap fits a large head (9), has not stretched out in four
months (15). Read but not counted: "I keep it in my bag now" (6), no flight,
hotel or trip named; "we ordered a second one" (11), a second purchase names no
benefit.

**Block 2.** 9 items carry an objection.

| rank | what they name | items | share | quote |
|---|---|---|---|---|
| 1 | Strap or size did not fit | 3 | 3/22 = 0.14 = 14% | "Strap too tight, left a red mark" (20) |
| 2 | The weight would be too much | 2 | 2/22 = 0.09 = 9% | "Was worried the weight would feel like too much" (4) |
| 3 tie | The price | 1 | 1/22 = 0.05 = 5% | "$58 for a sleep mask felt insane" (2) |
| 4 tie | It ran warm | 1 | 1/22 = 0.05 = 5% | "Almost returned it the first week because it felt too warm" (12) |
| 5 tie | Would not keep using it | 1 | 1/22 = 0.05 = 5% | "Didn't think I'd use it after the first week" (15) |
| 6 tie | It smelled | 1 | 1/22 = 0.05 = 5% | "Smelled like chemicals out of the box" (21) |

3 + 2 + 1 + 1 + 1 + 1 = 9, matching the 9 items. Ranks 3 to 6 tie at 1 and order
by earliest item: 2, 12, 15, 21.

**Block 3.** 7 before phrases, 7 after phrases.

```
1  before "laying there for an hour" | after "I fall asleep in about ten minutes now"
3  before "every other mask ends up around my neck by 3am" | after "still on my face in the morning"
4  before "used to be up at 5 with the sun" | after "Sleep straight through now"
18 before "hotel rooms where the curtains never close all the way" | after "Havent had a bad nights sleep on the road since"
5  before "My husband reads until midnight with the lamp on"
8  before "it used to be an hour of scrolling"
13 before "sun coming through cheap blinds"
7  after "First flight I have ever actually slept on"
12 after "now I cant sleep without it"
14 after "my brain goes quiet"
```

Same customer, both states: items 1, 3, 4, 18. Those four are the only pairs you
can run as a before and after without inventing a person.

**Block 4.** Entry 4 skips item 1, used by entry 1, and takes item 8. Entry 6
skips item 3, used by entry 5, and takes item 15. The second named once entry
sits only in item 15, already used, so it is skipped, and the fill is the first
before or after phrase on an unused item, item 5.

1. "No light gets in at the nose" (1)
2. "it just feels like a hand resting there" (4)
3. "It doesnt press on my eyes" (2)
4. "Asleep in maybe fifteen minutes most nights" (8)
5. "every other mask ends up around my neck by 3am" (3)
6. "still on my face every morning" (15)
7. "the weight over my eyes helps more than the dark does" (6)
8. "First flight I have ever actually slept on" (7)
9. "the velcro goes way further than I thought" (9)
10. "My husband reads until midnight with the lamp on" (5)

Ten phrases, ten different items: 1, 4, 2, 8, 3, 15, 6, 7, 9, 5. Longest is 11
words, inside the 14 word cap.

**Block 5.** Rank 1, blocks the light: the page says "Total blackout, edge to
edge", covered. Rank 2, the weight feels calming: the page says "for a calm,
settled feel", covered. Rank 3 is the first with no line on the page:

No pressure on the eyes, 3 of 22 items (14%): "I can open my eyes under it and
still see nothing. No pressure on my lashes at all" (10). Closest line on your
page: "11 oz of flax and glass bead fill for a calm, settled feel, quilted into
channels so it does not shift". That line sells the weight. Three customers are
talking about their eyeballs and their lashes, and the page mentions neither.

**On fixture-b**, `fixtures/halden-rest-under-minimum.md`: 9 reviews, no
returns, no survey answers, no page. Step 1 counts `9 reviews = 9 items`, under
15, and Refusal 1 fires with `more items needed: 15 - 9 = 6`. No block runs, no
benefit is ranked and no quote is pulled, even though several of the nine name
the same thing.

## Hard guardrails

- Never invent a number or a fact the input did not carry. Where a value is
  missing print `[NEEDS: <what to supply>]`, never a plausible fill.
- Never invent a quote and never smooth one. Typos, missing apostrophes and
  lowercase i stay as typed. A quote is one contiguous span of one item.
- Never merge two customers into one line, one story or one before and after.
- Never count a benefit the item did not name. Reading a mood into a five star
  review with no words is inference, and inference is what this skill stops.
- Never drop a return reason or a negative item out of the denominator.
- Never predict a click rate, a cost per purchase, a conversion rate or a ROAS
  outcome from a phrase in the bank. This counts words, it does not forecast.
- Never write the ad here. Block 4 hands quotes to a writer, tagged to items.
- No client or brand names from the RISE DTC roster. Fixture brands are invented.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize, AI-powered,
  cutting-edge, holistic.

<!-- self-check: Method re-run by hand on fixture-a. Mix 18 + 4 = 22 matches the
fixture. Benefits re-counted item by item: blackout 1,5,7,10,11,13 = 6; weight
calming 4,6,8,14 = 4; no eye pressure 2,10,16 = 3; faster 1,8 = 2; side sleeper
3,16 = 2; stays on 3,15 = 2; headache 6,17 = 2; plane or hotel 7,18 = 2; named
once 9, 15. Items with a benefit 17, without 12,19,20,21,22 = 5, 17 + 5 = 22.
Objections: fit 9,20,22 = 3; weight 4,19 = 2; price 2; warm 12; would not keep
15; smell 21; 3+2+1+1+1+1 = 9. Shares: 6/22 = 0.272727 prints 0.27 = 27%; 4/22 =
0.181818 prints 0.18 = 18%; 3/22 = 0.136363 prints 0.14 = 14%; 2/22 = 0.090909
prints 0.09 = 9%; 1/22 = 0.045454 prints 0.05 = 5%, half up. Before 7, after 7,
paired 1,3,4,18 = 4. Block 4: 10 phrases, 10 distinct items, longest 11 words,
inside the 14 word cap. Block 5: ranks 1 and 2 matched on the page, rank 3 not.
Fixture-b 15 - 9 = 6. Fixed list: the block table prints 5 rows, the text says
five. Grep over all three files: em dash zero, banned words zero outside the
guardrail line that declares them, exclamation marks zero outside the two HTML
comment delimiters. -->
