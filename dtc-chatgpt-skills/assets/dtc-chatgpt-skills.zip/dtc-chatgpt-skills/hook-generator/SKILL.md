---
name: hook-generator
description: "Use when you have one angle and need opening lines to test against each other. Takes the angle, the product facts the account can stand behind, and the audience in one sentence, and returns up to twelve opening lines, each tagged with the device it uses and the fact it rests on. Triggers on \"write me twelve hooks\", \"give me opening lines for this angle\", \"hook variations for this ad\", \"first three seconds, different ways\", \"hooks I can test this week on this client\", \"hooks for this angle only\"."
---

# RISE DTC ChatGPT Skills, 05 of 15: the hook set

## What this does

Writes the first line of an ad twelve different ways for one angle, using twelve fixed devices in a fixed order, and stops writing a device the moment it has no fact to rest on.

**The line only this skill produces:** up to twelve opening lines for one stated angle, each tagged with the device that produced it and the exact supplied fact it rests on, with an honest count of how many of the twelve it could not write and why.

## Required input

1. **The angle.** One of the eight the angle gap map skill in this kit uses, printed here so you do not need that skill first: PROBLEM/SOLUTION, MECHANISM, SOCIAL PROOF, COMPARISON, OFFER, IDENTITY, URGENCY/SCARCITY, FOUNDER/ORIGIN. A plain description of the angle in your own words is also accepted.
2. **Product facts the account can stand behind**, typed or pasted off the product page. At minimum: what it is, what it does, price, what's in the box. Optional: guarantee terms, a founder detail, review or rating data.
3. **The audience, in one sentence.** Who this is for, in your own words.

## What it refuses

**Refusal, no hook without a fact.** A device with no supplied fact to rest a claim on gets no line. Its slot is counted and named in the could-not-write list instead:

```
Could not write: [<DEVICE NAME>]
[NEEDS: <the fact type this device needs>]
```

This skill never pads to twelve by reusing a device, by writing a hook with no fact tag, or by inventing the missing fact.

## The twelve devices, fixed order

| # | Device | Fact type it needs |
|---|---|---|
| 1 | DIRECT QUESTION | what it does |
| 2 | NUMBER CALLOUT | any numeric fact (price, weight, quantity) |
| 3 | SECOND-PERSON RECOGNITION | what it does |
| 4 | SCENE-SETTING OPENER | what it does or what it is |
| 5 | OBJECT/INGREDIENT CALLOUT | what it is (material or component) |
| 6 | PRICE-FIRST OPENER | price |
| 7 | CONTENTS/UNBOX OPENER | what's in the box |
| 8 | BLUNT CLAIM OPENER | what it does |
| 9 | AUDIENCE-DIRECT ADDRESS | the audience sentence |
| 10 | GUARANTEE-FIRST OPENER | guarantee terms (optional input) |
| 11 | FOUNDER-VOICE STATEMENT | a founder detail (optional input) |
| 12 | REVIEW CALLOUT | review or rating data (optional input) |

Devices 1-9 draw on facts every shoot supplies as required input. Devices 10-12 draw on facts that are optional, and are the ones that are honestly skipped most often.

**Device 2 tie-break, stated once.** When more than one numeric fact is supplied, NUMBER CALLOUT uses the number that describes the product itself (weight, count, dimension, quantity in the box) before it uses a price. Price is device 6's fact and only becomes device 2's number when no product-describing number was supplied. The line prints which fact it used either way.

## Method

**Step 1, state the population.** "The twelve fixed devices, tried once each, in the order above, against the angle and facts you supplied."

**Step 2, walk the devices in order.** For each device, check whether its required fact type is present.
- Present: write one hook. It opens in that device's form and its content leads to the picked angle's primary claim. Tag it with the device name and the specific fact used, and for device 2 that tag names which numeric fact the tie-break selected.
- Absent: do not write a hook. Add it to the "could not write" list with `[NEEDS: <the fact type this device needs>]`.

A present base fact is permission to write the line, not permission to extend it. Every noun, number, material, outcome, name and scene detail in a written hook has to be traceable to the supplied fact list or to the audience sentence. A time of day, a room, a light level and a season are scene details like any other: if the input did not carry them, they are invented facts. Before a hook ships, read it back word by word against the input and strike any clause the input did not carry. A product name the input never stated is an invented fact, and so is a third-party endorsement, a care instruction, a competing remedy, or an outcome larger than the one the supplied fact states. This is where a run of this skill fails: not by writing a hook for a device with no fact, but by writing a hook for a device that has one and adding a second fact nobody supplied.

**Step 3, keep every hook pointed at the same angle.** All written hooks serve the one angle named in the input. A device may change the opening form; it does not change which angle the ad is testing.

**Step 4, count and stop.** Report exactly how many hooks were written, out of twelve possible. Never round up, never write a thirteenth, never reuse a device to replace a skipped one.

## Output format

```
# Ad hooks: <angle>
Audience: "<audience sentence>"
Population: <the sentence from Step 1, printed before any hook and before the count>
Hooks written: <n> of 12 possible

## Hooks
1. [<DEVICE NAME>]   fact: <fact used>
   "<hook line>"
(continue in device order, renumbered 1..n, only for devices that were written)

## Could not write
- [<DEVICE NAME>]: [NEEDS: <fact type>]
(one line per skipped device, or "None. All twelve devices had a fact to rest on.")
```

## Worked case

This worked case IS the fixture run at `fixtures/marrow-ash-mechanism-hooks.md`, re-run literally against the method above.

What a re-run has to reproduce, and what it does not: another run of this method on this fixture must land on the same devices written, the same devices skipped, the same count of 9 of 12, and the same fact tag on each written line, including the same numeric fact on device 2. The wording of each line is a free choice inside those constraints, so a second run will phrase these lines differently and still be correct. Word-for-word reproduction is not the test. Same devices, same skips, same count, same fact behind each line, and every clause traceable, is the test.

Angle: MECHANISM. Audience: "people who wake up at 3am and can't fall back asleep." Facts supplied: what it is (15 lb, glass micro-bead fill sewn into individual channels, cotton duvet cover), what it does (evenly distributes pressure across the body to reduce nighttime movement), price ($129), what's in the box (weighted insert, duvet cover, care card). No guarantee, founder, or review fact supplied. The fixture states no product name, so no hook below carries one.

Population: The twelve fixed devices, tried once each, in the order above, against the angle and facts you supplied.

Devices 1-9 all have a required fact type present in the supplied list, so all nine are written. Every clause in every line below traces back to one of the four supplied fact bullets or the audience sentence:

1. [DIRECT QUESTION] fact: what it does. "What if the reason you keep waking up is that nothing is holding your body still?"
2. [NUMBER CALLOUT] fact: what it is, the 15 lb weight. Two numeric facts were supplied, 15 lb and $129; the device 2 tie-break takes the number that describes the product itself, so the weight is used and the price is left to device 6. "15 pounds of glass micro-beads, sewn into individual channels."
3. [SECOND-PERSON RECOGNITION] fact: what it does. "You move all night without knowing you do it. This spreads pressure evenly across your body to cut that movement."
4. [SCENE-SETTING OPENER] fact: what it does, with the time of day taken from the audience sentence. "3am, and the pressure settles evenly across your body."
5. [OBJECT/INGREDIENT CALLOUT] fact: what it is. "Glass micro-beads, sewn into individual channels, inside a cotton duvet cover."
6. [PRICE-FIRST OPENER] fact: price. "$129 for a 15 pound weighted blanket with a cotton duvet cover."
7. [CONTENTS/UNBOX OPENER] fact: what's in the box. "In the box: the weighted insert, the duvet cover, and a care card."
8. [BLUNT CLAIM OPENER] fact: what it does. "This blanket distributes pressure evenly across your body to reduce how much you move at night."
9. [AUDIENCE-DIRECT ADDRESS] fact: audience sentence. "If you wake up at 3am and can't fall back asleep, this puts fifteen pounds of even pressure across your body."

What earlier shipped versions of this worked case got wrong, kept here so the failure class is legible. In the first version, device 5 read "the same fill occupational therapists use for even pressure," and the fixture names no therapist, no clinical use and no endorsement, so that clause was an invented fact inside a hook whose base fact was present. Devices 3, 6, 7 and 8 carried the same class of fault in that version, adding a competing remedy list, a washing instruction, a product name and an outcome ("stay asleep past 3am") the supplied facts never state.

Device 4 was the one that survived the first correction still broken. It read "11pm, lights off, and the pressure settles evenly across your body." The fixture's fact list carries no time of day and no lighting, and the audience sentence names 3am, the hour these people wake up, not an 11pm bedtime. Both "11pm" and "lights off" were invented scene details in a hook whose base fact was present, which is exactly the fault the first correction claimed to have cleared. Device 4 now reads "3am, and the pressure settles evenly across your body": the hour comes from the audience sentence and the pressure clause from the "what it does" fact, and nothing else is in the line. The count did not change at any point, because every one of these devices still had its base fact.

Devices 10-12 have no matching supplied fact (no guarantee, founder, or review data), so none is written:

- [GUARANTEE-FIRST OPENER]: `[NEEDS: your guarantee terms]`
- [FOUNDER-VOICE STATEMENT]: `[NEEDS: a founder detail: why the brand was built]`
- [REVIEW CALLOUT]: `[NEEDS: a review count or rating]`

Hooks written: 9 of 12 possible. 9 written + 3 skipped = 12, the fixed device count. This matches a literal walk of the device table against the fixture's fact list, with no rounding or padding.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a hook by inventing the fact a device needs.
- Never add an unsupplied clause to a hook whose base fact is present. No product name, third-party endorsement, care instruction, competing remedy, scene detail such as a time of day or a room, or outcome larger than the supplied fact states.
- Never open a hook by listing what the reader already tried and failing it against this product. That shape is a corrective contrast, and it needs facts about the alternatives that no input to this skill collects.
- Never claim what a hook will do to a click rate or a cost per purchase. This skill writes lines, it does not predict performance.
- Never write "in the brand's voice" or "the reader's register." These are neutral drafts for you to rewrite.
- No exclamation marks anywhere in a hook line.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.

<!-- ported from 01-existing/the-dtc-growth-team/creative/creative-03-ad-hook-writer, 2026-09-06; fixes applied: device 4's worked-case line rebuilt from supplied facts and the audience sentence only ("3am" replaces the invented "11pm, lights off") with the self-correction narrative rewritten to the truth, device 2 numeric tie-break added (product-describing number before price, fact printed), the line-by-line verification claim softened to what is checkable (devices written, devices skipped, count, fact per line; wording will differ), cross-unit reference to unit 01 replaced with the eight angles printed in this file -->
