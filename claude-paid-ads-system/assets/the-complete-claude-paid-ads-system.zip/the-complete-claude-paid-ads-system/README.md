# The Complete Claude Paid Ads System, built for DTC brands

Built by the team at RISE DTC.

A working system for running paid ads on Meta and Google with Claude, from the first customer interview to the monthly profit report. It is built for founders who run their own ads, media buyers, and creative strategists.

RISE is paid on results, so every part of this kit judges ads on the money they leave behind: contribution margin first, break-even before targets, profit in dollars before ROAS.

## What's inside

| Part | Count | What it is | Folder |
|---|---|---|---|
| Playbooks | 18 | One per stage of the ad system. Each says what the stage decides, the inputs, a step-by-step process, the numbers that decide it with a worked example, and the mistakes to avoid. | `playbooks/` |
| Skills | 15 | Single-job tools. Paste a screen you already have open, get one thing back you can act on. | `dtc-claude-skills/` |
| Prompts | 50 | Copy-paste Claude prompts, P01 to P50, in 20 categories. | `prompts/` |
| AI Agents | 30 | Five teams of six (Track, Spend, Creative, Convert, Decide), each agent one `SKILL.md` with one job. | `the-dtc-growth-team/` |


### The 18 playbooks

01 Market & Customer Research · 02 Customer Psychology · 03 Competitor Ad Analysis · 04 Offer & Positioning · 05 Angle Development · 06 Hook Writing · 07 Creative Briefs · 08 UGC & Static Ads · 09 Ad Copywriting · 10 Landing Page & CRO · 11 Campaign Structure · 12 Meta & Google Build · 13 Testing Framework · 14 Retargeting Journeys · 15 Budget & Bid Strategy · 16 Scaling Playbook · 17 Creative Refresh · 18 Margin & Profit Reporting

Each playbook names the exact skill, agent and prompt to use at each step.

### The 20 prompt categories

ICP (P01-P03) · Research (P04-P06) · Competitor (P07-P08) · Offer (P09-P11) · Angle (P12-P14) · Hook (P15-P17) · Script (P18-P19) · Static Ad (P20-P22) · UGC Brief (P23-P24) · Ad Copy (P25-P27) · Landing Page (P28-P30) · Campaign Build (P31-P32) · Audience (P33-P34) · Testing (P35-P37) · Retargeting (P38-P39) · Budget (P40-P42) · Scaling (P43-P44) · Creative Refresh (P45-P46) · Analytics (P47-P48) · Reporting (P49-P50)

## The one rule everything follows

No invented numbers. Every skill, agent and prompt uses only what you paste, shows its arithmetic so you can redo it by hand, and prints `[NEEDS: the missing input]` instead of filling a gap with a benchmark or an average. The worked examples in the playbooks use made-up numbers, labelled as examples. Replace them with your own.

## Install

### Claude.ai (any plan with Projects)

**Skills and agents:**

1. Create a Project, for example "Paid ads".
2. Either open a skill's `SKILL.md`, copy the whole file, and paste it into the Project instructions, or upload several `SKILL.md` files as Project knowledge.
3. In a chat inside the Project, ask for the job by name ("run break-even-and-affordable-cpa on these numbers") and paste your data under it.

For a one-off run with no setup: open any `SKILL.md`, paste the whole file into a new chat, paste your numbers under it, and send.

**Prompts:** open the category file, copy the prompt from its code block, replace every [BRACKETED] input, and send. Upload the `prompts/` files as Project knowledge if you want to call them by number ("run P40 with these figures").

**Playbooks:** upload the `playbooks/` files as Project knowledge, and Claude can walk you through a stage step by step.

### Claude Code

Skills and agents install into `~/.claude/skills/`. Run these from the folder where you unzipped the kit:

```
cp -R dtc-claude-skills/* ~/.claude/skills/
cp -R the-dtc-growth-team/track/* ~/.claude/skills/
cp -R the-dtc-growth-team/spend/* ~/.claude/skills/
cp -R the-dtc-growth-team/creative/* ~/.claude/skills/
cp -R the-dtc-growth-team/convert/* ~/.claude/skills/
cp -R the-dtc-growth-team/decide/* ~/.claude/skills/
```

Always use the `cp -R <dir>/*` form above. Never use `cp -r <dir>/*/` with a trailing slash: on macOS that copies the contents of each folder instead of the folder, so every `SKILL.md` lands on top of the last one in a single flat pile.

Check it worked: `ls ~/.claude/skills/` should list 45 new folders, each with its own `SKILL.md`. Claude Code picks them up on the next start. Skill and agent folder names do not clash, so both sets can live side by side.

## Start here

Run these three playbooks first, in this order, on any account you are about to touch:

1. **18 Margin & Profit Reporting.** Get your real contribution margin, break-even ROAS, affordable CPA, and last month's contribution after ads. Every other number in this kit is judged against these. Start with the `break-even-and-affordable-cpa` skill.
2. **11 Campaign Structure.** Run the `ad-account-hygiene-auditor` skill on what is live. It sums the spend going to ad sets that return nothing and names the exact fix.
3. **13 Testing Framework.** Run the `scale-or-kill-judge` skill on last week's per-ad rows with the affordable CPA from step 1. You get SCALE, HOLD, CUT or NOT ENOUGH SPEND for every ad, and a way to test from here on.

After those three, work through the playbooks in order from 01, or jump to the stage where your account is weakest.

## What this kit will not do

- It does not connect to Meta, Google, Shopify or anything else. You paste, Claude reads.
- It does not predict your future CPA or ROAS. It shows what happened and what a change has to clear.
- It does not fill missing inputs with industry averages.

## Questions

RISE DTC built these for its own media buyers and creative strategists. If you want this system run on your account, that is what the team does.

risedtc.com
