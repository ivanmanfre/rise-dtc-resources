# Analytics prompts (P47 to P48)

Two numbers run the account in this kit: contribution after ads, in dollars, and MER against your break-even MER. Platform ROAS is read beside them, never instead of them.

---

## P47 Weekly Contribution Read

**When to use it:** every Monday, before anyone touches a budget. Used in playbooks 16 and 18.

```
Read last week for [BRAND] on contribution.

Contribution margin % before ads (from break-even-and-affordable-cpa, returns-adjusted if you have it): [%]
Break-even MER = 1 / contribution margin %: [X]
Last 4 weeks, per week, from Shopify: gross sales [$], discounts [$], refunds [$], orders [N], new customers [N]
Last 4 weeks, per week, total ad spend across all channels: [$]
Platform-reported purchase value per channel, same weeks: [PASTE]

Do this, per week:
1. Net revenue = gross sales - discounts - refunds
2. MER = net revenue / total ad spend
3. Contribution after ads = net revenue x contribution margin % - total ad spend
4. New customer CAC = total ad spend / new customers (label it blended, since returning customers also saw ads)
5. Platform ROAS per channel = purchase value / channel spend
Show each line.

Then:
- Is contribution after ads rising, flat or falling across the 4 weeks, in dollars?
- Which week was best, and what was different about it (spend, orders, new customers)?
- One decision for this week, tied to a number above.

Rules: never add platform-reported revenue across channels. No benchmarks.
```

**What good output looks like:** a four-week table where contribution after ads in dollars is the headline row, MER sits against break-even, and platform ROAS is a side column. One decision, one number behind it.

---

## P48 Find Where Platform Revenue and Shopify Disagree

**When to use it:** your ad platforms together claim more revenue than your store took in, or one channel looks much better in-platform than in the bank. Used in playbooks 12 and 18.

```
Find where my ad platforms' revenue and my Shopify revenue disagree.

Window: [DATES]
Per channel: spend [$], platform-reported purchase value [$], attribution setting (for example 7-day click, 1-day view): [PASTE]
Shopify net revenue for the same window: [$]
Shopify revenue by UTM source or post-purchase survey answer, if I have it: [PASTE]

Do this:
1. Sum of platform-reported revenue across channels. Compare to Shopify net revenue. Overlap = sum - Shopify net revenue, in dollars and as % of Shopify net revenue. Show it.
2. MER on Shopify net revenue = Shopify net / total spend.
3. Per channel: platform ROAS, and, where I gave UTM or survey data, the Shopify-side share of revenue next to the share of spend.
4. Which channel's claim is furthest from the Shopify-side evidence, with the numbers.
5. Two checks to run next: a holdout, a spend pause on one channel for a set window, or a post-purchase survey question.

Rules: do not blend attribution settings as if they were the same. Do not treat survey share as revenue.
```

**What good output looks like:** the overlap in dollars, MER on real revenue, and one channel flagged with numbers. For the fixed-format version run `roas-vs-mer-reader`, and `track-02-attribution-window-matcher` if the channels report on different windows.
