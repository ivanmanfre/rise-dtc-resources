# ICP prompts (P01 to P03)

Paste each prompt into a new Claude chat and replace every [BRACKETED] input with your own. Every prompt in this kit tells Claude to use only what you paste, show its arithmetic, and print `[NEEDS: ...]` where an input is missing. Keep that rule in when you edit them.

---

## P01 Build Your ICP From Your Own Orders

**When to use it:** before any research, angle or targeting work, when you have a Shopify customer export and at least 15 survey answers or reviews. Used in playbook 01.

```
You are a DTC customer analyst. Build an ideal customer profile for [BRAND], which sells [PRODUCT] at [PRICE].

What I have:
1. Customer and order data, with these columns: [LIST YOUR COLUMNS, e.g. orders per customer, first product bought, AOV, discount code used, region, repeat within 90 days]
[PASTE ROWS OR A SUMMARY TABLE]

2. Post-purchase survey answers or reviews, at least 15:
[PASTE TEXT]

3. What I currently believe about my buyer, in two sentences:
[YOUR CURRENT GUESS]

Do this:
- Group customers into 2 to 4 segments using only fields present in the data. Name each segment by what they bought and the reason they gave for buying it.
- For each segment print: share of orders (count / total, arithmetic shown), average order value, repeat rate if the data has it, the top 3 reasons to buy quoted word for word, and the top 2 objections or hesitations quoted word for word.
- Name one segment as the ICP. Use highest contribution per customer if I gave you costs, otherwise highest repeat rate, and print which rule you used.
- Put my current guess next to what the data shows, line by line, and mark each line CONFIRMED, CONTRADICTED or NO DATA.

Rules: use only what I pasted. No invented demographics, income bands, persona names or stock photos of a "typical buyer". Where a field is missing, print [NEEDS: field] and carry on. Quote customers exactly, with no tidying.
```

**What good output looks like:** segment counts that add up to your total order count, verbatim quotes you can find in your own paste, one ICP named with the rule stated, and a short list of where your guess was wrong. If you see a persona with a first name and a hobby you never mentioned, the prompt was edited or ignored. Rerun.

---

## P02 Rank Customer Segments by Contribution Margin

**When to use it:** you already have segments (from P01 or your own cut) and need to know which one is worth paying the most to acquire. Used in playbook 01.

```
Rank my customer segments by the money each one leaves after product and fulfilment costs, so I know who is worth paying for.

For each segment I give you:
- Segment name: [NAME]
- Orders in the window: [N]
- Average order value before discount: [$]
- Average discount per order: [$]
- Cost of goods per order: [$]
- Shipping I pay per order: [$]
- Pick and pack per order: [$]
- Payment processing: [% + fixed fee]
- Return rate: [%] and cost of one return: [$]
- Share of customers who reorder within [90] days: [%] and their average repeat order value: [$]
Repeat this block for each segment:
[PASTE SEGMENT BLOCKS]

My target contribution left per first order after ad cost: [$ or "none, show me three options"]

Do this:
1. Per segment: net revenue per order, variable cost per order, contribution per order in $ and %, returns-adjusted contribution per order. Show every subtraction and division.
2. Per segment: expected contribution per customer over the repeat window = first-order contribution + (repeat share x repeat order contribution). Show the arithmetic.
3. Per segment: the most I can pay to acquire one customer while still keeping my target contribution, first order only and first order plus repeat window, as two separate numbers.
4. Rank segments by the repeat-window number and state the gap between first and last in dollars.

Rules: no benchmarks and no industry averages. A missing cost prints [NEEDS: cost] and that segment's contribution is labelled CEILING. Round only when printing.
```

**What good output looks like:** a table per segment where you can redo every line on a calculator, two CAC ceilings per segment (first order and with repeat), and a ranking. The useful surprise is usually that the biggest segment by order count is not the one worth the highest CAC. Carry the top segment's first-order ceiling into playbook 15.

---

## P03 Write the Anti-ICP

**When to use it:** you suspect you are paying to acquire customers who return, only buy on discount, or never reorder. Used in playbook 02.

```
Write the anti-ICP for [BRAND]: the buyers I should stop paying to acquire.

What I have:
- Return reasons, as the returns portal shows them: [PASTE]
- Orders using a discount code vs full price, with their repeat rates: [PASTE]
- Refund and chargeback notes: [PASTE]
- Support tickets from customers who returned or complained: [PASTE]
- Products or bundles with the lowest contribution per order: [PASTE, with contribution if known]

Do this:
1. Group the evidence into 2 to 4 buyer types I lose money on. For each, quote the evidence word for word and count how many items support it.
2. For each type, state what attracts them today: the ad claim, offer, discount or product that brings them in. Quote my own ad or page copy if I pasted it.
3. For each type, write three changes that repel them without hurting my ICP: one copy line, one offer or threshold change, one targeting or exclusion change.
4. List any evidence that did not fit a type under UNGROUPED.

Rules: only use what I pasted. Do not describe these buyers by age, gender, income or location unless the data shows it. Print [NEEDS: ...] for anything missing.
```

**What good output looks like:** named buyer types backed by counted, quoted evidence, and three specific changes each. A strong answer often points at your own discount code or a vague claim in your ad as the thing pulling the wrong buyer in. Take the exclusions into P33 and the copy lines into P25.
