# Testing prompts (P35 to P37)

The `creative-04-test-matrix-builder` agent builds the matrix, `spend-06-test-budget-ringfencer` sets aside test money, and `scale-or-kill-judge` gives the per-ad verdict. These prompts write the plan around them, read a finished test, and keep the record.

---

## P35 Write a Test Plan With Kill Rules

**When to use it:** before launching any test, so the decision rules exist before the results do. Used in playbook 13.

```
Write a test plan for this creative or offer test.

What I am testing (one variable): [e.g. hook, angle, format, offer, landing page]
Variants: [LIST]
What stays the same across variants: [LIST]
Affordable cost per purchase: [$]
Monthly test budget (from spend-06-test-budget-ringfencer or my own number): [$]
Current cost per purchase on the account: [$]

Do this:
1. The question this test answers, in one sentence, and the question it cannot answer.
2. Minimum spend per variant to reach 10 purchases at the affordable CPA = 10 x affordable CPA. Show it.
3. Total minimum test spend = minimum per variant x number of variants. Compare to the test budget. If it does not fit, cut variants until it does and say which.
4. Kill rule per variant: stop once spend reaches 2 x affordable CPA with zero purchases. Show the dollar figure.
5. Read rule: at 10 purchases, compare cost per purchase to the affordable CPA: at or under 0.85 x affordable is a winner, above affordable is a loser, in between is hold. Show all three dollar lines.
6. The date to read it and the one thing nobody may change until then.

Rules: one variable per test. If I listed variants that change more than one thing, say so and split them.
```

**What good output looks like:** a one-page plan with dollar kill and read lines printed before launch. The read bands match the ones `scale-or-kill-judge` uses, so the verdict at the end is mechanical.

---

## P36 Read a Finished Test

**When to use it:** the test has hit its read date or its spend. Used in playbook 13.

```
Read this finished test and tell me what it proved.

Test plan (from P35): [PASTE]
Per variant for the window: spend [$], impressions [N], clicks [N], purchases [N], purchase value [$]
Changes made to the campaign during the test (budget, bids, audiences, other ads added): [PASTE, or "none"]

Do this:
1. Per variant: CTR = clicks / impressions, CPC = spend / clicks, conversion rate = purchases / clicks, cost per purchase = spend / purchases. Show each.
2. Apply the read rule from the plan to each variant with 10 or more purchases. Mark variants under 10 purchases NOT ENOUGH DATA.
3. If any change during the test could explain the result, name it and mark the test CONFOUNDED.
4. State in one sentence what was learned, and in one sentence what was not.
5. The next test this result points to.

Rules: no verdict on a variant under 10 purchases. No "directional" wins.
```

**What good output looks like:** per-variant arithmetic, a verdict only where the data supports one, and a CONFOUNDED flag if someone touched the campaign mid-test. For a full change-log check, run `decide-02-change-log-auditor`.

---

## P37 Build the Learning Log

**When to use it:** monthly, so your tests add up to knowledge instead of a folder of screenshots. Used in playbooks 08, 13 and 17.

```
Turn these test results into a learning log for [BRAND].

Every test from the last [3] months: what was tested, variants, the verdict, cost per purchase per variant, dates: [PASTE]

Do this:
1. A table: test, variable, winner, cost per purchase of winner vs loser, confidence (10+ purchases per variant or not).
2. Group the learnings by variable (hooks, angles, formats, offers, pages) and write one rule per group that the results support, citing the tests.
3. List the questions still open, and the next test for each.
4. List any test that was confounded or underspent, so nobody quotes it as proof.

Rules: a rule must cite at least one test with 10 or more purchases per variant. No rule from a single underspent test.
```

**What good output looks like:** a short set of evidence-backed rules ("problem/solution hooks beat offer-led hooks in tests 4 and 7") and an honest list of what is still unknown. This is the file your next creative brief starts from.
