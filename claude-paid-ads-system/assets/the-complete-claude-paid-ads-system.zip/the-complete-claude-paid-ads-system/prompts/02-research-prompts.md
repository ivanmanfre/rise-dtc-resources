# Research prompts (P04 to P06)

For your own reviews, run the `customer-researcher` skill first: it returns the full customer language bank in a fixed format. These three prompts cover the sources that skill does not: competitor reviews, your post-purchase survey, and forum threads.

---

## P04 Mine Competitor Reviews for Unmet Needs

**When to use it:** you want to know what buyers of the category alternative complain about, so you can build angles on the gaps. Used in playbooks 01 and 03.

```
Read these reviews of a competitor's product and find the needs it leaves unmet.

Competitor and product: [NAME AND PRODUCT]
My product, and the facts I can prove about it: [PASTE FACTS]
Reviews, ideally 1 to 3 stars, at least 20:
[PASTE REVIEWS, one per line]

Do this:
1. Group the complaints into themes. For each theme print the count, the share of all reviews pasted (count / total, arithmetic shown), and 3 quotes word for word.
2. For each theme, mark whether my facts answer it: ANSWERED (quote my fact), PARTIAL, or NOT ANSWERED.
3. List the exact phrases buyers use to describe the problem, as they wrote them, ready to use in an ad.
4. List anything buyers praise about the competitor that my facts do not match. These are claims I must not make.

Rules: no claims about my product beyond the facts I pasted. Do not name the competitor in any ad line you suggest. Where a review is too short to classify, put it under UNCLASSIFIED.
```

**What good output looks like:** counted themes with quotes, a clear ANSWERED list you can build ads on, and a "do not claim" list. If every theme comes back ANSWERED, check that Claude used only your pasted facts.

---

## P05 Read Your Post-Purchase Survey

**When to use it:** you run a post-purchase survey ("where did you hear about us", "what almost stopped you") and want it turned into decisions. If you do not have one yet, run the `track-04-post-purchase-survey-writer` agent first. Used in playbook 01.

```
Read my post-purchase survey answers and turn them into three decisions.

Window: [DATES]
Total orders in the window: [N]
Survey responses: [N]
Question 1 "[QUESTION TEXT]" answers:
[PASTE ANSWER COUNTS OR RAW ANSWERS]
Question 2 "[QUESTION TEXT]" answers:
[PASTE]
Question 3 "[QUESTION TEXT]" answers, open text:
[PASTE]
Ad spend by channel for the same window: [PASTE]

Do this:
1. Response rate = responses / orders, arithmetic shown. If under 20%, say the channel split may not represent all buyers and keep going.
2. For "where did you hear about us": share per answer. Put it beside spend share per channel and print both columns.
3. For open-text answers: group into themes, count them, quote 2 per theme.
4. Write three decisions this data supports, each tied to a number above, and one thing this data cannot tell me.

Rules: do not convert survey shares into revenue per channel. Do not fill any missing channel with an estimate. Print [NEEDS: ...] for gaps.
```

**What good output looks like:** a side-by-side of "said they heard about us here" against "where the money went", with the mismatch named. For example, if a channel takes a large share of spend and a small share of mentions, that is a question for playbook 18, and the answer should say so.

---

## P06 Mine Forum and Reddit Threads for Buying Triggers

**When to use it:** you have too few reviews, or you are entering a new product line and need the buyer's own words from outside your store. Used in playbooks 01 and 02.

```
Read these forum or Reddit threads about [PROBLEM OR CATEGORY] and pull out what makes people buy, delay, or give up.

Threads, pasted as text with usernames removed:
[PASTE THREADS]

My product and its provable facts: [PASTE]

Do this:
1. List every buying trigger: the moment or event that made someone go looking for a fix. Quote each and count repeats.
2. List every delay reason: what made people wait, compare, or not buy. Quote and count.
3. List the solutions people already tried and what they said went wrong with each.
4. List 10 phrases that describe the problem in the buyer's words, ready to test as hook lines.
5. Mark which triggers and delay reasons my facts answer, quoting the fact.

Rules: quote exactly. No medical, financial or legal claims. Nothing that is not in the threads.
```

**What good output looks like:** triggers and delay reasons counted and quoted, the "already tried" list (useful for comparison angles), and ten buyer-language lines. Feed the lines into P12 and P15.
