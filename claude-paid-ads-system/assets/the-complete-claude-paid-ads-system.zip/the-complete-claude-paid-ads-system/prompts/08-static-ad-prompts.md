# Static Ad prompts (P20 to P22)

Statics are cheap to make, so they are the fastest way to test an angle before you pay for video. These prompts return concepts a designer can build without a follow-up question.

---

## P20 Static Ad Concept Set for One Angle

**When to use it:** you have one angle and want 6 static concepts that test it from different directions. Used in playbook 08.

```
Write 6 static ad concepts for one angle.

Angle: [PASTE]
Customer phrases: [PASTE]
Product facts I can prove: [PASTE]
Offer: [PASTE]
Claim boundary: [PASTE FROM P14]
Brand assets I have: [product photos, lifestyle shots, logo, colours]
Sizes needed: [e.g. 1:1 and 4:5 for feed, 9:16 for stories]

Do this, per concept:
1. Concept name and layout type: product hero, before and after state, checklist, quote card, us vs the alternative, offer-led, or problem callout.
2. Headline on the image (7 words or fewer).
3. Supporting text on the image (15 words or fewer).
4. What the image shows, specific enough for a designer.
5. The fact each claim rests on.
6. Suggested primary text opening line.

Rules: stay inside the claim boundary. No before and after images of bodies or skin. No invented review counts or ratings.
```

**What good output looks like:** six concepts that each look different in the feed, all testing the same angle, each buildable in under an hour. If three of them are "product on a plain background with a headline", ask for more layout range.

---

## P21 Comparison Static Ad

**When to use it:** the comparison angle is empty in your account and you have facts that beat the category alternative. Used in playbook 08.

```
Write 3 comparison static ads: my product against the category alternative.

My product and its provable facts: [PASTE]
The category alternative (a type of product or habit, never a named brand): [e.g. "drugstore moisturiser", "cheap foam pillows"]
What buyers say about the alternative, quoted: [PASTE FROM P04 OR P06]

Do this, per ad:
1. Headline (7 words or fewer).
2. A two-column comparison with 3 to 5 rows. Each row states a fact for my product and a fair description of the alternative.
3. The source of each fact on my side.
4. What the image shows.

Rules: never name a competitor brand. Every row on my side must be a supplied fact. Every row on the alternative's side must be fair and backed by the buyer quotes, never exaggerated. Drop a row rather than stretch it.
```

**What good output looks like:** clean two-column tables where each of your rows cites a fact and each alternative row cites a buyer quote. If a row makes you wince at how it treats the alternative, cut it.

---

## P22 Review-Led Static Ads From Real Reviews

**When to use it:** you have reviews and want social proof statics that use them word for word. Used in playbook 08.

```
Build 5 review-led static ads from these real reviews.

Reviews, word for word, with star rating and first name or initial as shown on my store: [PASTE AT LEAST 15]
Total review count and average rating as shown on my store today: [N, X.X]
Product and offer: [PASTE]

Do this:
1. Pick the 5 reviews that each answer a different objection. Name the objection.
2. For each: the pull quote (cut down, never reworded), the headline on the image, what the image shows, and how the reviewer is credited.
3. Show the full original review beside each pull quote so I can check the cut keeps its meaning.

Rules: never reword a review. Cutting is allowed only if the meaning stays the same. Use my review count and rating exactly as I gave them, or leave them out.
```

**What good output looks like:** five pull quotes, each tied to a different objection, each checkable against the original. Run the finished ads through `spend-04-policy-risk-checker` if your category has health or results claims.
