# Campaign Build prompts (P31 to P32)

Before building anything on an existing account, run the `ad-account-hygiene-auditor` skill on what is live. For names that carry the test variable, use the `track-05-campaign-naming-fixer` agent.

---

## P31 Account Structure Plan

**When to use it:** you are setting up a new account, or the current one has too many campaigns and ad sets for its budget. Used in playbooks 11 and 12.

```
Plan the account structure for [BRAND] on [Meta / Google / both].

Monthly ad budget: [$]
Affordable cost per purchase (from break-even-and-affordable-cpa): [$]
Products or collections to advertise, with contribution per order each: [PASTE]
Markets: [COUNTRIES]
Current structure, if any (campaigns, ad sets, daily budgets): [PASTE]
Creative I have ready now: [N videos, N statics]

Do this:
1. Daily budget = monthly budget / 30.4. Show it.
2. Purchases the budget can buy per week at the affordable CPA = (daily budget x 7) / affordable CPA. Show it.
3. The number of ad sets that budget can support, if each ad set needs about 50 purchases a week to exit Meta's learning phase: ad sets = weekly purchases / 50, rounded down, minimum 1. Show it. If the result is under 1, say the account should run one ad set per campaign.
4. A structure: campaigns, ad sets, what goes in each, daily budget each, and which products each promotes. Separate prospecting from retargeting only if the budget supports it.
5. For Google: which campaign types (Search brand, Search non-brand, Shopping or Performance Max) and a starting budget split, each tied to contribution per product.
6. What to switch off or merge in the current structure.

Rules: no structure that splits the budget thinner than step 3 allows. No benchmarks. [NEEDS: ...] for any missing input.
```

**What good output looks like:** a small structure sized to the budget, with the arithmetic that justifies the number of ad sets. The most common fix it produces is fewer ad sets, each with enough budget to learn.

---

## P32 Pre-Launch QA Checklist

**When to use it:** before you publish any new campaign. Ten minutes here saves a week of bad data. Used in playbook 12.

```
Build a pre-launch QA checklist for this campaign and check what I pasted against it.

Campaign settings, as they read in Ads Manager or Google Ads (objective, conversion event, attribution setting, budget, bid strategy, locations, placements, schedule): [PASTE]
Ad set or ad group settings: [PASTE]
Each ad: name, primary text, headline, destination URL with its UTM parameters: [PASTE]
Pixel and conversion API status, or Google tag status, as the events screen shows it: [PASTE]

Do this:
1. Check each item and mark PASS, FAIL or CANNOT CHECK:
   - Objective and optimisation event are purchase, unless I said otherwise
   - Attribution setting matches the one I report on
   - Locations are only the markets I ship to
   - Every destination URL loads the right product and carries UTM parameters
   - Ad names follow one naming pattern that includes the angle and the format
   - Purchase event shows recent activity
   - No two ad sets target the same audience with the same creative
   - Budget matches the plan
   - Exclusions for recent purchasers are set on prospecting
2. For each FAIL, the exact fix.

Rules: only mark PASS where the paste shows it. Anything not pasted is CANNOT CHECK.
```

**What good output looks like:** a PASS / FAIL / CANNOT CHECK list with fixes. Clear every FAIL, then run `utm-tag-auditor` on the links and `track-03-tracking-break-checker` on the events before you spend a dollar.
