# Budget prompts (P40 to P42)

Every budget in this kit starts from contribution margin. Run `break-even-and-affordable-cpa` first, then these. For one campaign's next budget step, use `budget-step-planner`.

---

## P40 Monthly Budget From a Contribution Target

**When to use it:** setting next month's ad budget from the profit you need, instead of from last month's spend. Used in playbook 15.

```
Set next month's ad budget from my contribution target.

Contribution margin % before ad spend (from break-even-and-affordable-cpa): [%]
Contribution I need left after ad spend next month: [$]
Fixed costs I want this to cover, for reference: [$]
Last 3 months: total revenue [$], total ad spend [$], MER = revenue / spend, per month: [PASTE]
Revenue I expect with zero ad spend (returning customers, organic), if I know it: [$ or unknown]

Do this:
1. Per month: MER and contribution after ads = revenue x contribution margin % - ad spend. Show each.
2. Break-even MER = 1 / contribution margin %. Show it.
3. For three spend levels (my last month's spend, 20% lower, 20% higher): the revenue needed to hit my contribution target = (target + spend) / contribution margin %, and the MER that revenue requires = revenue needed / spend. Show each.
4. Set each required MER next to my best and second-best month's MER. Mark each spend level INSIDE MY HISTORY or ABOVE MY HISTORY.
5. Recommend the highest spend level that sits inside my history.

Rules: no forecasts. Compare only against my own months. [NEEDS: ...] for anything missing.
```

**What good output looks like:** three spend levels, each with the MER it requires and a flag showing whether you have ever hit it. For a stricter check against your history, run `decide-04-target-feasibility-checker`.

---

## P41 Split Budget Across Campaigns

**When to use it:** you have a monthly number and need it divided across campaigns and channels by what each returns in contribution. Used in playbook 15.

```
Split my monthly budget across campaigns by contribution.

Monthly budget: [$]
Affordable cost per purchase: [$]
Per campaign for the last [30] days: name, channel, spend [$], purchases [N], new-customer purchases if known [N], contribution margin % of the products it sells [%], average order value [$]
Test budget to set aside first (from spend-06-test-budget-ringfencer): [$]

Do this:
1. Per campaign: cost per purchase = spend / purchases, and contribution after ads per purchase = AOV x margin % - cost per purchase. Show each.
2. Rank campaigns by contribution after ads per purchase.
3. Take the test budget off the top. Split the rest: campaigns under 0.85 x affordable CPA may grow by up to 20%, campaigns between 0.85x and 1x hold, campaigns over the affordable CPA shrink or stop. Show each new monthly and daily budget.
4. Check the new total equals the monthly budget. Show the sum.

Rules: no campaign rises more than 20% in one step. No campaign with under 10 purchases in the window gets more budget.
```

**What good output looks like:** a table of current and new budgets per campaign that adds up to your monthly number, with every move tied to cost per purchase against the affordable CPA. To move money in capped steps, run `spend-03-spend-shift-planner`.

---

## P42 Cash and Payback Check Before Spending More

**When to use it:** before a big spend increase, a sale, or a stock order, when cash is tight. Used in playbook 15.

```
Check whether I can afford to spend more on ads this month, on cash as well as margin.

Cash in the bank today: [$]
Cash I must keep as a floor: [$]
Planned ad spend next 30 days: [$]
New customer acquisition cost last 30 days (new-customer spend / new customers): [$]
First-order contribution per new customer: [$]
Share of new customers who reorder within 30, 60, 90 days: [% / % / %], and contribution per reorder: [$]
Payout delay from Shopify or my processor: [DAYS]
Inventory on hand, daily units sold, and next restock date: [PASTE]

Do this:
1. Payback per customer: first-order contribution minus CAC, then add expected reorder contribution at 30, 60 and 90 days. Show when it turns positive, or say it does not within 90 days.
2. Cash needed = planned ad spend + inventory purchases due in the next 30 days. Compare to cash minus floor.
3. Days of stock cover per product = units on hand / daily units sold. Flag any product that runs out before the restock date at the planned spend.
4. A verdict: SPEND AS PLANNED, SPEND LESS (and how much), or HOLD, with the reason in one line.

Rules: only my numbers. Label any reorder share I marked as a guess.
```

**What good output looks like:** a payback line by day 30, 60 and 90, a cash check, a stock cover check, and one verdict. For per-SKU spend ceilings based on stock, run `spend-05-stock-cover-guard`.
