# UGC Brief prompts (P23 to P24)

For the script a creator reads on camera, use the `ugc-script-writer` skill. For a shot-by-shot brief with a claim boundary block, use the `ad-brief-generator` skill. These prompts cover the creator-facing brief and the edit after footage comes back.

---

## P23 UGC Creator Brief

**When to use it:** you have booked a creator and need a brief she can shoot from without a call. Used in playbooks 06, 07 and 08.

```
Write a UGC creator brief for [PRODUCT].

Angle: [PASTE]
Hooks to film (film all of them, same body): [PASTE 3 FROM P15]
Claim boundary: [PASTE FROM P14]
Creator, in one line: [who she is, how she uses the product]
Target length: [15 / 30 / 45] seconds
Deliverables: [e.g. 3 hook takes, 1 body take, 5 b-roll clips, raw files]
Usage rights and deadline: [PASTE]

Do this:
1. A one-paragraph "why this ad exists" in plain words.
2. The hooks to film, each as its own take.
3. Beats for the body with what to say in her own words (talking points, never a word-for-word script unless I ask), and what to show.
4. B-roll shot list: 5 to 8 shots, each one line.
5. Must say / must not say lists, copied from the claim boundary.
6. Technical: vertical 9:16, natural light, product label visible, no music, no captions burned in.
7. Deliverables and deadline.

Rules: nothing outside the claim boundary. No results claims the creator has not personally had.
```

**What good output looks like:** a one-page brief with separate hook takes, talking points, a b-roll list, and must-say / must-not-say lists. Separate hook takes are the point: one shoot, several testable ads.

---

## P24 Edit Plan From Raw UGC Footage

**When to use it:** the creator's files are back and you need the editor to cut several ads from them. Used in playbooks 08 and 17.

```
Plan the edits from this raw UGC footage.

Transcript of each clip with timestamps (auto-transcripts are fine): [PASTE]
B-roll clips, one line each: [PASTE]
Angle and claim boundary: [PASTE]
Ads I need: [e.g. 3 x 30s with different hooks, 1 x 15s cutdown]

Do this:
1. For each ad, an edit list: clip name, in and out timestamps, what is said, overlay text, b-roll cut-ins.
2. Use the same body across ads that test hooks, so the only change is the hook.
3. Flag any line the creator said that breaks the claim boundary, with its timestamp, so it gets cut.
4. Flag missing coverage: any beat with no usable take.

Rules: only use lines the creator actually said. Do not rewrite her words in overlays as if she said them.
```

**What good output looks like:** a timestamped edit list per ad, identical bodies across hook tests, and a list of lines to cut for compliance. Name the files so the test reads cleanly in playbook 13.
