# Scaling prompts (P43 to P44)

Scaling in this kit means adding spend while contribution after ads keeps growing in dollars. Use `budget-step-planner` for each step and `spend-02-scale-break-diagnoser` when a step goes wrong.

---

## P43 Scale Readiness Check

**When to use it:** before raising spend on an account or a campaign by more than one step. Used in playbook 16.

```
Tell me whether this account is ready to scale.

Affordable cost per purchase: [$]
Break-even MER (1 / contribution margin %): [X]
Last 4 weeks, per week: spend [$], total revenue from Shopify [$], purchases from the ad platform [N], new customers from Shopify [N]
Top 5 ads by spend, with spend, purchases, cost per purchase, and days live: [PASTE]
Days of stock cover on the top products: [PASTE]
Creative made in the last 30 days: [N new ads]

Check each and mark PASS or FAIL, showing the numbers:
1. MER each week = revenue / spend. PASS if every week is above break-even MER.
2. Cost per purchase over the last 2 weeks at or under 0.85 x affordable CPA.
3. No single ad takes more than half of the spend.
4. At least 3 ads with 10 or more purchases each, under the affordable CPA.
5. Stock cover of at least 30 days on the products being pushed.
6. New creative made in the last 30 days is 4 or more ads.
7. New customers per week are flat or rising.

Then: READY, READY WITH ONE FIX (name it), or NOT READY (name the first fix).

Rules: show every division. No verdict on a check with missing data; mark it [NEEDS: ...].
```

**What good output looks like:** seven checks with the numbers beside each and a one-line verdict. These thresholds are this kit's working rules for a first read; change them to your own if your history says otherwise, and write the change down.

---

## P44 Horizontal Expansion Plan

**When to use it:** your best campaign has stopped taking more budget without its cost per purchase rising, and you need new places to spend at the same margin. Used in playbook 16.

```
Plan horizontal expansion for [BRAND]: new angles, audiences, formats, products and channels, each priced against my margin.

Current winning ads and their angle, format and cost per purchase: [PASTE]
Angles nobody in my account runs (from angle-gap-mapper): [PASTE]
Products with contribution per order each: [PASTE]
Channels live today and their spend: [PASTE]
Affordable cost per purchase: [$]
Monthly test budget: [$]

Do this:
1. Ten expansion moves across: new angle, new format of a winning angle, new creator, new product as the lead, new market I already ship to, new channel.
2. For each: what it tests, the minimum spend to read it (10 x affordable CPA), and the creative it needs.
3. Rank by cost to read, cheapest first, and fit as many as the monthly test budget allows. Show the running total.

Rules: only products, markets and channels I listed. No predicted results.
```

**What good output looks like:** a ranked list of moves, each with a dollar cost to read it, cut off where the test budget runs out. Run each through the plan in P35.
