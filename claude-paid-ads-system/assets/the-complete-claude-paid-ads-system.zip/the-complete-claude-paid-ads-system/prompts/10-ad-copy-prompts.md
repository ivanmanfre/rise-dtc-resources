# Ad Copy prompts (P25 to P27)

Write copy after the angle, claim boundary and landing page are settled. Run finished copy through `spend-04-policy-risk-checker`, and check it against the page with `message-match-checker`.

---

## P25 Meta Primary Text Variants

**When to use it:** you have a creative ready and need the primary text that sits above it. Used in playbooks 09 and 12.

```
Write 5 primary text variants for this Meta ad.

Creative: [DESCRIBE THE VIDEO OR STATIC, OR PASTE THE SCRIPT]
Angle: [PASTE]
Customer phrases: [PASTE]
Product facts I can prove: [PASTE]
Offer and guarantee: [PASTE]
Claim boundary: [PASTE]
Landing page first screen, word for word: [PASTE]

Write:
1. Short: 1 to 2 lines. The first line does all the work.
2. Medium: 3 to 5 lines, problem, product, proof, offer.
3. Long: a story in 6 to 10 short lines, using the customer phrases.
4. List-style: 3 to 5 lines starting with a simple mark, one benefit per line.
5. Objection-led: opens by naming the main objection and answering it.

For each:
- The first line must make sense on its own, because it is what shows before "See more".
- Every claim tagged with the fact it rests on.
- Every promise must be answered on the landing page first screen I pasted. Flag any that is not.

Rules: plain words, short sentences, no hashtags, no emoji walls. Nothing outside the claim boundary.
```

**What good output looks like:** five variants with clearly different lengths and structures, a strong first line each, and a flag on any promise the page does not answer. Fix the flags before launch, or run them through `message-match-checker`.

---

## P26 Headline and Description Set

**When to use it:** you need the headline and description fields under Meta ads, or text for carousel cards. Used in playbooks 09 and 12.

```
Write headlines and descriptions for [PRODUCT] ads.

Angle: [PASTE]
Offer: [PASTE]
Guarantee: [PASTE]
Top objection: [PASTE]
Claim boundary: [PASTE]

Write:
1. 10 headlines, each 6 words or fewer. Mix: offer-led, benefit-led, objection-answering, product-name-led.
2. 5 descriptions, each 8 words or fewer, each doing a different job from the headline it would sit under (for example shipping, guarantee, or a proof point).
3. 3 suggested pairs of headline and description, and why they work together.

Rules: nothing outside the claim boundary. No all caps. No invented discounts.
```

**What good output looks like:** short, varied headlines, descriptions that add a second reason to click, and three tidy pairs.

---

## P27 Google Responsive Search Ad Assets

**When to use it:** building or rewriting Google Search ads. Google's responsive search ads take up to 15 headlines of 30 characters and up to 4 descriptions of 90 characters. Used in playbooks 09 and 12.

```
Write Google responsive search ad assets for one ad group.

Ad group theme and its main keywords: [PASTE]
Product facts I can prove: [PASTE]
Offer, shipping and guarantee: [PASTE]
Top 3 objections, in buyer words: [PASTE]
Brand name: [NAME]
Claim boundary: [PASTE]

Write:
1. 15 headlines, each 30 characters or fewer including spaces. Print the character count beside each. Include: 3 with the main keyword, 2 with the brand name, 3 benefit lines, 3 offer or shipping lines, 2 objection answers, 2 calls to action.
2. 4 descriptions, each 90 characters or fewer including spaces, with the count beside each.
3. Suggest which 1 or 2 headlines to pin to position 1, if any, and say that pinning reduces the combinations Google can test.

Rules: count characters exactly and rewrite any line over the limit. No claims outside the boundary. No superlatives I cannot prove.
```

**What good output looks like:** fifteen headlines and four descriptions, every one with a character count under the limit, grouped by job. Recount two or three by hand; if any count is off, ask Claude to recount all of them.
