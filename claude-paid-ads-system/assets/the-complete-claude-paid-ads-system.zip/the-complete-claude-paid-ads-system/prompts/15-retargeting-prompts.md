# Retargeting prompts (P38 to P39)

Retargeting ads can take credit for buyers who were coming back anyway, so every retargeting decision in this kit is checked against blended numbers too. Run `roas-vs-mer-reader` before you add retargeting budget.

---

## P38 Retargeting Journey Map

**When to use it:** you want retargeting built around where people dropped off, with a message for each step. Used in playbook 14.

```
Map a retargeting journey for [BRAND].

Retargeting pools available (from P33), with their size if known: [PASTE]
Top objections by stage, from support tickets, surveys or exit polls: [PASTE]
Offer, guarantee, shipping terms: [PASTE]
Creative I already have: [LIST]
Current retargeting spend per month and share of total spend: [$ / %]

Do this:
1. A table by stage: visited product page, added to cart, started checkout, bought once. For each: window in days, the objection most likely at that stage (cite the input), the message, the format, and the creative to use from my list or [NEEDS: new creative].
2. Frequency cap target per stage and why.
3. What the purchasers stage should sell: a second product, a refill, a bundle, based on my products.
4. How to tell whether retargeting is adding orders: compare total orders and MER in weeks with and without retargeting spend, or hold out a share of the audience. Pick one and describe it in 3 steps.

Rules: no invented objections. No discount in the journey unless I listed it as my offer.
```

**What good output looks like:** a stage table where each message answers an objection you actually have, plus a plain way to check retargeting is adding orders. Build the missing creative with P39.

---

## P39 Retargeting Ads by Objection

**When to use it:** you have retargeting pools but they see the same ads as prospecting. Used in playbook 14.

```
Write retargeting ads, one per objection.

Objections, with counts and quotes: [PASTE]
Proof I have for each (reviews, guarantee, demos, comparisons, shipping facts): [PASTE]
Formats I can make this week: [static / short video / carousel]
Claim boundary: [PASTE]

Do this, per objection:
1. The ad: first line, body of 2 to 4 short lines, headline, and what the creative shows.
2. The proof it uses, cited.
3. Which retargeting pool it runs to, and in which window.

Rules: each ad answers one objection. No new claims. No countdowns or fake scarcity.
```

**What good output looks like:** one ad per objection, each with a cited proof and a named pool. The objection with the highest count gets its ad made first.
