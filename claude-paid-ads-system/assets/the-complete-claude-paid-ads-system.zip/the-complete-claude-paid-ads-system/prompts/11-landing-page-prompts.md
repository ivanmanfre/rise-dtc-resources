# Landing Page prompts (P28 to P30)

For a fixed 48-point audit of a page taking paid traffic, run the `cro-auditor` skill. For a promise-by-promise check between ad and page, run `message-match-checker`. These prompts build or rewrite the page itself.

---

## P28 Landing Page Outline From the Ad

**When to use it:** you are sending an angle to a dedicated landing page (or rebuilding the product page) and want the page to continue the ad's argument. Used in playbook 10.

```
Outline a landing page that continues this ad.

The ad, primary text and script or visual description: [PASTE]
Angle: [PASTE]
Customer objections, in the order they come up most, with counts: [PASTE]
Product facts and proof I have (reviews count, guarantee, certifications, press, demos): [PASTE]
Offer: [PASTE]
Traffic split by device, from Shopify or analytics: [% mobile / % desktop]

Do this:
1. The first screen on mobile: headline, subhead, image, price and offer, button. The headline must repeat or answer the ad's main promise.
2. The sections below it, in order. For each: its job, the objection it retires, and the proof it uses.
3. Where the second and third buy buttons go.
4. What to cut from the current page (if I pasted it) because no objection needs it.

Rules: only proof I supplied. Order sections by the objection counts I gave, most common first. Where there is no proof for an objection, print [NEEDS: proof for objection X].
```

**What good output looks like:** a mobile-first outline where the headline echoes the ad, each section tied to a named objection, and gaps printed as `[NEEDS:]`. Compare its order with the `convert-03-objection-order-writer` agent if you have support tickets to feed it.

---

## P29 Rewrite the First Screen

**When to use it:** your ads get clicks, the page gets few add-to-carts, and the first screen is mood copy. Used in playbook 10.

```
Rewrite the first screen of my product page on mobile.

Current first screen, word for word, top to bottom: [PASTE]
The ad sending the most traffic here: [PASTE]
Customer phrases: [PASTE]
Product facts, offer, price, guarantee: [PASTE]
Numbers for the last [30] days: sessions [N], add to carts [N], orders [N]

Do this:
1. Add-to-cart rate = add to carts / sessions and conversion rate = orders / sessions. Show both.
2. What the current first screen fails to say: what it is, who it is for, why it beats the alternative, what it costs, why trust it.
3. Three rewrites of headline, subhead, 3 bullet benefits and button text. Each line must cite the input it rests on.
4. Which rewrite matches the ad's promise most closely, and why.

Rules: no line without an input behind it. Where you need a fact I did not give, print [NEEDS: ...].
```

**What good output looks like:** two rates you can check, a clear list of what is missing, and three rewrites with every line sourced. Test the rewrite only if traffic supports it: size it with `convert-04-landing-test-sizer` first.

---

## P30 Objection-Handling FAQ Block

**When to use it:** support keeps answering the same pre-purchase questions and you want them answered on the page. Used in playbooks 02 and 10.

```
Write the FAQ block for my product page from real customer questions.

Pre-purchase questions from support tickets, chat and DMs, word for word: [PASTE AT LEAST 20]
Return reasons: [PASTE]
Product facts, shipping, returns and guarantee policy: [PASTE]

Do this:
1. Group the questions, count each group, sort most asked first.
2. Write one FAQ per group: the question in the customer's words, the answer in 2 to 3 short sentences using only my facts.
3. Mark the 3 questions that should move out of the FAQ and into the page body above the fold or near the button, because they block the sale.
4. List any question my facts cannot answer as [NEEDS: answer to ...].

Rules: no answers I did not supply the facts for. No legal promises beyond my written policy.
```

**What good output looks like:** a counted, sorted FAQ in customer words, three questions promoted into the page body, and the gaps named. The promoted three are often the fastest page fix available.
