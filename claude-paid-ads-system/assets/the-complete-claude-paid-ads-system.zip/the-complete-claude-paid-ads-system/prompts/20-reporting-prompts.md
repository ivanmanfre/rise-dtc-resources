# Reporting prompts (P49 to P50)

A report in this kit has one job: tell the founder how much money the ads left behind after paying for themselves, and what happens next. If you get reports from an agency, run `track-06-agency-report-reader` on them.

---

## P49 Weekly Margin and Profit Report

**When to use it:** the weekly update to the founder, partner or team. Takes 10 minutes once P47 is done. Used in playbook 18.

```
Write this week's margin and profit report for [BRAND].

Weekly read from P47 (net revenue, spend, MER, contribution after ads, new customers, CAC, per week for 4 weeks): [PASTE]
Break-even MER and affordable CPA: [X / $]
What we changed this week (budgets, new ads, pauses, offers, page changes): [PASTE]
Scale-or-kill verdicts this week (from scale-or-kill-judge): [PASTE]
Stock or cash issues: [PASTE or none]

Write, in this order:
1. One line: contribution after ads this week in dollars, and the change from last week in dollars.
2. A 5-row table: net revenue, ad spend, MER against break-even MER, contribution after ads, new customers and CAC. This week, last week, 4-week average. Show how the 4-week average was computed.
3. What we changed and what we saw after, one line each. Mark anything too recent to judge as TOO EARLY.
4. Ads scaled, held and cut this week, with the count of each.
5. Next week: up to 3 actions, each with the number that will tell us it worked.

Rules: under 250 words outside the table. Platform ROAS appears only as a footnote. No adjectives on results: numbers only. No claims of cause unless a test proved it.
```

**What good output looks like:** a report a founder reads in one minute that opens with profit in dollars. If the first line of the report is ROAS, it was written for the ad platform.

---

## P50 Monthly Founder Report With Decisions

**When to use it:** month end, when budgets, offers and creative plans for next month get set. Used in playbook 18.

```
Write the monthly paid ads report for [BRAND] and the decisions it supports.

This month and the 2 before it: net revenue [$], ad spend [$], MER, contribution after ads [$], new customers [N], CAC [$], returning customer revenue [$], refunds [$], per month: [PASTE]
Break-even MER and affordable CPA, and whether costs changed this month: [PASTE]
Tests run this month and their verdicts (from P36 or the learning log P37): [PASTE]
Creative made and launched: [N]
Next month's contribution target: [$]

Write:
1. Headline: contribution after ads this month in dollars, against target and against last month.
2. A table for the 3 months with every figure above, and each MER beside break-even.
3. Three things we learned, each citing a test with 10 or more purchases per variant.
4. What did not work, with the dollars spent on it.
5. Next month: spend level (from P40), test budget, the 3 tests, creative volume needed, and any offer or page change, each with the number that decides it.
6. One risk to watch (stock, cash, costs, tracking) and the number that would trigger action.

Rules: numbers I gave only. Separate what a test proved from what we believe. No invented benchmarks or comparisons to other brands.
```

**What good output looks like:** one page that starts with profit, shows three months side by side, and ends in decisions with numbers attached. If spend needs to fall fast, the `decide-06-spend-freeze-planner` agent gives the ordered shutdown list.
