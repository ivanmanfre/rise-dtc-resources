# Competitor prompts (P07 to P08)

For the full fixed-format read of up to three competitors, run the `competitor-researcher` skill. Use these two prompts for a quick single-competitor teardown and for the offer and price comparison.

---

## P07 Tear Down a Competitor's Ad Library

**When to use it:** you have a competitor's Meta Ad Library listings open and want to know what they keep paying to run. Used in playbook 03.

```
Tear down this competitor's live ads.

Competitor: [NAME]
Today's date: [DATE]
For each ad, pasted from the Meta Ad Library:
- Started running on: [DATE]
- Format: [video / image / carousel]
- Primary text: [PASTE]
- Headline: [PASTE]
- Landing page URL: [PASTE]
- What the visual shows, in one sentence: [DESCRIBE]
[REPEAT PER AD]

Do this:
1. Days live per ad = today minus start date. Show the subtraction. Sort ads longest running first.
2. For each ad: the angle (one of: problem/solution, mechanism, social proof, comparison, offer, identity, urgency/scarcity, founder/origin), the main claim quoted word for word, the offer if any, and the landing page.
3. Group ads that share an angle and count them.
4. List the angles with zero ads from this competitor.
5. Name the 3 longest-running ads and describe the hook in the first line or first frame of each.

Rules: days live means they keep paying for the ad. Do not say it proves the ad is profitable. No guesses about their spend. Print [NEEDS: ...] if a start date is missing.
```

**What good output looks like:** a sorted table by days live, one angle per ad with the claim quoted, an angle count, and the empty angles. The empty angles go straight into playbook 05.

---

## P08 Map Competitor Offers and Prices Against Yours

**When to use it:** before changing your price, bundle, or free shipping threshold, and whenever a competitor launches a promo. Used in playbooks 03 and 04.

```
Put my offer next to my competitors' offers so I can see where I sit on price and terms.

For me and for each competitor, from the product page as a buyer sees it:
- Brand: [NAME]
- Price: [$]
- Units, servings, or size in the pack: [NUMBER AND UNIT]
- Discount shown: [WORDS AND AMOUNT]
- Subscription discount: [% or none]
- Free shipping threshold and shipping cost below it: [$ / $]
- Guarantee, in the page's own words: [PASTE]
- Bundles offered: [PASTE]
[REPEAT PER BRAND]

Do this:
1. Price per unit = price / units, for each brand, arithmetic shown. Same for the best bundle and the subscription price.
2. Effective first-order price for one pack below the free shipping threshold = price - discount + shipping. Show it.
3. A table with every brand as a row and every term as a column.
4. Where my offer is the most expensive, the cheapest, and the middle on each term.
5. Three offer moves worth pricing in playbook 04, each naming the one term it changes.

Rules: use only the numbers pasted. Do not estimate competitor costs or margins. If units are not comparable (different sizes, different formats), say so and stop that comparison.
```

**What good output looks like:** a price-per-unit column you can check, the effective first-order price, and three one-term offer moves. Take the moves to P10 or the `convert-02-offer-variant-designer` agent to price them against your margin before running anything.
