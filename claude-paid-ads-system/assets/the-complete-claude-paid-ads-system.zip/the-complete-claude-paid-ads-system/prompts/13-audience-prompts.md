# Audience prompts (P33 to P34)

These prompts cover the audience choices you control directly: exclusions, retargeting pool definitions, and Google keywords.

---

## P33 Audience and Exclusion Plan

**When to use it:** setting up or cleaning up audiences, especially when retargeting and prospecting overlap. Used in playbooks 11, 12 and 14.

```
Build an audience and exclusion plan for [BRAND] on Meta.

Current campaigns and the audiences each targets: [PASTE]
Customer lists I can upload: [e.g. all purchasers, purchasers last 180 days, subscribers]
Website events firing: [e.g. view content, add to cart, initiate checkout, purchase]
Average days from first visit to purchase, if known: [N or unknown]
Anti-ICP signals from P03: [PASTE]

Do this:
1. Prospecting: the broad setup, and the exclusions it needs (recent purchasers, current subscribers, existing customers if the goal is new customers).
2. Retargeting pools, each defined by event and window: for example viewed product 1-7 days, added to cart 1-7 days, engaged with video 50% or more 1-30 days. Name each one.
3. Exclusions between retargeting pools so no one sits in two at once.
4. A naming pattern for every audience.
5. Anything in my current setup that overlaps or leaks, and the fix.

Rules: no interest stacks presented as a strategy. No audience sizes unless I pasted them.
```

**What good output looks like:** a short list of named audiences with clear windows and exclusions, and a list of current overlaps to fix. Build the retargeting pools into the journey in P38.

---

## P34 Google Search Keyword and Negative Plan

**When to use it:** building Google Search campaigns, or when search terms reports show spend on queries that never buy. Used in playbooks 09, 12 and 16.

```
Build a keyword and negative keyword plan for [BRAND] on Google Search.

Products and what each solves: [PASTE]
Customer phrases for the problem, from reviews or surveys: [PASTE]
Search terms report for the last [30] days, with cost, clicks, conversions, conversion value: [PASTE]
Affordable cost per purchase: [$]

Do this:
1. Group keywords into ad groups: brand, product name, problem, solution category, comparison. Give 5 to 15 keywords each with the match type.
2. From the search terms report: cost per conversion = cost / conversions for each term, arithmetic shown. List every term with cost above my affordable CPA and zero conversions as a NEGATIVE candidate, and every term above the affordable CPA with conversions as REVIEW.
3. A negative keyword list at account level: jobs, free, DIY, wholesale, and anything in the report that clearly will not buy.
4. Which search terms deserve their own exact-match keyword because they converted under the affordable CPA.

Rules: use only the report I pasted for any performance statement. No search volume estimates.
```

**What good output looks like:** clean ad groups, a negatives list with the cost each term wasted, and a short list of proven terms to add. The wasted-cost total is the number to show the founder.
