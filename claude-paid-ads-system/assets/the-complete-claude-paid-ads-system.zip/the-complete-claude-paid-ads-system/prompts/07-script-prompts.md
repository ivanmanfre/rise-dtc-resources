# Script prompts (P18 to P19)

For a creator script in a fixed five-beat format, use the `ugc-script-writer` skill. These two prompts cover a direct-response script you shoot yourself and a founder-to-camera script.

---

## P18 30-Second Direct Response Video Script

**When to use it:** you have an angle, a hook, and a product you can film in-house or with an editor, and you want a script that sells in 30 seconds. Used in playbook 08.

```
Write a 30-second direct response video script for [PRODUCT].

Angle: [PASTE]
Hook to open with: [PASTE FROM P15]
Customer phrases to use: [PASTE]
Product facts I can prove: [PASTE]
Offer and guarantee: [PASTE]
Claim boundary: [PASTE FROM P14]
Footage I have or can shoot: [LIST]

Do this:
1. A table with columns: seconds, spoken line, on-screen action, text overlay.
2. Structure: hook (0-3s), problem in the buyer's words (3-8s), what the product is and how it works (8-18s), proof (18-24s), offer and call to action (24-30s).
3. Every spoken line under 15 words. Total spoken words under 80.
4. Mark every claim with the fact it rests on.
5. Write 2 alternate proof beats in case the first one cannot be filmed.

Rules: nothing outside the claim boundary. No proof I did not supply. If I gave no reviews, the proof beat uses a demonstration.
```

**What good output looks like:** a second-by-second table you can hand to an editor, under 80 spoken words, every claim tagged. If the proof beat invents a review or a number, reject it.

---

## P19 Founder-to-Camera Script

**When to use it:** the founder is willing to film, and the founder/origin angle is empty in your account. Used in playbook 08.

```
Write a founder-to-camera ad script for [FOUNDER NAME] at [BRAND].

Why the founder started the brand, in their own words (voice note transcript is fine): [PASTE]
The problem the product solves, in customer words: [PASTE]
Product facts I can prove: [PASTE]
Offer: [PASTE]
Length: [30 / 45 / 60] seconds

Do this:
1. Three hook options in the founder's own voice, first person.
2. One script with columns: seconds, spoken line, what the camera shows.
3. Keep the founder's phrasing where it is clear. Cut anything that sounds like a press release.
4. End with one plain call to action and the offer.
5. Mark any line that states a fact and cite which input it came from.

Rules: use only the founder's story as given. No invented hardship, no invented numbers, no dramatised backstory.
```

**What good output looks like:** a script that sounds like the founder talking, with facts tagged and one clear ask. Read it out loud once. If it sounds like an ad voice, cut the lines that do.
