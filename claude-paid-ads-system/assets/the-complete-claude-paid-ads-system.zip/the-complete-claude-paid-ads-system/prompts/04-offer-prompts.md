# Offer prompts (P09 to P11)

Run the `break-even-and-affordable-cpa` skill first. These prompts ask for the contribution per order it gives you.

---

## P09 Build an Offer Stack That Survives the Margin Check

**When to use it:** you are building or rebuilding the offer on your main product and want options that do not give the margin away. Used in playbook 04.

```
Build five offer options for [PRODUCT] and price each one against my margin.

My order economics per order:
- Price: [$]
- Current discount: [$ or %]
- Cost of goods: [$]
- Shipping I pay: [$]
- Pick and pack: [$]
- Processing: [% + fixed fee]
- Contribution per order today: [$] (from break-even-and-affordable-cpa)
- Anything I can add to the box and its cost: [ITEM: $]
- Guarantee today: [TERMS]

The buyer's main objections, quoted: [PASTE 3 TO 5]

Do this:
1. Five offer options. Each changes one or two terms: price, bundle, free gift, guarantee, shipping threshold, subscription. Name which objection each answers.
2. For each: net revenue per order, variable cost per order, contribution per order, contribution %, and break-even ROAS = net revenue / contribution. Show every line.
3. For each: orders needed to match today's total contribution = today's contribution per order / new contribution per order. Show it as a multiplier and as a percent increase.
4. Rank the five by the smallest increase in orders needed.

Rules: no conversion-rate predictions. Print the increase each option needs, never whether it will get it. [NEEDS: ...] for any missing cost.
```

**What good output looks like:** five options, each with contribution and break-even ROAS, and a line like "needs 1.25x the orders to match today". The options that need the smallest lift and answer a real objection go to test in playbook 13.

---

## P10 Price a Discount Before You Run It

**When to use it:** someone wants a sale, a sitewide code, or a Black Friday offer. Run this first. Used in playbooks 04 and 14.

```
Tell me what this discount costs me and how many extra orders it needs.

Price: [$]
Discount being proposed: [% or $]
Cost of goods: [$]
Shipping I pay: [$]
Pick and pack: [$]
Processing: [% + fixed fee]
Orders per day at full price, last 30 days: [N]
Share of those orders that would have happened without the discount (my best guess, and I will label it a guess): [%]

Do this:
1. Contribution per order at full price and at the discounted price. Show each line.
2. Multiplier = full-price contribution / discounted contribution. This is how many discounted orders replace one full-price order.
3. Daily orders needed during the discount to match today's daily contribution = today's daily orders x multiplier.
4. The cost of giving the discount to buyers who would have paid full price = my guessed share x daily orders x (full-price contribution - discounted contribution). Label it as resting on my guess.
5. Break-even ROAS at full price and at the discounted price, side by side.

Rules: no predictions of how many orders the sale will bring. Show the bar it has to clear.
```

**What good output looks like:** two contribution figures, a multiplier (for example "each discounted order is worth 0.6 of a full-price one, so you need 1.67x the orders"), the break-even ROAS rising in the same table, and the cost of discounting buyers who were already coming. That last line is the one most sales forget.

---

## P11 Design Bundles That Raise Contribution per Order

**When to use it:** your contribution per order is thin because shipping and pick-and-pack are fixed costs spread over one small item. Used in playbooks 04 and 14.

```
Design bundles that raise contribution per order for [BRAND].

Products, one per line: [NAME, price, cost of goods, weight or size if it changes shipping]
Shipping I pay per order: [$ for 1 item, $ for 2-3 items, $ for 4+ items]
Pick and pack per order: [$ base + $ per extra item]
Processing: [% + fixed fee]
Current top 3 products bought together (from Shopify): [PASTE]
Current average order value: [$]

Do this:
1. Propose 4 bundles built on items customers already buy together first, then on items that answer the same problem.
2. For each: bundle price, bundle cost of goods, shipping, pick and pack, processing, contribution in $ and %, and break-even ROAS. Show the arithmetic.
3. For each: contribution per order compared to today's single-item order, in dollars.
4. Suggest a bundle discount for each that still leaves contribution per order higher than today's single item, and show the maximum discount allowed.

Rules: only use products and costs I pasted. No claims about how many customers will choose the bundle.
```

**What good output looks like:** four bundles with contribution per order and a maximum allowed discount each. The best ones spread fixed shipping and packing over more margin, and the arithmetic shows it.
