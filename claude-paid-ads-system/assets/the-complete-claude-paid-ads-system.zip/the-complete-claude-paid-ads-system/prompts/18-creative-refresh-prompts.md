# Creative Refresh prompts (P45 to P46)

Use these with `winner-iteration-planner` (or the `creative-05-winner-iteration-planner` agent) and the `creative-06-creative-capacity-planner` agent.

---

## P45 Diagnose Creative Fatigue From Your Rows

**When to use it:** cost per purchase on a long-running ad is rising and you need to know whether the creative is tired or something else changed. Used in playbooks 14 and 17.

```
Tell me whether this ad is fatigued or whether something else changed.

Ad name: [NAME]
Weekly rows since launch: week, spend [$], impressions [N], reach [N], clicks [N], purchases [N], 3-second video views if video [N]
Changes to the campaign in the same period (budget, audience, bids, landing page, price, stock-outs, promotions): [PASTE]

Do this, per week:
1. Frequency = impressions / reach
2. CTR = clicks / impressions
3. CPM = spend / impressions x 1000
4. Conversion rate = purchases / clicks
5. Cost per purchase = spend / purchases
6. Hook rate = 3-second views / impressions, if video
Show each division.

Then:
- FATIGUE if frequency rises while CTR and hook rate fall and conversion rate holds.
- AUCTION if CPM rises while CTR holds.
- PAGE OR OFFER if CTR holds and conversion rate falls.
- CONFOUNDED if a listed change lines up with the drop.
Name the pattern that fits, cite the weeks, and say what to do next.

Rules: fewer than 3 weeks of rows is NOT ENOUGH DATA. No guessing past the rows.
```

**What good output looks like:** a week-by-week table and one named pattern with the weeks that show it. Fatigue points to P46. Auction points to playbook 15. Page or offer points to playbook 10.

---

## P46 Refresh Plan for a Tired Winner

**When to use it:** P45 says FATIGUE on an ad that made you money, and you want new versions without losing what worked. Used in playbook 17.

```
Plan a refresh for this fatigued winner.

The ad: script or copy word for word, and what the visual shows: [PASTE]
What made it win, if known (hook, creator, angle, offer): [PASTE]
Variations already tried and their results: [PASTE]
Creative capacity this week: [e.g. 2 edits, 1 new shoot, 4 statics]
Claim boundary: [PASTE]

Do this:
1. Split the ad into its parts: hook, first frame, creator, angle, proof, offer, format, music or voice, length.
2. Propose 8 refreshes, grouped:
   - Light (edit only): new hook, new first frame, new overlay, new length cutdown
   - Medium: same script, new creator; same angle, new format
   - Heavy: same angle, new concept
3. For each, the one part that changes and what it costs to make.
4. Fit the list to my capacity, light first.
5. Skip anything already tried.

Rules: keep the angle and proof that won. Change one part per refresh. Stay inside the claim boundary.
```

**What good output looks like:** eight refreshes, each changing one named part, ordered cheapest first and trimmed to your capacity. Each one goes in as its own ad so you can read it with `scale-or-kill-judge`.
