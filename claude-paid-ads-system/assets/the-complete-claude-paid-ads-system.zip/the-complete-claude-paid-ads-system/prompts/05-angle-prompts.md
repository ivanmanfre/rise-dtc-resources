# Angle prompts (P12 to P14)

Run the `angle-gap-mapper` skill (or the `creative-01-angle-gap-mapper` agent) on your live ads first. It tells you which of the eight angles you already run. These prompts build new angles for the empty slots.

The eight angles used across this kit: problem/solution, mechanism, social proof, comparison, offer, identity, urgency/scarcity, founder/origin.

---

## P12 Generate Angles From Customer Language

**When to use it:** you have a customer language bank (from `customer-researcher`, P04 or P06) and a list of angles nobody on your account runs. Used in playbook 05.

```
Build new ad angles for [PRODUCT] from my customers' own words.

Customer language bank (benefits, objections, before and after states, phrases), pasted from customer-researcher or my own notes:
[PASTE]

Product facts I can prove: [PASTE]

Angles already running in my account: [PASTE FROM angle-gap-mapper]
Angles nobody runs: [PASTE]

Do this:
1. Write 8 angles, at least 5 of them in the angles nobody runs. Each angle gets:
   - The angle type from the eight-angle list
   - A one-sentence angle statement: who, what problem, what changes
   - The customer quote it rests on, word for word
   - The product fact that backs the claim, word for word
   - The objection it answers
2. Mark any angle that needs proof I have not supplied as NEEDS PROOF and name the proof.
3. Rank the 8 by how many customer quotes support them, count shown.

Rules: every angle must trace to a quote and a fact I pasted. No new claims.
```

**What good output looks like:** eight angles, each with a quote and a fact attached, ranked by count. An angle with a count of one is a hunch. Brief the top three.

---

## P13 Match Angles to Segments

**When to use it:** you have more than one customer segment and need to know which angle to point at whom. Used in playbooks 02 and 05.

```
Match my angles to my customer segments.

Segments, with their top reasons to buy and top objections quoted:
[PASTE FROM P01 OR P02]

Angles, one per line with the quote and fact behind each:
[PASTE FROM P12]

Contribution per customer by segment, if known: [PASTE]

Do this:
1. A grid: segments as rows, angles as columns. In each cell write STRONG, WEAK or NONE, and cite the quote from that segment that justifies it.
2. For each segment, pick the one best angle and the one best backup.
3. Put the highest-contribution segment first and say which angle to brief for it this week.

Rules: a cell is STRONG only if a quote from that segment supports it. No guessing.
```

**What good output looks like:** a filled grid with citations and one clear "brief this first" line pointed at the segment worth the most money.

---

## P14 Check an Angle's Claims Before You Brief It

**When to use it:** before any angle becomes a brief, script or ad. Cheap insurance against ad rejections and claims you cannot back. Used in playbooks 03, 04, 05 and 07.

```
Check every claim in this angle before I brief it.

Angle statement: [PASTE]
Draft lines I want to use: [PASTE]
Product facts, with the source of each (lab report, supplier spec, review count from my store, guarantee terms): [PASTE]
Category: [e.g. supplements, skincare, apparel, home]

Do this:
1. List every claim in the angle and draft lines, one per row.
2. Mark each claim SUPPORTED (quote the fact and source), PARTIAL (say what extra proof is needed) or UNSUPPORTED.
3. Flag any claim that touches health outcomes, before and after results, personal attributes of the viewer, money outcomes, or time-bound results, as POLICY RISK, and write a replacement line built only from supported facts.
4. Print the claim boundary: the list of things this ad may say, and the list it may not.

Rules: do not soften a claim into something vaguer that is still unsupported. Replace it with a supported fact or cut it.
```

**What good output looks like:** a row per claim with a verdict and a quoted source, replacement lines for risky ones, and a two-column claim boundary. Paste the boundary into P23 and the `ad-brief-generator` skill. For a full policy read on finished copy, run `spend-04-policy-risk-checker`.
