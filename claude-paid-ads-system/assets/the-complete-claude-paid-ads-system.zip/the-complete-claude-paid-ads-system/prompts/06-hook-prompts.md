# Hook prompts (P15 to P17)

The `hook-generator` skill (and the `creative-03-ad-hook-writer` agent) writes up to twelve opening lines from twelve fixed devices, each tied to a fact. Use these prompts when you need hooks built from customer language, hooks cut from a winner, or text for the first frame.

---

## P15 Write Hooks for One Angle

**When to use it:** you have one angle picked and want spoken and written opening lines built from what customers actually say. Used in playbook 06.

```
Write 15 hooks for one angle.

Angle: [ANGLE STATEMENT]
Audience in one sentence, in their words: [PASTE]
Customer phrases to draw on, quoted: [PASTE 5 TO 10]
Product facts I can prove: [PASTE]
Claim boundary (what this ad may and may not say): [PASTE FROM P14]
Format: [video / static / both]

Do this:
1. 15 hooks, each under 12 words, spread across these forms: a question the buyer asks themselves, a callout of the buyer, a before state, a blunt claim, a number, a comparison to what they tried, a line quoted from a customer.
2. Tag each hook with its form, the customer phrase or fact it rests on, and the objection it opens.
3. For video hooks, add the first-frame visual in one sentence.
4. Mark the 3 you would test first and say why in one line each.

Rules: every hook stays inside the claim boundary. No hook may promise a result the facts do not support. No clickbait that the ad then fails to pay off.
```

**What good output looks like:** fifteen short lines, each traceable to a quote or fact, grouped by form, with three picked. If two hooks say the same thing in different words, they count as one.

---

## P16 Rewrite Hooks From a Winning Ad

**When to use it:** one ad is winning and you want new openings on the same body, so the test reads the hook alone. Used in playbooks 06 and 17.

```
Write 8 new hooks for a winning ad. The body of the ad stays the same.

The winning ad, transcript or copy word for word: [PASTE]
The current hook (first line or first 3 seconds): [PASTE]
What the first frame shows: [DESCRIBE]
Its numbers for [WINDOW]: spend [$], purchases [N], cost per purchase [$], 3-second view rate or thumb-stop rate if you track it [%]
Hooks already tried against it: [PASTE]

Do this:
1. Say in one sentence what the current hook does: which form, which claim, which buyer.
2. Write 8 new hooks that lead into the same second line of the body without a jump. Change one thing each: the form, the buyer called out, or the claim that opens.
3. For each, name what changed from the original.
4. Skip anything already tried.

Rules: the new hook must be true to the body that follows it. No new claims.
```

**What good output looks like:** eight hooks that each change one named thing, none of them repeats of past tests. Run them as a hook-only test (playbook 13) so the result tells you something.

---

## P17 Write First-Frame Text Hooks

**When to use it:** for the text overlay on a video's first frame or the headline on a static, where the viewer reads before they hear anything. Used in playbook 06.

```
Write on-screen text for the first frame of [AD NAME OR ANGLE].

Angle: [PASTE]
Spoken hook, if video: [PASTE]
Visual in the first frame: [DESCRIBE]
Customer phrases: [PASTE]
Claim boundary: [PASTE]

Do this:
1. 10 overlay lines, each 7 words or fewer.
2. For video, each overlay must add to the spoken hook, never repeat it word for word.
3. Tag each line with the buyer it calls out or the problem it names.
4. Say where each line sits on the frame so it stays clear of the platform's buttons and caption area, top third or middle.

Rules: plain words a buyer would say. No invented numbers. Stay inside the claim boundary.
```

**What good output looks like:** ten very short lines that read in a second, each doing a job the audio does not. Pair the best three with the best spoken hooks from P15.
