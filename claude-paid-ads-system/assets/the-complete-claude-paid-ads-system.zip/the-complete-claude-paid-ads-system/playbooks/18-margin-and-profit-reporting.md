# 18 Margin & Profit Reporting

**What this stage decides:** how much money the ads left behind after paying for themselves, whether that is rising or falling, where the platforms' numbers and your store's numbers disagree, and what happens next week and next month. Every other playbook feeds this one. Reporting here opens with contribution after ads in dollars; platform ROAS is a footnote.

**What you walk away with:** a weekly contribution read, a one-minute weekly report, a monthly report that ends in decisions, and a clear trigger for when spend has to fall.

## Inputs you need

- Current order economics (rerun monthly).
- Weekly and monthly Shopify figures: gross sales, discounts, refunds, orders, new customers.
- Variable costs from your books: cost of goods, shipping, pick and pack, processing, return handling.
- Total ad spend across every channel.
- Platform-reported revenue per channel and each platform's attribution setting.
- Scale-or-kill verdicts, test results and the change log.

## Step by step

1. **Refresh the economics monthly.** Rerun the `break-even-and-affordable-cpa` skill with this month's costs. Supplier price changes, shipping rate changes and a higher return rate all move break-even.

2. **Restate revenue on what you kept.** Run the `decide-05-net-revenue-corrector` agent with gross revenue, discounts, refunds and ad spend for one matched window. It restates return on ad spend on net revenue, with the gross figure beside it.

3. **Find the overlap.** Run the `roas-vs-mer-reader` skill with per-channel spend and reported revenue plus your Shopify revenue. It prints MER on the store figure and the overlap gap in dollars. If channels report on different attribution windows, run `track-02-attribution-window-matcher` first. For the analysis in your own words, use **P48 Find Where Platform Revenue and Shopify Disagree**.

4. **Read the week.** Every Monday run **P47 Weekly Contribution Read**: net revenue, MER, contribution after ads, blended new-customer CAC, platform ROAS as a side column.

5. **Write the weekly report.** Run **P49 Weekly Margin and Profit Report**. First line: contribution after ads in dollars and the change from last week.

6. **Write the monthly report.** Run **P50 Monthly Founder Report With Decisions**. It ends with next month's spend level, tests, creative volume and the risk to watch.

7. **Check any agency report.** If someone else reports to you, run the `track-06-agency-report-reader` agent on their report. It lists the claims that cannot be checked from what was supplied and writes the one-line reply asking for the missing figure.

8. **Know your stop trigger.** Run `decide-03-cpa-drift-reader` on cost per purchase over time. If contribution after ads turns negative and stays there, run the `decide-06-spend-freeze-planner` agent: it returns the ordered shutdown list, the one campaign that stays on, and the metric that has to recover.

## The numbers that decide it

**Example numbers (made up for this playbook):** one month.

| Line | Figure |
|---|---|
| Gross sales | $132,000.00 |
| Discounts | $9,000.00 |
| Refunds | $6,000.00 |
| **Net revenue** | $132,000.00 - $9,000.00 - $6,000.00 = **$117,000.00** |
| Variable costs (cost of goods, shipping, pick and pack, processing, return handling) | $61,200.00 |
| **Contribution before ads** | $117,000.00 - $61,200.00 = **$55,800.00** |
| Contribution margin | $55,800.00 / $117,000.00 = 47.69% |
| Total ad spend | $30,000.00 |
| **Contribution after ads** | $55,800.00 - $30,000.00 = **$25,800.00** |
| MER | $117,000.00 / $30,000.00 = 3.90 |
| Break-even MER | $117,000.00 / $55,800.00 = 2.10 |

Platform-reported revenue: Meta $82,000.00 plus Google $51,000.00 = $133,000.00.

- Overlap: $133,000.00 - $117,000.00 = $16,000.00, which is $16,000.00 / $117,000.00 = 13.7% of net revenue
- Blended platform ROAS: $133,000.00 / $30,000.00 = 4.43, against MER on real revenue of 3.90

The platforms together claim $16,000.00 more revenue than the store kept, before counting any orders that would have come without ads. The report leads with $25,800.00 of contribution after ads and MER of 3.90 against a break-even of 2.10. The 4.43 goes in a footnote.

**The first line of the weekly report**, from these numbers, reads like this: "Contribution after ads this week: $6,120.00, up $410.00 on last week." (Weekly figures here are examples.) Anyone can read that in five seconds and know whether the ads made money.

## Common mistakes

- **ROAS as the headline.** A report that opens on platform ROAS tells the founder what the platform thinks. Open on contribution after ads in dollars.
- **Gross revenue.** Discounts and refunds are money you never kept. Report on net revenue.
- **Stale costs.** A break-even calculated last year on last year's shipping rates will be wrong. Refresh it monthly.
- **Adding platform revenues together.** Each platform counts orders the others also count. Compare their sum with the store figure and report the gap.
- **Reports without decisions.** Every weekly and monthly report ends with actions and the number that will show whether each one worked.
- **Claiming causes a test did not prove.** "Revenue rose because of the new hook" needs a test with 10 or more purchases per variant behind it. Otherwise write what changed and what was seen, and leave the cause open.

**Back to the start:** the monthly report sets next month's targets, which sends you back to playbooks 04 and 15 with fresh numbers.
