# 08 UGC & Static Ads

**What this stage decides:** which formats each angle ships in, how they get made, and how much each usable ad costs to produce. Statics are usually the fastest and cheapest way to test whether an angle has pull. UGC and in-house video usually carry more of the argument. Most accounts need both, made in sets that can be tested cleanly.

**What you walk away with:** for each angle, at least one static set and one video with several hook versions, all inside the claim boundary, named and ready for the test campaign.

## Inputs you need

- Briefs from playbook 07, each with a claim boundary.
- Hooks and first-frame text (playbook 06).
- Customer reviews, word for word, with your store's review count and rating.
- Creators booked, or the founder willing to film.
- Product photos and brand assets.

## Step by step

1. **Screen angles with statics first.** For each new angle, run **P20 Static Ad Concept Set for One Angle** for six concepts in different layouts. If the comparison angle is open, add **P21 Comparison Static Ad**. If you have reviews, add **P22 Review-Led Static Ads From Real Reviews**, which keeps every quote word for word.

2. **Script the video.** For a creator, use the `ugc-script-writer` skill: one five-beat script with spoken line, action, overlay and seconds for each beat. For in-house footage, use **P18 30-Second Direct Response Video Script**. If the founder will film and the founder/origin angle is empty, use **P19 Founder-to-Camera Script**.

3. **Brief the creator.** Send **P23 UGC Creator Brief**. Ask for three to five hook takes, one body take, b-roll, and raw files with no captions or music burned in.

4. **Plan the edit.** When footage comes back, run **P24 Edit Plan From Raw UGC Footage**. It gives a timestamped edit list per ad and flags any line that breaks the claim boundary.

5. **Check policy before upload.** Run finished copy and scripts through the `spend-04-policy-risk-checker` agent. It names the policy family each claim falls under and writes a replacement line built only from your facts.

6. **Ship in sets.** Each angle goes out as one static set plus one video with its hook versions. Every version is its own ad, named with the pattern from playbook 07, so the test in playbook 13 reads one variable.

## The numbers that decide it

The number to watch is the cost of finding one winner, which includes production and the spend needed to read each ad.

**Example numbers (made up for this playbook):**

- UGC: creator fee $300.00 for three hook takes, a body and b-roll; editing $150.00. The edit yields 3 hook versions and one 15-second cutdown, so 4 ads. Production per ad: ($300.00 + $150.00) / 4 = $112.50.
- Static: designer time $40.00 per finished static.
- Spend to read one ad at the example affordable CPA of $24.20: 10 purchases x $24.20 = $242.00.

Say one ad in five you test turns into a winner. That hit rate is an example assumption; track your own in the learning log (**P37 Build the Learning Log**) and replace it.

- Cost to find one UGC winner: 5 x ($112.50 + $242.00) = 5 x $354.50 = $1,772.50
- Cost to find one static winner: 5 x ($40.00 + $242.00) = 5 x $282.00 = $1,410.00

With these example numbers, a static winner is cheaper to find, so statics make sense as the first screen of an angle. Once an angle proves itself, video usually earns its higher cost by carrying more proof. Your own hit rates by format decide the mix, and after two months of logging you will have them.

**Monthly production volume.** If you can read 5 new ads a week (playbook 07), you need about 5 x 4 = 20 finished ads a month. At the mix of 8 UGC and 12 statics: (8 x $112.50) + (12 x $40.00) = $900.00 + $480.00 = $1,380.00 production for the month.

## Common mistakes

- **Polished brand films as direct response ads.** A beautiful video that never states the problem, the product and the offer is hard to read as a test.
- **Creators going off-script on claims.** Talking points are fine; results claims the creator has not had are not. Send the must-not-say list and cut any breach in the edit.
- **Captions and music burned in.** You lose the ability to re-edit hooks, swap overlays, and cut new lengths. Ask for clean files.
- **No usage rights.** Get written rights for paid use and the length of use before the shoot.
- **Rewording reviews.** A review quote in an ad must be the customer's own words. Cutting is fine if the meaning stays.
- **Before and after body images.** Ad platform policies restrict them in health and appearance categories. Run anything close to that line through `spend-04-policy-risk-checker`.

**Next:** playbook 09 writes the copy that sits around these ads.
