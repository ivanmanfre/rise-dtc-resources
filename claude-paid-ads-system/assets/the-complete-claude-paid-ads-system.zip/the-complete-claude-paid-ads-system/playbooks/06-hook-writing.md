# 06 Hook Writing

**What this stage decides:** the first line, or first three seconds, of each ad, and which openings get tested against each other. A hook earns the next few seconds of attention. The rest of the ad has to pay off what the hook promised, or the clicks it earns will not buy.

**What you walk away with:** three to five hooks per angle, each tied to a fact or customer phrase, with on-screen text for the first frame, ready to film as separate takes on one body.

## Inputs you need

- One angle statement from playbook 05, and its claim boundary.
- The audience in one sentence, in their words.
- Customer phrases from the language bank.
- Product facts you can stand behind.
- For iteration: your current winning ad and the hooks already tried against it.

## Step by step

1. **Work one angle at a time.** Hooks written for three angles at once blur together.

2. **Get the device set.** Run the `hook-generator` skill (or the `creative-03-ad-hook-writer` agent) with the angle, the facts and the audience sentence. It writes up to twelve opening lines from twelve fixed devices, each tagged with the fact it rests on, and names the devices it could not write for lack of a fact.

3. **Add customer-language hooks.** Run **P15 Write Hooks for One Angle** with your customer phrases. These often sound more like the buyer than anything written from product facts.

4. **Write the first-frame text.** Run **P17 Write First-Frame Text Hooks**. The text on screen should add to the spoken line, because some viewers watch with the sound off.

5. **Cut to three to five.** Remove duplicates (two lines that say the same thing are one hook), anything outside the claim boundary, and any hook the body of the ad does not pay off.

6. **Film all hooks on one body.** In the brief (playbook 07) and the creator brief (**P23 UGC Creator Brief**), each hook is a separate take. One shoot gives you several ads that differ only in the opening.

7. **Test hook against hook.** Put the hook versions in one test (playbook 13) with everything else identical.

8. **Iterate from winners.** When a hook wins, run **P16 Rewrite Hooks From a Winning Ad** for the next round.

## The numbers that decide it

**Hook rate** is the early screen for video: 3-second video views divided by impressions.

**Example numbers (made up for this playbook):** two hooks on the same body, 40,000 impressions each.

- Hook A: 10,400 3-second views. Hook rate = 10,400 / 40,000 = 26.0%
- Hook B: 9,200 3-second views. Hook rate = 9,200 / 40,000 = 23.0%

Hook rate tells you which opening holds attention. The decision is still made on cost per purchase, because a hook can win attention from people who will never buy.

**Why the cheapest click can be the most expensive purchase.** Cost per purchase = CPM / (1,000 x CTR x conversion rate).

- Honest hook: CPM $12.00, CTR 1.8%, conversion rate 3.0%. Cost per purchase = $12.00 / (1,000 x 0.018 x 0.030) = $12.00 / 0.54 = $22.22
- Clickbait hook: CPM $12.00, CTR 2.0%, conversion rate 2.0%. Cost per purchase = $12.00 / (1,000 x 0.020 x 0.020) = $12.00 / 0.40 = $30.00

The clickbait hook wins on CTR and loses on cost per purchase. Against the example affordable CPA of $24.20, the honest hook makes money and the clickbait hook does not.

**What a hook test costs.** Four hooks, each read at 10 purchases, at an affordable CPA of $24.20: 4 x 10 x $24.20 = $968.00 minimum. If that is more than your test budget allows this month, test three.

## Common mistakes

- **Hooks the ad does not pay off.** A hook promising a result the body never shows raises CTR and lowers conversion rate, as the arithmetic above shows.
- **Testing hooks on different bodies.** If the body changes too, you cannot tell which change moved the number.
- **Judging on CTR or hook rate alone.** Both are early signals. Cost per purchase against your affordable CPA decides.
- **One hook per ad concept.** Filming one opening wastes the shoot. Always film three to five takes of the opening.
- **Writing from product facts only.** The buyer's own phrase for the problem is often a stronger opening than any feature.
- **Stretching a fact.** Every noun and number in a hook needs to trace back to your fact list. The `hook-generator` skill enforces this; hand-written hooks need the same read-back.

**Next:** playbook 07 turns the angle and hooks into briefs that can be shot without a follow-up call.
