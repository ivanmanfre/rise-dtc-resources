# 04 Offer & Positioning

**What this stage decides:** what you sell, at what price, with what bundle, guarantee and shipping terms, and the one sentence that says why a buyer should pick you over the alternative. It also sets the two numbers every later stage buys against: break-even ROAS and the cost per purchase you can afford.

**What you walk away with:** contribution per order, break-even ROAS, break-even CPA, affordable CPA, a positioning line, and one or two offer changes priced and ready to test.

## Inputs you need

- Eight order economics lines: average order value before discount, average discount per order, cost of goods, processing (percent and fixed fee), shipping you pay, pick and pack, return rate, cost of one return.
- The offer and price map from playbook 03.
- The ranked objections from playbook 02.
- Your product catalogue with cost of goods per item.

## Step by step

1. **Run the unit economics first.** Paste your eight lines into the `break-even-and-affordable-cpa` skill. It returns contribution per order, break-even ROAS, break-even CPA, the same three after returns, and the CPA you can afford at the contribution you want left. Nothing else in this playbook runs until you have these.

2. **Write the positioning line.** Fill in: for [ICP segment] who [trigger from playbook 02], [product] is the [category] that [difference backed by a fact]. Run it through **P14 Check an Angle's Claims Before You Brief It**. If the difference fails the check, pick a different one.

3. **See where you sit.** Take the table from **P08 Map Competitor Offers and Prices Against Yours**. Note where you are most expensive and where you are cheapest per unit.

4. **Build offer options.** Run **P09 Build an Offer Stack That Survives the Margin Check**. Each option answers a named objection and prints its contribution and the extra orders it needs.

5. **Price any discount before it runs.** Run **P10 Price a Discount Before You Run It** on every proposed sale or code.

6. **Look at bundles.** Run **P11 Design Bundles That Raise Contribution per Order**. Bundles spread fixed shipping and packing costs over more margin.

7. **Build four one-term variants.** Paste your current offer into the `convert-02-offer-variant-designer` agent. It returns four variants that each move one term, with the break-even condition for each printed as arithmetic.

8. **Pick one or two to test.** Choose options that need the smallest lift in orders and answer your top objection. They go into the test plan in playbook 13.

## The numbers that decide it

**Example numbers (made up for this playbook, and used across this kit):**

- Net order value: $80.00
- Cost of goods $24.00, shipping $9.00, pick and pack $3.00, processing $4.00
- Variable cost per order: $24.00 + $9.00 + $3.00 + $4.00 = $40.00
- **Contribution per order:** $80.00 - $40.00 = $40.00, which is $40.00 / $80.00 = 50%
- **Break-even ROAS:** $80.00 / $40.00 = 2.00
- **Break-even CPA:** $40.00

Now returns. 10% of orders come back, and each return loses $18.00 (the $9.00 outbound shipping, the $3.00 pick and pack, and $6.00 return label and handling). Per 100 orders: 90 kept x $40.00 = $3,600.00, minus 10 returned x $18.00 = $180.00, leaves $3,420.00.

- **Returns-adjusted contribution per order:** $3,420.00 / 100 = $34.20, which is 42.75%
- **Returns-adjusted break-even ROAS:** $80.00 / $34.20 = 2.34
- **Returns-adjusted break-even CPA:** $34.20

You want $10.00 left per order after paying for the ad:

- **Affordable CPA:** $34.20 - $10.00 = $24.20
- **Target ROAS:** $80.00 / $24.20 = 3.31

Returns alone moved break-even ROAS from 2.00 to 2.34. A brand running to 2.00 would lose money on every order and never see it in Ads Manager.

**A discount, priced.** Same product at 20% off: net $64.00. Processing drops a little with the price, to $3.20 in this example. Variable cost $24.00 + $9.00 + $3.00 + $3.20 = $39.20. Contribution $64.00 - $39.20 = $24.80. You need $40.00 / $24.80 = 1.61 times the orders to earn the same contribution, 61% more. Break-even ROAS rises to $64.00 / $24.80 = 2.58.

**A bundle, priced.** Two-pack at $150.00: cost of goods $48.00, shipping $10.00, pick and pack $4.00, processing $7.00, variable cost $69.00. Contribution $150.00 - $69.00 = $81.00, or 54%. Break-even ROAS $150.00 / $81.00 = 1.85. One bundle order leaves $81.00 against $40.00 for a single, because shipping and packing barely moved.

## Common mistakes

- **Setting a target ROAS before the unit economics.** A ROAS target copied from a blog or a previous agency is someone else's margin.
- **Forgetting returns.** Run the returns-adjusted numbers. They are the ones you carry into the ad account.
- **Judging an offer on conversion rate alone.** A discount that lifts conversion rate 30% still loses money if it needs 61% more orders.
- **Free shipping thresholds below your average order.** If the threshold sits under what most people spend, it gives away shipping on orders that were coming anyway. Put it just above your average order value and check the bundle arithmetic.
- **Positioning on claims you cannot prove.** The positioning line has to pass the claim check, or every ad built on it inherits the problem.
- **Letting costs go stale.** Rerun step 1 whenever a supplier invoice, shipping rate or 3PL fee changes.

**Next:** playbook 05 picks the angles this offer gets sold through.
