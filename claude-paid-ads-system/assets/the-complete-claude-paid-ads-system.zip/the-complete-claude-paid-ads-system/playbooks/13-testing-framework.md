# 13 Testing Framework

**What this stage decides:** what gets tested, with how much money, by what rule a variant wins, loses or gets more time, and how results are recorded so they add up. The rules are written before the test runs, so the verdict at the end is arithmetic and nobody argues about it.

**What you walk away with:** a ring-fenced monthly test budget, a test matrix, a written plan per test with dollar kill and read lines, verdicts from `scale-or-kill-judge`, and a learning log.

## Inputs you need

- Affordable CPA (playbook 04).
- Monthly ad budget.
- The ads, hooks, angles, offers or pages you want to test.
- Per-ad spend and purchase rows from Ads Manager for the test window.
- A change log: every budget, audience, page, price or offer change with its date.

## Step by step

1. **Ring-fence the money.** Run the `spend-06-test-budget-ringfencer` agent. It splits the month into proven money and test money and prints how many decisions the test money can buy.

2. **Build the matrix.** Run the `creative-04-test-matrix-builder` agent with what you want to test. It returns a row-by-row matrix and prints the question the matrix cannot answer underneath, which stops you reading more into a result than it holds.

3. **Write the plan.** Run **P35 Write a Test Plan With Kill Rules** for each test. It prints the minimum spend per variant, the kill line, the three read lines, the read date, and what nobody may change until then.

4. **Launch in the test campaign.** One variable per test. Everything else identical: same body for hook tests, same creative for copy tests, same audience and budget per variant.

5. **Kill early only on the kill rule.** A variant that spends 2 x your affordable CPA with zero purchases stops. Anything else runs to its read point.

6. **Read at 10 purchases.** Paste the per-ad rows into the `scale-or-kill-judge` skill (or the `decide-01-scale-or-kill-judge` agent) with your affordable CPA. It returns SCALE, HOLD, CUT or NOT ENOUGH SPEND per ad, and never guesses on a row too thin to read.

7. **Check for collisions.** Paste the change log into the `decide-02-change-log-auditor` agent. Any change marked CONFOUNDED means the test cannot be read, whatever the numbers say. Then run **P36 Read a Finished Test** to write down what was learned and what was not.

8. **Graduate and log.** SCALE ads move into the scale campaign. Every result goes into **P37 Build the Learning Log** once a month.

## The numbers that decide it

These are the same bands `scale-or-kill-judge` uses. A is your affordable CPA.

- SCALE: cost per purchase at or under 0.85 x A
- HOLD: above 0.85 x A, up to A
- CUT: above A
- NOT ENOUGH SPEND: fewer than 10 purchases

**Example numbers (made up for this playbook):** A = $24.20.

- SCALE line: 0.85 x $24.20 = $20.57
- HOLD: $20.58 to $24.20
- CUT: above $24.20
- Minimum spend per variant to reach 10 purchases at A: 10 x $24.20 = $242.00
- Kill line with zero purchases: 2 x $24.20 = $48.40

Four hook variants:

| Variant | Spend | Purchases | Cost per purchase | Verdict |
|---|---|---|---|---|
| Hook 1 | $260.00 | 14 | $260.00 / 14 = $18.57 | SCALE |
| Hook 2 | $250.00 | 11 | $250.00 / 11 = $22.73 | HOLD |
| Hook 3 | $255.00 | 10 | $255.00 / 10 = $25.50 | CUT |
| Hook 4 | $52.00 | 0 | none | killed at $48.40 |

**Test budget.** Monthly budget $30,000.00 with 20% ring-fenced for tests (an example share): $30,000.00 x 0.20 = $6,000.00. Reads it buys: $6,000.00 / $242.00 = 24.79, so 24 variant reads a month. That is the ceiling on how many new things you can learn about this month. Real tests usually cost more than the minimum, since some variants run past 10 purchases before the read date.

## Common mistakes

- **Testing several variables at once.** New hook, new creator and new offer in one variant: when it wins, you do not know why, and you cannot repeat it.
- **Reading early.** Three purchases at a great cost per purchase is noise. `scale-or-kill-judge` prints NOT ENOUGH SPEND for a reason.
- **"Directional" winners.** A variant that looks ahead at 5 purchases has not won. Either fund it to 10 or call the test unread.
- **Killing on day two.** Ads often deliver unevenly in the first days. Use the dollar kill line, never the calendar.
- **Touching the campaign mid-test.** A budget change or a new ad set during the test can move results on its own. Log every change and run `decide-02-change-log-auditor`.
- **No log.** Tests that are not written down get rerun six months later. The learning log is what your next brief starts from.

**Next:** playbook 14 builds the retargeting journey that follows up on the people these ads reach.
