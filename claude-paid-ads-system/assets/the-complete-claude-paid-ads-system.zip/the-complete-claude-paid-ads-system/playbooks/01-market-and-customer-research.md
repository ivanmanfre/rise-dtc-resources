# 01 Market & Customer Research

**What this stage decides:** who actually buys from you, why they buy, the words they use, and which customer group is worth paying the most to acquire. Everything later in this kit (angles, hooks, pages, budgets) reads from the output of this playbook. If this stage is guessed, every stage after it is built on the guess.

**What you walk away with:** a one-page research doc holding your ICP, a customer language bank, the top objections with counts, and a maximum acquisition cost per customer group.

## Inputs you need

- A Shopify customer export for the last 90 days: orders per customer, first product bought, order value, discount code used, region.
- At least 15 pieces of customer text: reviews, post-purchase survey answers, support tickets, return reasons, ad comments. More is better.
- Your order economics: price, discount, cost of goods, shipping you pay, pick and pack, processing fee, return rate, cost of one return.
- Optional: 1 to 3 star reviews of the category alternative, and forum or Reddit threads about the problem you solve.

## Step by step

1. **Pull the data once, in one window.** Export 90 days of customers and orders. Write down the total order count; every share you calculate later divides by it.

2. **Build your language bank from your own customers.** Paste 15 or more reviews, survey answers or tickets into the `customer-researcher` skill. It returns benefits, objections, before and after states and ten ad-ready phrases, each counted and quoted. Fewer than 15 items and the counts mean little, so collect more before you run it.

3. **Get a post-purchase survey live if you do not have one.** Run the `track-04-post-purchase-survey-writer` agent to write the question and answer options. If a survey is already running, read it with **P05 Read Your Post-Purchase Survey**.

4. **Listen outside your store.** Run **P04 Mine Competitor Reviews for Unmet Needs** on the category alternative and **P06 Mine Forum and Reddit Threads for Buying Triggers** on the problem. These find the complaints your own happy reviewers never mention.

5. **Segment your customers.** Run **P01 Build Your ICP From Your Own Orders** with the export and the text. Expect 2 to 4 segments, named by what they bought and why.

6. **Price the segments.** Run the `break-even-and-affordable-cpa` skill to get contribution per order, then **P02 Rank Customer Segments by Contribution Margin**. This turns "who buys" into "who is worth paying for".

7. **Write the research doc.** One page: the ICP segment, its CAC ceiling, the ten phrases, the top five objections with counts, and the three biggest gaps between what customers say and what your product page says.

## The numbers that decide it

The decision here is which segment gets your money first. Rank by contribution per customer, including repeat orders, never by order count.

**Example numbers (made up for this playbook):** a store with 1,000 orders in 90 days and two segments.

| | Segment A: single-item buyers | Segment B: bundle buyers |
|---|---|---|
| Orders | 600 | 400 |
| Share of orders | 600 / 1,000 = 60% | 400 / 1,000 = 40% |
| Contribution per first order | $40.00 | $52.00 |
| Reorder within 90 days | 30% | 10% |
| Contribution per reorder | $36.00 | $36.00 |
| 90-day contribution per customer | $40.00 + (0.30 x $36.00) = $50.80 | $52.00 + (0.10 x $36.00) = $55.60 |

Now set how much contribution you want left per customer after paying for the ad. Say $10.00.

- Segment A ceiling: first order only $40.00 - $10.00 = $30.00. With the repeat window $50.80 - $10.00 = $40.80.
- Segment B ceiling: first order only $52.00 - $10.00 = $42.00. With the repeat window $55.60 - $10.00 = $45.60.

Segment A has more orders. Segment B is worth more per customer, and it can carry a $42.00 acquisition cost on the first order alone, where A needs its repeat orders to get past $30.00. If your cash is tight, the first-order ceiling is the one you buy against. The repeat-window ceiling is only safe once your own data proves the repeat share holds.

Checks before you move on:
- Segment shares add to 100% of the order count.
- Every quote in the language bank can be found in your own paste.
- Each segment has a first-order ceiling and a repeat-window ceiling.

## Common mistakes

- **Writing a persona instead of reading data.** "Busy mum, 34, loves yoga" with no row behind it sends every later stage in the wrong direction. If a trait is not in your export or your text, leave it out.
- **Ranking segments by size.** The largest segment is often the cheapest to reach and the least valuable. Rank by contribution per customer.
- **Counting on repeat orders you have not measured.** Use your own reorder share. If you do not have 90 days of it yet, price on the first order.
- **Only reading happy customers.** Reviews on your own store come from people who chose to leave one. Support tickets, return reasons and competitor reviews carry the objections that stop sales.
- **Doing this once.** Rerun steps 2 and 6 every quarter, and whenever costs change. A segment's ceiling moves every time your cost of goods or shipping does.

**Next:** playbook 02 turns the language bank into the reasons people buy, wait, and walk away.
