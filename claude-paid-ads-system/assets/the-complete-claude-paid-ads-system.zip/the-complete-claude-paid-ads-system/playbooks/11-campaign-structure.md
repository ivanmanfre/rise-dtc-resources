# 11 Campaign Structure

**What this stage decides:** how many campaigns and ad sets your budget can support, what goes in each, how test money is kept apart from proven money, and how everything is named. A structure that splits the budget too thin keeps every ad set starved of data, and nothing gets a clean read.

**What you walk away with:** a structure sized to your budget and affordable CPA, a naming pattern, test and scale campaigns separated, and a fix list for anything broken in the current account.

## Inputs you need

- The current campaign and ad set list as it reads on the Ads Manager screen, with spend and results.
- Monthly ad budget.
- Affordable CPA (playbook 04).
- Products or collections to advertise, with contribution per order each.
- Your tracking links.

## Step by step

1. **Audit what is live before changing anything.** Paste the campaign and ad set list into the `ad-account-hygiene-auditor` skill. It returns a 24-point verdict, the wasted spend summed from your own rows, and a fix list naming the exact campaign or ad set. On an account new to you, this runs first.

2. **Check the links.** Run the `utm-tag-auditor` skill (or the `track-01-utm-tag-auditor` agent) on every destination URL. A BREAK means that traffic reports as direct or unassigned, which hides what the ads bought.

3. **Size the structure to the budget.** Run **P31 Account Structure Plan**. It works out how many purchases your budget buys per week and how many ad sets that can support, using the arithmetic below.

4. **Fix the names.** Pick one pattern, for example `market_objective_audience_angle_format_date`. Run the `track-05-campaign-naming-fixer` agent to get a rename map. Names that carry the test variable make every later read faster.

5. **Separate test money from proven money.** Run the `spend-06-test-budget-ringfencer` agent to split the month. Give tests their own campaign so a new ad does not steal delivery from a proven winner, and winners graduate into the scale campaign once `scale-or-kill-judge` says SCALE.

6. **Set exclusions.** Run **P33 Audience and Exclusion Plan** so prospecting excludes recent purchasers and retargeting pools do not overlap.

7. **Write it down.** One page: each campaign, its job, its budget, its audience, what goes in it, and what gets it switched off.

## The numbers that decide it

Meta's help center says an ad set generally needs around 50 optimization events in a week to exit the learning phase. When you optimize for purchases, the number of ad sets your budget can feed is roughly your weekly purchases divided by 50.

**Example numbers (made up for this playbook):** affordable CPA $24.20.

Budget of $30,000.00 a month:
- Daily budget: $30,000.00 / 30.4 = $986.84
- Weekly spend: $986.84 x 7 = $6,907.89
- Weekly purchases at the affordable CPA: $6,907.89 / $24.20 = 285.45
- Ad sets it can feed: 285.45 / 50 = 5.71, so **5 at most**

Budget of $6,000.00 a month:
- Daily budget: $6,000.00 / 30.4 = $197.37
- Weekly spend: $197.37 x 7 = $1,381.58
- Weekly purchases: $1,381.58 / $24.20 = 57.09
- Ad sets it can feed: 57.09 / 50 = 1.14, so **1**

At $6,000.00 a month, one prospecting ad set with several ads, plus a test campaign run on its own ring-fenced money, is the structure the numbers support. Twelve ad sets at that budget means each gets about 57.09 / 12 = 4.76 purchases a week, and none of them ever learns.

**Wasted spend.** The `ad-account-hygiene-auditor` sums wasted spend from your own rows. Example: three ad sets each spent $400.00 over 30 days with zero purchases, so $400.00 x 3 = $1,200.00 of the month bought nothing. That money goes back into the ad sets that sell.

## Common mistakes

- **Too many ad sets.** Splitting the budget by age band, interest and placement leaves each ad set with a handful of purchases. Fewer, bigger ad sets learn faster.
- **Tests running inside the scale campaign.** New ads compete with proven ones for delivery and rarely reach 10 purchases. Keep test money apart.
- **Overlapping audiences.** Two ad sets targeting the same people bid against each other. Check exclusions with **P33 Audience and Exclusion Plan**.
- **Names that say nothing.** "Campaign 4 copy" cannot be grouped by angle or format when you read results.
- **Restructuring every week.** Each rebuild restarts learning. Change the structure when the budget or the product mix changes, and otherwise leave it alone.
- **Broken UTM links.** Revenue from untagged ads shows up as direct traffic, and the channel looks worse than it is.

**Next:** playbook 12 builds the campaigns on Meta and Google.
