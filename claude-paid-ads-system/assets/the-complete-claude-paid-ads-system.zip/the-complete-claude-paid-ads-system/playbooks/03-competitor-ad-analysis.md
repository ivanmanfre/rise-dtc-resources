# 03 Competitor Ad Analysis

**What this stage decides:** what your buyers already hear from other brands, which angles are crowded, which are empty, where your price and terms sit, and which claims you must not copy. The goal is a space map you can brief against.

**What you walk away with:** a space map listing crowded angles, open angles, competitor claims word for word, and an offer and price-per-unit comparison.

## Inputs you need

- Two to three competitors. Pick the ones your customers name in reviews and survey answers first, then one larger brand in the category.
- Their active ads from the Meta Ad Library: start date, format, primary text, headline, landing page, a one-line description of the visual.
- Their product pages as a buyer sees them: price, pack size, discount, shipping threshold, guarantee, bundles.
- Your own product facts with sources, and your own live ad text.
- Optional: their 1 to 3 star reviews.

## Step by step

1. **Choose competitors from your customers' mouths.** Search your language bank and survey answers for brand names. A brand your buyers compare you against is a better choice than the biggest brand in the category.

2. **Pull the ad library.** For each competitor, record every active ad with its start date. The start date is the most useful field on the page, because it shows what they keep paying to run.

3. **Run the fixed read.** Paste listings and page text for up to three competitors into the `competitor-researcher` skill. It returns their claims word for word, their offer next to yours, the angles their longest-running ads hold, and the angles nobody occupies.

4. **Go deep on the one that matters most.** Run **P07 Tear Down a Competitor's Ad Library** on your closest competitor. It sorts ads by days live and names the hook of the three longest-running ones.

5. **Compare offers on the numbers.** Run **P08 Map Competitor Offers and Prices Against Yours**. It prints price per unit and the effective first-order price once shipping is added.

6. **Read their unhappy customers.** Run **P04 Mine Competitor Reviews for Unmet Needs**. Complaints your facts answer are angle material. Praise your facts cannot match goes on the do-not-claim list.

7. **Map your own ads the same way.** Run the `angle-gap-mapper` skill on your live ads. Now you have both maps on the same eight-angle list: problem/solution, mechanism, social proof, comparison, offer, identity, urgency/scarcity, founder/origin.

8. **Write the space map.** Three lists: angles crowded in the market, angles open in the market and in your account, competitor claims you must avoid copying.

## The numbers that decide it

**Days live.** Today's date minus the ad's start date. A long runtime means the brand keeps paying for the ad. It does not tell you whether the ad is profitable, so treat it as a signal worth studying and nothing more.

Example: an ad started 1 June 2026, read on 28 September 2026. June 1 to July 1 is 30 days, to August 1 is 61, to September 1 is 92, to September 28 is 119 days live.

**Angle crowding.** Count each competitor ad by angle and divide by the total.

**Example numbers (made up for this playbook):** 24 active ads across three competitors.

| Angle | Ads | Share |
|---|---|---|
| Social proof | 11 | 11 / 24 = 45.8% |
| Offer | 7 | 7 / 24 = 29.2% |
| Problem/solution | 4 | 4 / 24 = 16.7% |
| Identity | 2 | 2 / 24 = 8.3% |
| Mechanism, comparison, urgency, founder | 0 | 0% |

If your facts support a mechanism claim and the market runs zero mechanism ads, that angle goes to the top of playbook 05.

**Price per unit.** Example: you sell 30 servings for $48.00, so $48.00 / 30 = $1.60 a serving. A competitor sells 20 servings for $39.00, so $39.00 / 20 = $1.95 a serving. Their free shipping starts at $50.00 and they charge $5.95 below it, so their effective first-order price for one pack is $39.00 + $5.95 = $44.95. On price per serving you are cheaper, on sticker price you look more expensive. That tells playbook 04 to show price per serving on the page and in the ad.

## Common mistakes

- **Copying claims.** A competitor's claim rests on their proof. Your ad can only say what your facts support. Run **P14 Check an Angle's Claims Before You Brief It** on anything inspired by a competitor.
- **Reading days live as profit.** Brands keep ads running for many reasons, including nobody checking. Study long runners for their hook and structure, never as proof.
- **Naming competitors in ads.** Compare against the category alternative ("cheap foam pillows"), never a brand name.
- **Watching only the biggest brand.** The brand your customers compare you to is the one that decides your sale.
- **Doing it once a year.** Rerun step 2 monthly. New long runners and new promos show up there first.

**Next:** playbook 04 turns the price map into an offer that survives your margin.
