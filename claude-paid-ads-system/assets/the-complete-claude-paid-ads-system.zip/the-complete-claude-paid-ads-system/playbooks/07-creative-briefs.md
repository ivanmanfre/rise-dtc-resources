# 07 Creative Briefs

**What this stage decides:** what gets made this week, by whom, in what format, and exactly what each piece may and may not say. A good brief lets an editor or creator deliver without a single follow-up question, and produces ads that differ in one thing at a time so tests can be read.

**What you walk away with:** a set of briefs sized to your production capacity and your test budget, each with hooks as separate takes, a claim boundary block, and file names that carry the test variable.

## Inputs you need

- Angle statements and claim boundaries (playbook 05).
- Three to five hooks per angle (playbook 06).
- Your production capacity this week: editor hours, creators booked, designer time.
- Your test budget and affordable CPA (playbooks 04 and 13).
- Available footage, product shots and brand assets.

## Step by step

1. **Work out how many ads you can afford to read.** Before writing any brief, use the arithmetic below. Making more ads than you can read wastes production money.

2. **Check capacity against the plan.** Run the `creative-06-creative-capacity-planner` agent with what you want made and what your team can make. It returns the shortfall and a named cut order, so you know what drops first.

3. **Confirm the claim boundary.** For each angle, have the output of **P14 Check an Angle's Claims Before You Brief It** open. Every brief carries it word for word.

4. **Write the shot-by-shot brief.** Run the `ad-brief-generator` skill (or the `creative-02-ad-brief-writer` agent) with the angle, the product facts and the format. It returns a shot-by-shot brief with a claim boundary block naming exactly what the facts allow.

5. **Write the creator version.** For UGC, run **P23 UGC Creator Brief**. It turns the brief into talking points, separate hook takes, a b-roll list, and must-say and must-not-say lists.

6. **Name every asset before it is made.** Use one pattern, for example `angle_hook_format_creator_v1`. Clean names let `scale-or-kill-judge` rows be read by angle and hook later. If your existing names are a mess, the `track-05-campaign-naming-fixer` agent builds a rename map.

7. **Run the brief checklist.** One angle per brief. Hooks as separate takes. Proof available for every claim. Deliverables, sizes, deadline and usage rights stated. Anything missing goes back before the shoot, when it is still cheap to fix.

## The numbers that decide it

**How many new ads you can read in a week.** Each new ad needs about 10 purchases before `scale-or-kill-judge` will give it a verdict.

**Example numbers (made up for this playbook):**

- Weekly ad spend: $7,000.00
- Share set aside for testing: 20%, so $7,000.00 x 0.20 = $1,400.00 a week
- Affordable CPA: $24.20, so one read costs at least 10 x $24.20 = $242.00
- New ads you can read per week: $1,400.00 / $242.00 = 5.79, rounded down to **5**

That is the brief count. Five new ads a week, for example one angle with three hook takes plus two statics on a second angle. Briefing fifteen means ten of them sit unread or split the test money so thin that none reaches a verdict.

**Brief cost against read cost.** If a creator shoot costs $300.00 and yields three hook versions plus a cutdown, and editing costs $150.00, that is ($300.00 + $150.00) / 4 = $112.50 per ad. Each still needs $242.00 of spend to read. Production cost per ad is usually the smaller of the two numbers in this example, which is why cutting the brief count is often a spend decision more than a production one.

**Test budget share.** The 20% above is an example. Set yours with the `spend-06-test-budget-ringfencer` agent, which splits the month into proven money and test money and tells you how many decisions the test money buys.

## Common mistakes

- **Vague briefs.** "Make it feel premium and viral" gets you something nobody can test. Specify the hook, the beats, the proof shot and the call to action.
- **No claim boundary.** Creators improvise. Without a must-not-say list, you get unapproved claims on camera and a rejected ad or a reshoot.
- **Changing several things per brief.** A new angle, new creator, new format and new offer in one ad teaches you nothing when it wins or loses.
- **One hook per shoot.** The cheapest extra test is another hook take filmed the same day.
- **Briefing beyond the budget.** Match the brief count to the number of reads your test money can buy.
- **No file naming.** Ads named "Final_v3_NEW" cannot be grouped by angle or hook when you read results.

**Next:** playbook 08 covers producing the UGC and static ads these briefs call for.
