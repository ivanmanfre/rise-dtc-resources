# 09 Ad Copywriting

**What this stage decides:** the primary text, headlines and descriptions around each creative on Meta, and the responsive search ad assets on Google. Copy carries the angle's argument for people who read before they watch, and it sets the expectation the landing page has to meet.

**What you walk away with:** for each creative, a set of primary text variants, headlines and descriptions, all matched to the landing page and checked for policy risk; and for Google, full responsive search ad assets within character limits.

## Inputs you need

- The finished creative or its script (playbook 08).
- The angle, customer phrases and claim boundary (playbooks 01, 05).
- Offer, guarantee and shipping terms (playbook 04).
- The landing page first screen, word for word (playbook 10).
- For Google: ad group themes and keywords (**P34 Google Search Keyword and Negative Plan**).

## Step by step

1. **Write copy after the creative and page are settled.** Copy that promises what the page does not answer loses sales at the click.

2. **Write primary text variants.** Run **P25 Meta Primary Text Variants**. You get five structures: short, medium, long story, list, and objection-led. The first line of each has to make sense alone, because it is what shows before the "See more" cut.

3. **Write headlines and descriptions.** Run **P26 Headline and Description Set**. The description should add a second reason to click, such as the guarantee or shipping terms.

4. **Write Google assets.** Run **P27 Google Responsive Search Ad Assets** for each ad group. Google's responsive search ads take up to 15 headlines of 30 characters and up to 4 descriptions of 90 characters. Recount a few by hand.

5. **Check copy against the page.** Paste the ad and the page down to the first buy button into the `message-match-checker` skill (or the `convert-01-message-match-checker` agent). Every promise comes back ANSWERED, PARTIAL or UNANSWERED with the page line quoted. Fix the UNANSWERED ones in the copy or on the page.

6. **Check policy.** Run the final copy through the `spend-04-policy-risk-checker` agent. Replace any flagged line with the line it writes from your facts.

7. **Decide what to test.** Most of the time, launch one or two copy variants per creative and let the creative carry the test. Test copy on its own only on a proven creative, with everything else fixed, using the plan in playbook 13.

## The numbers that decide it

Copy is judged on cost per purchase, like everything else. CTR alone can point you the wrong way.

**Example numbers (made up for this playbook):** one winning video, two primary text variants, same audience and budget, affordable CPA $24.20. The `scale-or-kill-judge` bands are: SCALE at or under 0.85 x $24.20 = $20.57, HOLD above $20.57 up to $24.20, CUT above $24.20.

| | Copy A (objection-led) | Copy B (short) |
|---|---|---|
| Impressions | 30,000 | 30,000 |
| Clicks | 420 | 540 |
| CTR | 420 / 30,000 = 1.40% | 540 / 30,000 = 1.80% |
| Purchases | 12 | 11 |
| Conversion rate | 12 / 420 = 2.86% | 11 / 540 = 2.04% |
| Spend | $240.00 | $240.00 |
| Cost per purchase | $240.00 / 12 = $20.00 | $240.00 / 11 = $21.82 |
| Verdict | $20.00 is at or under $20.57, SCALE | $21.82 is between $20.57 and $24.20, HOLD |

Copy B got more clicks. Copy A, which answered the main objection before the click, sent buyers who were readier to purchase. Both have 10 or more purchases, so both can be read.

**Contribution check.** At the example returns-adjusted contribution of $34.20 per order, Copy A leaves $34.20 - $20.00 = $14.20 per purchase after ad cost, and Copy B leaves $34.20 - $21.82 = $12.38. Over 500 purchases a month that gap is 500 x ($14.20 - $12.38) = $910.00.

## Common mistakes

- **Copy that outruns the page.** If the ad promises "fits every size" and the page has no size guide, conversion rate drops. Run `message-match-checker` before launch.
- **Claims drifting between creative and copy.** The creative passed the claim check; copy written later often adds new claims. Check the copy against the same claim boundary.
- **A first line that needs the second to make sense.** The first line is all a scroller sees before "See more".
- **Hashtags, emoji walls and all caps.** They take space from the argument and add nothing a buyer needs.
- **Testing copy on an unproven creative.** Copy tests need a creative that already gets purchases, or neither variant reaches 10.
- **Google headlines over 30 characters.** Count them. An over-length headline gets rejected at upload.

**Next:** playbook 10 makes sure the page finishes what the ad started.
