# 14 Retargeting Journeys

**What this stage decides:** who gets retargeted, for how long, with which message, and whether the retargeting spend adds orders you would not have had anyway. Retargeting tends to report high platform ROAS because it reaches people already close to buying. The question this playbook answers is how many of those orders the ads caused.

**What you walk away with:** named retargeting pools with windows and exclusions, one message per stage tied to a real objection, a frequency target, and a plain test that shows whether retargeting pays for itself.

## Inputs you need

- Website events firing (view content, add to cart, initiate checkout, purchase).
- Customer lists you can upload.
- Ranked objections by stage (playbook 02).
- Retargeting spend and results by week.
- Shopify revenue and orders by week for the same period.

## Step by step

1. **See what retargeting really adds.** Before adding any budget, run the `roas-vs-mer-reader` skill with per-channel spend, platform-reported revenue and your Shopify revenue. It prints the overlap gap in dollars. A large gap is a warning that retargeting may be claiming orders that other ads or organic demand already produced.

2. **Define the pools.** Run **P33 Audience and Exclusion Plan**. Typical pools: viewed a product 1 to 7 days, added to cart 1 to 7 days, started checkout 1 to 3 days, engaged with a video 1 to 30 days, purchased. Each pool excludes the ones further down so nobody sits in two.

3. **Map the journey.** Run **P38 Retargeting Journey Map**. For each stage it names the likely objection (from your data), the message, the format and the creative, or `[NEEDS: new creative]`.

4. **Write one ad per objection.** Run **P39 Retargeting Ads by Objection**. Fit questions get the size guide ad; shipping questions get the delivery-time ad; "will it work for me" gets proof.

5. **Check the pages.** Retargeting ads often send to the cart or a specific product page. Run `message-match-checker` so the page answers what the retargeting ad promises.

6. **Cross-sell to buyers.** The purchased pool gets the second product, refill or bundle from **P11 Design Bundles That Raise Contribution per Order**, and is excluded from prospecting.

7. **Watch frequency.** Frequency = impressions / reach over the window. Set a target per pool and refresh creative when frequency climbs while CTR falls (**P45 Diagnose Creative Fatigue From Your Rows**).

8. **Run the check.** Once a quarter, pause retargeting or hold out part of the audience for two weeks and compare total orders and contribution. The arithmetic below shows how to read it.

## The numbers that decide it

**Example numbers (made up for this playbook):** returns-adjusted contribution $34.20 per order.

Two weeks with retargeting on, then two weeks paused, prospecting unchanged:

| | Retargeting on (per week) | Retargeting paused (per week) |
|---|---|---|
| Retargeting spend | $1,500.00 | $0.00 |
| Total orders from Shopify | 700 | 680 |
| Retargeting platform ROAS | 6.0 | none |

- Orders lost per week without retargeting: 700 - 680 = 20
- Contribution lost: 20 x $34.20 = $684.00
- Spend saved: $1,500.00
- Net effect of retargeting on contribution: $684.00 - $1,500.00 = **-$816.00 a week**

In this example the platform said 6.0 ROAS, and the pause test said retargeting cost $816.00 a week in contribution. The right move would be a smaller budget, shorter windows, or objection-specific ads, then another check. Your own numbers may say the opposite. The point is to run the check on your own account.

**Frequency.** Example: add-to-cart pool, 7 days, 42,000 impressions, 6,000 people reached. Frequency = 42,000 / 6,000 = 7.0. Each person saw the ads seven times in a week. If CTR on that pool is falling week over week, that is the signal to cap frequency or change the creative.

## Common mistakes

- **Trusting retargeting ROAS.** It is the easiest number in the account to look good. Judge it on what total orders and contribution do with and without it.
- **A discount for every cart abandoner.** It can teach buyers to add to cart and wait. Answer the objection first; if a discount is part of your offer, price it with **P10 Price a Discount Before You Run It**.
- **Showing prospecting ads again.** People in retargeting have seen the pitch. Give them the answer to what stopped them.
- **No exclusions.** Recent buyers seeing "complete your order" ads cost money and look careless.
- **Windows that are too long.** A 180-day viewer pool at retargeting budgets often means paying repeatedly to reach people who decided long ago.
- **Never testing it.** Without a pause or a holdout, you cannot know what retargeting adds.

**Next:** playbook 15 sets the monthly budget and the bid strategy from your contribution target.
