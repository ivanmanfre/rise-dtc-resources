# 02 Customer Psychology

**What this stage decides:** what makes your best customers start looking, what they want to feel afterwards, what makes them hesitate, and the order in which those hesitations need answering. Ads, pages and retargeting all answer objections. This stage decides which objections, in which order, and which ones are costing you money after the sale through returns.

**What you walk away with:** a psychology sheet with buying triggers, before and after states, ranked objections with counts, an anti-ICP, and the awareness level of each segment.

## Inputs you need

- The language bank and ICP from playbook 01.
- At least 20 pre-purchase questions from support tickets, chat, DMs and ad comments, word for word.
- Return reasons from your returns portal, with counts.
- Orders split by discount code vs full price, with repeat rates.
- Optional: an exit poll or cart abandonment survey.

## Step by step

1. **Sort the language bank into four piles.** From the `customer-researcher` output: triggers (the moment they went looking), desired outcome (the after state), fears (what they worry will happen if they buy), and objections (why they wait). Keep every quote verbatim.

2. **Count the objections.** Paste your pre-purchase questions into the `convert-03-objection-order-writer` agent. It returns the objections in the order a page should answer them, and flags sections nothing you supplied justifies. Use **P30 Objection-Handling FAQ Block** to turn the same questions into page copy.

3. **Link objections to returns.** Put your return reasons next to your pre-purchase objections. When the same worry appears in both lists (fit, size, taste, "did not work for me"), that objection is costing you twice: once in lost sales, once in return costs.

4. **Name the buyers you should stop paying for.** Run **P03 Write the Anti-ICP** on return reasons, discount-only buyers and refund notes. This gives you copy lines and exclusions that keep them out.

5. **Place each segment on an awareness level.** Five levels: unaware of the problem, aware of the problem, aware of solutions, aware of your product, ready to buy. Look at the triggers and the "already tried" list from **P06 Mine Forum and Reddit Threads for Buying Triggers**. A segment that names competitors is solution aware. A segment describing symptoms without naming any fix is problem aware. The level sets how much the ad has to explain before it can sell.

6. **Match angles to segments later.** Keep this sheet open for **P13 Match Angles to Segments** in playbook 05.

7. **Write the sheet.** Per segment: top trigger, before state, after state, top three objections with counts, awareness level, and the return reason linked to an objection.

## The numbers that decide it

Rank objections by how often they come up, then move any objection that also shows up in returns to the top, because it costs you on both sides.

**Example numbers (made up for this playbook):** 120 pre-purchase questions in 60 days.

| Objection | Count | Share |
|---|---|---|
| "Will it fit / which size?" | 42 | 42 / 120 = 35.0% |
| "How long is shipping?" | 30 | 30 / 120 = 25.0% |
| "Will it work for my situation?" | 28 | 28 / 120 = 23.3% |
| "Is it worth the price?" | 20 | 20 / 120 = 16.7% |

Same window: 1,000 orders, 10% returned, so 100 returns. Each return loses $18.00 (outbound shipping $9.00, pick and pack $3.00, return label and handling $6.00, all example figures). 40 of the 100 returns give fit as the reason.

- Return cost from fit over the 60 days: 40 x $18.00 = $720.00, or $720.00 / 2 = $360.00 a month.
- Contribution lost on those orders as well: the revenue is refunded, so the contribution of each of those 40 orders is gone.

Fit is the top pre-purchase objection and the top return reason. It goes first on the page, first in the retargeting journey (playbook 14), and first in the FAQ. Clearing it up front lowers return cost and lifts the conversion rate at the same time, and both show up in contribution per order.

The price objection at 16.7% comes last here. Read what those tickets actually say before touching price: a price question is often a request for proof that the product is worth it.

## Common mistakes

- **Guessing motives.** "They want to feel confident" with no quote behind it is a guess. Every line on the sheet needs a quote and a count.
- **Treating every price objection as a pricing problem.** Check whether the page shows enough proof, a guarantee, and what is in the box before you discount. Playbook 04 prices any discount before you run it.
- **Answering objections nobody has.** A page section with no objection behind it is scroll length between the buyer and the button.
- **Ignoring returns.** Return reasons are objections that got past your page. They are the cheapest research you own.
- **One sheet for all segments.** Bundle buyers and single-item buyers often hesitate for different reasons. Keep a column per segment.

**Next:** playbook 03 checks what your competitors already say to the same buyers.
