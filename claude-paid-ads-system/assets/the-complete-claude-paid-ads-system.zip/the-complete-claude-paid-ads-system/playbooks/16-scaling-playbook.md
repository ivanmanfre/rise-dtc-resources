# 16 Scaling Playbook

**What this stage decides:** when to add spend, how much at a time, how long to hold each step, what puts the budget back, and when to stop stepping and look for new places to spend. Scaling here means contribution after ads keeps rising in dollars as spend rises. Revenue can grow while profit stays flat; the numbers below show how to spot it.

**What you walk away with:** a readiness verdict, a planned budget step with a hold window and a revert trigger, a weekly marginal read, and a horizontal expansion list for when vertical steps stop paying.

## Inputs you need

- Affordable CPA and break-even MER (playbooks 04 and 15).
- 7-day and 30-day rows per campaign from Ads Manager.
- Weekly spend and Shopify net revenue for at least 4 weeks.
- Per-ad spend and purchases for the current window.
- Stock cover on the products you push.

## Step by step

1. **Check readiness.** Run **P43 Scale Readiness Check**. It marks seven checks PASS or FAIL: weekly MER above break-even, recent cost per purchase under 0.85 x affordable CPA, no single ad taking over half the spend, at least three ads with 10 or more purchases under the affordable CPA, 30 days of stock cover, fresh creative, and new customers flat or rising.

2. **Know which ads carry the account.** Run the `scale-or-kill-judge` skill on the per-ad rows. Spend follows SCALE ads. CUT ads come out before any step, so new budget does not flow into them.

3. **Plan one step.** Paste the campaign's current daily budget, its 7-day and 30-day rows, your affordable CPA and today's date into the `budget-step-planner` skill (or the `spend-01-budget-step-planner` agent). It returns the next daily budget, the days to hold it untouched, and the revert trigger written as a number and a date. It plans one step at a time and refuses to step on fewer than 10 purchases in the 7-day row.

4. **Hold and read weekly.** Do not touch the campaign during the hold. Each Monday, run **P47 Weekly Contribution Read** and do the marginal arithmetic below.

5. **Diagnose a step that breaks.** If cost per purchase jumps after a step, paste the before and after rows into the `spend-02-scale-break-diagnoser` agent. It names one cause with the metric that moved and the metric that held, or says the rows cannot separate the causes. Run the `decide-03-cpa-drift-reader` agent on a longer series to see whether cost per purchase drifted or sits within its usual range.

6. **Go horizontal when vertical steps stop paying.** Run **P44 Horizontal Expansion Plan** for new angles, formats, creators, lead products, markets and channels, each priced at its cost to read. For Google, add proven search terms from **P34 Google Search Keyword and Negative Plan**.

7. **Keep creative supply ahead of spend.** More spend means faster fatigue. Playbook 17 sets the refresh rhythm.

## The numbers that decide it

**The budget step.** The `budget-step-planner` reads headroom = (affordable CPA - 7-day cost per purchase) / affordable CPA. At 25% or more headroom it steps 20% of the current budget; from 10% up to 25% it steps 10%. The hold is at least 7 days.

**Example numbers (made up for this playbook):** current budget $1,000.00 a day, 7-day cost per purchase $18.00, affordable CPA $24.20.

- Headroom: ($24.20 - $18.00) / $24.20 = 0.2562, so 25.6%, which is 25% or more
- Step: $1,000.00 x 0.20 = $200.00, next daily budget $1,200.00
- Hold at least 7 days before judging

**The marginal read.** Blended MER can look fine while the extra spend earns almost nothing. Compare the extra revenue to the extra spend.

Returns-adjusted contribution margin 42.75%, break-even MER 2.34.

| | Week before the step | Week after the step |
|---|---|---|
| Spend | $7,000.00 | $8,400.00 |
| Net revenue | $25,200.00 | $28,500.00 |
| Blended MER | $25,200.00 / $7,000.00 = 3.60 | $28,500.00 / $8,400.00 = 3.39 |
| Contribution after ads | $25,200.00 x 0.4275 - $7,000.00 = $3,773.00 | $28,500.00 x 0.4275 - $8,400.00 = $3,783.75 |

- Extra spend: $8,400.00 - $7,000.00 = $1,400.00
- Extra revenue: $28,500.00 - $25,200.00 = $3,300.00
- Marginal MER: $3,300.00 / $1,400.00 = 2.36, almost exactly break-even MER of 2.34
- Extra contribution: $3,783.75 - $3,773.00 = $10.75 for $1,400.00 more spend

Blended MER of 3.39 still looks healthy. The marginal read says the last $1,400.00 bought almost nothing. Stop stepping this campaign. Hold at the current budget or step back, and put the next dollars into horizontal moves from **P44 Horizontal Expansion Plan**.

One week is a thin read; confirm over the full hold window before acting.

## Common mistakes

- **Doubling budgets overnight.** Big jumps make it hard to tell what broke if cost per purchase rises. One planned step, one hold, one read.
- **Judging scale on blended MER alone.** Watch contribution after ads in dollars and the marginal MER on the extra spend.
- **Scaling one ad.** If one ad takes most of the spend, its fatigue becomes the account's problem. Build a bench of SCALE ads first.
- **Scaling into a stock-out.** Check cover with `spend-05-stock-cover-guard` before each step.
- **Changing creative, audience and budget in the same week.** The step cannot be read. `decide-02-change-log-auditor` will mark it CONFOUNDED.
- **No revert trigger.** Write down the number and the date that put the budget back before you raise it.

**Next:** playbook 17 keeps the creative supply ahead of the spend.
