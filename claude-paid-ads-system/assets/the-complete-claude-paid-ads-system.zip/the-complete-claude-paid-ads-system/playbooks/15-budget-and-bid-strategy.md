# 15 Budget & Bid Strategy

**What this stage decides:** next month's ad budget, how it splits across campaigns and tests, which bid strategy each campaign uses and at what target, and when cash or stock should cap spend. The budget starts from the contribution you need, and your own history decides whether that is reachable.

**What you walk away with:** a monthly spend level checked against your own best months, a per-campaign split that adds up, a test budget, bid targets set from your break-even, and a cash and stock check.

## Inputs you need

- Contribution margin % before ads, returns-adjusted (playbook 04).
- Your contribution target for next month, in dollars.
- At least 3 months of total ad spend and Shopify revenue.
- Per-campaign spend and purchases for the last 30 days.
- Cash on hand, inventory on hand, daily units sold, restock dates.

## Step by step

1. **Refresh the unit economics.** Rerun the `break-even-and-affordable-cpa` skill if any cost changed this month.

2. **Set the spend level from the target.** Run **P40 Monthly Budget From a Contribution Target**. It prints three spend levels, the MER each requires, and whether each sits inside your own history.

3. **Check the target against your history.** Run the `decide-04-target-feasibility-checker` agent for a stricter read. It sets the required blended return against your best and second-best months and refuses to rule on fewer than 3 months.

4. **Check cash and stock.** Run **P42 Cash and Payback Check Before Spending More**, and the `spend-05-stock-cover-guard` agent for days of cover per SKU and the daily spend ceiling that keeps each one in stock until restock.

5. **Split it.** Ring-fence test money with `spend-06-test-budget-ringfencer`, then run **P41 Split Budget Across Campaigns** for the rest.

6. **Move money in capped steps.** Use the `spend-03-spend-shift-planner` agent to plan what leaves each campaign and what arrives at each, capped per step. For a single campaign's next increase, use `budget-step-planner`.

7. **Set bid strategies.**
   - **Highest volume / lowest cost (Meta) or Maximize conversions (Google):** for new campaigns and tests, when you need data. Watch cost per purchase against your affordable CPA daily in the first week.
   - **Cost per result goal (Meta) or target CPA (Google):** set at or under your affordable CPA, once a campaign has a steady purchase history. Good for protecting margin while scaling.
   - **ROAS goal (Meta) or target ROAS (Google):** set at or above your returns-adjusted target ROAS, for catalogues with a wide spread of order values where a flat CPA target would underbid big orders.

## The numbers that decide it

**Example numbers (made up for this playbook):** returns-adjusted contribution margin 42.75% (from playbook 04). Contribution target after ads next month: $15,000.00.

- Break-even MER = 1 / 0.4275 = 2.34
- Revenue needed = (target + spend) / 0.4275
- Required MER = revenue needed / spend

| Spend | Revenue needed | Required MER |
|---|---|---|
| $24,000.00 | ($15,000.00 + $24,000.00) / 0.4275 = $91,228.07 | $91,228.07 / $24,000.00 = 3.80 |
| $30,000.00 | ($15,000.00 + $30,000.00) / 0.4275 = $105,263.16 | $105,263.16 / $30,000.00 = 3.51 |
| $36,000.00 | ($15,000.00 + $36,000.00) / 0.4275 = $119,298.25 | $119,298.25 / $36,000.00 = 3.31 |

Your own history, three example months: MER 3.20, 3.70, 3.40. Best 3.70, second-best 3.40.

- $24,000.00 needs 3.80: above your best month. Not reachable on your history.
- $30,000.00 needs 3.51: inside your best month, above your second-best. Possible, and depends on repeating your best month.
- $36,000.00 needs 3.31: inside both on paper. Now check what spend your best months ran at. If 3.70 came at $22,000.00 of spend, you have no evidence the account holds 3.31 at $36,000.00, and MER can fall as spend rises. That spend level needs a step plan (playbook 16).

The table shows a trap: the arithmetic says more spend needs a lower MER, which makes big budgets look easy. Your own history at each spend level is the check.

**Bid target.** Affordable CPA $24.20, so a cost per result goal at or under $24.20. Target ROAS $80.00 / $24.20 = 3.31, so a ROAS goal at or above 3.31.

## Common mistakes

- **Budget from last month's spend.** "Up 20% because it's Q4" is a guess. Start from the contribution target and check it against your history.
- **ROAS goals from the platform's suggestion.** Set them from your returns-adjusted break-even and target.
- **Daily budget edits.** Change budgets in planned steps and hold them, using `budget-step-planner`.
- **Ignoring stock.** Spending into a product that runs out in ten days burns the learning you paid for. `spend-05-stock-cover-guard` gives the ceiling.
- **Ignoring cash.** A campaign can be profitable per order and still drain cash if payback takes months. **P42 Cash and Payback Check Before Spending More** checks both.
- **One budget for tests and scale.** Tests without ring-fenced money get starved the first week results dip.

**Next:** playbook 16 covers how to add spend without losing the margin.
