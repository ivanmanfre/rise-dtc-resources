# 10 Landing Page & CRO

**What this stage decides:** where each ad sends traffic, what the first screen says, which objections the page answers and in what order, and whether a page change is worth testing at your traffic. Conversion rate sits inside every cost per purchase you pay, so a page fix lowers the cost of every ad pointed at it.

**What you walk away with:** a page (or product page rewrite) whose first screen matches the ad, objections answered in order of how often they come up, and a test sized to your traffic, or a clear note that the traffic is too thin to test.

## Inputs you need

- The ads sending the most traffic, with their primary text and script.
- The page text top to bottom, word for word.
- Last 30 days: sessions, add to carts, orders, by device.
- Ranked objections and pre-purchase questions (playbook 02).
- Proof you have: review count and rating, guarantee terms, demos, certifications.
- The list of apps running on your storefront.

## Step by step

1. **Get the three numbers.** Add-to-cart rate = add to carts / sessions. Conversion rate = orders / sessions. Split both by mobile and desktop. Fix the device that carries the most traffic first.

2. **Check the ad against the page.** Run the `message-match-checker` skill with the top ad and the page down to the first buy button. Every promise comes back ANSWERED, PARTIAL or UNANSWERED. An UNANSWERED promise is the first fix.

3. **Run the full audit.** Paste the page and the ad into the `cro-auditor` skill. It returns a 48-point PASS / FAIL / CANNOT CHECK table with the page line quoted and one fix per FAIL.

4. **Rewrite the first screen.** Use the `convert-05-first-screen-rewriter` agent, which quotes the input line each slot rests on, or **P29 Rewrite the First Screen**. The first screen on mobile has to say what it is, who it is for, why it beats the alternative, what it costs, and why to trust it.

5. **Order the sections by objection.** Run the `convert-03-objection-order-writer` agent with your customer questions. It returns the section order with the objection each one retires. Write the FAQ with **P30 Objection-Handling FAQ Block**, and move the top three blockers into the page body.

6. **Build a dedicated page for a big angle.** If one angle carries a large share of spend and the product page argues something else, run **P28 Landing Page Outline From the Ad** and build a page that continues that ad.

7. **Check what the apps cost you.** Run the `convert-06-storefront-app-lister` agent with your apps screen. It shows per app whether it is visible, what it costs a month, and the screen to check next.

8. **Size the test before you run it.** Paste the page's traffic and orders into the `convert-04-landing-test-sizer` agent. It prints the weeks the test needs, or says the page cannot be tested at this traffic. If it cannot, ship the fixes from steps 2 to 5 that are clear defects and watch conversion rate on a matched window.

## The numbers that decide it

Cost per purchase = cost per click / conversion rate. Change the conversion rate and every ad's cost moves with it.

**Example numbers (made up for this playbook):** cost per click $0.80, monthly ad spend $20,000.00, returns-adjusted contribution $34.20 per order.

| | Before | After a page fix |
|---|---|---|
| Conversion rate | 2.5% | 3.2% |
| Cost per purchase | $0.80 / 0.025 = $32.00 | $0.80 / 0.032 = $25.00 |
| Purchases from $20,000.00 | $20,000.00 / $32.00 = 625 | $20,000.00 / $25.00 = 800 |
| Contribution before ads | 625 x $34.20 = $21,375.00 | 800 x $34.20 = $27,360.00 |
| Contribution after ads | $21,375.00 - $20,000.00 = $1,375.00 | $27,360.00 - $20,000.00 = $7,360.00 |

Same ads, same spend. The page change took contribution after ads from $1,375.00 to $7,360.00 in this example, because the page sits under every ad.

**When you cannot test.** Say the page gets 300 sessions a day at 2.5%: 300 x 0.025 = 7.5 orders a day, or 52.5 a week. Whether that is enough to split and read depends on the size of the change you expect, which is the arithmetic `convert-04-landing-test-sizer` prints. At low traffic, fix clear defects directly and skip the split test.

## Common mistakes

- **Sending every ad to the homepage.** The homepage argues for the brand. The ad argued for one product and one angle. Send traffic to the page that continues the ad.
- **Mood copy on the first screen.** "Feel your best, every day" does not tell a buyer what the product is. Put the product, the buyer and the reason in the first screen.
- **Testing with too little traffic.** A test that needs 14 weeks is likely to be confounded by a promo, a stock-out or a new ad long before it ends.
- **Changing the page during an ad test.** It breaks both tests. Log every page change with its date so `decide-02-change-log-auditor` can flag collisions.
- **Adding apps for every problem.** Each app adds cost and page weight. Check them with `convert-06-storefront-app-lister`.
- **Ignoring desktop and mobile differences.** Read the rates by device. The fix for the larger device comes first.

**Next:** playbook 11 sets up the account structure that sends traffic here.
