# 12 Meta & Google Build

**What this stage decides:** the settings every campaign launches with: tracking, conversion event, attribution setting, budgets, audiences, bid strategy, ads and links. Most bad data starts with a build mistake nobody noticed for three weeks. This playbook is the checklist that catches it on day zero.

**What you walk away with:** Meta and Google campaigns built from the plan in playbook 11, with tracking verified, one attribution setting across your reporting, clean links, and a QA sheet with every line marked PASS.

## Inputs you need

- The structure plan from playbook 11.
- Ads with copy from playbooks 08 and 09.
- Your events screen (Meta Events Manager, Google tag status).
- Destination links with UTM parameters.
- For Google: keyword plan and responsive search ad assets, and your product feed status in Merchant Center.

## Step by step

1. **Verify tracking first.** Paste your events screen into the `track-03-tracking-break-checker` agent. It marks each event LIVE, STALE or NEVER FIRED, with revenue-carrying events ranked first. Do not launch while the purchase event is anything other than LIVE.

2. **Pick one attribution basis.** Paste each platform's attribution setting and the figures you report into the `track-02-attribution-window-matcher` agent. It returns the one basis your figures share and names the figures that cannot be added together. Set your campaigns to that basis.

3. **Check every link.** Run the `utm-tag-auditor` skill on every destination URL. Fix each BREAK before upload.

4. **Build Meta.** Create the campaigns and ad sets from **P31 Account Structure Plan**. Objective: sales, optimizing for purchase. Audiences and exclusions from **P33 Audience and Exclusion Plan**. Ads named with your pattern, copy from **P25 Meta Primary Text Variants** and **P26 Headline and Description Set**.

5. **Build Google.** Start with Search: a brand campaign and a non-brand campaign built from **P34 Google Search Keyword and Negative Plan**, with ads from **P27 Google Responsive Search Ad Assets**. Add Shopping or Performance Max once your product feed is clean. If you run Performance Max next to a brand Search campaign, look at the search terms insights and use brand exclusions so the two do not bid on the same brand searches.

6. **Set bids to your economics.** If you use a cost per result goal on Meta or target CPA on Google, set it at or under your affordable CPA. If you use a ROAS goal or target ROAS, set it at or above your returns-adjusted target ROAS, never at the platform's suggestion. Playbook 15 covers when to use which.

7. **Run QA.** Paste the settings into **P32 Pre-Launch QA Checklist**. Clear every FAIL.

8. **Launch and leave it.** Do not edit budgets, audiences or ads for 7 days unless tracking breaks or spend runs far above plan. Every edit can reset learning and muddies the first read.

## The numbers that decide it

**Minimum daily budget per ad set.** To reach around 50 purchases a week at your affordable CPA:

**Example numbers (made up for this playbook):** affordable CPA $24.20.
- Weekly spend needed: 50 x $24.20 = $1,210.00
- Daily budget: $1,210.00 / 7 = $172.86

An ad set on $50.00 a day buys about $50.00 x 7 / $24.20 = 14.46 purchases a week at the affordable CPA. It will sit in learning. Either raise its budget, merge it with another ad set, or accept that it will read slowly and plan for that.

**Target settings from your economics.** From playbook 04's example: affordable CPA $24.20 and target ROAS $80.00 / $24.20 = 3.31. A cost cap at $24.20 or a ROAS goal of 3.31 means each purchase the platform buys at that cost still leaves $10.00 of contribution. A ROAS goal of 2.00, the non-returns break-even, would lose money on every order once returns are counted.

**Brand search.** Example: brand campaign spend $1,200.00, platform-reported revenue $14,000.00, platform ROAS $14,000.00 / $1,200.00 = 11.67. Some of those buyers may have searched your name because they already meant to buy. Judge brand search on whether total revenue holds when you lower it, which **P48 Find Where Platform Revenue and Shopify Disagree** helps set up.

## Common mistakes

- **Launching without a LIVE purchase event.** The platform optimizes toward what it can see. A broken purchase event trains it on nothing.
- **Different attribution settings across reports.** Adding a 7-day click figure to a 1-day view figure gives you a number that describes nothing.
- **Optimizing for add to cart or landing page views to "get data faster".** You get cheaper events from people who do not buy.
- **Letting the platform set your ROAS goal.** Your break-even comes from your margin, as playbook 04 shows.
- **Editing in the first week.** Hold for 7 days, the same minimum `budget-step-planner` uses before a budget change is judged.
- **Skipping negatives on Google.** Queries with "free", "DIY", "jobs" or "wholesale" can spend for weeks without a sale.

**Next:** playbook 13 sets how every test in these campaigns gets planned, read and logged.
