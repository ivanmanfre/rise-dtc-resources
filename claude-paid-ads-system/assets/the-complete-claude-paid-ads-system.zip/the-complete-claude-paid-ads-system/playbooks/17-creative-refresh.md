# 17 Creative Refresh

**What this stage decides:** when a winning ad is tired, what to change in it, and how many new versions your team can make each week. A refresh keeps what won (the angle, the proof) and changes one part at a time, cheapest first, so each new version can be read.

**What you walk away with:** a weekly fatigue check, a refresh list for each tired winner ordered by cost, a production plan that fits your capacity, and results logged against the original.

## Inputs you need

- Weekly rows since launch for each top ad: spend, impressions, reach, clicks, purchases, 3-second views.
- The change log for the same period.
- The winning ad's script or copy and a description of its visual.
- What has already been tried against it.
- Your production capacity per week.

## Step by step

1. **Check fatigue weekly.** Run **P45 Diagnose Creative Fatigue From Your Rows** on each ad that carries a meaningful share of spend. It computes frequency, CTR, CPM, conversion rate, cost per purchase and hook rate per week, and names the pattern: FATIGUE, AUCTION, PAGE OR OFFER, or CONFOUNDED.

2. **Act only on FATIGUE.** An AUCTION pattern (CPM up, CTR flat) is a budget and bidding question for playbook 15. PAGE OR OFFER (CTR flat, conversion rate down) goes to playbook 10. Refreshing creative will not fix either.

3. **Confirm with the verdict.** Run the `scale-or-kill-judge` skill on the current window. A fatigued ad that has slid from SCALE to HOLD is a refresh candidate. One already at CUT needs its spend moved now, with a refresh made after.

4. **List the next variants.** Paste the winner, its visual and what you have tried into the `winner-iteration-planner` skill (or the `creative-05-winner-iteration-planner` agent). It returns six next variants, each changing one named element, cheapest to shoot first. For a wider list grouped light, medium and heavy, run **P46 Refresh Plan for a Tired Winner**.

5. **Start with new hooks.** Run **P16 Rewrite Hooks From a Winning Ad**. A new opening on a proven body is often the cheapest refresh to make and to read.

6. **Re-cut before you reshoot.** Run **P24 Edit Plan From Raw UGC Footage** on the original footage. Unused takes and b-roll often give you two or three versions for editing time only.

7. **Fit it to capacity.** Run the `creative-06-creative-capacity-planner` agent with the refresh list and your capacity. It prints the shortfall and the cut order.

8. **Launch as new ads and log.** Each refresh is its own ad in the test campaign, named as a version of the original. Record results in **P37 Build the Learning Log** so you learn which parts of your winners wear out first.

## The numbers that decide it

**Example numbers (made up for this playbook):** one ad over four weeks, affordable CPA $24.20.

| Week | Frequency | CTR | CPM | Conversion rate | Cost per purchase |
|---|---|---|---|---|---|
| 1 | 1.6 | 1.60% | $10.00 | 3.0% | $10.00 / (1,000 x 0.016 x 0.030) = $20.83 |
| 4 | 3.1 | 1.10% | $10.50 | 3.0% | $10.50 / (1,000 x 0.011 x 0.030) = $31.82 |

Frequency nearly doubled, CTR fell from 1.60% to 1.10%, CPM moved only $0.50, and conversion rate held at 3.0%. The people who click still buy at the same rate; fewer people click. That is the FATIGUE pattern. The ad went from under the SCALE line ($20.57) to above the affordable CPA ($24.20), so it is now a CUT with a refresh owed.

**How many refreshes you need.** If your scale campaign runs on 4 winning ads and each stays under the affordable CPA for about 6 weeks before it fatigues (an example; measure your own from the log), you lose 4 / 6 = 0.67 winners a week. At an example hit rate of one winner in five tests, you need 0.67 x 5 = 3.33 new tests a week just to stand still. Round up to 4. Scaling needs more on top.

**Cost per refresh.** A new hook edited onto existing footage might cost $40.00 in editing; a reshoot with a new creator might cost $450.00 (example figures). Both need $242.00 of spend to read at 10 x $24.20. Cheap refreshes first means more reads for the same money: $40.00 + $242.00 = $282.00 against $450.00 + $242.00 = $692.00.

## Common mistakes

- **Killing a winner instead of refreshing it.** The angle and proof that won still work. Change the part that wore out.
- **Changing everything at once.** A new hook, creator and offer together gives you a new ad and no lesson about the old one.
- **Refreshing on a CPM spike.** Auction pressure (seasonal peaks, promotions) raises costs on every ad. Check the pattern before making new creative.
- **Waiting until it is dead.** Start the refresh when frequency climbs and CTR slips, while the ad still pays for itself.
- **Reshooting before re-cutting.** Raw footage you already paid for often holds the next version.
- **No record of what wore out.** Log which part you changed and whether it worked. After a few rounds, you will know what to change first.

**Next:** playbook 18 reports what all of this left in the bank.
