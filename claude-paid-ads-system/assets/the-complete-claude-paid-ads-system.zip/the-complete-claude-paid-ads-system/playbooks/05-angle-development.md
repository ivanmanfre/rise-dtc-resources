# 05 Angle Development

**What this stage decides:** which three to five angles get briefed this month. An angle is the argument an ad makes: the problem it names, the reason to believe, and the buyer it speaks to. A hook is the first line of that argument. Many hooks can serve one angle, so decide the angle first.

**What you walk away with:** three to five angle statements, each tied to a customer quote, a product fact, a segment and an objection, and each checked against your claim boundary.

## Inputs you need

- The language bank and psychology sheet (playbooks 01 and 02).
- The space map from playbook 03.
- The primary text of every live ad in your account.
- Product facts with their sources.
- Your affordable CPA from playbook 04.

## Step by step

1. **Map what you already run.** Paste your live ads into the `angle-gap-mapper` skill (or the `creative-01-angle-gap-mapper` agent). It assigns each ad to one of eight angles (problem/solution, mechanism, social proof, comparison, offer, identity, urgency/scarcity, founder/origin) and prints the angles nobody runs.

2. **Find the double gaps.** Lay your empty angles next to the empty angles in the market from playbook 03. An angle empty in both lists is the best opening you have, as long as your facts support it.

3. **Generate angles.** Run **P12 Generate Angles From Customer Language**. Every angle it returns carries a quote, a fact and an objection. Those with a support count of one are hunches.

4. **Point angles at segments.** Run **P13 Match Angles to Segments**. The highest-contribution segment from playbook 01 gets its best angle briefed first.

5. **Check claims.** Run **P14 Check an Angle's Claims Before You Brief It** on each shortlisted angle. Keep the claim boundary it prints; every brief, script and ad built on the angle uses it.

6. **Score and pick.** Use the scorecard below and pick three to five.

7. **Write each angle as one sentence.** Who, what problem, what changes, which fact proves it. Hand these to playbook 06 for hooks and playbook 07 for briefs.

## The numbers that decide it

**Scorecard.** Score each shortlisted angle 0 to 2 on five lines and add them up.

| Line | 0 | 1 | 2 |
|---|---|---|---|
| Customer quotes supporting it | 0 to 1 | 2 to 4 | 5 or more |
| Segment it serves | lowest value | middle | highest contribution per customer |
| Claim check | UNSUPPORTED | PARTIAL | SUPPORTED |
| Your account | already running | running once | empty |
| The market | crowded | some | empty |

**Example numbers (made up for this playbook):**

- Mechanism angle: quotes 2, segment 2, claims 2, account 2, market 2 = 10
- Problem/solution angle: quotes 2, segment 2, claims 2, account 0, market 1 = 7
- Identity angle: quotes 1, segment 1, claims 2, account 2, market 1 = 7
- Social proof angle: quotes 2, segment 1, claims 1, account 1, market 0 = 5

Brief mechanism first, then the two sevens.

**What it costs to read an angle.** An angle is read once its ads reach 10 purchases, the minimum `scale-or-kill-judge` uses. At the example affordable CPA of $24.20, one angle costs at least 10 x $24.20 = $242.00 to read. Three angles cost at least 3 x $242.00 = $726.00. If your monthly test budget is $1,000.00, that is four angles at most ($1,000.00 / $242.00 = 4.13, rounded down), before counting any hook tests inside them. The budget decides how many angles you can learn about, so pick the few that score highest.

**Coverage.** Occupied angles divided by eight. An account running only social proof and offer ads covers 2 / 8 = 25% of the list, which means every ad is making one of two arguments to every buyer.

## Common mistakes

- **Calling five hooks five angles.** If every ad argues "our customers love it", you are running one angle with five openings. Test angles against angles, then hooks inside the winner.
- **Taking angles from competitors.** A crowded angle in the market means buyers have heard it already. Use playbook 03 to find the empty ones.
- **Angles without proof.** An angle that fails the claim check will get rewritten into something vague at the brief stage, or rejected at review.
- **Too many angles at once.** Five angles on a budget that can read two gives you five unread tests.
- **Skipping the segment.** An angle that speaks to nobody in particular tends to perform like it.

**Next:** playbook 06 writes the opening lines for each chosen angle.
