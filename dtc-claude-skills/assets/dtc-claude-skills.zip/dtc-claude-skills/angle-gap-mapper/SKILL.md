---
name: angle-gap-mapper
description: "Use before briefing new creative, to see which sales angles the account's live ads already occupy and which ones nothing is running against. Takes the ad name and primary text of the live ads in the account and returns each ad's angle with counts, plus the angles from a fixed list that no live ad occupies. Triggers on \"what angles are we even running\", \"map the current ad angles\", \"which angle has nobody touched\", \"audit the live ads by angle\", \"what angles is this client already running\", \"what are we not saying in these ads\"."
---

# RISE DTC Claude Skills, 03 of 15: the angle gap map

## What this does

Reads the primary text of every live ad you paste and assigns each one to exactly one angle from a fixed eight-angle list, based on the first claim-bearing sentence in it. Ads with no claim at all get their own row instead of a forced angle.

**The line only this skill produces:** the angles from the fixed list that zero of the account's live ads occupy, printed by name, next to the angles that are occupied and by which ads. This is an absence finding read off the creative that is actually running, not a mining exercise over reviews and not a judgment on how any ad is performing.

## Required input

1. **The ad name and primary text of each live ad**, copied from the Ads screen, up to 15 ads. Text only, exactly as it runs. An ad with a name but no text is still counted, it just cannot be classified.

Never supply spend, results, click-through rate, or any performance number. This skill does not read them and a performance number changes nothing about which angle an ad occupies.

## What it refuses

**Refusal 1, nothing to map.** If zero ads are pasted:

```
NO ADS SUPPLIED
Ads pasted: 0

There is no live creative to map, so there is nothing to compare against the
angle list and no absence to report. Absence is only meaningful measured
against ads that exist.
```

**Refusal 2, no forced angle.** An ad's text is refused an angle assignment, and printed in the UNCLASSIFIABLE row instead, whenever no sentence read under the scope rule in Step 3 matches any of the eight angle tests below:

```
UNCLASSIFIABLE
"<ad name>": "<the ad's primary text>"
No sentence in this ad names a problem, a mechanism, a proof point, a
comparison, a price or guarantee term, an audience, a time or stock pressure,
or a founder account. Assigning the nearest-sounding angle would be a guess,
not a reading.
```

## The eight angles, fixed order

The order below is also the tie-break order: if one sentence matches more than one test, the earlier-numbered angle wins.

| # | Angle | The test |
|---|---|---|
| 1 | PROBLEM/SOLUTION | The sentence states a problem the buyer has, before or instead of any product-feature sentence. |
| 2 | MECHANISM | The sentence names a component, material or process and how it works. |
| 3 | SOCIAL PROOF | The sentence carries a review count, a rating, a quote, or names what other buyers experienced. |
| 4 | COMPARISON | The sentence contrasts the product against a described category alternative, without naming a specific competitor brand. |
| 5 | OFFER | The sentence states a number tied to money, a discount, a bundle or a guarantee condition. |
| 6 | IDENTITY | The sentence names a person type, a role, or a way of living the buyer joins, rather than a product fact. |
| 7 | URGENCY/SCARCITY | The sentence names a date, a countdown or a stock level. |
| 8 | FOUNDER/ORIGIN | The sentence is a first-person account of why the writer built or started something. |

## Method

**Step 1, state the population.** "Every ad you pasted, counted once each, up to 15. Ads pasted beyond 15 are not read; name them as not read rather than silently dropping them."

**Step 2, sort ads that carry no text.** An ad with a name but empty or missing primary text is printed in its own NO TEXT SUPPLIED row with `[NEEDS: primary text for this ad]`. It is not classified and it is not counted as UNCLASSIFIABLE, because UNCLASSIFIABLE means text was read and carried no claim, which is a different fact than no text existing.

**Step 3, find the first claim-bearing sentence per ad, under a stated scope rule.** Read the primary text in order and test the first sentence against the eight tests.

- **Scope rule.** A test fires only when the words in front of you carry everything that test names. Read the first sentence. If a test needs a contrast, a claim, or a subject that the first sentence does not carry, read on through the second sentence and no further, and test the two sentences read together. A test that is still incomplete at the end of the second sentence has not fired. Nothing past the second sentence is read for classification, and no meaning is imported from a sentence you did not read.
- **Print which sentence decided.** Every classified ad carries `decided by sentence 1` or `decided by sentence 1+2` next to its matched claim, so a second run lands on the same reading and not just the same label.
- **Tie-break.** If the words read match more than one test, the earlier-numbered angle wins.
- **Founder tie-break, stated once.** A problem stated inside a first-person account of why the writer built or started the thing is the writer's problem, not a problem the buyer has, so test 1 does not fire on it and test 8 wins that sentence outright.

Stop reading an ad once a match is found.

**Step 4, class ads with no matching sentence.** If nothing read under the Step 3 scope rule matches any test, the ad goes to UNCLASSIFIABLE (Refusal 2), not to the nearest angle.

**Step 5, tally.** Count ads per angle, over the population from Step 1 minus the NO TEXT SUPPLIED ads. Print every ad's name and its matched claim under its angle.

**Step 6, name the absence.** Any of the eight angles with zero ads is printed as UNRUN. An angle can show phrasing that touches it in a losing tie-break (Step 3) and still be UNRUN, because UNRUN is about which angle is the ad's primary, first-matched angle, not about which words appear anywhere in the text. State this plainly when it happens.

## Output format

```
# Angle gap map
Ads pasted: <n>   Ads read (cap 15): <n>   Ads not read (beyond cap): <n or 0>

## Occupied angles
### <ANGLE NAME>, <count> ad(s)
- "<ad name>": "<matched claim>"   (decided by sentence 1 | sentence 1+2)

(repeat per occupied angle, in the fixed order 1-8)

## Angles nobody is running
- <ANGLE NAME>
(or: "None. All 8 angles have at least one live ad.")
Each angle above is a brief nobody has written for this account.

## No text supplied
- <ad name>: [NEEDS: primary text for this ad]
(or: "None. Every pasted ad carried text.")

## Unclassifiable
- <ad name>: "<verbatim primary text>"
(or: "None. Every ad with text matched an angle.")

## Counts
Population for classification: ads read minus no-text ads = <n> - <n> = <n>
Classified (matched an angle): <n> / <n>
Unclassifiable: <n> / <n>
No text supplied: <n> / <n> (of ads read)
Angles occupied: <n> / 8
Angles unrun: <n> / 8
```

## Worked case

This worked case IS the fixture run at `fixtures/marrow-ash-live-ads.md`, re-run literally against the method above and checked line by line before shipping.

Eight ads pasted, all read (under the cap of 15).

- **Ad A, "Sleep Better Tonight."** Sentence 1: "You lie there at 11pm replaying the day instead of sleeping." A problem the buyer has, stated before any product-feature sentence. Test 1 is complete on sentence 1. -> **PROBLEM/SOLUTION, decided by sentence 1.**
- **Ad B, "How It Actually Works."** Sentence 1 names 15 pounds of glass micro-beads sewn into individual channels and how weight distributes. Test 2 is complete on sentence 1, before anything else. -> **MECHANISM, decided by sentence 1.**
- **Ad C, "1,900 Five-Star Reviews."** Sentence 1 carries a review count and a rating ("Over 1,900 buyers rated... five stars"). Test 3 is complete on sentence 1. -> **SOCIAL PROOF, decided by sentence 1.**
- **Ad D, "The Other Kind Goes Flat."** Sentence 1 reads "Plastic-pellet weighted blankets clump in the wash and go flat within a year." It names a category alternative and its flaw, and nothing else. Test 4 needs a contrast against the product, and sentence 1 carries no product to contrast with, so test 4 is incomplete there. Test 1 needs a problem the buyer has, and this flaw is attributed to a rival category, not to the buyer's situation, so test 1 does not fire either. Under the scope rule, read on through sentence 2: "The Ash Blanket's glass beads keep their shape wash after wash." The two sentences read together carry the described alternative, the product, and the contrast between them, with no competitor brand named. Test 4 completes there, and it is the earliest-numbered test that completes on the words read. -> **COMPARISON, decided by sentence 1+2.**
- **Ad E, "Weekend Ship Sale."** Sentence 1 states both a discount ("$30 off... through Sunday") and a date. This matches test 5 (OFFER) and test 7 (URGENCY/SCARCITY) in the same sentence. Tie-break: angle 5 is earlier than angle 7 in the fixed order, so OFFER wins. -> **OFFER, decided by sentence 1.** Note for the reader: urgency language is present in the copy and still does not occupy the URGENCY/SCARCITY angle, because that angle is about which claim is primary, not which words appear.
- **Ad F, "Built For My Own Kid."** Sentence 1 is a first-person account of why the writer started sewing the product, and the problem inside it belongs to the writer's child. The founder tie-break in Step 3 settles it: test 1 does not fire on a problem stated inside a founder account, so test 8 wins. -> **FOUNDER/ORIGIN, decided by sentence 1.**
- **Ad G, "Our Bestseller."** Nothing in sentences 1 and 2 states a problem, mechanism, proof, comparison, price, audience, timing or founder account. It names the product and three adjectives. -> **UNCLASSIFIABLE.**
- **Ad H, "Retargeting, Static 4."** Primary text field is empty. -> **NO TEXT SUPPLIED**, `[NEEDS: primary text for this ad]`.

Tally: PROBLEM/SOLUTION 1 (A), MECHANISM 1 (B), SOCIAL PROOF 1 (C), COMPARISON 1 (D), OFFER 1 (E), IDENTITY 0, URGENCY/SCARCITY 0, FOUNDER/ORIGIN 1 (F).

Occupied angles: 6 / 8. Unrun angles: IDENTITY, URGENCY/SCARCITY, 2 / 8.

Counts: ads pasted 8, ads read 8, no text supplied 1 (H), classification population = 8 - 1 = 7, classified 6 (A, B, C, D, E, F), unclassifiable 1 (G). 6 + 1 = 7, matches the classification population. No arithmetic disagreement between this worked case and a literal run of the fixture.

**On the second fixture** (`fixtures/no-ads-pasted.md`): it exercises Refusal 1, the zero-ads branch. The run prints the NO ADS SUPPLIED block and stops, so the Output format above is never reached: no angle rows, no UNRUN list, no counts block.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never assign an angle to an ad by resemblance or vibe. Only the fixed eight tests decide, under the Step 3 scope rule and the fixed tie-break order.
- Never read past the second sentence to complete a test, and never import meaning from a sentence you did not read.
- Never fold UNCLASSIFIABLE or NO TEXT SUPPLIED ads into an angle's count to make an angle look occupied.
- Never invent a ninth angle. If an ad's real message needs one, it still gets read against the eight, and UNCLASSIFIABLE is the honest outcome.
- Never treat an UNRUN angle as a recommendation to run it. This skill reports absence. It does not rank angles or say which one to build next.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.

<!-- ported from 01-existing/the-dtc-growth-team/creative/creative-01-angle-gap-mapper, 2026-09-06; fixes applied: Step 3 two-sentence scope rule with "which sentence decided" printed, Ad D reasoning rewritten to the new rule, editing artifact removed from the tally, founder-origin tie-break line added, "brief nobody has written" line added under the UNRUN list, second fixture branch and its output named under the worked case -->
