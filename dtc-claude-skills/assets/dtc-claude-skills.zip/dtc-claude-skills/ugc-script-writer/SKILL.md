---
name: ugc-script-writer
description: "Use when you have one angle and a creator booked and need the script she will read on camera. Takes the angle, the product facts you can stand behind, one line about the creator, and a target length of 15, 30 or 45 seconds, and returns one five-beat script where every beat carries its spoken line, its on-screen action, its overlay text and its seconds. Triggers on \"write me a UGC script\", \"30 second creator script for this angle\", \"script for my UGC creator\", \"turn this angle into a shoot script\"."
---

# RISE DTC Claude Skills, 07 of 15: the UGC script

## What this does

Turns one angle and one product fact list into a script a creator can shoot
today: five beats in a fixed order, each with the words she says, what her hands
do, the text on screen, and the seconds it runs.

The seconds are a budget. A creator reads about 2.4 words per second, so a 30
second script holds 72 words and no more. This skill counts the words it wrote,
prints them against that budget, and refuses to fill a beat with no supplied
fact behind it. One job per skill: one script, one angle.

**The line only this skill produces:** one shootable five-beat script for one
angle at one length, every spoken line traced to a supplied fact, with the word
count printed against the budget, beat by beat.

## Required input

1. **The angle**, one plain sentence you type, for example "MECHANISM, the
   magnets are what makes it hold."
2. **The product facts you can stand behind.** At minimum: what it is, what it
   does, price, what's in the box. Typed, or pasted off your product page.
3. **The creator, one line.** Who she is and where she films, for example "a
   commuter who films in her kitchen and on her bike."
4. **The target length**, 15, 30 or 45 seconds.
5. **Optional, only if you have it:** guarantee terms, a founder detail, and a
   verbatim customer quote with its source, pasted off your review widget.

## What it refuses

Where an input this format needs is absent, print `[NEEDS: <what to supply>]` in
the slot, never a plausible value.

**Refusal 1, PROOF with nothing to prove with.** No verbatim quote and no review
count or rating means no PROOF line. All four lines of that beat print
`[NEEDS: one verbatim customer quote with its source, or a review count and rating]`
and its seconds are reported as unfilled.

**Refusal 2, a CTA with no offer.** The CTA is built from price, guarantee terms
and what's in the box, and nothing else. Neither price nor guarantee supplied
prints `[NEEDS: price, or your guarantee terms]`.

**Refusal 3, an angle nobody can back.** An angle needing a fact class that is
absent prints `ANGLE UNSUPPORTED: <angle>` at the top, falls the HOOK back to
what it is, and keeps going.

## The five beats, fixed order

| # | Beat | What it carries | Fact class it rests on |
|---|---|---|---|
| 1 | HOOK | first words, 0 to 3s at every length | what it is, or what it does |
| 2 | PROBLEM | the before-state | what it does |
| 3 | REVEAL | the product on camera | what it is, what's in the box |
| 4 | PROOF | the supplied quote or review data | the quote, or count and rating |
| 5 | CTA | the offer line | price, guarantee, what's in the box |

Five beats. Every run prints all five, a refused one included.

## Seconds and words, all three lengths

| Beat | 15s | 30s | 45s |
|---|---|---|---|
| HOOK | 0-3 (3s) | 0-3 (3s) | 0-3 (3s) |
| PROBLEM | 3-6 (3s) | 3-9 (6s) | 3-12 (9s) |
| REVEAL | 6-9 (3s) | 9-16 (7s) | 12-24 (12s) |
| PROOF | 9-12 (3s) | 16-24 (8s) | 24-38 (14s) |
| CTA | 12-15 (3s) | 24-30 (6s) | 38-45 (7s) |
| whole script | 15s | 30s | 45s |

Word budget is 2.4 spoken words per second, floored to a whole word. Whole
script: 15 x 2.4 = 36, 30 x 2.4 = 72, 45 x 2.4 = 108 words max. Per beat, in
the order above. 15s: 3x2.4=7.2 floor 7, five times, 35 in all. 30s: 7,
6x2.4=14.4 floor 14, 7x2.4=16.8 floor 16, 8x2.4=19.2 floor 19, 14, so 70 in
all. 45s: 7, 9x2.4=21.6 floor 21, 12x2.4=28.8 floor 28, 14x2.4=33.6 floor 33,
7x2.4=16.8 floor 16, so 105 in all.

Counting rule, so two runs land on the same number: a word is anything between
two spaces, so `$49` is one word and `stem cap` is two. The same rule counts the
overlay, capped at 6 words in every beat at every length.

## Method

**Step 1, state the population read.** First output line, always:
`Read: 1 angle (<angle>), <n> product facts, 1 creator line, target length <NN> seconds.`
Count the fact bullets you were given, not the ones you wish you had.

**Step 2, print the budget.** Take the column for the stated length and print
the cap with its arithmetic, `30 x 2.4 = 72 words max`.

**Step 3, walk the five beats in order.** A present fact class means write the
beat. An absent one means that beat refuses and the next beat still runs.

**Step 4, four lines per live beat.** `spoken`, inside the beat budget.
`action`, what her hands or the product do, set where the creator line says she
films. `overlay`, 6 words or fewer. `rests on`, the supplied fact.

**Step 5, the tracing rule.** Every noun, number, material and claim in a spoken
line traces to a supplied fact, to the quote, or to the creator line, which
supplies setting only. A present base fact is permission to write the beat, not
to extend it. Read the line back word by word and strike any clause the input
did not carry. PROBLEM fails most often: write it as the plain inverse of the
supplied "what it does" sentence, never as a new harm.

**Step 6, PROOF is quoted, never authored.** The spoken line is the supplied
quote word for word. A lead-in may name the source type ("One review says") and
counts against the budget, but never characterises the quote or adds a count.
Supplied review data instead of a quote: state the count and rating as supplied,
nothing beyond them.

**Step 7, count and print.** Words per beat and in total, each against its
budget. Over budget is a rewrite, not a note.

**Step 8, unfilled seconds.** For a refused beat, subtract its seconds from the
target, printing both numbers.

## Output format

```
Read: 1 angle (<angle>), <n> product facts, 1 creator line, target length <NN> seconds.
Word budget: <NN> x 2.4 = <cap> words max.
[ANGLE UNSUPPORTED: <angle>, only on Refusal 3]

# UGC script: <angle>, <NN> seconds
Creator: "<creator line>"

## <#> <BEAT>  <a>-<b>s (<n>s, budget <w> words)
spoken:   "<line>"      <n> words
action:   <what her hands or the product do>
overlay:  <6 words max>
rests on: <supplied fact>
(all five beats in order, a refused one printing [NEEDS: ...] on all four lines)

## Word count
HOOK <n>/<w>  PROBLEM <n>/<w>  REVEAL <n>/<w>  PROOF <n>/<w>  CTA <n>/<w>
total <n> / <cap>

## Unfilled
<beat>: <n>s unfilled. Script runs <NN> - <n> = <r> of <NN> seconds.
(or "None. All five beats filled.")
```

## Worked case

This IS the fixture at `fixtures/kestrel-lane-mechanism-30s.md`, re-run
literally against the method above and checked line by line.

```
Read: 1 angle (MECHANISM), 5 product facts plus 1 quote, 1 creator line, target length 30 seconds.
Word budget: 30 x 2.4 = 72 words max.

## 1 HOOK  0-3s (3s, budget 7)
spoken:  "This is a stem cap with magnets."   7 words
action:  in her kitchen, turns the cap so the magnets face the lens
overlay: Magnets in the stem cap    rests on: what it is

## 2 PROBLEM  3-9s (6s, budget 14)
spoken:  "Before this, my phone moved on every bump between my flat and work."  13 words
action:  on the bike, holds the phone against the bare stem, lets it tip
overlay: Phone moved on every bump  rests on: the inverse of what it does, plus the creator line

## 3 REVEAL  9-16s (7s, budget 16)
spoken:  "It replaces the stem cap on your bike, and a steel ring sticks to your case."  16 words
action:  hex key into the cap, tightens it, presses the ring on her case
overlay: Cap swap, then the ring    rests on: what it is, what's in the box

## 4 PROOF  16-24s (8s, budget 19)
spoken:  "One review says: I hit a pothole on Ferrow Lane and the phone did not move."  16 words
action:  rides over a raised drain cover, camera on the stem
overlay: Pothole. Phone did not move.  rests on: the supplied quote, verified buyer

## 5 CTA  24-30s (6s, budget 14)
spoken:  "It's $49, and you can send it back within 30 days."   11 words
action:  back in the kitchen, tips the four box items onto the counter
overlay: $49, 30 days to return     rests on: price and guarantee

## Word count
HOOK 7/7  PROBLEM 13/14  REVEAL 16/16  PROOF 16/19  CTA 11/14
total 7 + 13 + 16 + 16 + 11 = 63 / 72

## Unfilled
None. All five beats filled.
```

**On fixture-b** (`fixtures/kestrel-lane-social-proof-no-quote.md`, same facts,
angle SOCIAL PROOF, no quote and no review data): the run opens
`ANGLE UNSUPPORTED: SOCIAL PROOF`, the HOOK falls back to what it does, "A stem
cap that holds your phone", 7 words, and PROBLEM, REVEAL and CTA are unchanged
above, so the count is 7 + 13 + 16 + 11 = 47 / 72. PROOF prints its NEEDS line
on all four lines, and the unfilled line reads `PROOF: 8s unfilled. Script runs
30 - 8 = 22 of 30 seconds.`

## Hard guardrails

- Never invent a number or a fact the input did not carry. Print
  `[NEEDS: <what to supply>]` for every gap.
- Never write a testimonial the customer did not say. PROOF is the supplied
  quote word for word, or it is a NEEDS line.
- Never write "as seen on", an award, a press mention, or a named competitor.
- Never predict a click rate, a cost per purchase or a return on ad spend.
- Never open with "guys", "stop scrolling", or "you NEED this".
- Never name a RISE client or any brand off the roster.
- Never run two angles in one script. A second angle is a second run.
- Over a beat budget is a rewrite, never a note.
- Overlay text is 6 words or fewer, every beat, every length.
- No em dashes anywhere in the output. No exclamation marks.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize, AI-powered,
  cutting-edge, holistic.

<!-- self-check: Method re-run by hand on fixture-a. 30s column 3/6/7/8/6 = 30s. Budgets 3x2.4=7.2 floor 7, 6x2.4=14.4 floor 14, 7x2.4=16.8 floor 16, 8x2.4=19.2 floor 19, 6x2.4=14.4 floor 14; sum 70, cap 72. Spoken words counted: 7, 13, 16, 16, 11 = 63, every beat at or under budget. Overlays 5, 5, 5, 5, 5, all under 6. Fixture-b 7+13+16+11=47, unfilled 30-8=22. Fixed list: 5 rows in the beat table, 5 beat rows in the seconds table, printed "Five beats" matches. 15s 5x3=15s, 5x7=35 under 36. 45s 3+9+12+14+7=45s, 7+21+28+33+16=105 under 108. grep, all three files: 0 em dashes, 0 banned words outside the banned list, 0 exclamation marks except this opener. -->
