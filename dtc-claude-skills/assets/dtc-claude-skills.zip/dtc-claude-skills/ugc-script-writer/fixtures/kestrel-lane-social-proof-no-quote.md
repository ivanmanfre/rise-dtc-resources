# Fixture, one UGC script request for Kestrel Lane, SOCIAL PROOF angle, 30 seconds

Invented for testing. Kestrel Lane is not a real brand. Note: designed to hit
the PROOF refusal branch. No customer quote and no review data are supplied,
and the requested angle is the one that needs them.

---

Angle: SOCIAL PROOF

Product facts:
- What it is: a magnetic bike phone mount. An aluminium stem cap with twelve neodymium magnets set into it, plus a steel ring that adheres to the back of a phone case.
- What it does: holds the phone flat against the stem cap so it stays put over road bumps.
- Price: $49.
- What's in the box: the stem cap mount, the steel ring, an adhesive pad, a 4mm hex key.
- Guarantee: 30 days, send it back for a full refund.

Customer quote: none supplied.
Review count or rating: none supplied.

Creator: a commuter who films in her kitchen and on her bike.

Target length: 30 seconds.
