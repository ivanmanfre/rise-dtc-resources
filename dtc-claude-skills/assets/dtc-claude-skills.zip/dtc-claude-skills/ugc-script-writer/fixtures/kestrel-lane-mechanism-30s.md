# Fixture, one UGC script request for Kestrel Lane, MECHANISM angle, 30 seconds

Invented for testing. Kestrel Lane is not a real brand. Note: designed to
exercise the full-run branch, where the PROOF beat has a supplied verbatim
quote to rest on.

---

Angle: MECHANISM

Product facts:
- What it is: a magnetic bike phone mount. An aluminium stem cap with twelve neodymium magnets set into it, plus a steel ring that adheres to the back of a phone case.
- What it does: holds the phone flat against the stem cap so it stays put over road bumps.
- Price: $49.
- What's in the box: the stem cap mount, the steel ring, an adhesive pad, a 4mm hex key.
- Guarantee: 30 days, send it back for a full refund.

Verbatim customer quote (pasted off the review widget on the product page,
verified buyer, August 2026):
"I hit a pothole on Ferrow Lane and the phone did not move."

Creator: a commuter who films in her kitchen and on her bike.

Target length: 30 seconds.
