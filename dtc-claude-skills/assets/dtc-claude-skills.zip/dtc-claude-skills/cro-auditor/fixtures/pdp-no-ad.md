# Fixture, a page paste with no ad supplied

Invented for testing. Threadmoor is not a real brand. Note: designed to
exercise the missing-ad branch, where the whole AD-TO-PAGE MATCH block has
nothing to read against.

Page: Threadmoor / Ribbed Merino Base Layer
Device split: 64% mobile, 36% desktop

Ad: not supplied.

## PAGE TEXT, TOP TO BOTTOM

Built for the cold you actually get.

$88.00

[ Add to bag ]

- 100% merino wool, 250gsm
- Flatlock seams
- Machine washable at 30C

SIZE AND FIT
Regular fit. Model is 183cm and wears a medium. Sizes S to XXL.

CARE
Machine wash at 30C. Do not tumble dry. Dry flat.

REVIEWS
4.8 stars, 96 reviews

"Warmer than the two layers it replaced. No itch." - Priya S.

SHIPPING AND RETURNS
Free UK delivery over $60. Returns within 60 days, we pay the return label.
