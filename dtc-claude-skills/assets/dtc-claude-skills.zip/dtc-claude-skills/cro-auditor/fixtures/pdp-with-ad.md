# Fixture, one supplement PDP with the ad that sends traffic to it

Invented for testing. Brackenwater is not a real brand. Note: designed to
exercise all three verdicts in one run, including the CANNOT CHECK branch on
the cart and speed points, and the UNANSWERED branch in the ad claim ledger.

Page: Brackenwater / Nightly Magnesium Glycinate Powder
Device split: 78% mobile, 22% desktop

## PAGE TEXT, TOP TO BOTTOM

Sleep is a skill. Learn it.

Nightly is a magnesium glycinate powder you stir into water before bed.

$44.00
was $58.00

[ Add to cart ]

Free shipping over $50

30 nights per tub
Third-party tested by Kestrel Labs
Made in an NSF certified facility

- 300mg magnesium glycinate per serving
- L-theanine 200mg
- No sugar, no melatonin
- Berry flavour, dissolves cold

WHAT IS IN THE TUB
One 240g tub. 30 servings. One 8g scoop included.

HOW TO USE
One scoop in 250ml of cold water, 45 minutes before bed, nightly.

INGREDIENTS
Magnesium glycinate, L-theanine, natural berry flavour, citric acid, stevia leaf extract.

WHY PEOPLE STAY ON IT
Selling fast. Our last run sold out in nine days.

REVIEWS
4.6 stars, 812 reviews

"Third week in and I stopped waking up at 3am. The berry one dissolves properly in cold water, which the last powder I tried never did." - Dana R.

"Tastes fine. Arrived in two days." - Marcus T.

SHIPPING AND RETURNS
Dispatch within 1 business day. UK delivery 2 to 3 working days.
Returns accepted within 30 days, we pay the return label.

FAQ
Q: Is there a subscription?
A: Yes. Subscribe and save 15%, billed every 30 days, cancel any time in your account.

Q: Can I take it with other supplements?
A: Most people do. Ask your doctor if you are pregnant or on medication.

Q: How do I contact you?
A: help@brackenwater-invented.example

## THE AD THAT SENDS TRAFFIC HERE

Primary text:
Most sleep powders are melatonin in a tub. Nightly is 300mg of magnesium
glycinate and 200mg of L-theanine, no melatonin, no sugar. 30 nights for $44.
Clinically studied dose. Free returns, 60 days.

Headline:
Fall asleep in under 20 minutes
