---
name: cro-auditor
description: "Use when a page is taking paid traffic and you want a fixed list of what is missing. Takes the page text top to bottom, the ad sending traffic to it, and the device split, and returns 48 points marked PASS / FAIL / CANNOT CHECK, with the page line quoted and one fix per FAIL. Triggers on \"audit my product page\", \"CRO check on this PDP\", \"does my page match my ad\", \"what is missing from this page\"."
---

# RISE DTC Claude Skills, 09 of 15: the page checklist

## What this does

Walks one product or landing page against 48 fixed points, in 8 blocks of 6, in
a fixed order. Every point gets PASS, FAIL, or CANNOT CHECK FROM PASTE.

One job per skill: it finds what is absent. It does not rank fixes by guessed
impact, score the page, or call a page good.

**The line only this skill produces:** 48 points marked PASS / FAIL / CANNOT
CHECK, then the FAIL list in block order, each with the page line quoted and one
fix written only from facts you supplied.

## Required input

1. **The page text, top to bottom, as it reads.** Headline, subhead, price line,
   buttons (as `[ label ]`), badges, bullets, headings, reviews, shipping and
   returns lines, FAQ. Paste order is load bearing.
2. **The ad sending traffic to it**: primary text and headline, both.
3. **The device split**, if you have it ("78% mobile").
4. Optional, for the cart points: the cart or checkout lines, and a load time.

## What it refuses

**Refusal 1, nothing to walk.** No page text pasted, stop:

```
NO PAGE TEXT SUPPLIED
Nothing here reads as a page. Paste the page top to bottom, in order.
```

**Refusal 2, no ad, no guessing the ad.** With no ad supplied, all six AD-TO-PAGE
MATCH points print CANNOT CHECK FROM PASTE under one shared NEEDS line, the count
still reads "of 48", and the ad is never rebuilt from the page.

**Refusal 3, no score, no forecast.** No mark out of ten, no grade, no ranked
"biggest wins", no predicted lift in conversion rate or revenue per session.

Where the input lacks a value, print `[NEEDS: <what to paste>]`, never a
plausible value.

## Method

**Step 1, state the read:** the page, ad supplied yes or no, the device split.
Then mark the first screen: every line above the primary button, plus the button.
Block F and point M2 read only those lines.

**Step 2, walk all 48 in ID order**, never reordering or skipping. FAIL means the
page does not carry it. CANNOT CHECK FROM PASTE means a paste cannot settle it.

| ID | check | PASS requires |
|---|---|---|
| **FIRST SCREEN** | | |
| F1 | headline category | a plain category noun |
| F2 | what it does | what it is and when it is used |
| F3 | price up top | a price with a currency |
| F4 | one buy button | one button, buying verb on it |
| F5 | buyer named | who it is for, or their state |
| F6 | coined terms | each invented name explained there |
| **OFFER & PRICE** | | |
| O1 | a real price | a number, not "from" alone |
| O2 | per unit cost | per unit cost, or price and unit count |
| O3 | struck price | a word saying what it was |
| O4 | discount terms | amount, what it applies to, the code |
| O5 | subscription terms | price, frequency, cancel route, beside price |
| O6 | shipping named | the charge, or threshold and charge below |
| **PROOF** | | |
| P1 | count and average | both print as numbers |
| P2 | attributed review | a quote with a name or handle |
| P3 | about this product | a review names product, format or use |
| P4 | claims sourced | each numeric claim names study or lab |
| P5 | proof of the promise | a review names the first screen outcome |
| P6 | marks name a body | each badge names who tested it |
| **PRODUCT CLARITY** | | |
| C1 | what arrives | contents and count |
| C2 | size | a number with a unit |
| C3 | ingredients | an itemised list, not an adjective |
| C4 | how to use | quantity and frequency |
| C5 | time to result | an "it works" claim carries a timeframe |
| C6 | variants | options and what separates them |
| **OBJECTIONS** | | |
| B1 | returns window | a number of days |
| B2 | return shipping | who pays it |
| B3 | guarantee terms | the trigger and the claim route |
| B4 | delivery time | dispatch or arrival in days |
| B5 | suitability | who it is not for, or an allergen note |
| B6 | contact route | an email, phone or chat route |
| **CART & CHECKOUT SIGNALS** | | |
| K1 | where the button goes | drawer, cart page or checkout |
| K2 | payment methods | named in text or a screenshot |
| K3 | conditions above button | auto renew, term, pre order, final sale |
| K4 | no unnamed charge | cart lines pasted, each charge named |
| K5 | buy box default | pre selected variant and quantity |
| K6 | scarcity number | units left, or a date |
| **MOBILE & SPEED SIGNALS** | | |
| M1 | device split | a mobile percentage |
| M2 | words above button | 60 or fewer |
| M3 | headline length | 12 words or fewer |
| M4 | paragraph length | none over 60 words |
| M5 | sections before reviews | 8 or fewer headings |
| M6 | measured load | a load time or speed score, sourced |
| **AD-TO-PAGE MATCH** | | |
| A1 | ad supplied | primary text and headline |
| A2 | claims answered | every ledger row reads ANSWERED |
| A3 | ad headline on page | its promise on the first screen |
| A4 | price match | ad price equals page price |
| A5 | offer match | the ad's offer appears, same terms |
| A6 | same product | product, pack size and variant match |

P4, C5, B3, K3, K6 and A4 also pass when no such claim is made. In the M block a
word is a whitespace separated token, so `$44.00` is one word. Those thresholds
are this checklist's own cut points, not an industry benchmark and not a forecast.

**Step 3, the ad claim ledger:** one quoted row per ad claim, ANSWERED when the
page carries the same fact in its own words, UNANSWERED when it does not,
meaning absent, not false. Print `ANSWERED n + UNANSWERED n = n claims`.

**Step 4, count:** `PASS n / FAIL n / CANNOT CHECK n of 48`, addition printed
under it. If it does not sum to 48, a point was skipped.

**Step 5, print the FAIL list, then the CANNOT CHECK list, both in block order**
(F, O, P, C, B, K, M, A, by number), never by guessed impact. Each FAIL carries
the page line quoted and one fix from facts already in the paste, or
`[NEEDS: ...]` if the fix needs a fact nobody supplied. Each CANNOT CHECK names
the paste or screenshot that settles it. Two points can flag one line: fix both.

## Output format

```
Read: one page paste for "<page>", ad supplied: <yes/no>, mobile split <n>%. 48 points, 8 blocks of 6.

VERDICT TABLE   | ID | verdict | note |   (48 rows, ID order)
AD CLAIM LEDGER | claim quoted from the ad | ANSWERED / UNANSWERED | where on the page |
ANSWERED <n> + UNANSWERED <n> = <n> claims
COUNT   PASS <n> / FAIL <n> / CANNOT CHECK <n> of 48, and <n> + <n> + <n> = 48

FAILS, block order:        <ID>  "<page line>"  fix: <one line, or [NEEDS: ...]>
CANNOT CHECK, block order: <ID>  [NEEDS: <what to paste or screenshot>]
```

## Worked case

`fixtures/pdp-with-ad.md`, walked against the method above.

Read: one page paste for "Brackenwater / Nightly Magnesium Glycinate Powder", ad
supplied: yes, mobile split 78%. 48 points, 8 blocks of 6.

The first screen is the four lines above `[ Add to cart ]` plus the button. M2
counts 6 + 12 + 1 + 2 = 21 words there, under 60, PASS. M3 counts 6 headline
words, PASS. M5 counts 4 headings above REVIEWS, PASS. O2 has price and count
printed: $44.00 / 30 servings = $1.47 per night.

Ledger: the ad's five product facts (300mg magnesium glycinate, 200mg
L-theanine, no melatonin, no sugar, 30 nights for $44) are ANSWERED. Its
competitor line, "Clinically studied dose", "Free returns, 60 days" and the ad
headline are UNANSWERED. ANSWERED 5 + UNANSWERED 4 = 9 claims.

Count: PASS 34 / FAIL 9 / CANNOT CHECK 5 of 48, and 34 + 9 + 5 = 48.

```
F1  "Sleep is a skill. Learn it."  fix: put the subhead's words up top, magnesium glycinate powder.
F5  (no buyer named)  fix: [NEEDS: who this is for. The only buyer signal sits inside a review.]
O5  "billed every 30 days, cancel any time" (FAQ)  fix: move it beside the $44.00 price.
O6  "Free shipping over $50"  fix: [NEEDS: postage on a $44.00 order, $50.00 - $44.00 = $6.00 short.]
K3  "billed every 30 days, cancel any time" (FAQ)  fix: print it above [ Add to cart ].
K6  "Selling fast."  fix: [NEEDS: units left, or a restock date. Nine days was a past run.]
A2  4 of 9 ad claims absent.  fix: [NEEDS: per claim, cut it or supply the page fact.]
A3  "Sleep is a skill. Learn it."  fix: [NEEDS: a sleep onset time. The page states none.]
A5  "Returns accepted within 30 days"  fix: [NEEDS: one window. Ad says 60, 60 - 30 = 30 apart.]
```

CANNOT CHECK: K1 `[NEEDS: the screen the button lands on]`, K2 `[NEEDS: a
screenshot under the button]`, K4 `[NEEDS: the cart lines]`, K5 `[NEEDS: a
screenshot of the buy box]`, M6 `[NEEDS: a load time or speed score]`.

On fixture-b, `fixtures/pdp-no-ad.md`, no ad is supplied, so Refusal 2 fires: A1
through A6 print CANNOT CHECK FROM PASTE under one shared `[NEEDS: the primary
text and headline of the ad sending traffic here]`, so that run's count reads
"of 48" with 6 of its CANNOT CHECK from that block. Blocks F through M are walked
in full, so it still returns a quoted FAIL list.

## Hard guardrails

- Never invent a number or a fact the paste did not carry, and never write fix
  copy needing a fact nobody supplied. Print `[NEEDS: ...]` instead.
- Never copy a claim from the ad onto the page as a fix. An UNANSWERED claim is
  a decision for the reader, not a gap to fill with the advertiser's words.
- Never score or grade the page, rank fixes by guessed impact, call a page good,
  or predict a click rate, conversion rate, cost per purchase or return on ad
  spend outcome.
- Never reorder the 48 points, skip one, or merge two, and never fold CANNOT
  CHECK into FAIL: absent evidence is not a defect.
- No brand or client names from the RISE DTC roster, invented brands only.
  Audience word is DTC, never "ecom".
- No em dashes. No exclamation marks anywhere in the output.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize, AI-powered,
  cutting-edge, holistic.
