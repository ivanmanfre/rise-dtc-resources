---
name: cro-auditor
description: "Use when a page is taking paid traffic and you want a fixed list of what is missing. Takes the page text top to bottom, the ad sending traffic to it, and the device split, and returns 48 points marked PASS / FAIL / CANNOT CHECK, with the page line quoted and one fix per FAIL. Triggers on \"audit my product page\", \"CRO check on this PDP\", \"does my page match my ad\", \"what is missing from this page\"."
---

# RISE DTC Claude Skills, 09 of 15: the page checklist

## What this does

Walks one product or landing page against 48 fixed points, in 8 blocks of 6, in
a fixed order. Every point gets PASS, FAIL, or CANNOT CHECK FROM PASTE.

One job per skill: it finds what is absent, and never ranks fixes by guessed
impact, scores the page, or calls a page good.

**The line only this skill produces:** 48 points marked PASS / FAIL / CANNOT
CHECK, then the FAIL list in block order, each carrying the page line quoted and
one fix built only from facts you supplied.

## Required input

1. **The page text, top to bottom, as it reads.** Headline, subhead, price,
   buttons (as `[ label ]`), badges, bullets, headings, reviews, shipping and
   returns lines, FAQ. Paste order counts.
2. **The ad sending traffic to it**: primary text and headline.
3. **The device split**, if you have it ("78% mobile").
4. Optional, for the cart and speed points: cart lines, and a load time.

## What it refuses

**Refusal 1, nothing to walk.** No page text pasted, stop:

```
NO PAGE TEXT SUPPLIED
Paste the page top to bottom, in the order it reads.
```

**Refusal 2, no ad, no guessing the ad.** With no ad supplied, all six AD-TO-PAGE
MATCH points print CANNOT CHECK FROM PASTE under one shared NEEDS line, the count
still reads "of 48", and the ad is never rebuilt from the page.

**Refusal 3, no score, no forecast.** No mark out of ten, no grade, no ranked
"biggest wins", no predicted lift in conversion rate or revenue.

Where the input lacks a value, print `[NEEDS: <what to paste>]`, never a
plausible value.

## Method

**Step 1, state the read** (page, ad supplied yes or no, device split), then mark
the first screen: every line above the primary button, plus the button. Block F
and M2 read only those.

**Step 2, walk all 48 in ID order**, never reordering or skipping. FAIL means the
page does not carry it. CANNOT CHECK FROM PASTE means a paste cannot settle it.

| ID | check | PASS requires |
|---|---|---|
| **FIRST SCREEN** | | |
| F1 | headline category | plain category noun |
| F2 | what it does | what it is and when it is used |
| F3 | price up top | price with a currency |
| F4 | one buy button | one button, buying verb |
| F5 | buyer named | who it is for, or their state |
| F6 | coined terms | invented names explained there |
| **OFFER & PRICE** | | |
| O1 | a real price | a number, not "from" |
| O2 | per unit cost | per unit cost, or price and count |
| O3 | struck price | a word saying what it was |
| O4 | discount terms | amount, what it covers, the code |
| O5 | subscription terms | price, frequency, cancel route, up top |
| O6 | shipping named | the charge, or threshold and charge |
| **PROOF** | | |
| P1 | count and average | both print as numbers |
| P2 | attributed review | a quote with a name or handle |
| P3 | about this product | a review names product or use |
| P4 | claims sourced | numeric claims name study or lab |
| P5 | proof of the promise | a review names the promised outcome |
| P6 | marks name a body | badges name who tested it |
| **PRODUCT CLARITY** | | |
| C1 | what arrives | contents and count |
| C2 | size | a number with a unit |
| C3 | ingredients | an itemised list, not adjectives |
| C4 | how to use | quantity and frequency |
| C5 | time to result | "it works" claims carry a timeframe |
| C6 | variants | options and what separates them |
| **OBJECTIONS** | | |
| B1 | returns window | a number of days |
| B2 | return shipping | who pays it |
| B3 | guarantee terms | the trigger and claim route |
| B4 | delivery time | dispatch or arrival in days |
| B5 | suitability | who it is not for, or allergens |
| B6 | contact route | an email, phone or chat route |
| **CART & CHECKOUT SIGNALS** | | |
| K1 | where the button goes | drawer, cart page or checkout |
| K2 | payment methods | named in text or a screenshot |
| K3 | conditions above button | auto renew, term, pre order, final sale |
| K4 | no unnamed charge | cart lines pasted, charges named |
| K5 | buy box default | pre selected variant and quantity |
| K6 | scarcity number | units left, or a date |
| **MOBILE & SPEED SIGNALS** | | |
| M1 | device split | a mobile percentage |
| M2 | words above button | 60 or fewer |
| M3 | headline length | 12 words or fewer |
| M4 | paragraph length | none over 60 words |
| M5 | sections before reviews | 8 or fewer headings |
| M6 | measured load | a load time or speed score, sourced |
| **AD-TO-PAGE MATCH** | | |
| A1 | ad supplied | primary text and headline |
| A2 | claims answered | every ledger row reads ANSWERED |
| A3 | ad headline on page | its promise on the first screen |
| A4 | price match | ad price equals page price |
| A5 | offer match | the ad's offer appears, same terms |
| A6 | same product | product, pack size and variant match |

P4, C5, B3, K3, K6 and A4 also pass when no such claim is made. In the M block a
word is a whitespace separated token, so `$44.00` is one word, and those
thresholds are this checklist's own, not an industry benchmark.

**Step 3, the ad claim ledger:** one quoted row per ad claim, ANSWERED when the
page carries the same fact in its own words, UNANSWERED when it does not,
meaning absent, not false. Print `ANSWERED n + UNANSWERED n = n claims`.

**Step 4, count:** `PASS n / FAIL n / CANNOT CHECK n of 48`, addition printed
under it. If it does not sum to 48, a point was skipped.

**Step 5, print the FAIL list, then the CANNOT CHECK list, both in block order**
(F, O, P, C, B, K, M, A, by number), never by guessed impact. Each FAIL carries
the page line quoted and one fix from facts in the paste, or `[NEEDS: ...]` if
it needs a fact nobody supplied. Each CANNOT CHECK names what to paste. Two
points can flag one line: fix both.

## Output format

```
Read: one page paste for "<page>", ad supplied <yes/no>, mobile split <n>%. 48 points, 8 blocks.

VERDICT TABLE   | ID | verdict | note |   (48 rows, ID order)
AD CLAIM LEDGER | claim quoted from the ad | ANSWERED / UNANSWERED | where on page |
ANSWERED <n> + UNANSWERED <n> = <n> claims
COUNT   PASS <n> / FAIL <n> / CANNOT CHECK <n> of 48, and <n> + <n> + <n> = 48

FAILS, block order:        <ID> "<page line>" fix: <one line, or [NEEDS: ...]>
CANNOT CHECK, block order: <ID> [NEEDS: <what to paste or screenshot>]
```

## Worked case

`fixtures/pdp-with-ad.md`, walked against the method above.

Read: one page paste for "Brackenwater Nightly Magnesium", ad supplied yes,
mobile split 78%. 48 points, 8 blocks.

First screen: the four lines above `[ Add to cart ]` plus the button. M2 counts
6 + 12 + 1 + 2 = 21 words, under 60, PASS. M3 counts 6 headline words,
PASS. M5 counts 4 headings above REVIEWS, PASS. O2 has both printed: $44.00 / 30
servings = $1.47 per night.

Ledger: the ad's five product facts (300mg magnesium glycinate, 200mg
L-theanine, no melatonin, no sugar, 30 nights for $44) are ANSWERED. Its
competitor line, "Clinically studied dose", "Free returns, 60 days" and the ad
headline are UNANSWERED. So ANSWERED 5 + UNANSWERED 4 = 9 claims.

Count: PASS 34 / FAIL 9 / CANNOT CHECK 5 of 48, and 34 + 9 + 5 = 48.

```
F1  "Sleep is a skill. Learn it."  fix: subhead's words up top, magnesium glycinate powder.
F5  (no buyer named)  fix: [NEEDS: who this is for. The one buyer signal is in a review.]
O5  "billed every 30 days, cancel any time" (FAQ)  fix: move it beside the $44.00 price.
O6  "Free shipping over $50"  fix: [NEEDS: postage on $44.00, $50.00 - $44.00 = $6.00 short.]
K3  "billed every 30 days, cancel any time" (FAQ)  fix: print it above [ Add to cart ].
K6  "Selling fast."  fix: [NEEDS: units left, or a restock date. Nine days is past.]
A2  4 of 9 ad claims absent.  fix: [NEEDS: per claim, cut it or supply the fact.]
A3  "Sleep is a skill. Learn it."  fix: [NEEDS: a sleep onset time. The page states none.]
A5  "...within 30 days, we pay the return label"  fix: [NEEDS: one window, 60 - 30 = 30 apart.]
```

CANNOT CHECK: K1 `[NEEDS: the screen the button lands on]`, K2 `[NEEDS: a
screenshot under the button]`, K4 `[NEEDS: the cart lines]`, K5 `[NEEDS: a buy
box shot]`, M6 `[NEEDS: a load time]`.

On fixture-b, `fixtures/pdp-no-ad.md`, no ad is supplied, so Refusal 2 fires: A1
through A6 print CANNOT CHECK FROM PASTE under one shared `[NEEDS: the ad's
primary text and headline]`, so that count still reads "of 48" with 6 CANNOT
CHECK from that block alone. Blocks F through M are walked in full and still
return a quoted FAIL list.

## Hard guardrails

- Never invent a number or fact the paste did not carry, and never write fix
  copy needing a fact nobody supplied. Print `[NEEDS: ...]` instead.
- Never copy an ad claim onto the page as a fix. An UNANSWERED claim is the
  reader's decision, not a gap to fill with the advertiser's words.
- Never score or grade the page, rank fixes by guessed impact, call a page good,
  or predict a click rate, conversion rate, cost per purchase or return on ad
  spend outcome.
- Never reorder the 48 points, skip one, merge two, or fold CANNOT CHECK into
  FAIL: absent evidence is not a defect.
- No brand or client names from the RISE DTC roster, invented brands only. The
  audience word is DTC, never "ecom". No em dashes, no exclamation marks.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize, AI-powered,
  cutting-edge, holistic.

<!-- self-check: 48 rows, 8 blocks of 6; fixture-a re-walked, 34+9+5=48; 0 em dash, 0 banned, 0 "!"; M2=21, M3=6, M5=4, $44/30=$1.47 -->
