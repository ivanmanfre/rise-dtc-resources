---
name: budget-step-planner
description: "Use when you are about to raise a campaign's daily budget on an account you are running and you do not want to find out three days later that you broke it. Takes the current daily budget, the 7-day and 30-day rows for that one campaign from Ads Manager, and the cost per purchase the brand can afford, and returns the next daily budget, the number of days to hold it untouched, and the printed condition that puts it back. Triggers on \"how much should I increase this budget\", \"can I scale this campaign\", \"how fast can I raise spend\", \"what budget should I go to next\", \"when do I revert if this goes wrong\", \"the client wants to spend more, how much can this campaign take\"."
---

# RISE DTC Claude Skills, 14 of 15: the budget step planner

## What this does

Sizes one budget increase on one campaign, decides how long it has to sit
untouched before anyone is allowed to judge it, and writes the sentence that
puts the budget back where it was.

Out comes one file, `budget-step.md`.

**The line only this unit produces:** the next daily budget for one named
campaign, the number of days to hold it, and the revert trigger written as a
number and a date.

Nothing here reads an increase you already made. This unit only plans the one in
front of you, and it plans exactly one step. The step after this one is planned
after this one has been held and judged.

## Required input

1. **The campaign name**, copied from the Campaigns screen.
2. **Its current daily budget**, in dollars.
3. **The 7-day row for that campaign**: amount spent, purchases, cost per
   purchase. Set the date preset to Last 7 Days and read the row.
4. **The 30-day row for the same campaign**: amount spent, purchases, cost per
   purchase. Same screen, date preset Last 30 Days.
5. **The cost per purchase you can afford**, in dollars. One number, the one you
   would still be comfortable with if every purchase cost it.
6. **Today's date**, so the hold window and the judgement date can print.

If the paste carries several campaigns, this unit does not run once over the
block. It splits the block first and prints one plan per campaign name, because
a hold window and a revert trigger belong to one campaign and cannot be shared.

Never ask for a CSV, an account connection, a pixel, a margin figure or a
lifetime value. Everything above is on two screens with the date preset changed
once.

## What it refuses

**Refusal 1, too few purchases to step on.** The minimum is **10 purchases in
the 7-day row**. Below that the cost per purchase in that row is a small-sample
number, and stepping on it is stepping on noise. Print:

```
NO STEP: NOT ENOUGH PURCHASES IN THE 7-DAY ROW
campaign: <name>
purchases in the 7-day row: <n>          minimum this unit will step on: 10
still needed: 10 - <n> = <n> purchases

At the pasted 7-day cost per purchase of $<x>, those purchases cost
<n> x $<x> = $<y> of further spend at the current budget.
Hold the current daily budget of $<b> until the 7-day row carries 10, then run
this again. No step is planned and no revert trigger is written.
```

**Refusal 2, the week is already above what you can afford.** If the 7-day cost
per purchase is at or above the cost per purchase you can afford, there is no
step to size:

```
NO STEP: THE WEEK IS ALREADY ABOVE WHAT YOU CAN AFFORD
7-day cost per purchase: $<x>      what you can afford: $<a>
This is not a step question while that is true. No step is planned.
```

**Refusal 3, no second campaign.** This unit will not plan a step on a campaign
whose rows were not pasted, will not infer a budget from an account total, and
will not plan the step after this one.

**Refusal 4, the 7-day row is incomplete.** Every figure in this unit hangs off
the 7-day row's purchase count and its cost per purchase. Where the row was
pasted with either of those cells empty, and the row's own spend and purchases
cannot supply the missing one (see the edge case on a blank cost-per-purchase
cell, which is arithmetic on the same row and is not this refusal), the run stops
here rather than printing a plan whose every line is a `[NEEDS:]`:

```
NO STEP: THE 7-DAY ROW IS INCOMPLETE
campaign: <name>
7-day row as pasted:  spend $<s>   purchases <n | blank>   cost per purchase $<c | blank>
missing: <name each empty cell>
[NEEDS: <the exact cell, named, for this campaign's Last 7 Days row>]

Without that cell there is no minimum check, no headroom, no step share, no next
budget, no hold and no revert trigger, so none of them print. Set the date preset
to Last 7 Days on this campaign, read the row again, and run this once more. The
30-day row you pasted is not a substitute: a step sized on a month and reverted
on a week is reverted against a figure it was never sized against.
```

The 30-day row is printed back verbatim under that block if it was pasted, so
nothing the reader supplied is thrown away, but no figure is computed from it.

## Method

State this once at the top of the output, before any figure:

> Every figure below is counted over the one campaign whose rows you pasted, the
> 7-day row counted once and the 30-day row counted once. Nothing here is
> averaged across campaigns and nothing here is read from any other campaign.

**Step 1, the zero-budget branch.** If the current daily budget is 0, this is not
a step, it is a start. Print the named branch and stop:

```
NO BUDGET TO STEP
This campaign is at $0.00 a day, so there is no budget to take a share of and no
step division prints.

Starting daily budget, so that one week produces the 10 purchases this unit
needs before it will size a step:
  10 x $<afford> = $<x> over 7 days
  $<x> / 7 = $<raw quotient> a day, rounded up to the cent = $<start> a day

Run it at $<start> a day for 7 days without touching it, then run this unit
again with the 7-day row it produces.
```

Print the raw quotient before the rounded figure, then round up to the cent.
Rounding up is the same direction Step 6 rounds its days up to a whole day, and
for the same reason: a figure rounded down leaves the week short of the spend
those 10 purchases need, and the week is the thing being bought.

The 10 in that line is this unit's own stated minimum, and the cost per purchase
used is the one the brand can afford, because a campaign with no history has no
cost per purchase of its own yet.

**Step 2, check the 7-day row is readable, then check the minimum.** Two checks,
in this order, because the second one cannot run without the first.

First, is the 7-day row complete. The purchase count has to be a number. A blank
cell is not a zero and is not read as one: a zero is a week that sold nothing,
and a blank is a week nobody read. If the purchase count is blank, Refusal 4
fires and the run stops for that campaign. If the purchase count is present and
only the cost per purchase is blank, that is the edge case below, not this
refusal, because spend divided by purchases is on the same row.

Second, purchases in the 7-day row against 10. Below it, Refusal 1 fires and the
run stops.

**Step 3, headroom.** How far the pasted week sits under what you can afford:

```
headroom = (afford - 7-day cost per purchase) / afford
```

Print the raw division and the decimal before any rounding. Then read the step
share off this table. The table is the whole rule and it is not adjusted by
judgement:

| headroom | step share of the current daily budget | why |
|---|---|---|
| 25% or more | 20% | there is room to absorb a worse week |
| 10% up to 25% | 10% | there is room, and one bad week eats it |
| 0% up to 10% | no step | the increase would spend the room it needs |
| below 0% | Refusal 2 | the week is already above what you can afford |

A step larger than 20% of the current daily budget is outside this unit. Past
that size the campaign after the step is a different campaign from the one you
measured, and the revert trigger has nothing to compare against.

**Step 4, the 30-day check.** Divide the 7-day cost per purchase by the 30-day
cost per purchase and print the division. Three printed outcomes, exactly one of
which applies:

| ratio | printed status | effect on the step |
|---|---|---|
| above 1.20 | `RECENT WEEK WORSE THAN THE MONTH` | step share is capped at 10% whatever Step 3 said |
| 0.80 up to 1.20 | `WEEK AND MONTH AGREE` | no change |
| below 0.80 | `RECENT WEEK BETTER THAN THE MONTH, ONE WEEK ONLY` | no change, and the line is printed so the reader knows the step rests on the better of two figures |

**Step 5, the next daily budget.** Print the arithmetic in full:

```
step share: <p>% of the current daily budget
  $<budget> x <p as decimal> = $<step>
  $<budget> + $<step>          = $<new budget>
```

**Step 6, the hold.** The budget sits untouched until the window it needs to be
readable has passed. Two numbers, the larger wins:

```
days to reach 10 purchases at the new budget:
  10 x $<7-day cost per purchase> = $<x> of spend
  $<x> / $<new budget> = <d> days, rounded up to <D>
hold: the larger of 7 and <D> = <H> days
window: <today> to <today + H - 1>
judged on: <today + H>
```

Seven is this unit's floor because a shorter window is a weekday-and-weekend
artefact rather than a result.

**Step 7, what the window is expected to buy.** Print it, and print what it is
not:

```
$<new budget> x <H> = $<spend in the window>
$<spend in the window> / $<7-day cost per purchase> = <n> purchases
```

That count is arithmetic on the rate you pasted, and the rate is the thing the
step is testing. It is the count that makes the window readable rather than a
forecast of what you will get. Say that in the output in those words.

**Step 8, the revert trigger.** One trigger, one number, one date:

```
REVERT TRIGGER
If the cost per purchase for <campaign> over <window> closes above $<afford>,
set the daily budget back to $<budget> on <judged on>.
```

The trigger is judged once, at the close of the window, on the window's own cost
per purchase. Judging it daily inside the window turns a seven-day read into
seven one-day reads, and every one of those is below this unit's minimum.

**Step 9, what this step is not allowed to touch.** Print the three, plainly:
the campaign's targeting, its creative, and its bid or cost controls. A budget
step with a second change inside it cannot be reverted, because you will not
know which change you are reverting.

## Output format

Write one file, `budget-step.md`.

```
# Budget step
campaign: <name>          today: <date>
population line: <the sentence from the Method preamble>

current daily budget: $<b>
7-day row:   spend $<s>   purchases <n>   cost per purchase $<c>
30-day row:  spend $<s>   purchases <n>   cost per purchase $<c>
what you can afford: $<a>

minimum check: <n> purchases against 10 -> MET | NOT MET
headroom: ($<a> - $<c>) / $<a> = <decimal> = <percent>
week against month: $<c7> / $<c30> = <decimal> -> <status>
step share: <p>%

NEXT DAILY BUDGET: $<new>
  $<b> x <p decimal> = $<step>;  $<b> + $<step> = $<new>

HOLD: <H> days, <window>, judged on <date>
  <the two numbers from Step 6>

expected in the window: <n> purchases
  <the arithmetic from Step 7, with the sentence saying what it is not>

REVERT TRIGGER
  <the trigger from Step 8>

do not touch during the hold: targeting, creative, bid or cost controls
```

Every slot above that the input did not carry prints
`[NEEDS: <the exact thing to supply>]` in place of the figure, and every figure
computed from it prints `[NEEDS: ...]` as well rather than a value derived from a
guess.

## Edge cases

**The 7-day row and the 30-day row disagree about which is the campaign.** Two
different campaign names means two different campaigns. Print
`[NEEDS: the 30-day row for <the campaign named in the 7-day row>]` and do not
step.

**The purchases figure is present but the cost per purchase cell is blank.**
Divide the row's own spend by its own purchases, print that division, and label
it `derived from the row you pasted`. Both figures are on the same row, so this
is arithmetic rather than an assumption.

**The reader gives a range for what they can afford.** Use the lower number, and
print one line saying the plan was built on the lower end of the range they gave.
A step sized on the top of a range has a revert trigger that fires late.

**The campaign is a shopping or a search campaign rather than a Meta campaign.**
The rule is the same and the screen is different: the Final URL side of Google
Ads carries the same three fields per campaign row. Print the source screen name
back to the reader so the next pull comes from the same place.

**The reader has already raised the budget before running this.** Then the
current daily budget is the raised one and the 7-day row is from before the
raise. Print `ROWS PREDATE THE CHANGE` and say plainly that the hold window
starts today at the budget now live, and that the revert target is the budget
they raised from, which they have to supply:
`[NEEDS: the daily budget this campaign was on before you raised it]`.

**The reader wants the step and the hold at the same time as a creative launch.**
Print the plan and print `HOLD BROKEN BY A SECOND CHANGE` beside it. The step
cannot be judged on the window, and the unit says so rather than sizing around
it.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never plan a step larger than 20% of the current daily budget.
- Never plan a second step. One step, one hold, one trigger, then this unit is
  run again on the rows the hold produced.
- Never write a revert trigger without a date on it.
- Never invent a purchase count, a cost per purchase, a budget or a date the
  input did not carry.
- Never divide by a purchase count of zero. The zero case leaves through
  Refusal 1 before any division runs.
- Never state what the step will do to revenue, to return on ad spend, or to the
  account. This unit sizes a step and names the condition that reverses it.
- Never average figures across two campaigns. One campaign per plan.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-ridgeline-boots.md` run literally, line by
line, under the rules above, followed by fixture
`fixtures/fixture-b-three-campaigns-no-step.md` run the same way. Fixture B
pastes three campaigns in one block, so it splits into three plans, one per
campaign name, and all three print here. Both are the shipped fixtures. Neither
is a separate example.**

Input: campaign `RB | Prospecting | Broad | Video`, current daily budget $120.00,
7-day row spend $840.00 / purchases 14 / cost per purchase $60.00, 30-day row
spend $3,300.00 / purchases 50 / cost per purchase $66.00, afford $85.00, today
2026-05-11.

Run against the Output format above, slot for slot, with nothing abbreviated
away. The restatement block prints in full, and the `HOLD:` and
`expected in the window:` headers carry their summary values inline, exactly as
the template writes them.

```
# Budget step
campaign: RB | Prospecting | Broad | Video          today: 2026-05-11
population line: Every figure below is counted over the one campaign whose rows
you pasted, the 7-day row counted once and the 30-day row counted once. Nothing
here is averaged across campaigns and nothing here is read from any other
campaign.

current daily budget: $120.00
7-day row:   spend $840.00   purchases 14   cost per purchase $60.00
30-day row:  spend $3,300.00   purchases 50   cost per purchase $66.00
what you can afford: $85.00

minimum check: 14 purchases against 10 -> MET
headroom: ($85.00 - $60.00) / $85.00 = 0.294117... = 29.4%
  -> 25% or more -> step share 20%
week against month: $60.00 / $66.00 = 0.909 -> WEEK AND MONTH AGREE
step share: 20%

NEXT DAILY BUDGET: $144.00
  $120.00 x 0.20 = $24.00;  $120.00 + $24.00 = $144.00

HOLD: 7 days, 2026-05-11 to 2026-05-17, judged on 2026-05-18
  10 x $60.00 = $600.00 of spend
  $600.00 / $144.00 = 4.17 days, rounded up to 5
  hold: the larger of 7 and 5 = 7 days

expected in the window: 16.8 purchases
  $144.00 x 7 = $1,008.00
  $1,008.00 / $60.00 = 16.8 purchases
  This is arithmetic on the rate you pasted, and that rate is the thing the step
  is testing. It is the count that makes the window readable rather than a
  forecast of what you will get.

REVERT TRIGGER
  If the cost per purchase for RB | Prospecting | Broad | Video over 2026-05-11
  to 2026-05-17 closes above $85.00, set the daily budget back to $120.00 on
  2026-05-18.

do not touch during the hold: targeting, creative, bid or cost controls
```

**Fixture `fixtures/fixture-b-three-campaigns-no-step.md`, split into its three
campaign names and run literally.** Today is 2026-05-11 and the cost per
purchase the brand can afford is $85.00 for all three, both stated once at the
top of the block. Every campaign gets its own run, because a hold window and a
revert trigger belong to one campaign and cannot be shared. None of the three
reaches a step, and each one stops at a different place.

**Campaign 1 of 3, `RB | Retargeting | 30d viewers`.** Current daily budget
$40.00, 7-day row spend $210.00 / purchases 4 / cost per purchase $52.50, 30-day
row spend $1,150.00 / purchases 26 / cost per purchase $44.23. Step 1 does not
apply, the budget is not $0.00. Step 2's first check passes, both cells are
present. Step 2's second check stops the run at 4 purchases against 10:

```
NO STEP: NOT ENOUGH PURCHASES IN THE 7-DAY ROW
campaign: RB | Retargeting | 30d viewers
purchases in the 7-day row: 4          minimum this unit will step on: 10
still needed: 10 - 4 = 6 purchases

At the pasted 7-day cost per purchase of $52.50, those purchases cost
6 x $52.50 = $315.00 of further spend at the current budget.
Hold the current daily budget of $40.00 until the 7-day row carries 10, then run
this again. No step is planned and no revert trigger is written.
```

**Campaign 2 of 3, `RB | Prospecting | Lookalike 3%`.** Current daily budget
$0.00, 7-day row spend $0.00 / purchases 0 / cost per purchase blank, 30-day row
the same. Step 1 fires on the $0.00 budget and the run stops there, so no
minimum check, no headroom and no division by that purchase count of 0 ever
runs. The starting budget is built on the $85.00 the brand can afford, because
this campaign has no cost per purchase of its own, and the division rounds up to
the cent under the rule in Step 1:

```
NO BUDGET TO STEP
This campaign is at $0.00 a day, so there is no budget to take a share of and no
step division prints.

Starting daily budget, so that one week produces the 10 purchases this unit
needs before it will size a step:
  10 x $85.00 = $850.00 over 7 days
  $850.00 / 7 = $121.428571... a day, rounded up to the cent = $121.43 a day

Run it at $121.43 a day for 7 days without touching it, then run this unit
again with the 7-day row it produces.
```

**Campaign 3 of 3, `RB | Prospecting | Broad | Static`.** Current daily budget
$75.00, 7-day row spend $455.00 with both the purchase cell and the cost per
purchase cell empty, 30-day row spend $2,010.00 / purchases 31 / cost per
purchase $64.84. The blank purchase count is not read as a zero, and the blank
cost per purchase cannot be derived from the row because the count it would be
divided by is the missing cell, so this is Refusal 4 and not the edge case for a
blank cost-per-purchase cell. Step 2's first check stops it in one place:

```
NO STEP: THE 7-DAY ROW IS INCOMPLETE
campaign: RB | Prospecting | Broad | Static
7-day row as pasted:  spend $455.00   purchases blank   cost per purchase blank
missing: purchases, cost per purchase
[NEEDS: purchases in the Last 7 Days row for RB | Prospecting | Broad | Static]

Without that cell there is no minimum check, no headroom, no step share, no next
budget, no hold and no revert trigger, so none of them print. Set the date preset
to Last 7 Days on this campaign, read the row again, and run this once more. The
30-day row you pasted is not a substitute: a step sized on a month and reverted
on a week is reverted against a figure it was never sized against.

30-day row as pasted:  spend $2,010.00   purchases 31   cost per purchase $64.84
```

<!-- ported from 01-existing/the-dtc-growth-team/spend/spend-01-budget-step-planner, 2026-09-06; fixes applied: rounding rule added to the zero-budget branch division line and shown in the worked case; worked case extended to all three campaigns of fixture B, each re-run -->
