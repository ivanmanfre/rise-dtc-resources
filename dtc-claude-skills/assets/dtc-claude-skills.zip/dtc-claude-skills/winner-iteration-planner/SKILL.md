---
name: winner-iteration-planner
description: "Use when one ad is working and you need what to try next without repeating what the account already tried. Takes the copy of the best current ad, a two-sentence description of its visual, and what has already been tried against it, and returns six next variants, each changing one named element, ordered cheapest to shoot first. Triggers on \"what should I test off the winning ad\", \"plan the next six variants\", \"iterate on this ad without repeating ourselves\", \"what haven't we tried on this one yet\", \"cheapest next test off this client's best ad\"."
---

# RISE DTC Claude Skills, 06 of 15: the next six

## What this does

Takes the ad that is working and plans its next variants from a fixed eight-element list, excluding anything already listed as tried, ordered by production cost from cheapest to most expensive.

**The line only this skill produces:** the next variants of one specific best-performing ad, each changing exactly one named element not already listed as tried, in an order set by a fixed, stated production-cost tier rather than by guesswork.

## Required input

1. **The copy of the best current ad**, in full, pasted off the Ads screen. Paste the ad name too if the account uses one.
2. **Two sentences describing its visual.** What is in frame, the shot type, and the action. Not a product description, a description of what is on screen in this specific ad.
3. **What has already been tried against it.** A plain list, in your own words (for example: "we already changed the CTA," "tried a new hook twice").

## What it refuses

**Refusal 1, no visual, no variants.** If the visual description is missing, or does not name a setting, a shot type or an action:

```
CANNOT PLAN VARIANTS: NO VISUAL DESCRIBED
Visual description supplied: <what was given, or "none">

Every variant below depends on knowing what is already on screen, so a
"change one element" instruction has something to hold constant. Describe
what is currently in frame: the setting, the shot type, and the action, in
two sentences.
```

**Refusal 2, no repeating a tried element.** Any of the eight elements matched to something in the "already tried" list is excluded from planning, named as TRIED, and never appears as a variant, even if excluding it leaves fewer than six variants to plan.

## The eight elements, fixed order and cost tier

| # | Element | Cost tier |
|---|---|---|
| 1 | HOOK LINE (copy only) | LOW |
| 2 | CTA LINE (copy only) | LOW |
| 3 | PRICE FRAME (copy only, how the offer is mentioned) | LOW |
| 4 | SOCIAL PROOF LINE (copy only, inserted into existing copy) | LOW |
| 5 | CAPTION/TEXT OVERLAY (copy only, on existing footage) | LOW |
| 6 | VISUAL OPENING SHOT (reshoot of the first shot only) | MEDIUM |
| 7 | FULL VISUAL (full reshoot) | HIGH |
| 8 | FORMAT (static to video or back, full new production) | HIGH |

Ordering rule, stated once: variants are printed cheapest tier first (LOW, then MEDIUM, then HIGH), and ties within a tier are broken by the fixed list order above (lower number first). This is the skill's own stated convention, not a fact read off any account.

## Method

**Step 1, gate the visual.** No usable visual description, Refusal 1 fires and nothing further is built.

**Step 2, state the population.** "The 8 fixed elements this skill tracks, counted once each."

**Step 3, match tried elements.** Read the "already tried" list and match each item to one of the eight elements by what it changed. Matched elements are TRIED and excluded. An "already tried" item that names something not on the eight-element list is printed as UNMATCHED, with a note that it could not be excluded from planning because it does not correspond to a tracked element.

**Step 4, select untried elements.** Remaining untried elements = 8 minus TRIED count. If untried is 6 or more, plan the 6 lowest-cost-tier untried elements (Step 3's ordering rule). If untried is fewer than 6, plan all of them and print the shortfall honestly, naming what would close it:

```
Variants planned: <n> of 6 requested
Could not plan the remaining <6-n>: every other tracked element is already
listed as tried.
[NEEDS: an element not yet tried, or explicit permission to repeat <tried
element list>]
```

**Step 5, write each variant.** For each selected element: name it, its cost tier, the one concrete change, and confirm everything else stays as supplied. The change description names which existing line or shot in the supplied ad changes and what changes about it, and it never writes the replacement copy: writing the new line is the hook generator's job in this kit, or the editor's, on the brief this plan produces.

**Step 6, name the ad in the header.** Use the ad name if one was supplied. If no ad name was supplied, use the first four words of the supplied primary text, in quotes, and nothing else.

## Output format

```
# Next variants: <the ad name if supplied, otherwise the first four words of the supplied primary text in quotes>
Elements already tried (excluded): <list, or "none supplied">
Unmatched "already tried" items: <list, or "none">
Elements untried and available: <n> / 8

## Variants, cheapest to shoot first
1. <ELEMENT> (cost: LOW/MEDIUM/HIGH)
   change: "<which supplied line or shot changes, and what changes about it>"
   everything else: unchanged from the ad you supplied
(continue for each planned variant)

## Shortfall
<the Step 4 NEEDS block, or "None. All 6 requested variants planned.">
```

## Worked case

Two fixtures, both re-run literally against the method above and checked line by line before shipping.

**`fixtures/marrow-ash-winner-one-tried.md`.** Neither fixture supplies an ad name, so Step 6 takes the first four words of the supplied primary text and the header reads `# Next variants: "You lie there at"`. Already tried: "we already tried a new CTA line," matching CTA LINE. TRIED: CTA LINE (1). Untried: 8 - 1 = 7 elements. Untried is 6 or more, so 6 are planned, cheapest tier first, ties broken by list order: HOOK LINE (1, LOW), PRICE FRAME (3, LOW), SOCIAL PROOF LINE (4, LOW), CAPTION/TEXT OVERLAY (5, LOW) are the four remaining LOW-tier elements (CTA LINE excluded as TRIED), then VISUAL OPENING SHOT (6, MEDIUM), then the tie between FULL VISUAL (7, HIGH) and FORMAT (8, HIGH) is broken by list order, FULL VISUAL first. Six variants planned: HOOK LINE, PRICE FRAME, SOCIAL PROOF LINE, CAPTION/TEXT OVERLAY, VISUAL OPENING SHOT, FULL VISUAL. Shortfall: none.

Each change description points at the supplied ad and stops short of writing the new line. The HOOK LINE variant names the opening sentence "You lie there at 11pm replaying the day instead of sleeping" as the line that changes and states that the replacement opens on the even-pressure claim already in the supplied copy instead of the 11pm scene, without writing the new line. The VISUAL OPENING SHOT variant names the first shot, the phone-shot bedroom lit by a bedside lamp, as the shot that changes, and holds the second shot, the folded blanket with the price overlaid, exactly as supplied.

**`fixtures/marrow-ash-winner-four-tried.md`.** Same header rule, same four words, no ad name supplied. Already tried names four items matching HOOK LINE, CTA LINE, PRICE FRAME, SOCIAL PROOF LINE. TRIED: 4. Untried: 8 - 4 = 4 elements, CAPTION/TEXT OVERLAY, VISUAL OPENING SHOT, FULL VISUAL, FORMAT, which is fewer than 6. All 4 are planned, cheapest first: CAPTION/TEXT OVERLAY (LOW), VISUAL OPENING SHOT (MEDIUM), FULL VISUAL (HIGH), FORMAT (HIGH, tie broken by list order after FULL VISUAL). Shortfall printed: "Variants planned: 4 of 6 requested. Could not plan the remaining 6 - 4 = 2: every other tracked element is already listed as tried," with the NEEDS line naming the four tried elements as the ones that would need explicit permission to repeat.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never plan a variant off an element already listed as tried, even to reach a full six.
- Never write the replacement copy for a variant. Name the line or shot that changes and what changes about it, and stop there.
- Never invent a ninth element or a cost tier not in the fixed table.
- Never claim a variant will beat the current ad. This skill plans what to try, it does not predict which will win.
- Never claim what a change will do to cost per purchase, click rate, or any other performance figure.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.

<!-- ported from 01-existing/the-dtc-growth-team/creative/creative-05-winner-iteration-planner, 2026-09-06; fixes applied: Step 6 header naming rule added (ad name if supplied, otherwise the first four words of the supplied primary text in quotes) and applied in both worked-case runs, Step 5 given an explicit line on what a change description carries and that it never writes the replacement copy (the hook generator writes that) -->
