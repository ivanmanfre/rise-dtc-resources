# Fixture, an inherited account pasted off the Ads Manager screen

Invented for testing. Halden Provisions is not a real brand. Note: designed to
exercise the full 24 point walk with the spend and purchase columns present,
including the audience overlap branch and the paused campaign branch.

Window: Sep 1 to Sep 7
Spend floor: an ad set needs $100 in the window before I will read it.

CAMPAIGN: TOF | Prospecting | Sep   Status: Active   Campaign budget: $400/day
| ad set | status | budget | spend | purchases | audience |
|---|---|---|---|---|---|
| Broad 25-54 | Active | uses campaign budget | $1,240 | 31 | US, 25-54, all genders, no detailed targeting |
| LAL 1% Purchasers 180d | Active | uses campaign budget | $860 | 18 | US, 18-65+, Lookalike 1% purchasers 180d |
| Interest - Home Fragrance | Active | uses campaign budget | $410 | 9 | US, 25-54, Interests: candles, home fragrance |

CAMPAIGN: Retargeting   Status: Active   Campaign budget: none, ad set budgets
| ad set | status | budget | spend | purchases | audience |
|---|---|---|---|---|---|
| RT 30d ATC | Active | $60/day | $380 | 22 | US, 18-65+, Added to cart, last 30 days, website |
| RT ATC 30 day | Active | $45/day | $295 | 14 | US, 18-65+, Website added to cart 30 days |
| Email list - non purchasers | Active | $35/day | $210 | 0 | US, 18-65+, Customer list: email non purchasers |

CAMPAIGN: test_new_creative_SEPT   Status: Paused   Campaign budget: none, ad set budgets
| ad set | status | budget | spend | purchases | audience |
|---|---|---|---|---|---|
| adset 1 | Paused | $50/day | $0 | 0 | US, 18-65+, broad |
| Broad 25-54 | Active | $50/day | $185 | 0 | US, 25-54, Interests: yoga, meditation |
| Winter Gifting - LAL 3% | Active | $50/day | $95 | 3 | US, 25-65+, Lookalike 3% purchasers 180d |
