# Fixture, a paste with the name and status columns only

Invented for testing. Thorn & Meridian is not a real brand. Note: designed to
exercise the branch where the spend, purchase, budget and audience columns were
never copied across, and where no spend floor is stated.

Window: Sep 1 to Sep 7

(Columns copied: Campaign, Ad set, Delivery. The rest of the Ads Manager row
was not selected before the copy.)

CAMPAIGN: Prospecting - Broad   Delivery: Active
| ad set | delivery |
|---|---|
| US Broad 25-54 | Active |
| LAL 2% ATC | Active |

CAMPAIGN: sale_sept   Delivery: Active
| ad set | delivery |
|---|---|
| adset 3 | Active |
| US Broad 25-54 | Paused |
| Retargeting 14d | Active |
