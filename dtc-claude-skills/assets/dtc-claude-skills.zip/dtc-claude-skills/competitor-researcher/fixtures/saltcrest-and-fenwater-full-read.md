# Fixture, two competitors in electrolyte drink mix, ads plus product pages

Invented for testing. Saltcrest, Fenwater and Quarry Salt Co. are not real
brands. Note: designed to exercise the full read, including one ad the library
shows with no run length, one angle that loses a tie-break, and one claim type
no competitor occupies.

---

Library read on: 2026-09-05

## Competitor 1: Saltcrest, ad library listings

| ad | format | active since | headline | ad copy as it reads |
|---|---|---|---|---|
| A1 | video | 2026-03-02 | Shop Saltcrest | 1,000 mg of sodium per stick, no sugar, no citric acid. |
| A2 | image | 2026-07-28 | Read the reviews | Over 41,000 five star reviews from people who run in the heat. |
| A3 | video | 2026-01-19 | Saltcrest | Other mixes give you 11 grams of sugar per serving. Saltcrest gives you zero. |
| A4 | image | (library shows no date on this listing) | Saltcrest sticks | 20% off your first subscription order, this week only. |

## Competitor 1: Saltcrest, product page text

$45 for 30 sticks, or subscribe and save 15%.
1,000 mg sodium, 200 mg potassium, 60 mg magnesium per stick.
No sugar, no citric acid, no artificial colors.
If you don't like your first box we refund it and you keep the sticks.
Free shipping on orders over $60, ships in 2 to 4 business days.

## Competitor 2: Fenwater, ad library listings

| ad | format | active since | headline | ad copy as it reads |
|---|---|---|---|---|
| B1 | video | 2026-05-11 | Fenwater | I made this in my kitchen after my third hospital trip for dehydration. |
| B2 | image | 2026-08-14 | The 60 pack | $1.20 a stick when you buy the 60 pack. |
| B3 | video | 2026-06-20 | Fenwater sticks | For nurses on a twelve hour shift who forget to drink water. |

## Competitor 2: Fenwater, product page text

$72 for the 60 pack, $1.20 a stick.
Also sold as a 20 pack at $30, save $18 by buying the 60.
800 mg sodium per stick.
Third party tested for heavy metals, every batch.
Flat $5 shipping, every order.

## My own brand facts: Quarry Salt Co.

Price: $39 for 30 sticks.
Discount: subscribe and save 10%.
Bundle: (nothing on our page about a bundle)
Guarantee: 30 day refund, unopened boxes only.
Shipping: free over $50, otherwise $6.95.
Claims we can stand behind: 900 mg sodium and 150 mg potassium per stick. No
sugar. Made in the US.
