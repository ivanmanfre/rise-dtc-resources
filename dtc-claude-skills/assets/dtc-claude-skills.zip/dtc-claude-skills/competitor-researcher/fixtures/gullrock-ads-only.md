# Fixture, one competitor, ads only

Invented for testing. Gullrock is not a real brand. Note: designed to exercise
three refusal branches at once, a paste with no product page text, an ad library
that prints no run length on any listing, and no own brand facts to compare
against.

---

Library read on: 2026-09-05

## Competitor 1: Gullrock, ad library listings

| ad | format | active since | headline | ad copy as it reads |
|---|---|---|---|---|
| G1 | image | (this library does not show a date) | Gullrock | Salt, potassium, and nothing else. |
| G2 | video | (this library does not show a date) | Gullrock tins | Buy two tins, get the third free, ends Sunday. |
| G3 | video | (this library does not show a date) | Gullrock | You drink water all day and still get the 3pm headache. |

## Competitor 1: Gullrock, product page text

(I could not open their product page, nothing pasted here)

## My own brand facts

(not pasted this time)
