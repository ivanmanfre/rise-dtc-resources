---
name: roas-vs-mer-reader
description: "Use when the platforms report one revenue number and the backend reports another, and you need the distance between them before moving budget. Takes per-channel spend and reported revenue, each platform's attribution setting, and backend revenue for the same window, and returns per-channel ROAS, MER on the backend figure, and the overlap gap in dollars and as a percent of backend revenue. Triggers on \"why does Meta report more revenue than Shopify\", \"platform ROAS versus MER\", \"my ROAS is up but revenue is flat\", \"do these channel numbers add up\", \"blended ROAS for the week\"."
---

# RISE DTC Claude Skills, 12 of 15: platform ROAS versus MER

## What this does

Takes one window of channel rows read off the ad platforms, plus the one revenue figure your backend booked for that same window, and prints both readings side by side: what each platform claims for itself, and what the whole account returned against every dollar spent.

Each platform counts under its own attribution setting, so one order can appear on two of them. This skill sums those figures on purpose, because the distance from that sum to the backend figure is the read. Unit economics come off the backend number, so MER carries the weight and platform ROAS stays a per-channel diagnostic.

**The line only this skill produces:** the overlap gap, platform-reported revenue minus backend revenue, in dollars and as a percent of backend revenue, next to MER on the backend figure and each channel's own ROAS shown as a division.

## Required input

1. **The window**, one date range, stated once ("Aug 25 to Aug 31"). Every row is read on it.
2. **Per-channel rows**, typed or pasted off the Ads Manager screens: channel name, spend, platform-reported revenue.
3. **The attribution setting each platform reports on**, per row, copied off the account ("7-day click, 1-day view"). Write "cannot see it" where the account does not print it.
4. **Backend revenue for the same window**, one number, source named: Shopify total sales, Stripe gross volume, or whichever single report you pulled.
5. **Optional:** a prior window, its total ad spend, and its backend revenue from that same report.

## What it refuses

**Refusal 1, no backend number, no MER and no gap.** Both are computed against it:

```
[NEEDS: backend revenue for <window>, from one named report]
Platform ROAS still prints below. MER and the overlap gap do not.
```

**Refusal 2, an attribution setting you could not see.** That channel's ROAS still prints, being one platform's revenue over that same platform's spend, then it is locked out of every comparison:

```
<channel>: UNKNOWN SETTING
[NEEDS: the attribution setting <channel> reports on, copied off the account]
Not compared, ranked, or averaged against any other channel in this output.
```

**Refusal 3, no blended platform ROAS, ever.** ROAS figures counted under different attribution settings are never added and never averaged. No line here sums or means them, and the skill names which channel sits on which setting so the refusal is legible.

## Method

**Rounding.** Divisions carry at full precision and round only when printed, to two decimals. A printed rounded figure is never fed into a later division.

**Step 1, read the rows, flag the incomplete.** A row needs channel name, spend and reported revenue. A row missing one prints `[NEEDS: <missing field>] for "<channel>"` and is excluded from every sum below it. A missing attribution setting does not exclude a row, it routes to Refusal 2.

**Step 2, population.** Every channel row pasted for the window you named, counted once, minus rows routed to `[NEEDS:]` in Step 1.

**Step 3, platform ROAS per channel.** `reported revenue / spend`, printed as the division, tagged with the setting it was counted under.

**Step 4, the two totals.** Sum the reported revenue column, sum the spend column, both additions printed in full.

**Step 5, MER.** `backend revenue / total ad spend`, printed as the division, with the line that MER is the only figure here computed on a single source of truth: one revenue report over one spend total, no attribution setting inside it.

**Step 6, the overlap gap.** `platform-reported total - backend revenue`, then `gap / backend revenue`. Print both with sign.

**Step 7, the band, three bands, fixed.** Compare the gap against 5% of backend revenue, computed and printed. These three bands are this skill's own convention, not a figure from outside your numbers:

| Band | Rule | The read |
|---|---|---|
| PLATFORMS OVER BACKEND | gap > +5% of backend revenue | Platforms claim more than the business booked. Orders touched by two platforms are counted by both, and view-through windows count purchases no click preceded. The wider the gap, the more per-channel revenue is the same orders wearing two badges. |
| CLOSE | gap within -5% to +5% | The counts land near each other, roughly one order per order. Read per-channel ROAS as directional inside its own setting, keep budget calls on MER. |
| PLATFORMS UNDER BACKEND | gap < -5% of backend revenue | Platforms claim less than the business booked. Either tracking drops conversions (consent, iOS, tag breakage, short click windows) or demand arrives through channels these rows do not carry: organic, email, retail. |

**Step 8, name the settings, refuse the sum.** Group channels by their exact attribution string and print the groups. Channels in different groups are never summed, averaged or ranked against each other on ROAS. Name those channels in the sentence.

**Step 9, the incremental read, only with a prior window.** MER this window beside MER prior window, each as its own division, then the spend change in dollars and percent, then verbatim: "This is a correlation across two windows, not proof of causation. Season, promo, stock, price and organic demand all moved in this period too." With no prior window: `[NEEDS: a prior window with its total ad spend and its backend revenue]`.

Never estimate an attribution multiplier, never scale a platform figure to fit the backend figure, never assign a share of backend revenue to a channel.

## Output format

```
Read: <n> channel rows, window <window>, backend source <source>
Population: <the Step 2 sentence, filled in>

Platform ROAS, per channel, per setting
- <channel>: $<revenue> / $<spend> = <roas>x   setting: <setting>

Totals
platform-reported revenue: $<a> + $<b> = $<total>
total ad spend: $<a> + $<b> = $<total>
backend revenue (<source>): $<backend>

MER = $<backend> / $<spend total> = <mer>x
MER is the only figure in this output computed on a single source of truth.

Overlap gap
$<platform total> - $<backend> = $<gap>, and $<gap> / $<backend> = <percent>
5% of backend revenue = $<threshold>
BAND: <band name>
<the read for that band>

Attribution settings
<setting>: <channels>
Not summed, averaged, or ranked against each other: <channel> vs <channel>.

Two-window MER
MER <this window> = <mer>x   MER <prior window> = <mer>x
spend change: $<x> - $<y> = $<delta> = <percent>
This is a correlation across two windows, not proof of causation.
```

## Worked case

This worked case IS `fixtures/fixture-a-harrow-and-tide.md`, re-run against the Method above.

Read: 3 channel rows, window Aug 25 to Aug 31, backend source Shopify total sales.
Population: every channel row pasted for that window, counted once, 0 excluded.

- Meta: $62,560 / $18,400 = 3.40x   setting: 7-day click, 1-day view
- Google: $41,400 / $9,200 = 4.50x   setting: 30-day, data-driven
- TikTok: $9,890 / $4,300 = 2.30x   setting: 7-day click

Totals: $62,560 + $41,400 + $9,890 = $113,850 reported revenue. $18,400 + $9,200 + $4,300 = $31,900 spend. Backend revenue $95,700.

MER = $95,700 / $31,900 = 3.00x. One revenue report over one spend total, no attribution setting inside it.

Overlap gap: $113,850 - $95,700 = $18,150, and $18,150 / $95,700 = 18.97%. 5% of backend revenue = 0.05 x $95,700 = $4,785. $18,150 is greater than $4,785, so the band is **PLATFORMS OVER BACKEND**. The three platforms together claim $18,150 more than Shopify booked, 18.97% of the real number, and Meta's 1-day view window counts purchases no click preceded.

Attribution settings: three channels, three settings. "7-day click, 1-day view" is Meta only, "30-day, data-driven" Google only, "7-day click" TikTok only. Those three ROAS figures are not summed, averaged, or ranked against each other. Google's 4.50x sits on 30 days and TikTok's 2.30x on 7, so ordering them orders two counting rules.

Two-window MER: Aug 25 to Aug 31 = $95,700 / $31,900 = 3.00x. Aug 18 to Aug 24 = $79,860 / $24,200 = 3.30x. Spend change $31,900 - $24,200 = $7,700, and $7,700 / $24,200 = +31.82%. MER change 3.00 - 3.30 = -0.30, and -0.30 / 3.30 = -9.09%. Backend revenue change $95,700 - $79,860 = $15,840, and $15,840 / $79,860 = +19.83%. On the added spend alone, $15,840 / $7,700 = 2.06x, arithmetic on two points and nothing more. This is a correlation across two windows, not proof of causation. Season, promo, stock, price and organic demand all moved in this period too.

On fixture-b (`fixtures/fixture-b-nolen-supply.md`): Meta prints $38,400 / $12,000 = 3.20x on 7-day click 1-day view, Google prints $19,250 / $5,500 = 3.50x tagged `Google: UNKNOWN SETTING` with `[NEEDS: the attribution setting Google Ads reports on]`, so 3.50x is never set against 3.20x. MER = $52,500 / $17,500 = 3.00x, gap $57,650 - $52,500 = $5,150, and $5,150 / $52,500 = 9.81% against a 5% threshold of $2,625, so the band is PLATFORMS OVER BACKEND. The two-window block prints `[NEEDS: a prior window with its total ad spend and its backend revenue]` and no MER trend is stated.

## Hard guardrails

- Never invent a number or a fact the input did not carry. Where a value is absent, print `[NEEDS: <what to supply>]`, never a plausible figure.
- Never estimate an attribution multiplier, a discount factor, or a "true" per-channel revenue. This skill prints the gap, it does not allocate it.
- Never add or average platform ROAS across different attribution settings, and never print a blended platform ROAS.
- Never rank channels by platform ROAS across different attribution settings. Ordering is readable only inside one identical setting.
- Never treat the sum of platform-reported revenue as revenue earned. It is computed only as the input to the gap.
- Never predict a click rate, a cost per acquisition, or a ROAS outcome, and never say what the gap will be next window.
- Never state an industry benchmark MER or ROAS. The only threshold here is the 5% band, this skill's own printed convention.
- Never name a client or brand from the RISE roster. Fixtures use invented names.
- No em dashes anywhere in the output. No exclamation marks.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize, AI-powered, cutting-edge, holistic.

<!-- self-check: fixture-a re-run by hand: 62560/18400=3.40, 41400/9200=4.50, 9890/4300=2.30; totals 113850 and 31900; MER 95700/31900=3.00; gap 18150 = 18.97% of 95700, threshold 4785, band PLATFORMS OVER BACKEND; prior MER 79860/24200=3.30; spend delta 7700/24200=+31.82%; MER delta -0.30/3.30=-9.09%; backend delta 15840/79860=+19.83%; marginal 15840/7700=2.06. Fixture-b: 3.20, 3.50, totals 57650 and 17500, MER 3.00, gap 5150 = 9.81%, threshold 2625, PLATFORMS OVER BACKEND. All confirmed. grep on all three files: em dash 0; exclamation marks 0 in every prose and output line (the only "!" in the folder is this comment's opener); banned words appear only in the guardrail bullet naming them. Fixed list = the 3 gap bands in Step 7; table rows counted = 3, matches the printed count. -->
