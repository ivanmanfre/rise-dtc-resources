# Fixture, one week across three channels plus a prior week

Invented for testing. Harrow & Tide is not a real brand. Note: designed to
exercise the full read, with three channels on three different attribution
settings and a prior window pasted for the two-window MER comparison.

Window: Aug 25 to Aug 31
Backend revenue source: Shopify admin, total sales for the same window

| channel | spend | platform-reported revenue | attribution setting shown in the account |
|---|---|---|---|
| Meta | $18,400 | $62,560 | 7-day click, 1-day view |
| Google | $9,200 | $41,400 | 30-day, data-driven |
| TikTok | $4,300 | $9,890 | 7-day click |

Backend revenue, Aug 25 to Aug 31: $95,700

Prior window for comparison: Aug 18 to Aug 24
Prior total ad spend: $24,200
Prior backend revenue (Shopify, same report): $79,860
