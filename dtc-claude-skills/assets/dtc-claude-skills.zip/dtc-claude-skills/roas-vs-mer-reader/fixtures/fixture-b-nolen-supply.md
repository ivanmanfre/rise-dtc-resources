# Fixture, two channels with one attribution setting the reader could not find

Invented for testing. Nolen Supply is not a real brand. Note: designed to
exercise the UNKNOWN SETTING branch on one channel and the absent-prior-window
branch on the incremental read.

Window: Sep 1 to Sep 7
Backend revenue source: Stripe, gross volume for the same window

| channel | spend | platform-reported revenue | attribution setting shown in the account |
|---|---|---|---|
| Meta | $12,000 | $38,400 | 7-day click, 1-day view |
| Google | $5,500 | $19,250 | could not find where the account prints this |

Backend revenue, Sep 1 to Sep 7: $52,500

Prior window: not pulled yet
