# Fixture, one order profile with every required cost line supplied

Invented for testing. Thistlebank is not a real brand. Note: designed to
exercise the full path where all eight required inputs are present, the
returns branch runs on a restock disposition, and no target contribution is
stated so the three-rung branch prints.

Currency: USD

Read off the Shopify orders screen (last 90 days, all channels):

| line | value |
|---|---|
| average order value, before discount | $86.00 |
| average per-order discount or promo | $6.00 |
| return rate | 22% |

Read off the supplier invoice and the 3PL invoice:

| line | value |
|---|---|
| cost of goods per order | $24.50 |
| shipping cost per order we pay | $7.20 |
| pick and pack per order | $2.10 |

Read off the payment processor statement:

| line | value |
|---|---|
| payment processing | 2.9% + $0.30 per order |

Returns, from the warehouse return log:

- Returned goods are inspected and put back into sellable stock. Nothing is
  written off.
- Cost of one return, itemised: return label $6.90, inspect and restock
  labour $4.20, the fixed processing fee the processor keeps on a refunded
  order $0.30.

Target contribution left per order: not stated.
