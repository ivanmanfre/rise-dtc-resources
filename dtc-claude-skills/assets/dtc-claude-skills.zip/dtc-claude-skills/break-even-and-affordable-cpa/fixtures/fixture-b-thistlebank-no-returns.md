# Fixture, the same brand with two required lines absent

Invented for testing. Thistlebank is not a real brand. Note: designed to
exercise the ceiling branch on a missing per-order cost line and the refusal
branch on the returns-adjusted outputs. The 3PL invoice for this account
bills pick and pack inside a bundled monthly fee, and the brand has never
pulled a return rate.

Currency: USD

Read off the Shopify orders screen (last 90 days, all channels):

| line | value |
|---|---|
| average order value, before discount | $86.00 |
| average per-order discount or promo | $6.00 |
| return rate | (never pulled, not in the export) |

Read off the supplier invoice and the 3PL invoice:

| line | value |
|---|---|
| cost of goods per order | $24.50 |
| shipping cost per order we pay | $7.20 |
| pick and pack per order | (bundled into a monthly 3PL fee, no per-order figure on the invoice) |

Read off the payment processor statement:

| line | value |
|---|---|
| payment processing | 2.9% + $0.30 per order |

Returns: no return log, no cost of a return, no restock or write-off answer.

Target contribution left per order: not stated.
