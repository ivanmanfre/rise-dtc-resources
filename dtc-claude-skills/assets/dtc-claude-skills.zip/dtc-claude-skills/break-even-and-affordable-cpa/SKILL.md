---
name: break-even-and-affordable-cpa
description: "Use when you need to know what a purchase can cost you before you open the ad account. Takes the order-economics lines off a Shopify order screen, a supplier invoice and a processor statement, and returns contribution margin per order, break-even ROAS, break-even CPA, the same three recomputed after returns, and the CPA you can afford at a contribution you name. Triggers on \"what's my break-even ROAS\", \"what can I pay for a customer\", \"what CPA can I afford\", \"work out my contribution margin\", \"is a 2.1 ROAS profitable for me\"."
---

# RISE DTC Claude Skills, 11 of 15: break-even and affordable CPA

## What this does

Turns eight numbers off your own screens into the two thresholds you buy media against. Unit economics first: no target gets set and no ad gets judged until this arithmetic has run on this brand's own costs.

Every figure is a division or a subtraction printed on the page, so you can check it against your invoice. Nothing here is a benchmark, a category average, or a number borrowed from another brand.

**The line only this skill produces:** the returns-adjusted break-even ROAS and the returns-adjusted affordable CPA for one brand, each shown as arithmetic on that brand's supplied costs, with any missing cost line named and its blast radius stated.

## Required input

Rows typed or pasted off the screen. No integration, no connected account.

1. **Average order value, before discount.** Shopify admin, orders screen, one window you name.
2. **Average per-order discount or promo, in dollars.** If the order value you pasted is already net of discounts, enter $0.00 and say so.
3. **Cost of goods per order.** Supplier invoice or your cost field.
4. **Payment processing: percent and fixed fee**, for example 2.9% + $0.30.
5. **Shipping per order you pay**, net of anything the customer paid toward shipping.
6. **Pick and pack per order.** 3PL invoice, per-order line.
7. **Return rate, percent**, same window.
8. **Cost of one return, and whether goods are restocked or written off.** Return label, inspect and restock labour, and any processing fee kept on a refunded order.

Optional: **target contribution left per order** after ad cost. State none and three rungs print for you to pick from.

## What it refuses

**Refusal 1, no revenue line, nothing computes.** Without order value or the discount answer there is no denominator:

```
[NEEDS: average order value before discount]
[NEEDS: average per-order discount, or $0.00 if your order value is already net]
Computable: none of the five outputs.
```

**Refusal 2, a missing cost line prints a ceiling, never a filled slot.** The missing line prints as `[NEEDS: ...]` and contribution is computed from the costs supplied and labelled CEILING, because the true figure is lower by exactly the missing line. A ceiling contribution gives a floor break-even ROAS and a ceiling CPA. A ceiling is never a carry figure.

**Refusal 3, no return data, no returns-adjusted output.** A missing return rate or cost of a return refuses outputs 4 and 5 outright. There is no default return rate and no category figure. Outputs 1, 2 and 3 still print in full.

## Method

**Rounding.** Divisions are carried at full precision and rounded only when printed, half-up, two decimals. A printed rounded figure is never fed into a later division, so a later line names the unrounded value it used.

**Step 1, walk the input table first.** Five outputs: (1) contribution per order in dollars and percent, (2) break-even ROAS, (3) break-even CPA, (4) the returns-adjusted version of 1, 2 and 3, (5) affordable CPA at a target contribution. Eight inputs feed them:

| # | Input | Kind | Feeds | If missing |
|---|---|---|---|---|
| 1 | Order value before discount | revenue | 1,2,3,4,5 | nothing computes, Refusal 1 |
| 2 | Per-order discount | revenue | 1,2,3,4,5 | nothing computes, Refusal 1 |
| 3 | Cost of goods per order | cost | 1,2,3,4,5 | 1,2,3 ceiling and floor; 4,5 refuse |
| 4 | Processing, percent and fee | cost | 1,2,3,4,5 | 1,2,3 ceiling and floor; 4,5 refuse |
| 5 | Shipping you pay | cost | 1,2,3,4,5 | 1,2,3 ceiling and floor; 4,5 refuse |
| 6 | Pick and pack | cost | 1,2,3,4,5 | 1,2,3 ceiling and floor; 4,5 refuse |
| 7 | Return rate | returns | 4,5 | 1,2,3 in full; 4,5 refuse |
| 8 | Cost of a return, restock or write-off | returns | 4,5 | 1,2,3 in full; 4,5 refuse |

Eight rows. Print how many were supplied on the first output line.

**Step 2, revenue booked per order.** `order value - discount = net`. Subtract the discount once: if the pasted value was already net and a discount is also listed, ask which before computing. This net figure is the denominator for every percent and every ROAS below. It is revenue booked at checkout, the same thing the ad platform counts when it prints ROAS.

**Step 3, variable cost per order.** `processing = pct% x net + fixed fee`, then `variable cost = cost of goods + processing + shipping + pick and pack`.

**Step 4, outputs 1, 2 and 3.**

```
contribution per order      = net - variable cost
contribution percent        = contribution / net
break-even ROAS             = net / contribution   (equals 1 / contribution percent)
break-even CPA              = contribution, in dollars
```

Break-even CPA is contribution in dollars because at that acquisition cost the order clears zero. A dollar above it, the order loses money.

**Step 5, the loss on a returned order.** Two dispositions, two rows, use the one stated:

| Disposition | Loss on one returned order |
|---|---|
| Restocked and resellable | shipping you paid + pick and pack + cost of a return |
| Written off | shipping you paid + pick and pack + cost of a return + cost of goods |

Revenue is refunded, so a returned order books none. Cost of goods sits in the loss only when the unit cannot be sold again.

**Step 6, output 4.** Walk 100 booked orders so the arithmetic stays visible:

```
kept = 100 x (1 - return rate)        returned = 100 x return rate
contribution per 100 = (kept x contribution per order) - (returned x loss per return)
returns-adjusted contribution per order = that total / 100
returns-adjusted contribution percent   = that figure / net
returns-adjusted break-even ROAS        = net / that figure
returns-adjusted break-even CPA         = that figure, in dollars
```

The denominator stays net revenue booked, not revenue after refunds, so this ROAS lines up with the platform's.

**Step 7, output 5.** `affordable CPA = returns-adjusted contribution per order - target contribution left`, then print `net / affordable CPA` as the ROAS it implies. With no target stated, print three rungs at $5.00, $10.00 and $15.00 left per order. Those three are printed to show the slope, not a recommendation, and you pick.

**Step 8, the carry line.** Name two figures only: returns-adjusted break-even ROAS and returns-adjusted affordable CPA. Platform ROAS and this break-even ROAS are the same unit, revenue over ad spend on the same orders, so they compare directly. MER uses a different denominator, total revenue over total spend across every channel, so it does not compare against this number. MER is the job of the ROAS vs MER unit in this kit.

## Output format

```
Read: <n> of 8 required inputs supplied, one average-order profile, currency <ccy>.

## Before returns
revenue booked per order = $<aov> - $<disc> = $<net>
processing = <pct>% x $<net> + $<fee> = $<proc>
variable cost = $<cogs> + $<proc> + $<ship> + $<pnp> = $<vc>
1. contribution per order = $<net> - $<vc> = $<cm>, and $<cm> / $<net> = <pct>%
2. break-even ROAS = $<net> / $<cm> = <roas>
3. break-even CPA = $<cm>

## After returns   disposition: <restocked | written off>
loss per return = $<ship> + $<pnp> + $<retcost> = $<L>
kept = 100 x (1 - <r>) = <k>, contribution = <k> x $<cm> = $<A>
returned = 100 x <r> = <n>, loss = <n> x $<L> = $<B>
contribution per 100 = $<A> - $<B> = $<C>
4. per order = $<C> / 100 = $<cma>, and $<cma> / $<net> = <pct>%
   returns-adjusted break-even ROAS = $<net> / $<cma> = <roas>
   returns-adjusted break-even CPA  = $<cma>

## Affordable CPA   target left: <stated, or "not stated, three rungs">
5. $<target> left: $<cma> - $<target> = $<acpa>, ROAS it implies = $<net> / $<acpa> = <roas>

## Carry into the ad account
returns-adjusted break-even ROAS: <roas>
returns-adjusted affordable CPA:  $<acpa>
Platform ROAS is the same unit and compares directly. MER does not.

## Gaps
[NEEDS: <line>]   Computable without it: <outputs>. Not computable: <outputs>.
```

## Worked case

This is `fixtures/fixture-a-thistlebank-full-inputs.md`, re-run literally against the Method above and checked line by line.

Read: 8 of 8 required inputs supplied, one average-order profile, currency USD.

- revenue booked per order = $86.00 - $6.00 = $80.00
- processing = 2.9% x $80.00 = $2.32, plus $0.30 = $2.62
- variable cost = $24.50 + $2.62 + $7.20 + $2.10 = $36.42
- **1. contribution per order = $80.00 - $36.42 = $43.58**, and $43.58 / $80.00 = 0.54475 = 54.48%
- **2. break-even ROAS = $80.00 / $43.58 = 1.84** (unrounded 1.835704)
- **3. break-even CPA = $43.58**

Disposition is restocked, so cost of goods stays out of the loss:

- loss per return = $7.20 + $2.10 + $11.40 = $20.70, where the $11.40 is the fixture's own itemised return cost, $6.90 + $4.20 + $0.30 = $11.40
- kept = 100 x (1 - 0.22) = 78, contribution = 78 x $43.58 = $3,399.24
- returned = 100 x 0.22 = 22, loss = 22 x $20.70 = $455.40
- contribution per 100 booked orders = $3,399.24 - $455.40 = $2,943.84
- **4. returns-adjusted contribution per order = $2,943.84 / 100 = $29.44** (unrounded 29.4384), and $29.4384 / $80.00 = 0.36798 = 36.80%
- **returns-adjusted break-even ROAS = $80.00 / $29.4384 = 2.72** (unrounded 2.717539)
- **returns-adjusted break-even CPA = $29.44**

No target was stated, so three rungs print and you pick:

- **5.** $5.00 left: $29.4384 - $5.00 = **$24.44**, ROAS it implies = $80.00 / $24.4384 = 3.27
- $10.00 left: $29.4384 - $10.00 = **$19.44**, ROAS it implies = $80.00 / $19.4384 = 4.12
- $15.00 left: $29.4384 - $15.00 = **$14.44**, ROAS it implies = $80.00 / $14.4384 = 5.54

Carry into the ad account: returns-adjusted break-even ROAS 2.72, and the affordable CPA at the rung picked. Returns move this brand from a 1.84 break-even to a 2.72 break-even, which is arithmetic on the supplied 22% and $20.70, not a forecast.

On fixture-b, `fixtures/fixture-b-thistlebank-no-returns.md`: pick and pack is bundled into a monthly 3PL fee and no return data exists, so 6 of 8 inputs are supplied. Variable cost from the lines supplied = $24.50 + $2.62 + $7.20 = $34.32, so contribution per order = $80.00 - $34.32 = $45.68 CEILING, $45.68 / $80.00 = 57.10% CEILING, break-even ROAS = $80.00 / $45.68 = 1.75 FLOOR, break-even CPA = $45.68 CEILING. Outputs 4 and 5 print `[NEEDS: pick and pack per order]`, `[NEEDS: return rate]` and `[NEEDS: cost of a return, and whether goods are restocked or written off]`, and the gap block reads: computable as ceiling and floor, outputs 1, 2 and 3; not computable, outputs 4 and 5. Nothing is carried into the ad account on this run, because both carry figures are returns-adjusted.

## Hard guardrails

- Never invent a number or a fact the input did not carry. Print `[NEEDS: <what to supply>]` for every gap, never a plausible value.
- Never use an industry benchmark, a category average or another brand's figure to fill a missing cost. A missing cost yields a ceiling, never a value.
- Never let a ceiling become a carry figure. The two carry figures are returns-adjusted or they do not print.
- Never subtract the discount twice. Ask which basis the pasted order value is on.
- Never predict a click rate, a CPA or a ROAS outcome. This prints the CPA you can afford, never the CPA you will get, and never what your ROAS should be beyond this arithmetic.
- Never compare this break-even ROAS to MER. Different denominator, different unit.
- No client or brand names from RISE's roster. Fixture brands are invented.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize, AI-powered, cutting-edge, holistic.
- No corrective contrast, no "not just X but Y", no rhetorical openers.

<!-- self-check: Method re-run on fixture-a by hand, confirmed against exact decimal arithmetic. 86.00-6.00=80.00; .029x80=2.32 +0.30=2.62; 24.50+2.62+7.20+2.10=36.42; 80-36.42=43.58; 43.58/80=0.54475=54.48%; 80/43.58=1.835704=1.84; 7.20+2.10+11.40=20.70 (6.90+4.20+0.30=11.40); 78x43.58=3399.24; 22x20.70=455.40; 3399.24-455.40=2943.84; /100=29.4384=29.44; 29.4384/80=0.36798=36.80%; 80/29.4384=2.717539=2.72; rungs 24.4384 / 19.4384 / 14.4384, 80/x = 3.273537, 4.115565, 5.540780, printing 3.27, 4.12, 5.54. Fixture-b: 24.50+2.62+7.20=34.32; 80-34.32=45.68; 45.68/80=57.10%; 80/45.68=1.751313=1.75. Every worked-case figure matches. Greps over all three files: em dash 0; exclamation mark 0 (the only match in the file is this comment's own opener); banned words 0 outside the guardrail bullet naming them; corrective-contrast patterns 0 outside the guardrail bullet banning them. Fixed lists counted: input-to-output table 8 rows and the text prints "Eight rows", match; disposition table 2 rows and the text prints "Two dispositions, two rows", match. -->
