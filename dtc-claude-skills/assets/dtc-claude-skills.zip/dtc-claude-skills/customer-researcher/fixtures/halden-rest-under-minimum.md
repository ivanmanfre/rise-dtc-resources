# Fixture, a thin paste for Halden Rest

Invented for testing. Halden Rest is not a real brand. Note: designed to hit
the under minimum branch, and it carries no product page, so the page gap
block has nothing to read either.

---

REVIEWS (pasted out of the review widget)

1. Actually blacks out the room, my old mask leaked at the nose.

2. Bought it before a work trip. Slept on the plane for once.

3. Almost skipped it over the price. Glad I didnt.

4. Doesnt squash my eyelashes like the silk one did.

5. Its still on my face when the alarm goes off, which is new.

6. The weight is heavier than it looks. Took me a couple of nights.

7. My wife has it too now.

8. Sun comes up at half four here in summer and I sleep through it.

9. Strap dug into my ear the first night, moved it up and its fine.
