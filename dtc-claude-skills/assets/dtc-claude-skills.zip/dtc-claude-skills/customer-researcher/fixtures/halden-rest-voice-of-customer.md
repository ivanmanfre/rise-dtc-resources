# Fixture, pasted voice of customer for Halden Rest

Invented for testing. Halden Rest is not a real brand. Note: designed to run
all five blocks, including the page gap block, and to exercise the tie break
inside the ranking.

---

REVIEWS (pasted out of the review widget)

1. Third mask I've tried this year and the first one thats actually pitch black. No light gets in at the nose. I fall asleep in about ten minutes now instead of laying there for an hour.

2. I almost didn't buy it because $58 for a sleep mask felt insane. It doesnt press on my eyes, which is the whole reason the cheap ones failed for me.

3. Every other mask I've owned ends up around my neck by 3am. This one is still on my face in the morning.

4. Was worried the weight would feel like too much on my face. It doesnt, it just feels like a hand resting there.

5. My husband reads until midnight with the lamp on. I dont even know its on anymore. Pitch dark under it.

6. The weight over my eyes is the part I didnt expect. It feels heavy in a good way.

7. My room faces a street light. Nothing gets through this one.

8. It's heavier than I expected but in a good way. Asleep in maybe fifteen minutes most nights, it used to be an hour of scrolling.

9. Hesitated because I have a big head and straps never fit. the velcro goes way further than I thought.

10. I can open my eyes under it and still see nothing. No pressure on my lashes at all, which is why I kept it.

11. Bought it for my wife, she stole mine. Blocks out everything, we ordered a second one.

12. Its part of my routine now, I cant sleep without it.

13. Work nights so I sleep 8am to 3pm with sun coming through cheap blinds. Its completely dark under there.

14. The weight is the thing. I stop thinking so hard when its on. Sounds stupid but my brain goes quiet.

15. Its been four months and its still on my face every morning.

16. Wear glasses, tiny face. It's the only one that hasn't pushed into my eye socket.

17. Black as anything under there, and I've tried a lot of these.

18. Hotel curtains never close all the way, and I havent had a bad nights sleep on the road since.

---

RETURN REASONS (typed off the returns portal, free text field)

19. Too heavy, I couldnt get used to the weight.

20. Strap too tight, left a red mark across my forehead every morning.

21. Smelled like chemicals out of the box and didnt air out.

22. Kept sliding off, I think I needed the smaller size.

---

PRODUCT PAGE (pasted off the site)

Halden Rest Weighted Sleep Mask. $58.

Total blackout, edge to edge. A contoured nose baffle closes the gap where
light gets in.

Weighted. 11 oz of flax and glass bead fill for a calm, settled feel, quilted
into channels so it does not shift.

Organic cotton shell. Adjustable band with a wide hook and loop closure.

Washable. The outer cover unzips and goes in the machine.

Made for side sleepers and for travel. Ships with a cotton pouch.

30 night returns.
