# Fixture, hook request for Hearth & Rind, PROBLEM/SOLUTION angle

Invented for testing. Hearth & Rind is not a real brand. Note: this fixture
supplies only one core fact and the audience sentence, on purpose, to
exercise the no-fact refusal branch across most of the twelve device slots,
not only the optional ones.

---

Angle: PROBLEM/SOLUTION

Product facts:
- What it is: a bar of tallow soap, unscented, wrapped in wax paper.

Audience: people who react to synthetic fragrance in regular bar soap.
