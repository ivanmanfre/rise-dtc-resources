---
name: message-match-checker
description: "Use when an ad on an account you are running is getting clicks and the page behind it is not getting orders, to find the promises the ad makes that the page never answers. Takes the ad's primary text and headline plus the page copy down to the first buy button, and returns every promise claim classed ANSWERED, PARTIAL or UNANSWERED with the page line that answers it quoted verbatim. Triggers on \"people click but don't buy\", \"check my ad against my landing page\", \"does my page match my ad\", \"message match check\", \"why is this landing page not converting\", \"the ad is spending and the landing page is not converting, where is the gap\"."
---

# RISE DTC Claude Skills, 08 of 15: the message match checker

## What this does

Takes the ad apart into the separate things it promises, then goes looking for
each one in the page copy you pasted. Every promise comes back with the page
line that answers it, quoted, or with nothing beside it and the status that
says so.

Out comes one file, `message-match.md`.

**The line only this unit produces:** every promise claim in the ad, with the
page line that answers it quoted verbatim beside it, classed ANSWERED, PARTIAL
or UNANSWERED.

The check is one-directional. It reads the ad's promises and looks for them on
the page. It does not judge the page's own copy, does not rank the promises by
importance, and does not say whether the ad is good. A buyer arrives carrying
the sentence that made them click, and this unit finds out whether the page
says that sentence back.

## Required input

1. **The ad's primary text and headline**, copied from the Primary Text and
   Headline fields on the ad in Ads Manager, or the Headlines and Descriptions
   in Google Ads. One ad per run.
2. **The page copy**, from the top of the page down to the first buy button,
   typed or pasted in order. Include button labels, badges, the price, the
   small print under the price, and anything in a bar across the top of the
   page. Order matters, so paste it as it reads.
3. **One line saying where your paste stops.** For example: "stops at the Add
   to Cart button", or "the whole page down to the footer".

If you cannot supply line 3, the run still happens and every UNANSWERED row
prints `[NEEDS: where your paste stops]` beside it, because the difference
between "the page does not say this" and "you did not paste the part that says
this" is the entire value of the check.

No analytics figure is needed anywhere in this unit.

## What it refuses

**Refusal 1, answered by text you did not paste.** The moment the run is
tempted to credit a page section from memory, it prints this and stops
crediting it:

```
CANNOT COUNT THIS AS ANSWERED
promise: "<the promise claim>"
No line you pasted says this.
[NEEDS: the section of the page that says this]
Status stays UNANSWERED until that text is pasted. A section you remember
writing is not a section this check can read.
```

**Refusal 2, nothing to check.** If the ad carries no promise claim, the run
stops here and no share is printed:

```
NO PROMISE CLAIMS IN THE AD
Promise claims found: 0
Lines read in the ad: <n>

This ad says things about how it feels to own the product and never says a
thing a buyer could arrive and check. There is no match to test, because
nothing was promised.

What the ad is made of: <n> mood lines, <n> questions, <n> calls to action,
<n> lines that are the brand name on its own. Each one is listed below,
unclassed.

- "<line>"   mood line | question | call to action | brand name on its own
- "<line>"   mood line | question | call to action | brand name on its own
(one row per line read, in the ad's own order, primary text first and then the
headline. The four counts above add to "Lines read in the ad")
```

**What one line is, for every tally in this unit.** One line is one sentence.
A paragraph carrying two sentences is two lines, and a sentence standing alone
as its own paragraph is one line. The headline is one line. Count sentences and
not paragraphs, so the number does not move with how the ad happened to be laid
out in the composer. A line that is a brand name with no verb is still one line.

**Refusal 3, no new page copy.** This unit never writes the missing section.
It names the gap and stops:

```
This unit does not write page copy. It names what the page does not answer.
```

## Method

**Step 1, split the ad into promise claims.** One claim is one thing a buyer
could arrive on the page and check as true or false. A sentence carrying two
checkable things becomes two claims. Print the split with the source sentence
quoted above it, so the count can be audited:

```
from: "Free delivery over $50 and a 60 night trial."
  C1  free delivery over $50
  C2  60 night trial
```

What counts as a promise claim, the closed list:

| Form | Example shape |
|---|---|
| a stated fact about the product | what it is made of, what is in the box |
| a number | a price, a weight, a count, a percentage |
| a term | delivery, returns, guarantee, shipping threshold, subscription |
| a named outcome for the buyer | what it does for them |
| a named audience | who it is for |
| a comparison | against another product, another category, another price |
| a time | how long delivery takes, how long results take, how long an offer runs |

What is not a promise claim, and is listed but never classed: mood lines with
nothing checkable in them, questions, calls to action, the brand name on its
own.

**The split test, run before anything is classed.** Two facts in one sentence
are two claims when the page could answer one of them and not the other. Apply
it mechanically: write each candidate fact out as its own short sentence, then
ask whether a single pasted page line confirming the first necessarily confirms
the second. Where it does not, they are two claims and each carries its own
status. Grammar does not decide this. An `and`, a comma, a relative clause and a
subordinate clause all split the same way.

"Made in a mill in Yorkshire that has been running since 1890" becomes "it is
made in a mill in Yorkshire" and "that mill has been running since 1890". A page
line naming Yorkshire does not confirm 1890, so that is two claims, hitting `a
term` and `a time` on the closed list. Run as one claim it would carry one
status, and whichever of the two facts the page left alone would be hidden
inside it.

Never create a claim from a word the ad did not carry. If the split is still
arguable after that test, split it. Two claims each carrying their own status
lose nothing, and the reader can read them back as one. One claim carrying two
facts hides whichever fact the page did not answer, which is the finding this
unit exists to print.

**Step 2, print the population before anything is counted.**

```
Population for every count in this file: every promise claim in the ad you
pasted, counted once, after the split printed in Step 1. Claims: <n>.
```

If the same claim appears twice in the ad, it is counted once and both source
sentences are printed under it.

**Step 3, find each claim on the page.** Walk the pasted page copy in order and
quote the first line that addresses the claim. Quote it verbatim. If no pasted
line addresses it, leave the quote slot empty. Never paraphrase a page line into
a better version of itself.

**Step 4, class each claim.** Exactly one status each:

| Status | Definition | What must be printed with it |
|---|---|---|
| `ANSWERED` | A pasted page line states the same thing the claim states | the page line, verbatim |
| `PARTIAL` | A pasted page line addresses the same subject and changes a number, a condition, a scope or a name | the page line, verbatim, and the named difference |
| `UNANSWERED` | No pasted page line addresses it | `[NEEDS: the section of the page that says this]` |

`PARTIAL` is the row that carries the finding most of the time, so it never
gets folded into either of the other two. An ad saying "free delivery" and a
page saying "free delivery over $50" is PARTIAL, and the difference printed is
"the page adds a threshold the ad did not state".

**Step 5, print the counts, then the shares.** The population sentence prints
directly above them, in the same block, every time. It is never one section
away and never assumed from Step 2. Every class gets its own row over that one
stated population, including the classes with nothing in them:

```
Population: every promise claim in the ad you pasted, counted once, after the
Step 1 split. Claims: <N>.

ANSWERED    <n> claims   <n> / <N> = <decimal>
PARTIAL     <n> claims   <n> / <N> = <decimal>
UNANSWERED  <n> claims   <n> / <N> = <decimal>
                         ---------
                         <N> claims

not classed: <n> lines, listed in full under "Not classed" above. They are
outside the population by definition, because a mood line, a question, a call to
action and a brand name on its own promise nothing a buyer could arrive and
check. They are printed so the ad can be reconciled line by line, and they are
never added into <N>.
```

The count is the figure to read. The share is printed beside it and is not the
finding, because the denominator is set by how finely Step 1 split the ad and
not by anything the reader's account did. Two runs that split one sentence
differently print different shares from the same ad and the same page. The
counts move too, but a count carries its own denominator on its face and a
percentage does not.

There is no single match rate in this file and no score. Three counts and three
shares over one population, and the three counts add to N. Print the raw
division before any rounding.

The denominator is set by the Step 1 split, which is printed in full above it.
Print this line under the shares, always:

```
The denominator is the split printed in Step 1. If you would have split a
sentence differently, recount on your split; these shares move with it.
```

Never say what a good share is. There is no benchmark here and inventing one
would be the same fabrication the unit exists to catch.

**Step 6, name the first repair.** One claim, chosen by a printed rule, not by
judgement:

```
Fix this one first: the highest UNANSWERED claim in the ad's own reading order.
Reading order, because the input does not carry which promise sells hardest,
and picking on importance would be a guess wearing a ranking.
```

If there is no UNANSWERED claim, print the highest PARTIAL instead and say so.
If there is neither, print `NOTHING TO REPAIR IN WHAT YOU PASTED` and stop.

## Tie-breaks

Five calls the steps above leave open often enough to be worth deciding once,
here, instead of in the run.

**1, an audience named by a feeling-state.** A line that names an audience by how
they feel ("cold sleepers", "people who wake up cold") is a promise claim only
where a pasted page line can answer it with something checkable: who it is for,
a named condition, a named group. Where no pasted line does, it is a mood line,
it is listed under "Not classed", and it is outside the population. Print which
way the run went in one clause beside it, either
`not counted: no pasted line names who it is for, so this reads as a mood line`
or `counted: the page names the buyer it is built for`. Never decide it on the
ad alone: the page is what makes a feeling-state audience checkable or leaves it
as a mood.

**2, a second sentence that elaborates the sentence before it.** A sentence that
only restates or elaborates a term already stated in the sentence before it, a
trial term, a guarantee, a shipping condition, folds into that claim. Both
source sentences print under the one claim, one status covers both, and no
second row opens. A sentence that carries a new fact, a new number, a new name,
a new time or a new term is its own claim, whatever it elaborates. The split
test governs facts inside one sentence. This governs the sentence after it.

**3, a technical spec answering a plain-language claim.** Where the ad claims an
outcome in plain words ("it holds heat") and the only pasted page line on that
subject is a specification, a tog rating, a fill weight, a thread count, the row
is PARTIAL and never ANSWERED. Quote the spec as the page line, and in the
difference slot name the plain-language line the page does not carry. Naming the
missing line is naming a gap: Refusal 3 still holds and no replacement copy is
written. A buyer arrives holding the plain sentence that made them click, and a
number they have to translate for themselves is not that sentence said back.

**4, Refusal 1 prints inside the ledger.** Where Refusal 1 fires on a claim, its
block prints in that claim's own row in the ledger, in place of the status and
page line slots. It never resolves quietly into an UNANSWERED row. A claim no
pasted line addresses and a claim the run was tempted to credit from memory are
two different findings, and the reader sees which one this is. The row is shown
in the Output format below.

**5, Refusal 2 and the file header.** On Refusal 2 the file header still prints,
the title line and the paste boundary line, then the refusal block, then nothing.
No split, no population, no ledger, no counts, no shares, no first repair. The
header prints because a file with no header is a file nobody can file. This is
shown in the Output format below.

## Output format

Write one file, `message-match.md`.

```
# Message match: <ad name or "the ad you pasted"> against <page name or "the page you pasted">
Paste boundary: <line 3 of the input> | [NEEDS: where your paste stops]

## The split
<the Step 1 split, source sentence quoted above its claims>

## Population
<the Step 2 line>

## The ledger
### C<n>
claim: <the claim, in the ad's own words where possible>
from:  "<the ad sentence it came out of>"
from:  "<a second source sentence, where one folded in under Tie-break 2>"
status: ANSWERED | PARTIAL | UNANSWERED
page line: "<verbatim page line>" | [NEEDS: the section of the page that says this]
difference: <what changed>            (PARTIAL only)

### C<n>                                (the row where Refusal 1 fired)
claim: <the claim, in the ad's own words where possible>
from:  "<the ad sentence it came out of>"
<the Refusal 1 block in full, printed here in the place the status and page
line slots would have taken>

## Not classed
- "<line>"   mood line | question | call to action | brand name on its own

## Counts and shares
<the population sentence, then the three count rows and their shares from
Step 5, then the not-classed line, then the denominator line. The population
sentence prints inside this block and not only in the Population section above>

## Fix this one first
C<n>: <the claim>   because <the printed rule, restated>
```

**The Refusal 2 file, in full.** Where the ad carries no promise claim, the file
is the two header lines and the refusal block, and nothing after it:

```
# Message match: <ad name or "the ad you pasted"> against <page name or "the page you pasted">
Paste boundary: <line 3 of the input> | [NEEDS: where your paste stops]

<the Refusal 2 block, with its line-by-line list>
```

Nothing else prints on that branch. No split, no population, no ledger, no
counts, no shares, no first repair.

## Edge cases

**The claim is in the ad's image or video, not in the text.** This unit reads
text. Print `[NEEDS: the words on the ad creative, typed out]` once at the top
and run on what you have. Do not describe the creative.

**A claim is answered by a button label or a badge.** That counts. Quote the
label as the page line. A trust badge saying "60 night trial" answers the trial
claim as well as a paragraph would.

**The page paste is empty.** Print the named branch and stop before Step 5:

```
NO PAGE TEXT PASTED
Every claim in this ad is unchecked, not unanswered. This run is a finding
about the paste, not about the page.
```

**The page answers the claim below your paste boundary.** That is what line 3
of the input is for. The status stays UNANSWERED and the `[NEEDS:]` names the
section. Paste further down and rerun.

**The ad promises something the page contradicts.** That is PARTIAL with the
difference printed, and the difference is the whole row. This unit does not
have a CONTRADICTED class, because a contradiction is a difference large enough
to read for yourself once it is printed side by side.

**Two ads, one page.** One run per ad. Claims from two ads in one population
would produce a share over a denominator no single buyer ever saw.

## Worked case

**This is fixture `fixtures/ad-and-landing-page.md` run literally under the
Method and the Tie-breaks above, followed by fixture
`fixtures/ad-with-no-claims.md` run the same way. Both are the shipped fixtures.
Neither is a separate example.**

Ad: MF_wool_duvet_cold_sleeper_v3. Page: the paste stops at the Add to basket
button. Tie-break 1 fires on the two audience lines, tie-break 2 fires on the
sentence after the trial term, and tie-break 3 fires on the tog rating, so the
population is 8 claims and not the 10 the sentences would give without them.

```
# Message match: MF_wool_duvet_cold_sleeper_v3 against the page you pasted
Paste boundary: Stops at the Add to basket button. There are three more sections
below it, including a page section titled "How it is made" and the reviews.

## The split

from: "Cold sleepers, this one is for you."
  not counted: no pasted line names who it is for, so this reads as a mood line
  (Tie-break 1)

from: "The duvet for people who wake up cold"
  not counted: the same feeling-state audience, read the same way (Tie-break 1)

from: "Our wool duvet is filled with British wool from a single farm, so it
holds heat without the clamminess of a synthetic filling."
  C1  filled with British wool
  C2  the wool comes from a single farm
  C3  it holds heat
  C4  no clamminess of a synthetic filling

from: "Free delivery and a 60 night trial."
  C5  free delivery
  C6  60 night trial

from: "Send it back if it is wrong for you."
  folds into C6: it elaborates the trial term stated in the sentence before it
  and carries no new fact (Tie-break 2)

from: "Made in a mill in Yorkshire that has been running since 1890."
  C7  it is made in a mill in Yorkshire
  C8  that mill has been running since 1890

## Population

Population for every count in this file: every promise claim in the ad you
pasted, counted once, after the split printed in Step 1. Claims: 8.

## The ledger

### C1
claim: filled with British wool
from:  "Our wool duvet is filled with British wool from a single farm, so it
holds heat without the clamminess of a synthetic filling."
status: ANSWERED
page line: "Single farm British wool, washed and carded in Yorkshire."

### C2
claim: the wool comes from a single farm
from:  "Our wool duvet is filled with British wool from a single farm, so it
holds heat without the clamminess of a synthetic filling."
status: ANSWERED
page line: "Single farm British wool, washed and carded in Yorkshire."

### C3
claim: it holds heat
from:  "Our wool duvet is filled with British wool from a single farm, so it
holds heat without the clamminess of a synthetic filling."
status: PARTIAL
page line: "Warmth rating: 10.5 tog"
difference: the page answers a plain-language outcome with a specification. No
pasted line says in plain words that the duvet holds heat, and that is the line
the page does not carry (Tie-break 3)

### C4
claim: no clamminess of a synthetic filling
from:  "Our wool duvet is filled with British wool from a single farm, so it
holds heat without the clamminess of a synthetic filling."
status: ANSWERED
page line: "No synthetic filling, no down, no feather."

### C5
claim: free delivery
from:  "Free delivery and a 60 night trial."
status: PARTIAL
page line: "Bar across the top: FREE UK DELIVERY OVER $150"
difference: the page adds a threshold the ad did not state

### C6
claim: 60 night trial
from:  "Free delivery and a 60 night trial."
from:  "Send it back if it is wrong for you."
status: ANSWERED
page line: "60 nights to try it at home"

### C7
claim: it is made in a mill in Yorkshire
from:  "Made in a mill in Yorkshire that has been running since 1890."
status: PARTIAL
page line: "Single farm British wool, washed and carded in Yorkshire."
difference: the page names Yorkshire for washing and carding the wool, not for a
mill making the duvet

### C8
claim: that mill has been running since 1890
from:  "Made in a mill in Yorkshire that has been running since 1890."
status: UNANSWERED
page line: [NEEDS: the section of the page that says this]

## Not classed

- "Cold sleepers, this one is for you."   mood line
- "The duvet for people who wake up cold"   mood line

## Counts and shares

Population: every promise claim in the ad you pasted, counted once, after the
Step 1 split. Claims: 8.

ANSWERED    4 claims   4 / 8 = 0.5
PARTIAL     3 claims   3 / 8 = 0.375
UNANSWERED  1 claim    1 / 8 = 0.125
                       ---------
                       8 claims

not classed: 2 lines, listed in full under "Not classed" above. They are
outside the population by definition, because a mood line, a question, a call to
action and a brand name on its own promise nothing a buyer could arrive and
check. They are printed so the ad can be reconciled line by line, and they are
never added into 8.

The denominator is the split printed in Step 1. If you would have split a
sentence differently, recount on your split; these shares move with it.

## Fix this one first

C8: that mill has been running since 1890   because it is the highest
UNANSWERED claim in the ad's own reading order. Reading order, because the input
does not carry which promise sells hardest, and picking on importance would be a
guess wearing a ranking.
```

Refusal 1 never fires in this run: every ANSWERED and PARTIAL row above quotes a
line that is in the paste.

**Fixture `fixtures/ad-with-no-claims.md`, run the same way.** The ad carries no
promise claim, so Refusal 2 fires and the file is the header and the refusal
block, per Tie-break 5:

```
# Message match: HG_brand_film_15s_v1 against the page you pasted
Paste boundary: Stops at the Shop now button.

NO PROMISE CLAIMS IN THE AD
Promise claims found: 0
Lines read in the ad: 6

This ad says things about how it feels to own the product and never says a
thing a buyer could arrive and check. There is no match to test, because
nothing was promised.

What the ad is made of: 2 mood lines, 1 question, 1 call to action,
2 lines that are the brand name on its own. Each one is listed below,
unclassed.

- "Some mornings start slowly."   mood line
- "Ever wondered what the good ones have in common?"   question
- "Halden Goods."   brand name on its own
- "Made for the slow hour."   mood line
- "Shop the collection."   call to action
- "Halden Goods"   brand name on its own
```

The file ends there. 2 + 1 + 1 + 2 = 6, which is the "Lines read in the ad"
figure above it, and "Halden Goods. Made for the slow hour." is two lines
because one line is one sentence.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never quote a page line that is not in the paste, in any form, including a
  tidied version of one that is.
- Never credit a page section from memory, from the brand's other pages, or
  from what a page like this usually says.
- Never invent a claim the ad did not carry, and never split a sentence into a
  claim that uses a word the ad did not use.
- Never print a single match rate. Three shares over one stated population, all
  three printed, including the empty ones.
- Never state a benchmark, a typical share, or what good looks like.
- Never write replacement page copy. Refusal 3 fires instead.
- Never rank the claims by how much money each one is worth. The input does not
  carry that.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.

<!-- ported from 01-existing/the-dtc-growth-team/convert/convert-01-message-match-checker, 2026-09-06; fixes applied: Tie-breaks section added after the Method with the five rules (feeling-state audience, elaborating second sentence, technical spec against a plain-language claim, Refusal 1 printed in the ledger, Refusal 2 header); Output format shows the Refusal 1 ledger row and the Refusal 2 file; worked case added, both shipped fixtures re-run against the amended Method -->
