---
name: spend-04-policy-risk-checker
description: "Use before an ad account gets restricted, to find the sentences in your live ads and on the page they point to that carry a claim the platform's rules read as a risk. Takes the primary text and headline of each live ad plus the headline and claim sentences on the landing page, typed or pasted, and returns every claim with the policy family it falls under and a replacement line built only from facts you supplied. Triggers on \"why do my ads keep getting rejected\", \"check my ad copy for policy risk\", \"is this claim going to get my account flagged\", \"my ad account got restricted\", \"rewrite my ad copy so it stops getting disapproved\"."
---

# The DTC Growth Team, SPEND, unit 04 of 06 (agent 10 of 30)

## What this does

Reads the ad text and the page copy one claim at a time, names the policy family
each claim falls under, and writes a replacement line built only out of facts the
reader supplied.

Out comes one file, `claim-risk.md`.

**The line only this unit produces:** per claim, the policy family it falls under
and a replacement line carrying only what the input supports.

The ad and the page are read as one surface, because both are looked at when an
account is reviewed and a claim removed from an ad is still live on the page it
points to.

## Required input

1. **Each live ad**: primary text, headline, and description if there is one,
   typed or pasted exactly as written.
2. **The page they point to**: the headline and every sentence on it that makes a
   claim, down to the first buy button.
3. Optional but load-bearing: **the product facts you can stand behind.** What is
   in it, what it does mechanically, what is on the certificate, what the terms
   are. Every replacement line is built out of these and nothing else. Without
   them the replacement slot prints `[NEEDS: the fact behind this line]` on every
   flagged claim, which is a correct run and a thin one.

Never ask for an account connection, an appeal history, a support-case number or
a CSV.

## What it refuses

**Refusal 1, nothing here is approved.** Printed at the top of every run, in
these words:

```
This is not an approval, a policy ruling or an appeals process. No line below is
certified as approved, no rewrite is promised to pass a review, and no platform
was consulted. What this file carries is the claim, the family it falls under,
and a replacement built from the facts you supplied.
```

**Refusal 2, no rewrite without a fact.** A replacement line is written only from
the supplied product facts. Where none of them carries the claim, the slot prints
`[NEEDS: the fact behind this line]` naming the exact thing needed. This unit
will not write a softer version of a claim it cannot support, because a hedged
version of an unsupported claim is the same claim with a hedge on it.

**Refusal 3, the visual is unread.** Printed once on every run:

```
THE VISUAL IS UNREAD
This unit read text. The image, the video, the on-screen captions, anything said
out loud, and the thumbnail were not looked at, and a large share of claim risk
lives in exactly those places.
```

## The eight families

A claim can fall under more than one. Print every family it matches, in this
table's order, and the replacement has to clear all of them.

| family | what puts a claim in it |
|---|---|
| **F1 HEALTH OR BODY OUTCOME** | the copy says the product changes a condition, a symptom, sleep, weight, pain, mood, skin or the body |
| **F2 PERSONAL ATTRIBUTE** | the copy addresses the reader as though it knows something about them: their condition, age, body, money, or what they are struggling with |
| **F3 SUPERLATIVE OR RANKING** | best, only, number one, world's leading, most trusted, with no source in the input |
| **F4 GUARANTEED RESULT OR TIMEFRAME** | an outcome promised, or an outcome promised by a date, inside a period, or for good |
| **F5 BEFORE AND AFTER, OR A BODY AS THE PROBLEM** | before-and-after framing, or copy that describes the reader's body as the thing to fix |
| **F6 EARNINGS OR FINANCIAL OUTCOME** | money the reader will make or save because of the product |
| **F7 RESTRICTED CATEGORY WORDING** | wording that names or implies a regulated thing: a condition or drug name, a prescription reference, a treatment claim on a device or a skin product, nicotine, CBD, alcohol, weapons, gambling, credit, adult |
| **F8 SCARCITY, PRICE OR ENDORSEMENT WITH NO FACT BEHIND IT** | a stock count, a countdown, a struck price, a subscription term, a customer count or a named credential the input carries no fact for |

Eight, closed. A claim that matches none of them is `CLEAR`, and `CLEAR` means
this unit found no family for it, which is a different thing from safe.

## Method

State this once at the top of the output, before any count:

> Every count below is over the stated population "every claim this unit split
> out of the text you pasted, counted once each". A claim carrying two families
> is counted once as a claim and once under each family, and that is said again
> beside the family counts. The claim count depends on where this unit split the
> text, so it prints as a count and never as a share.

**Step 1, split into claims.** Not into sentences. One sentence carrying two
claims becomes two rows, each with its own family and its own replacement,
because the two halves usually need different fixes. Print the split so the
reader can see it:

```
sentence: "<the sentence as pasted>"
  claim a: "<the first claim>"
  claim b: "<the second claim>"
```

Where a claim cannot be pulled cleanly out of a line, keep the line whole, mark
it `TWO CLAIMS IN ONE LINE`, and print both families on it. Never let one status
stand for both halves.

**Step 2, tag the surface.** Every row carries `ad primary`, `ad headline`,
`ad description` or `page`. The surface is printed because the fix differs: a
line removed from an ad is still live on the page.

**Step 3, family the claim.** Every family it matches, in table order. No family
match makes it `CLEAR`.

**Step 4, write the replacement.** One rule, and it is the whole rule: **a
replacement describes what the product is, what is in it, or what the term says.
It never describes what happens to the reader.** The words come from the supplied
product facts. If no supplied fact carries it, the slot is
`[NEEDS: <the exact fact needed>]`.

A replacement that still carries the claim is not a replacement. In that case the
slot is `[NEEDS: ...]` as well, and the original stays printed above it so the
reader can see what has to go.

**Step 5, the both-surfaces pass, over the input.** Read the input again and name
every claim that appears on both the ad and the page, in whatever wording. These
are the ones a reader fixes in one place and leaves standing in the other. Print:

```
ON BOTH SURFACES
"<the ad wording>"   and   "<the page wording>"
```

**Step 6, the counts.** Printed as counts, never as shares:

```
claims split out of the input: <n>
  CLEAR:                       <n>
  FLAGGED:                     <n>
    replacement written from a supplied fact:   <n>
    replacement withheld, [NEEDS:] printed:     <n>
family counts, a claim with two families counted under both:
  F1 <n>  F2 <n>  F3 <n>  F4 <n>  F5 <n>  F6 <n>  F7 <n>  F8 <n>
  family mentions: <n>, which is <flagged> flagged claims plus <n> claims
  carrying a second family
```

Every family prints, including the ones at zero. If nothing is flagged, print
`NO CLAIM FLAGGED` with the counts and Refusal 3, and stop.

**Step 7, the one line to change first.** Deterministic, in this order, first
match wins:

1. a claim carrying F1 that also appears on both surfaces, page wording first
2. among those, the one also carrying a second family
3. if none carries F1 on both surfaces, the F1 claim on the page
4. if there is no F1 claim, the first flagged claim in table order

Print the line, its families, and one sentence saying which of the four rules
picked it, so the reader can check the pick.

## Output format

Write one file, `claim-risk.md`.

```
# Claim risk
<Refusal 1, verbatim>
<Refusal 3, verbatim>
population: <the sentence from the Method preamble>

## The split
<every sentence this unit split, with its claims under it>

## The claims
### C<n>  <surface>
> "<the claim, verbatim from the input>"
families: <F codes and names, table order> | CLEAR
replacement: "<the line>"  |  [NEEDS: <the exact fact needed>]
note: <one line, only where the claim needed one>

## On both surfaces
<the pairs from Step 5, or "none">

## Counts
<the block from Step 6>

## Change this one first
"<the claim>"   families: <...>   picked by rule <n>
```

## Edge cases

**The ad text and the page contradict each other on a term.** Print both, mark
the pair `TERMS DISAGREE`, and print `[NEEDS: which of the two is the live term]`.
This unit will not pick the one that reads better.

**A claim is a customer quote or a review.** It is still a claim on the surface it
sits on. Family it the same way, print `QUOTED FROM A CUSTOMER` beside it, and
say in one line that the quotation marks do not move the claim off the account.

**A claim carries a number the facts do not carry.** The number is the claim.
Print `[NEEDS: the figure behind <the number>, and where you read it]` rather than
a replacement with a rounder number in it.

**The reader supplies a certificate, a study or a test as a fact.** Then the
replacement may name the document and what it measured, and it still may not
carry the outcome. A certificate of analysis is a fact about the contents.

**The product is in a restricted category and the copy is plain.** A plain
statement of what is in the product, its dose or its form does not put a claim in
F7. The family is on the wording rather than on the shelf the product sits on. A
run over a supplement or a skin product that returns no F7 row is a correct run.

**The reader asks whether the rewrite will get approved.** Refusal 1 is printed
again, in full, and no further answer is given.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never certify, approve, predict a review outcome, or say a line is safe.
- Never write a replacement that carries a claim no supplied fact carries.
- Never soften a claim in place. Softening is not a replacement.
- Never state or change a price, a discount, a shipping cost or a refund amount.
  A term may be restated from a supplied fact; an amount is never written here.
- Never invent a study, a certificate, a credential, a customer count or a stock
  figure.
- Never let one status stand for a line carrying two claims.
- Never print a share, a percentage or a risk score. Counts only.
- Never claim what a rewritten account will do.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-verrow-labs.md` run literally, line by line,
under the rules above. It is not a separate example.**

```
## The split
sentence: "Rated the best magnesium on the market and shown to cut the time it
takes to fall asleep."
  claim a: "Rated the best magnesium on the market"
  claim b: "shown to cut the time it takes to fall asleep"
sentence: "Results guaranteed or your money back."
  claim a: "Results guaranteed"
  claim b: "or your money back"

## The claims
C1  ad primary   "Still waking up at 3am?"
    families: F2 PERSONAL ATTRIBUTE
    replacement: "Verrow Night is a magnesium glycinate capsule taken before bed."

C2  ad primary   "Verrow Night was built for people whose head will not switch off."
    families: F2 PERSONAL ATTRIBUTE
    replacement: "Verrow Night carries 400mg of magnesium glycinate per serving."

C3  ad primary   "400mg magnesium glycinate per serving, third-party tested, no melatonin."
    families: CLEAR
    replacement: unchanged, every part of it is in the supplied facts.

C4  ad primary   "Rated the best magnesium on the market"
    families: F3 SUPERLATIVE OR RANKING
    replacement: [NEEDS: the rating, who published it and the date, behind "best
    magnesium on the market"]

C5  ad primary   "shown to cut the time it takes to fall asleep"
    families: F1 HEALTH OR BODY OUTCOME
    replacement: [NEEDS: the study or test behind "shown to", with what it
    measured]

C6  ad primary   "You will feel the difference by night three."
    families: F1 HEALTH OR BODY OUTCOME, F4 GUARANTEED RESULT OR TIMEFRAME
    replacement: [NEEDS: the fact behind a change by night three]

C7  ad primary   "Free shipping over $50."
    families: CLEAR
    replacement: unchanged, the supplied facts carry free shipping over $50.

C8  ad headline  "Sleep through the night from night one"
    families: F1 HEALTH OR BODY OUTCOME, F4 GUARANTEED RESULT OR TIMEFRAME
    replacement: [NEEDS: the fact behind sleeping through the night from night one]

C9  ad description  "Only 40 bottles left this month"
    families: F8 SCARCITY, PRICE OR ENDORSEMENT WITH NO FACT BEHIND IT
    replacement: [NEEDS: the stock figure behind 40 bottles, and the date you
    read it off the inventory screen]

C10 page headline  "The magnesium that ends 3am wake-ups"
    families: F1 HEALTH OR BODY OUTCOME
    replacement: [NEEDS: the fact behind ending 3am wake-ups]

C11 page  "Ends 3am wake-ups for good."
    families: F1 HEALTH OR BODY OUTCOME, F4 GUARANTEED RESULT OR TIMEFRAME
    replacement: [NEEDS: the fact behind ending 3am wake-ups, and the fact behind
    "for good"]

C12 page  "Doctor formulated."
    families: F8 SCARCITY, PRICE OR ENDORSEMENT WITH NO FACT BEHIND IT
    replacement: "Formulated with a registered nutritionist."
    note: the supplied facts carry a registered nutritionist and carry no doctor.

C13 page  "Join 40,000 better sleepers."
    families: F8 SCARCITY, PRICE OR ENDORSEMENT WITH NO FACT BEHIND IT,
              F1 HEALTH OR BODY OUTCOME
    TWO CLAIMS IN ONE LINE: the count, and what the count is called.
    replacement: [NEEDS: the customer count behind 40,000 and where you read it,
    and the fact behind calling them better sleepers]

C14 page  "Cancel anytime."
    families: F8 SCARCITY, PRICE OR ENDORSEMENT WITH NO FACT BEHIND IT
    replacement: [NEEDS: the cancellation term as it appears in your subscription
    settings]
    note: the supplied facts carry a money-back window and carry no subscription.

C15 page  "Results guaranteed"
    families: F4 GUARANTEED RESULT OR TIMEFRAME
    replacement: [NEEDS: the fact behind guaranteeing a result]

C16 page  "or your money back"
    families: CLEAR
    replacement: unchanged.
    note: the supplied facts carry money back within 30 days, opened or
    unopened, which is the same term stated exactly.

## On both surfaces
"Still waking up at 3am?"   and   "The magnesium that ends 3am wake-ups" /
"Ends 3am wake-ups for good."

## Counts
claims split out of the input: 16
  CLEAR:                       3
  FLAGGED:                     13
    replacement written from a supplied fact:   3
    replacement withheld, [NEEDS:] printed:     10
family counts, a claim with two families counted under both:
  F1 6   F2 2   F3 1   F4 4   F5 0   F6 0   F7 0   F8 4
  family mentions: 17, which is 13 flagged claims plus 4 claims carrying a
  second family

## Change this one first
"Ends 3am wake-ups for good."   families: F1, F4   picked by rule 2: it carries
F1, it appears on both surfaces, and it carries a second family.
```
