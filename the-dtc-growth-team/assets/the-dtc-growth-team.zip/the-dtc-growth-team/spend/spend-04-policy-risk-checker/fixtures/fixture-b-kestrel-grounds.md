# Fixture B, one live ad with no product facts attached

Invented brand and invented copy. Not a record of any brand's advertising.
Designed to exercise a paste where the optional product facts are absent and two
sentences each carry two claims.

---

## Ad, as it is running

Primary text:
Our cold brew has 3x the caffeine of regular coffee and will fix your afternoon
crash. Best-selling cold brew in the country, and the only one with zero sugar.

Headline:
The last coffee you will ever buy

Description:
Ships free this week

## The page it points to

Headline:
Stop the 3pm crash

Claim sentences down to the first buy button:
Cold brewed for 18 hours, never heated.
Zero sugar, zero sweetener.
The strongest cold brew you can buy.

## Product facts I can stand behind

(none supplied)
