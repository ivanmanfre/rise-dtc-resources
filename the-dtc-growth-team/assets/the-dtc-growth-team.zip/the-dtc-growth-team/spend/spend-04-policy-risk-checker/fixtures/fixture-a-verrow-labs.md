# Fixture A, one live ad and the page it points to

Invented brand and invented copy. Not a record of any brand's advertising.
Designed to exercise a paste where product facts are supplied and one sentence
carries two claims.

---

## Ad, as it is running

Primary text:
Still waking up at 3am? Verrow Night was built for people whose head will not
switch off. 400mg magnesium glycinate per serving, third-party tested, no
melatonin. Rated the best magnesium on the market and shown to cut the time it
takes to fall asleep. You will feel the difference by night three. Free shipping
over $50.

Headline:
Sleep through the night from night one

Description:
Only 40 bottles left this month

## The page it points to

Headline:
The magnesium that ends 3am wake-ups

Claim sentences down to the first buy button:
Ends 3am wake-ups for good.
Doctor formulated.
Join 40,000 better sleepers.
Cancel anytime.
Results guaranteed or your money back.

## Product facts I can stand behind

- 400mg magnesium glycinate per serving, 60 capsules per bottle
- third-party tested for heavy metals, certificate linked on the product page
- no melatonin, no added sugar
- $34 a bottle, free shipping over $50
- money back within 30 days, opened or unopened
- formulated with a registered nutritionist
