# Fixture C, two live campaigns and a target of nothing

Invented brand and invented figures. Not a record of any account.
Designed to exercise the branch where the number the reader supplies is zero.

---

Campaigns screen, date preset Last 30 Days.

CF | Prospecting | Broad
  daily budget $200.00   purchases 33   cost per purchase $61.00

CF | Retargeting | Cart 7d
  daily budget $45.00    purchases 40   cost per purchase $19.80

Total daily budget I want to end on: $0.00
