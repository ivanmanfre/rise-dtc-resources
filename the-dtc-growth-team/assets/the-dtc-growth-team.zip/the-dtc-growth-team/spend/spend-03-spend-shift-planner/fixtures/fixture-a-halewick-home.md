# Fixture A, five live campaigns and a total to end on

Invented brand and invented figures. Not a record of any account.
Designed to exercise a paste in which the target total equals what the campaigns
already spend between them.

---

Campaigns screen, date preset Last 30 Days.

HH | Prospecting | Broad
  daily budget $150.00   purchases 62   cost per purchase $48.20

HH | Prospecting | Lookalike 2%
  daily budget $90.00    purchases 41   cost per purchase $39.10

HH | Retargeting | Site 30d
  daily budget $60.00    purchases 55   cost per purchase $22.40

HH | Prospecting | Interest stack
  daily budget $70.00    purchases 7    cost per purchase $96.00

HH | Brand search
  daily budget $30.00    purchases 24   cost per purchase $18.60

Total daily budget I want to end on: $400.00
