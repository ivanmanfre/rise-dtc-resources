# Fixture B, four live campaigns and a lower total to end on

Invented brand and invented figures. Not a record of any account.
Designed to exercise a paste in which one campaign's row is incomplete and the
target total is well below what the campaigns now spend between them.

---

Campaigns screen, date preset Last 30 Days.

CF | Prospecting | Broad
  daily budget $200.00   purchases 33   cost per purchase $61.00

CF | Prospecting | Video LAL
  daily budget $120.00   purchases 18   cost per purchase $54.00

CF | Retargeting | Cart 7d
  daily budget $45.00    purchases 40   cost per purchase $19.80

CF | Prospecting | Creator UGC
  daily budget $80.00    purchases      cost per purchase

Total daily budget I want to end on: $350.00
