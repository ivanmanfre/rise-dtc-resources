---
name: spend-03-spend-shift-planner
description: "Use when you want to move money between the campaigns you already run without wrecking the ones you touch. Takes each live campaign's name, daily budget and 30-day purchases and cost per purchase off the Campaigns screen, plus the total daily budget you want to end on, and returns a money-movement table showing what leaves each campaign and what arrives at each, capped per step, with every campaign printed including the ones this unit will not move money into. Triggers on \"how should I redistribute my ad budget\", \"move money from my worst campaign to my best\", \"rebalance my campaigns\", \"I want to spend X a day total, how do I split it\", \"which campaign should get more budget\"."
---

# The DTC Growth Team, SPEND, unit 03 of 06 (agent 09 of 30)

## What this does

Takes the campaigns you are already running and one number, the daily total you
want to end on, and writes the money movement for one step. Every campaign you
pasted gets a printed row, including the ones this unit will not put money into
and the ones it cannot read.

Out comes one file, `spend-shift.md`.

**The line only this unit produces:** the per-campaign money-movement table for
one step, dollars leaving on one side and dollars arriving on the other, each
capped at 25% of that campaign's own current daily budget.

This plans one step. The step after it is planned after this one has run for a
week and the rows have moved.

## Required input

1. **Every live campaign**, one line each, from the Campaigns screen with the
   date preset on Last 30 Days:
   - campaign name
   - current daily budget
   - purchases in the last 30 days
   - cost per purchase in the last 30 days
2. **The total daily budget you want to end on**, one number.

Purchases and cost per purchase are adjacent columns on that screen. If either
is missing on a campaign, say so on that line rather than leaving it out of the
paste. A campaign left out of the paste is a campaign this unit cannot hold a
budget for, and the totals will then be wrong.

Never ask for a CSV, an account connection, a pixel, a margin figure or a
lifetime value.

## What it refuses

**Refusal 1, no money into a campaign that cannot be read.** The minimum is **10
purchases in the 30-day row**. Below it, the campaign is printed as `UNREADY`,
holds its current budget unchanged, and receives nothing:

```
UNREADY: <campaign name>
purchases in 30 days: <n>        minimum this unit will move money into: 10
still needed: 10 - <n> = <n> purchases
holds its current daily budget of $<b>, unchanged by this step.
```

An `UNREADY` campaign is not a zero and is never folded into one. It keeps its
budget, it keeps its row, and its budget is subtracted from the total before any
movement is planned.

**Refusal 2, no reading a row that was not pasted.** A campaign with a missing
purchases figure or a missing cost per purchase is printed as `NO DATA`, holds
its budget unchanged, and prints
`[NEEDS: the 30-day purchases and cost per purchase for <campaign name>]`.

**Refusal 3, the target of zero.** If the total daily budget to end on is 0, this
unit stops:

```
TARGET IS ZERO
A total of $0.00 a day is a shutdown, and a shutdown has an order, a metric that
has to recover and a date it is judged on. None of those are in this unit and
none of them are guessed here. No movement table is printed and no division runs.
The freeze planner in the DECIDE stage is the unit that plans a stop.
```

**Refusal 4, no verdict on the campaigns themselves.** This unit ranks by the
cost per purchase you pasted and moves money along that ranking. It does not
say a campaign is good, does not say one should be turned off, and does not
predict what any campaign will do at its new budget.

## Method

State this once at the top of the output, before any figure:

> Every share below is counted over the stated population "the campaigns you
> pasted, counted once each". Every campaign appears in exactly one class and in
> exactly one row, including the ones nothing moves into.

**Step 1, class every campaign.** Three classes, all three printed even when
empty:

| class | test |
|---|---|
| `READY` | purchases in 30 days is 10 or more |
| `UNREADY` | purchases in 30 days is below 10 |
| `NO DATA` | purchases or cost per purchase missing |

**Step 2, the per-step cap.** For every campaign print
`cap = 25% of its own current daily budget`, with the multiplication shown. No
campaign's budget moves more than its cap in this step, up or down. Past that
size the campaign after the step is a different campaign from the one whose cost
per purchase you pasted, and next week's row cannot be compared to this week's.

**Step 3, the movable pool.** Print the subtraction:

```
target total daily budget:                          $<t>
minus the budgets held by UNREADY and NO DATA:      $<f>
movable pool:                                       $<p>
current total across READY campaigns:               $<r>
net change to place this step: D = $<p> - $<r> =    $<d>
```

If the movable pool is zero or below, print the named branch and stop:

```
NOTHING MOVABLE
The campaigns this unit will not move money into already hold $<f> a day, which
is at or above your target total of $<t>. There is no pool left to move and no
division prints. What is in front of you is a decision about those campaigns,
and it is not a shift.
```

**Step 4, the net change pass.** This runs first, and it consumes cap.

- **D above zero.** Add money to `READY` campaigns in cost-per-purchase order,
  cheapest first, each up to its own cap, until D is used. Any part of D that no
  remaining cap can take prints as `NOT PLACED THIS STEP: $<x>` with the reason.
- **D below zero.** Take money off `READY` campaigns in cost-per-purchase order,
  most expensive first, each up to its own cap, until the size of D is met. Any
  part still to come off prints as `NOT REMOVED THIS STEP: $<x>` with the reason.
  When the caps force the cheapest campaign to give as well, print that line
  plainly with the amount, because it is the part of a cut a reader does not
  expect.
- **D is zero.** Nothing happens in this pass, and the pass prints `$0.00`.

**Step 5, the shift pass.** This runs second, on whatever cap is left.

- Take the median cost per purchase across `READY` campaigns and print it. With
  an even count the median is the midpoint of the middle two, and the arithmetic
  is printed.
- Campaigns above the median give. Campaigns at or below the median receive.
- A campaign that lost money in Step 4 cannot receive in Step 5, and a campaign
  that gained money in Step 4 cannot give in Step 5. One campaign moves in one
  direction per step.
- Remaining give capacity `G` and remaining receive capacity `C` are each summed
  and printed. The amount moved is the smaller of the two.
- Money comes off the most expensive first and goes on the cheapest first.
- Print `held back: G - moved = $<x>` with one line saying which side was the
  binding one. That figure is the honest size of the step you could not take.

**Step 6, the movement table.** One row per campaign pasted, in the order they
were pasted, no campaign omitted:

```
campaign | class | now | cap | leaves | arrives | next | share of the ending total
```

`leaves` and `arrives` are never both filled on one row. `UNREADY` and `NO DATA`
rows carry `0.00` in both and their current budget in `next`.

**Step 7, the ending total and the shares.** Print:

```
ending total: <the sum of the next column> = $<e>
target total: $<t>
gap: $<e> - $<t> = $<g>        <one line naming the cap that caused it, or "none">
```

The share column divides each campaign's next budget by the ending total, over
the stated population from the preamble, so every pasted campaign is in the
denominator and every one of them has a printed share. Shares are rounded to one
decimal place, which means the printed column can total a little above or below
100%, and that line is printed under the table.

**Step 8, when to run this again.** One line: after seven days at the new
budgets, with the same four fields re-pulled on the same screen. No step here
predicts what those rows will say.

## Output format

Write one file, `spend-shift.md`.

```
# Spend shift, one step
population: <the sentence from the Method preamble>
per-step cap: 25% of each campaign's own current daily budget

## Classes
READY:   <names>
UNREADY: <names, each with purchases and what is still needed>
NO DATA: <names, each with its [NEEDS: ...] line>

## The pool
<the subtraction from Step 3>

## Net change pass
<per campaign, the amount and the running remainder, or $0.00>
<NOT PLACED / NOT REMOVED line if either applies>

## Shift pass
median cost per purchase across READY: <arithmetic> = $<m>
givers: <names>          receivers: <names>
remaining give capacity G: $<g>    remaining receive capacity C: $<c>
moved: the smaller of the two = $<x>
held back: $<g> - $<x> = $<y>, because <which side was binding>

## Movement table
campaign | class | now | cap | leaves | arrives | next | share
<one row per pasted campaign>
<the rounding line>

## Totals
<the three lines from Step 7>

## Run this again
<one line>
```

Any figure the input did not carry prints
`[NEEDS: <the exact thing to supply>]`, and any total that depends on it prints
`[NEEDS: ...]` rather than a total computed as though the missing campaign were
zero.

## Edge cases

**Only one READY campaign.** The median is that campaign's own cost per purchase,
so it is at or below the median and it can receive. It cannot give, because there
is nothing above the median. Print the shift pass as `$0.00` with that reason in
one line. The net change pass still runs.

**Two campaigns share a name.** Print both rows and mark the pair `SAME NAME`.
This unit will not merge two rows into one, because their budgets and their
purchases are separate facts and adding them would produce a cost per purchase
belonging to neither.

**A campaign is paused but still pasted.** It has a current daily budget of 0.00,
so its cap is 0.00 and it can neither give nor receive this step. Print it in the
table with that reason. Starting a paused campaign is a budget step rather than a
shift, and the budget step planner is the unit that sizes it.

**Budgets are set at the ad set level rather than the campaign level.** Then the
rows to paste are ad set rows, and every line in this unit reads "ad set" instead
of "campaign". Print the level back to the reader on the first line of the output
so the next pull comes from the same screen.

**Two campaigns have the same cost per purchase, and they sit either side of the
median.** Order them by the one with more purchases first, and print that
tie-break in one line so the reader can redo the ranking by hand.

**The reader wants a specific campaign to receive money and this unit ranks it as
a giver.** Print the table as the ranking gives it, and print one line naming the
campaign they asked for with its cost per purchase and its rank. This unit does
not rewrite the ranking to match a preference, and it does not argue with one.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never move more than 25% of a campaign's own current daily budget in one step.
- Never move money into a campaign under the 10-purchase minimum. It gets an
  `UNREADY` row instead, and it keeps its budget.
- Never drop a pasted campaign from the table, from the class list, or from the
  denominator of the share column.
- Never fold `UNREADY` or `NO DATA` into zero. They hold real budget and the
  totals are wrong without them.
- Never divide by an ending total of zero. Refusal 3 and the `NOTHING MOVABLE`
  branch both fire before any division.
- Never invent a purchase count, a cost per purchase or a budget the input did
  not carry.
- Never say a campaign is good, bad, or should be turned off. This unit moves
  money along the ranking you pasted.
- Never claim what the account will do after the step.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, supercharge, harness, utilize.

## Worked case 1, a pure shift

**This is fixture `fixtures/fixture-a-halewick-home.md` run literally, line by
line, under the rules above. It is not a separate example.**

```
population: the campaigns you pasted, counted once each.
per-step cap: 25% of each campaign's own current daily budget

## Classes
READY:   HH | Prospecting | Broad (62), HH | Prospecting | Lookalike 2% (41),
         HH | Retargeting | Site 30d (55), HH | Brand search (24)
UNREADY: HH | Prospecting | Interest stack, purchases 7, still needed 10 - 7 = 3,
         holds its current daily budget of $70.00, unchanged by this step.
NO DATA: none

## The pool
target total daily budget:                       $400.00
minus the budgets held by UNREADY and NO DATA:   $70.00
movable pool:                                    $330.00
current total across READY campaigns:            $330.00
net change to place this step: D = 330.00 - 330.00 = $0.00

## Net change pass
D is zero. $0.00 placed, $0.00 removed.

## Shift pass
READY costs per purchase, sorted: 18.60, 22.40, 39.10, 48.20
median: (22.40 + 39.10) / 2 = 61.50 / 2 = $30.75
givers (above 30.75):     HH | Prospecting | Broad 48.20, HH | Prospecting | Lookalike 2% 39.10
receivers (at or below):  HH | Brand search 18.60, HH | Retargeting | Site 30d 22.40
remaining give capacity G:    150.00 x 0.25 = 37.50, 90.00 x 0.25 = 22.50, G = $60.00
remaining receive capacity C: 30.00 x 0.25 = 7.50, 60.00 x 0.25 = 15.00, C = $22.50
moved: the smaller of 60.00 and 22.50 = $22.50
  off the most expensive first: HH | Prospecting | Broad gives $22.50, its cap is
  $37.50 so it is not capped out; HH | Prospecting | Lookalike 2% gives $0.00
  onto the cheapest first: HH | Brand search takes $7.50 (its cap), then
  HH | Retargeting | Site 30d takes $15.00 (its cap)
held back: 60.00 - 22.50 = $37.50, because the receiving side was binding at
$22.50 of capacity this step.

## Movement table
campaign                          | class   | now    | cap   | leaves | arrives | next   | share
HH | Prospecting | Broad          | READY   | 150.00 | 37.50 |  22.50 |    0.00 | 127.50 | 127.50/400.00 = 0.31875 = 31.9%
HH | Prospecting | Lookalike 2%   | READY   |  90.00 | 22.50 |   0.00 |    0.00 |  90.00 |  90.00/400.00 = 0.22500 = 22.5%
HH | Retargeting | Site 30d       | READY   |  60.00 | 15.00 |   0.00 |   15.00 |  75.00 |  75.00/400.00 = 0.18750 = 18.8%
HH | Prospecting | Interest stack | UNREADY |  70.00 |  0.00 |   0.00 |    0.00 |  70.00 |  70.00/400.00 = 0.17500 = 17.5%
HH | Brand search                 | READY   |  30.00 |  7.50 |   0.00 |    7.50 |  37.50 |  37.50/400.00 = 0.09375 =  9.4%
Shares are rounded to one decimal place, so the column above totals 100.1%
rather than 100.0%.

## Totals
ending total: 127.50 + 90.00 + 75.00 + 70.00 + 37.50 = $400.00
target total: $400.00
gap: 400.00 - 400.00 = $0.00        none

## Run this again
After seven days at these budgets, re-pull the four fields on the same screen.
```

## Worked case 2, a cut the caps cannot finish

**This is fixture `fixtures/fixture-b-cobalt-and-fern.md` run literally, line by
line, under the rules above.**

```
## Classes
READY:   CF | Prospecting | Broad (33), CF | Prospecting | Video LAL (18),
         CF | Retargeting | Cart 7d (40)
UNREADY: none
NO DATA: CF | Prospecting | Creator UGC
         [NEEDS: the 30-day purchases and cost per purchase for
         CF | Prospecting | Creator UGC]
         holds its current daily budget of $80.00, unchanged by this step.

## The pool
target total daily budget:                       $350.00
minus the budgets held by UNREADY and NO DATA:   $80.00
movable pool:                                    $270.00
current total across READY campaigns:            $365.00
net change to place this step: D = 270.00 - 365.00 = -$95.00

## Net change pass
D is below zero, so money comes off the most expensive first, each up to its cap.
  CF | Prospecting | Broad, $61.00 per purchase, cap 200.00 x 0.25 = 50.00,
    takes off 50.00, still to remove 95.00 - 50.00 = 45.00
  CF | Prospecting | Video LAL, $54.00 per purchase, cap 120.00 x 0.25 = 30.00,
    takes off 30.00, still to remove 45.00 - 30.00 = 15.00
  CF | Retargeting | Cart 7d, $19.80 per purchase, cap 45.00 x 0.25 = 11.25,
    takes off 11.25, still to remove 15.00 - 11.25 = 3.75
  The cheapest campaign on the list gives $11.25 as well, because the two above
  it are capped out at 25% each and the target still had to be met.
NOT REMOVED THIS STEP: $3.75, because every READY campaign is at its 25% cap.

## Shift pass
median cost per purchase across READY: 19.80, 54.00, 61.00, median = $54.00
givers (above 54.00):    CF | Prospecting | Broad
receivers (at or below): CF | Prospecting | Video LAL, CF | Retargeting | Cart 7d
Both receivers lost money in the net change pass, so neither can receive in this
pass, and the giver is already at its cap.
remaining give capacity G: $0.00     remaining receive capacity C: $0.00
moved: $0.00
held back: 0.00 - 0.00 = $0.00, because both sides are capped out this step.

## Movement table
campaign                       | class   | now    | cap   | leaves | arrives | next   | share
CF | Prospecting | Broad       | READY   | 200.00 | 50.00 |  50.00 |    0.00 | 150.00 | 150.00/353.75 = 0.42403 = 42.4%
CF | Prospecting | Video LAL   | READY   | 120.00 | 30.00 |  30.00 |    0.00 |  90.00 |  90.00/353.75 = 0.25442 = 25.4%
CF | Retargeting | Cart 7d     | READY   |  45.00 | 11.25 |  11.25 |    0.00 |  33.75 |  33.75/353.75 = 0.09541 =  9.5%
CF | Prospecting | Creator UGC | NO DATA |  80.00 |  0.00 |   0.00 |    0.00 |  80.00 |  80.00/353.75 = 0.22615 = 22.6%
Shares are rounded to one decimal place, so the column above totals 99.9% rather
than 100.0%.

## Totals
ending total: 150.00 + 90.00 + 33.75 + 80.00 = $353.75
target total: $350.00
gap: 353.75 - 350.00 = $3.75        the 25% per-step cap on all three READY
campaigns, with $80.00 a day held by a campaign this unit cannot read.

## Run this again
After seven days at these budgets, re-pull the four fields on the same screen.
```
