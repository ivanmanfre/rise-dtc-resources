---
name: spend-05-stock-cover-guard
description: "Use when you are spending against a product that will run out before the restock lands and you need to know what daily spend keeps it on the shelf. Takes units on hand per SKU off the Shopify inventory screen, units sold over the last 7 days off the Shopify analytics screen, the restock date your supplier confirmed, and the current daily spend pointed at that SKU, and returns days of cover per SKU and the daily spend ceiling that keeps it in stock until the restock date. Triggers on \"how much can I spend before this sells out\", \"will this SKU last until restock\", \"should I cut spend on a product that is running low\", \"days of cover on my bestseller\", \"my winner keeps going out of stock\"."
---

# The DTC Growth Team, SPEND, unit 05 of 06 (agent 11 of 30)

## What this does

Reads a stock position and a sell-through rate per SKU, works out how long the
stock lasts at that rate, and where the stock runs out before the restock lands,
prints the daily spend that would have kept it there.

Out comes one file, `stock-cover.md`.

**The line only this unit produces:** days of cover per SKU, and the daily spend
ceiling on that SKU that keeps it in stock until the restock date.

This is the one place in the pack where fulfilment reaches into a spend decision.
It does not plan production, chase a supplier or judge a lead time. It takes the
restock date as given and prices the spend against it.

## Required input

Per SKU, four things and today's date:

1. **The SKU code or product name**, as it appears on the inventory screen.
2. **Units on hand**, from the Shopify inventory screen. The number in the
   Available column.
3. **Units sold over the last 7 days** for that same SKU, from the Shopify
   analytics screen with the date preset on Last 7 Days.
4. **The restock date your supplier confirmed**, as a date.
5. **The current daily spend pointed at that SKU**, from the daily budget on the
   campaign or ad set that sends people to it.
6. **Today's date.**

If one line covers several variants of the same product, that line is split
before anything is classed. A size run or a colour run holds several stock
positions and one status cannot stand for all of them. Print
`[NEEDS: units on hand and units sold per variant]` and stop on that line rather
than working on the total.

Never ask for a CSV, an inventory feed, a connection or a purchase order.

## What it refuses

**Refusal 1, no ceiling without a restock date.**

```
NO CEILING: NO RESTOCK DATE
SKU: <code>
days of cover: <n> days      (printed, because that part is computable)
[NEEDS: the restock date your supplier confirmed]
Without a date there is nothing to keep the stock alive until, so there is no
ceiling to compute. No date is assumed and no ceiling prints.
```

Days of cover still prints on that SKU. One missing field takes out the field it
feeds, and no more.

**Refusal 2, no forecast.** The ceiling is a ceiling. This unit does not predict
units, revenue or the date the SKU actually runs out, and it does not say whether
the restock will land on the date it was given.

**Refusal 3, no reallocation.** This unit will not tell you where to move the
money it takes off a SKU. Moving money between campaigns is a different artifact
and it is planned in the spend shift planner.

## The assumption this unit runs on, printed on every run

```
This treats units sold as moving in line with spend on that SKU. They do not move
in line exactly, so the figure below is a ceiling rather than a plan. It also
assumes your daily spend on this SKU was steady across the last 7 days. If you
changed that spend inside the window, the sell-through rate and the spend figure
belong to two different weeks and the ceiling is wrong. Re-pull the 7-day units
after a steady week and run this again.
```

## Method

State this once at the top of the output, before any figure:

> Every rate below is counted over the stated population "the last 7 days on this
> SKU", one SKU at a time. Nothing here is pooled across SKUs and no SKU's rate is
> used on another.

**The rounding convention, one convention, used everywhere in this unit.** Every
division is carried at full precision and rounded only at the moment it is
printed. A printed, rounded figure is never fed back into a later division. The
later division uses the unrounded value, so the printed line and the value behind
it can differ in the last decimal and the file is still correct. Rounding is
half-up. Rates and allowed daily rates print to three decimals, days of cover to
one, ratios to four, money to two. Two runs of the same SKU under this one
convention print the same numbers.

**Step 1, one row per SKU, always.** Every SKU pasted gets a printed row and one
of the statuses in Step 6, including the ones nothing is computable for.

**Step 2, the daily sell-through rate.** Print the division:

```
units sold in the last 7 days / 7 = <rate> units a day
```

**Zero units sold in the window** routes to the named branch and no division of
units on hand prints:

```
NO SELL-THROUGH
SKU: <code>      units on hand: <n>      units sold in the last 7 days: 0
Days of cover cannot be computed, because there is no rate to divide by and this
unit will not divide by zero. At $<spend> a day pointed at this SKU, the question
in front of you is why nothing sold, and stock is not the constraint on it.
```

**Zero units on hand** routes to its own named branch, before any division:

```
OUT OF STOCK NOW
SKU: <code>      units on hand: 0
days of cover: 0
spend ceiling until <restock date>: $0.00 a day
Nothing is on the shelf, so every dollar pointed at this SKU today is buying
traffic to something that cannot be bought.
```

**Step 3, days of cover.** Print the division:

```
units on hand / daily sell-through rate = <days of cover>
```

**Step 4, days until restock.** Print the subtraction in dates and in days:

```
<restock date> minus <today> = <n> days
```

A restock date on or before today prints `RESTOCK DATE PASSED` with both dates,
and `[NEEDS: the restock date your supplier has confirmed now]`. Days of cover
still prints. `RESTOCK DATE PASSED` is also the SKU's status word in Step 6 and
its own row in the status counts. It is a different condition from Refusal 1,
where the date is absent, so it is never folded into `NO CEILING, MISSING INPUT`:

```
RESTOCK DATE PASSED
SKU: <code>
restock date: <date>      today: <date>
[NEEDS: the restock date your supplier has confirmed now]
days of cover: <d> days      (printed, because that part is computable)
The date on file is behind you, so there is nothing left to keep the stock alive
until. No ceiling prints and no new date is assumed.
```

**Step 5, the ceiling.** Only when days of cover is below days until restock.
Three divisions, all printed:

```
allowed daily rate = units on hand / days until restock = <a> units a day
ratio              = allowed daily rate / current daily rate = <r>
spend ceiling      = current daily spend x <r> = $<c> a day
```

A current daily spend of 0 prints `NO SPEND POINTED AT THIS SKU` instead of a
ceiling, because multiplying zero by a ratio produces a ceiling of zero that
reads as an instruction. Days of cover and the allowed daily rate still print.

**Step 6, the status per SKU.** One of exactly six, all six listed in the
output even when a class is empty:

| status | when |
|---|---|
| `CEILING SET` | cover is below days until restock, and a ceiling was computable |
| `HEADROOM` | cover is at or above days until restock |
| `NO SELL-THROUGH` | zero units sold in the window |
| `OUT OF STOCK NOW` | zero units on hand |
| `RESTOCK DATE PASSED` | the restock date is present and is on or before today |
| `NO CEILING, MISSING INPUT` | a required field for the ceiling is absent, with its `[NEEDS:]` printed |

The six are exhaustive over the SKUs you pasted. Every row lands in exactly one
of them, and the six counts add to the number of rows pasted. If a row will not
sit in one of the six, that is a defect in this unit, not a licence to invent a
seventh status or to leave the row out of the counts.

**Step 7, the headroom line.** On a `HEADROOM` SKU, print how far the current
spend is from biting, using the same three divisions as Step 5:

```
allowed daily rate = units on hand / days until restock = <a> units a day
ratio              = allowed daily rate / current daily rate = <r>
this ceiling only bites above $<current spend> x <r> = $<c> a day
```

**Step 8, the order to read them in.** SKUs are printed with `CEILING SET` first,
then `OUT OF STOCK NOW`, then `RESTOCK DATE PASSED`, then
`NO CEILING, MISSING INPUT`, then `NO SELL-THROUGH`, then `HEADROOM`. The order is
by what the reader has to touch today.

## Output format

Write one file, `stock-cover.md`.

```
# Stock cover
today: <date>
population: <the sentence from the Method preamble>
<the assumption block, verbatim>

## Per SKU
### <SKU code>          status: <one of the five>
units on hand: <n>          units sold in the last 7 days: <n>
restock date: <date> | [NEEDS: the restock date your supplier confirmed]
current daily spend on this SKU: $<s>

daily sell-through rate: <n> / 7 = <r> units a day
days of cover:           <n> / <r> = <d> days
days until restock:      <restock> minus <today> = <n> days
<the ceiling block, or the headroom block, or the named branch>

## Status counts
CEILING SET <n>   HEADROOM <n>   NO SELL-THROUGH <n>   OUT OF STOCK NOW <n>
RESTOCK DATE PASSED <n>   NO CEILING, MISSING INPUT <n>
counted over the SKUs you pasted, one row each, <n> rows in total.
All six rows print, including the zeros, and the six add to the total above.

## Today
<one line per CEILING SET and OUT OF STOCK NOW SKU: the SKU, the current spend,
the ceiling>
```

## Edge cases

**The 7-day window contains a promotion or a sold-out day.** Then the rate belongs
to a week that will not repeat. Print `THE WINDOW CARRIES A ONE-OFF` beside the
rate when the reader says so, keep every figure, and print one line saying which
direction it pushes the ceiling. This unit does not adjust the rate to correct for
it, because an adjusted rate is a rate nobody can check against the screen.

**Stock is held across two locations.** Add them only if the reader states both
are sellable on the same storefront. Print the two numbers and their sum on
separate lines so the addition is visible.

**The restock is partial.** The date carries a quantity the input does not hold.
Print `PARTIAL RESTOCK` and `[NEEDS: the number of units arriving on that date]`,
and set the ceiling from the units on hand alone, which is the conservative side
and is labelled as such in one line.

**One SKU is sold both on its own and inside a bundle.** The units sold figure
from the analytics screen may count one, the other or both. Print
`BUNDLE MAY BE UNCOUNTED` on that SKU and one line naming what to check on the
screen. The rate prints unchanged, with the flag beside it.

**The reader wants the ceiling expressed as a budget for a campaign that also
sells other SKUs.** Print the ceiling for the SKU and print
`THIS CAMPAIGN CARRIES MORE THAN THIS SKU` with
`[NEEDS: the share of that campaign's spend pointed at this SKU]`. A ceiling on a
campaign that sells four products is not this SKU's ceiling.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never assume, infer or round a restock date. Refusal 1 fires instead.
- Never divide by a sell-through rate of zero or by zero days until restock. Both
  route to a named branch printed in words before the division.
- Never fold a SKU with a missing field into a zero. It keeps its row and its own
  status.
- Never print one status for a line covering several variants.
- Never state when the SKU will actually run out, how many units will sell, or
  what the restock will do to revenue.
- Never tell the reader where to move the money the ceiling frees.
- Never invent a unit count, a date or a spend figure the input did not carry.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-tallow-and-pine.md` run literally, line by
line, under the rules above. It is not a separate example.**

```
today: 2026-06-02
population: the last 7 days on this SKU, one SKU at a time.

### TP-CANDLE-CEDAR-8OZ          status: CEILING SET
units on hand: 240        units sold in the last 7 days: 98
restock date: 2026-06-30  current daily spend on this SKU: $110.00
daily sell-through rate: 98 / 7 = 14.0 units a day
days of cover:           240 / 14.0 = 17.1 days
days until restock:      2026-06-30 minus 2026-06-02 = 28 days
17.1 is below 28, so a ceiling is set.
allowed daily rate = 240 / 28 = 8.571 units a day
ratio              = 8.571 / 14.0 = 0.6122
spend ceiling      = 110.00 x 0.6122 = $67.35 a day
(the ratio carried forward is the unrounded 0.61224489..., not the printed
0.6122, per the rounding convention: 110.00 x 0.61224489... = 67.3469..., which
prints as $67.35)

### TP-CANDLE-FIG-8OZ            status: HEADROOM
units on hand: 410        units sold in the last 7 days: 42
restock date: 2026-07-15  current daily spend on this SKU: $60.00
daily sell-through rate: 42 / 7 = 6.0 units a day
days of cover:           410 / 6.0 = 68.3 days
days until restock:      2026-07-15 minus 2026-06-02 = 43 days
68.3 is at or above 43, so no ceiling is set.
allowed daily rate = 410 / 43 = 9.535 units a day
ratio              = 9.535 / 6.0 = 1.5891
this ceiling only bites above 60.00 x 1.5891 = $95.35 a day
(the allowed daily rate carried into the ratio is the unrounded 9.5348837...,
not the printed 9.535, so the ratio is 1.58914728... and prints as 1.5891. The
same unrounded ratio carried into the money line gives 95.3488..., which prints
as $95.35)

### TP-DIFFUSER-CEDAR            status: NO SELL-THROUGH
units on hand: 75         units sold in the last 7 days: 0
restock date: 2026-06-20  current daily spend on this SKU: $25.00
NO SELL-THROUGH
Days of cover cannot be computed, because there is no rate to divide by and this
unit will not divide by zero. At $25.00 a day pointed at this SKU, the question
in front of you is why nothing sold, and stock is not the constraint on it.

### TP-SOAP-BUNDLE               status: NO CEILING, MISSING INPUT
units on hand: 130        units sold in the last 7 days: 61
restock date: [NEEDS: the restock date your supplier confirmed]
current daily spend on this SKU: $45.00
daily sell-through rate: 61 / 7 = 8.714 units a day
days of cover:           130 / 8.714 = 14.9 days
Without a date there is nothing to keep the stock alive until, so there is no
ceiling to compute. No date is assumed and no ceiling prints.

## Status counts
CEILING SET 1   HEADROOM 1   NO SELL-THROUGH 1   OUT OF STOCK NOW 0
RESTOCK DATE PASSED 0   NO CEILING, MISSING INPUT 1
counted over the SKUs you pasted, one row each, 4 rows in total.

## Today
TP-CANDLE-CEDAR-8OZ   spending $110.00 a day   ceiling $67.35 a day
```
