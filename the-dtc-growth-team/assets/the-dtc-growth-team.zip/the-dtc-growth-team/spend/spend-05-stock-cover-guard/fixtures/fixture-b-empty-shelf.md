# Fixture B, two SKUs at the edges

Invented brand and invented figures. Not a record of any store.
Exercises the zero-units-on-hand branch and the passed-restock-date branch.

---

Today's date: 2026-06-02

TP-CANDLE-CEDAR-16OZ
  units on hand (Available): 0
  units sold, Last 7 Days: 12
  restock date confirmed by supplier: 2026-06-09
  current daily spend pointed at this SKU: $30.00

TP-TRAVEL-TIN
  units on hand (Available): 60
  units sold, Last 7 Days: 25
  restock date confirmed by supplier: 2026-05-28
  current daily spend pointed at this SKU: $18.00
