# Fixture A, four SKUs with spend pointed at them

Invented brand and invented figures. Not a record of any store.
Designed to exercise a paste in which the four SKUs do not all carry the same
fields.

---

Today's date: 2026-06-02

TP-CANDLE-CEDAR-8OZ
  units on hand (Available): 240
  units sold, Last 7 Days: 98
  restock date confirmed by supplier: 2026-06-30
  current daily spend pointed at this SKU: $110.00

TP-CANDLE-FIG-8OZ
  units on hand (Available): 410
  units sold, Last 7 Days: 42
  restock date confirmed by supplier: 2026-07-15
  current daily spend pointed at this SKU: $60.00

TP-DIFFUSER-CEDAR
  units on hand (Available): 75
  units sold, Last 7 Days: 0
  restock date confirmed by supplier: 2026-06-20
  current daily spend pointed at this SKU: $25.00

TP-SOAP-BUNDLE
  units on hand (Available): 130
  units sold, Last 7 Days: 61
  restock date confirmed by supplier:
  current daily spend pointed at this SKU: $45.00
