---
name: spend-02-scale-break-diagnoser
description: "Use when you raised a campaign's budget, the cost per purchase got worse, and you want to know which named thing broke rather than a theory. Takes two Ads Manager rows for the same campaign, one at the old budget and one at the higher budget, each carrying spend, impressions, frequency, click rate, cost per click and cost per purchase, and returns one named cause with the metric that moved and the metric that held printed side by side, or the printed verdict that these two rows cannot separate the causes. Triggers on \"why did my cost per purchase go up when I scaled\", \"I raised the budget and it broke\", \"what happened when I increased spend\", \"is this fatigue or is the auction more expensive\", \"diagnose my scale break\"."
---

# The DTC Growth Team, SPEND, unit 02 of 06 (agent 08 of 30)

## What this does

Takes the two rows either side of a budget increase on one campaign and asks
which of four named things the numbers actually support. Then it prints that
one, or it prints that the rows do not separate them.

Out comes one file, `scale-break.md`.

**The line only this unit produces:** one named cause for one campaign's break,
with the metric that moved and the metric that held printed side by side as the
reason, or `UNDECIDABLE` with the same two columns filled in.

`UNDECIDABLE` is a verdict here with the same standing as the four causes. It is
printed in full, with its own reason columns and its own next step. A run that
produces it has worked correctly.

## Required input

For **one campaign**, two rows off the Ads Manager campaign or ad set screen,
one from before the budget went up and one from after:

1. **The campaign name**, identical on both rows.
2. **The daily budget on each row**, and the two have to be different.
3. **The date range on each row**, both start and end, so the number of days can
   be counted.
4. Per row, six figures as printed on the screen: **amount spent**,
   **impressions**, **frequency**, **click rate**, **cost per click**, **cost per
   purchase**.

Columns can be added to that screen from the Columns menu without exporting
anything. Everything above is read off the screen and typed in.

If the paste carries several campaigns, this unit splits the block before
anything is classed and runs once per campaign name. A single verdict over a
block that holds three campaigns describes none of them.

Never ask for a CSV, an account connection, a pixel, a lifetime value or a
margin figure.

## What it refuses

**Refusal 1, one budget level.** If only one row was pasted, or both rows carry
the same daily budget, there is no step to diagnose:

```
NO CAUSE NAMED: ONE BUDGET LEVEL
budget on row 1: $<x>/day        budget on row 2: $<y> | not supplied
A cause here is a difference between two budget levels. With one level there is
nothing to compare and this unit names nothing.
[NEEDS: the same six figures for this campaign at the other budget level, over a
window of the same number of days]
```

**Refusal 2, windows of different lengths.** Counted in days from the two date
ranges, before anything else is read:

```
NO CAUSE NAMED: THE TWO WINDOWS ARE DIFFERENT LENGTHS
row 1: <start> to <end> = <n> days        row 2: <start> to <end> = <m> days
Frequency is counted over the window it is pulled on, so a longer window carries
a higher frequency by itself, with no change in delivery. Spend, impressions and
purchases scale with the window as well.
Re-pull both rows on windows of the same number of days and run this again.
```

**Refusal 3, no verdict on anything outside these rows.** This unit will not rule
on your creative, your landing page, your offer, your season or your competitors.
It rules on what these two rows can carry, and where they carry nothing it prints
`UNDECIDABLE` rather than the most likely story.

## The four causes, and the movement threshold

**A metric has MOVED when it changed by 15% or more of its own earlier value, up
or down. Below 15% it HELD.** Every metric on these screens wobbles week to week,
and without a stated line every change reads as a signal. The 15% is this unit's
own rule and it is printed in the output so the reader can see what it did.

| cause | what must have MOVED | what must have HELD |
|---|---|---|
| **A. THE AUCTION GOT MORE EXPENSIVE** | cost per thousand impressions, up | click rate, and click-to-purchase rate |
| **B. THE SAME PEOPLE SAW IT TOO OFTEN** | frequency up, and click rate down | cost per thousand impressions |
| **C. THE CREATIVE STOPPED EARNING THE CLICK** | click rate down, with frequency held or down | cost per thousand impressions |
| **D. THE CLICKS STOPPED TURNING INTO BUYERS** | click-to-purchase rate, down | click rate |

**The four are mutually exclusive by construction.** A and D disagree about the
click-to-purchase rate. A and D on one side disagree with B and C about the click
rate. B and C disagree about frequency. So at most one signature can ever be
complete, and the verdict is either one named cause or `UNDECIDABLE`. There is no
tie to break and no ranking to apply.

**Cost per click is never a signature.** It is the cost per thousand impressions
divided by the click rate, so it moves whenever either of those moves. It is
printed on the movement table and it decides nothing.

## Method

State this once at the top of the output, before any figure:

> Every figure below is counted over one campaign and two windows of the same
> number of days, each window counted once. Nothing here is pooled across
> campaigns and nothing is added across the two windows.

**Step 1, count the days on both rows.** Refusal 2 fires here or nowhere.

**Step 2, check the two budgets differ.** Refusal 1 fires here or nowhere.

**Step 3, check the twelve figures are present.** Any missing figure prints
`[NEEDS: <the exact field>, from the <old|new> budget row]` and the verdict is
`UNDECIDABLE (A REQUIRED FIGURE IS MISSING)`. Do not derive a missing field from
a different row.

**Step 4, derive four figures per row. Print every division.**

```
cost per thousand impressions = spend / impressions x 1000
clicks                        = spend / cost per click
purchases                     = spend / cost per purchase
click-to-purchase rate        = purchases / clicks
```

Clicks are rounded to the nearest whole click and the unrounded figure is printed
beside the rounded one.

**Precision, so the reader can redo this by hand.** Rates print to four
significant figures. Every change in Step 8 is computed on the figures exactly as
they are printed on this table, not on a longer number held behind them. A
percentage a reader cannot reproduce from the digits in front of them is a
percentage they have to take on trust.

**Step 5, the click column check.** Work the click count a second way,
`impressions x click rate`, and compare it to the clicks from Step 4:

```
clicks from spend / cost per click:   <n>
clicks from impressions x click rate: <m>
apart by: |<m> - <n>| / <n> = <percent>
```

If they are apart by more than 15%, the click rate column and the cost per click
column are counting different clicks, which happens when one is all clicks and
the other is link clicks. Print `CLICK COLUMNS DISAGREE` and set the verdict to
`UNDECIDABLE (THE TWO CLICK COLUMNS COUNT DIFFERENT CLICKS)` whatever the
signatures say, because three of the four causes rest on a click count. The fix
printed with it: pull both rows again with one click column chosen in the Columns
menu and used for both.

**Step 6, check there is a break at all.** If the cost per purchase held, or
improved, print the named branch and stop:

```
NO BREAK TO DIAGNOSE
cost per purchase: $<old> -> $<new>, change <percent>
This is inside the 15% line this unit calls held, so there is nothing here for a
cause to explain. No cause is named.
```

**Step 7, check both rows can be read.** Purchases per row, from Step 4, against
this unit's minimum of **10 purchases in each row**. Below it in either row the
verdict is `UNDECIDABLE (TOO FEW PURCHASES TO READ)`, with both counts and the
number still needed printed. A cost per purchase built on four purchases moves
25% when one purchase lands or does not.

**Step 8, the movement table.** Six lines, always all six, always printed, in
this order: cost per purchase, cost per thousand impressions, frequency, click
rate, click-to-purchase rate, cost per click. Each line carries the old value,
the new value, the change as a percentage of the old value with the division
shown, and one of `MOVED UP`, `MOVED DOWN`, `HELD`.

**Step 9, run the four signatures against the table.** Print all four with
`FIRES` or `RULED OUT`, and on every ruled-out cause print the one figure that
rules it out. The reader gets to see the three that did not survive.

**Step 10, the verdict.**

- Exactly one signature complete: print that cause name.
- No signature complete: print `UNDECIDABLE`, with one of the sub-reasons below.

`UNDECIDABLE` sub-reasons, one of them named on every undecidable run:

| sub-reason | when it prints |
|---|---|
| `MORE THAN ONE THING MOVED` | two or more of the four signature metrics moved, so no signature has its held column intact |
| `NOTHING MOVED PAST THE LINE` | the cost per purchase got worse and no other metric on these rows moved 15% or more |
| `TOO FEW PURCHASES TO READ` | Step 7 |
| `A REQUIRED FIGURE IS MISSING` | Step 3 |
| `THE TWO CLICK COLUMNS COUNT DIFFERENT CLICKS` | Step 5 |
| `NO CLICKS IN A ROW` | clicks is zero in either row, so the click-to-purchase division cannot run in that row |

**Step 11, the reason columns.** Two columns, side by side, on every verdict
including `UNDECIDABLE`:

```
moved: <metric, old -> new, change>          held: <metric, old -> new, change>
```

**Step 12, one next step, tied to the verdict.** One line, describing something
the reader does on the same two screens. No step here promises a result.

## Output format

Write one file, `scale-break.md`.

```
# Scale break
campaign: <name>
old budget: $<x>/day over <start> to <end>, <n> days
new budget: $<y>/day over <start> to <end>, <n> days
population: <the sentence from the Method preamble>
movement line: a metric MOVED at 15% or more of its own earlier value.

## Pasted
                        old        new
spend                   $          $
impressions
frequency
click rate              %          %
cost per click          $          $
cost per purchase       $          $

## Derived, divisions shown
cost per thousand   <spend> / <impressions> x 1000 = $<x>   |   ... = $<y>
clicks              <spend> / <cost per click> = <n.nn> -> <n>  |  ...
purchases           <spend> / <cost per purchase> = <n>     |   ...
click-to-purchase   <purchases> / <clicks> = <decimal> = <percent>  |  ...
click column check  <the two counts and the gap>

## Movement
metric | old | new | change | status
<six rows, always all six>

## Signatures
A THE AUCTION GOT MORE EXPENSIVE          FIRES | RULED OUT by <figure>
B THE SAME PEOPLE SAW IT TOO OFTEN        FIRES | RULED OUT by <figure>
C THE CREATIVE STOPPED EARNING THE CLICK  FIRES | RULED OUT by <figure>
D THE CLICKS STOPPED TURNING INTO BUYERS  FIRES | RULED OUT by <figure>

## VERDICT: <cause name> | UNDECIDABLE (<sub-reason>)
moved: <...>                     held: <...>

## Next
<one line>
```

Every slot the input did not carry prints `[NEEDS: <the exact thing to supply>]`,
and every figure derived from it prints `[NEEDS: ...]` too.

## Edge cases

**The budget was raised part way through one window.** Then neither row is at a
single budget level and both are averages of two. Print
`THE ROWS STRADDLE THE CHANGE` and
`[NEEDS: two windows that each sit entirely on one side of the day you changed
the budget]`, and name no cause.

**Impressions are zero in a row.** The cost per thousand division cannot run.
Print `NO DELIVERY IN THIS ROW` with the row named, and the verdict is
`UNDECIDABLE (A REQUIRED FIGURE IS MISSING)` with
`[NEEDS: a window in which this campaign delivered]`.

**The reader also changed the creative, the audience or the offer inside the new
window.** Print `A SECOND CHANGE SITS INSIDE THE WINDOW`, name it back to them in
their own words, and print `UNDECIDABLE (MORE THAN ONE THING MOVED)` if any
signature would otherwise have fired. Two changes and one window is one
observation.

**The new row is worse on cost per purchase but better on purchases.** Both are
true and both are printed. This unit is reading the cost of a purchase and says
so in one line, then names the cause of the cost movement. It does not rule on
whether the trade was worth taking.

**Only three or four of the six columns are on the reader's screen.** The missing
ones are added from the Columns menu on that screen. Print the exact column names
still needed rather than working around them, because every signature needs its
held column as much as its moved column.

**The two rows are from different ad accounts or different platforms.** Print
`TWO DIFFERENT ACCOUNTS` and name no cause. Cost per thousand impressions and
frequency are not comparable across accounts that were not bidding for the same
inventory.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- **Never name a cause because the output has a slot for one.** If no signature
  is complete, the verdict is `UNDECIDABLE` and the run is finished and correct.
- Never rank the four causes by likelihood, by what is common, or by what is
  being discussed anywhere. The signatures decide, and they are mutually
  exclusive.
- Never treat cost per click as a signature.
- Never compare two windows of different lengths. Refusal 2 fires first.
- Never divide by zero clicks or zero impressions. Both route to a named printed
  branch before the division.
- Never invent a figure, a date, a window length or a budget the input did not
  carry.
- Never state what fixing the named cause will do to the account.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, supercharge, harness, utilize.

## Worked case 1, a named cause

**This is fixture `fixtures/fixture-a-one-cause.md` run literally, line by line,
under the rules above. It is not a separate example.**

```
campaign: MV | Prospecting | Video 04
old budget: $150.00/day over 2026-04-06 to 2026-04-12, 7 days
new budget: $300.00/day over 2026-04-13 to 2026-04-19, 7 days
population: one campaign, two windows of 7 days each, each counted once.

## Derived, divisions shown
cost per thousand   1,050 / 75,000 x 1000 = $14.00 | 2,100 / 140,000 x 1000 = $15.00
clicks              1,050 / 0.88 = 1,193.18 -> 1,193 | 2,100 / 1.43 = 1,468.53 -> 1,469
purchases           1,050 / 42.00 = 25 | 2,100 / 70.00 = 30
click-to-purchase   25 / 1,193 = 0.020956 = 2.0956% | 30 / 1,469 = 0.020422 = 2.0422%
click column check  1,193 against 75,000 x 1.60% = 1,200, apart by 7 / 1,193 = 0.59%
                    1,469 against 140,000 x 1.05% = 1,470, apart by 1 / 1,469 = 0.07%
                    both under 15%, the two columns agree

## Movement
cost per purchase    $42.00   $70.00    (70.00-42.00)/42.00 = +66.7%   MOVED UP
cost per thousand    $14.00   $15.00    (15.00-14.00)/14.00 = +7.1%    HELD
frequency            1.40     2.60      (2.60-1.40)/1.40    = +85.7%   MOVED UP
click rate           1.60%    1.05%     (1.05-1.60)/1.60    = -34.4%   MOVED DOWN
click-to-purchase    2.0956%  2.0422%   (2.0422-2.0956)/2.0956 = -2.5%  HELD
cost per click       $0.88    $1.43     (1.43-0.88)/0.88    = +62.5%   MOVED UP, not a signature

## Signatures
A THE AUCTION GOT MORE EXPENSIVE          RULED OUT by cost per thousand at +7.1%
B THE SAME PEOPLE SAW IT TOO OFTEN        FIRES
C THE CREATIVE STOPPED EARNING THE CLICK  RULED OUT by frequency at +85.7%, which is up
D THE CLICKS STOPPED TURNING INTO BUYERS  RULED OUT by click-to-purchase at -2.5%

## VERDICT: B. THE SAME PEOPLE SAW IT TOO OFTEN
moved: frequency 1.40 -> 2.60, +85.7%      held: cost per thousand $14.00 -> $15.00, +7.1%
       click rate 1.60% -> 1.05%, -34.4%         click-to-purchase 2.0956% -> 2.0422%, -2.5%

## Next
The extra money went to people this campaign was already reaching, at the same
price per thousand, and they clicked less. The reader's own next pull is the same
six fields on this campaign's audience at the old budget for one further window
of 7 days.
```

## Worked case 2, undecidable

**This is fixture `fixtures/fixture-b-undecidable.md` run literally, line by line,
under the rules above.**

```
campaign: MV | Prospecting | Static 11
old budget: $80.00/day over 2026-04-01 to 2026-04-14, 14 days
new budget: $200.00/day over 2026-04-15 to 2026-04-28, 14 days
population: one campaign, two windows of 14 days each, each counted once.

## Derived, divisions shown
cost per thousand   1,120 / 70,000 x 1000 = $16.00 | 2,800 / 127,000 x 1000 = $22.05
clicks              1,120 / 1.33 = 842.11 -> 842 | 2,800 / 2.45 = 1,142.86 -> 1,143
purchases           1,120 / 56.00 = 20 | 2,800 / 112.00 = 25
click-to-purchase   20 / 842 = 0.023753 = 2.3753% | 25 / 1,143 = 0.021872 = 2.1872%
click column check  842 against 70,000 x 1.20% = 840, apart by 2 / 842 = 0.24%
                    1,143 against 127,000 x 0.90% = 1,143, apart by 0 / 1,143 = 0.00%
                    both under 15%, the two columns agree

## Movement
cost per purchase    $56.00   $112.00   (112.00-56.00)/56.00 = +100.0%  MOVED UP
cost per thousand    $16.00   $22.05    (22.05-16.00)/16.00  = +37.8%   MOVED UP
frequency            1.90     3.40      (3.40-1.90)/1.90     = +78.9%   MOVED UP
click rate           1.20%    0.90%     (0.90-1.20)/1.20     = -25.0%   MOVED DOWN
click-to-purchase    2.3753%  2.1872%   (2.1872-2.3753)/2.3753 = -7.9%  HELD
cost per click       $1.33    $2.45     (2.45-1.33)/1.33     = +84.2%   MOVED UP, not a signature

## Signatures
A THE AUCTION GOT MORE EXPENSIVE          RULED OUT by click rate at -25.0%, which had to hold
B THE SAME PEOPLE SAW IT TOO OFTEN        RULED OUT by cost per thousand at +37.8%, which had to hold
C THE CREATIVE STOPPED EARNING THE CLICK  RULED OUT by frequency at +78.9%, which is up
D THE CLICKS STOPPED TURNING INTO BUYERS  RULED OUT by click-to-purchase at -7.9%

## VERDICT: UNDECIDABLE (MORE THAN ONE THING MOVED)
moved: cost per thousand $16.00 -> $22.05, +37.8%   held: click-to-purchase 2.3753% -> 2.1872%, -7.9%
       frequency 1.90 -> 3.40, +78.9%
       click rate 1.20% -> 0.90%, -25.0%

Reaching people got 37.8% more expensive and the same people saw it 78.9% more
often, inside one window. Cause A needs the click rate to have held and it fell
25.0%. Cause B needs the cost per thousand to have held and it rose 37.8%. These
two rows do not separate them and no cause is named.

## Next
Put this campaign back to $80.00 a day for one further window of 14 days and pull
the same six fields. If the cost per thousand comes back to about $16.00 and the
frequency comes back to about 1.90, the budget was buying both at once. If the
cost per thousand stays near $22.05 at the old budget, the price of reaching
people moved underneath this campaign and the budget was not the thing that
changed it.
```
