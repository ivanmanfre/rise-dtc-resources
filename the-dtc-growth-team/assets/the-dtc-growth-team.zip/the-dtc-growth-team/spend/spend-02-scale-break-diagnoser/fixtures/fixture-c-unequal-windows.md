# Fixture C, two rows pulled off different date ranges

Invented brand and invented figures. Not a record of any account.
Designed to exercise the check that runs before any cause is considered.

---

Campaign: MV | Prospecting | Video 04

Row 1, daily budget $150.00, 2026-04-06 to 2026-04-12
  Amount spent: $1,050.00
  Impressions: 75,000
  Frequency: 1.40
  CTR (link click-through rate): 1.60%
  CPC (cost per link click): $0.88
  Cost per purchase: $42.00

Row 2, daily budget $300.00, 2026-04-13 to 2026-04-22
  Amount spent: $3,000.00
  Impressions: 205,000
  Frequency: 3.10
  CTR (link click-through rate): 1.10%
  CPC (cost per link click): $1.33
  Cost per purchase: $65.00
