# Fixture A, one campaign across a budget increase

Invented brand and invented figures. Not a record of any account.
Designed to exercise the path where all twelve figures are present and the two
windows are the same length.

---

Campaign: MV | Prospecting | Video 04

Row 1, daily budget $150.00, 2026-04-06 to 2026-04-12
  Amount spent: $1,050.00
  Impressions: 75,000
  Frequency: 1.40
  CTR (link click-through rate): 1.60%
  CPC (cost per link click): $0.88
  Cost per purchase: $42.00

Row 2, daily budget $300.00, 2026-04-13 to 2026-04-19
  Amount spent: $2,100.00
  Impressions: 140,000
  Frequency: 2.60
  CTR (link click-through rate): 1.05%
  CPC (cost per link click): $1.43
  Cost per purchase: $70.00
