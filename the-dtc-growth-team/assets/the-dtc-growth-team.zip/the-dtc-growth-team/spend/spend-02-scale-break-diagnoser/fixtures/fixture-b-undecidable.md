# Fixture B, a second campaign across a larger budget increase

Invented brand and invented figures. Not a record of any account.
Designed to exercise a break in which more than one of the signature metrics
moves inside the same window.

---

Campaign: MV | Prospecting | Static 11

Row 1, daily budget $80.00, 2026-04-01 to 2026-04-14
  Amount spent: $1,120.00
  Impressions: 70,000
  Frequency: 1.90
  CTR (link click-through rate): 1.20%
  CPC (cost per link click): $1.33
  Cost per purchase: $56.00

Row 2, daily budget $200.00, 2026-04-15 to 2026-04-28
  Amount spent: $2,800.00
  Impressions: 127,000
  Frequency: 3.40
  CTR (link click-through rate): 0.90%
  CPC (cost per link click): $2.45
  Cost per purchase: $112.00
