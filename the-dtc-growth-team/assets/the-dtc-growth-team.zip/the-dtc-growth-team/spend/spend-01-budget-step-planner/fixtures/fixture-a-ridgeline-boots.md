# Fixture A, one campaign with a week worth stepping on

Invented brand and invented figures. Not a record of any account.
Designed to exercise the ordinary path where every required field is present.

---

Today's date: 2026-05-11

Campaign name: RB | Prospecting | Broad | Video
Current daily budget: $120.00

Last 7 Days (2026-05-04 to 2026-05-10)
  Amount spent: $840.00
  Purchases: 14
  Cost per purchase: $60.00

Last 30 Days (2026-04-11 to 2026-05-10)
  Amount spent: $3,300.00
  Purchases: 50
  Cost per purchase: $66.00

Cost per purchase I can afford: $85.00
