# Fixture B, three campaigns pasted as one block

Invented brand and invented figures. Not a record of any account.
Designed to exercise the paths where a step cannot be sized from the rows given.

---

Today's date: 2026-05-11
Cost per purchase I can afford: $85.00

Campaign name: RB | Retargeting | 30d viewers
Current daily budget: $40.00
  Last 7 Days:  spend $210.00   purchases 4    cost per purchase $52.50
  Last 30 Days: spend $1,150.00 purchases 26   cost per purchase $44.23

Campaign name: RB | Prospecting | Lookalike 3%
Current daily budget: $0.00
  Last 7 Days:  spend $0.00     purchases 0    cost per purchase
  Last 30 Days: spend $0.00     purchases 0    cost per purchase

Campaign name: RB | Prospecting | Broad | Static
Current daily budget: $75.00
  Last 7 Days:  spend $455.00   purchases      cost per purchase
  Last 30 Days: spend $2,010.00 purchases 31   cost per purchase $64.84
