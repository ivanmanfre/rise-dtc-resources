---
name: spend-06-test-budget-ringfencer
description: "Use when every dollar in the account is expected to perform and nothing is ever left free to learn anything. Takes your total monthly ad budget, the cost per purchase on your best current campaign from Ads Manager, and the number of purchases you accept before you call a test, and returns the split of the month into proven money and test money with the number of decisions that test money can buy. Triggers on \"how much should I spend on testing\", \"what percentage of budget goes to new creative\", \"can I afford to test anything this month\", \"split my ad budget into safe and experimental\", \"how many tests can I run this month\"."
---

# The DTC Growth Team, SPEND, unit 06 of 06 (agent 12 of 30)

## What this does

Splits one month of ad budget into money that has to perform and money that is
allowed to lose, then prices that second pot in the only currency a test spends:
decisions.

Out comes one file, `test-ringfence.md`.

**The line only this unit produces:** the split of one month's budget into proven
money and test money, with the number of decisions the test money buys.

## What a decision costs, defined before anything is divided

**One decision is one new thing run until it has reached the number of purchases
you accept, or until it has spent the cost of that many purchases without getting
them.** Both endings cost the same money, and both are decisions. That is why a
test budget is priced in decisions rather than in tests: a test that fails has
been paid for in full.

```
cost of one decision = purchases you accept before calling a test
                       x cost per purchase on your best current campaign
```

Printed with the multiplication shown, every run. And printed beside it, every
run:

```
This uses your best campaign's cost per purchase as the price of a purchase. A
new thing usually costs more per purchase than your best campaign does, so the
decision count below is a ceiling on what this money buys rather than a plan for
what it will buy.
```

## Required input

1. **Total monthly ad budget**, one number, the whole month across every campaign.
2. **The cost per purchase on your best current campaign**, from that campaign's
   row in Ads Manager on a 30-day preset. Best means the lowest cost per purchase
   among the campaigns you would keep.
3. **The number of purchases you accept before you call a test.** The count at
   which you would stop arguing with a result.

Never ask for a CSV, an account connection, a margin figure or a lifetime value.

## What it refuses

**Refusal 1, a ringfence that buys nothing.** If the largest rung on the ladder
buys fewer than one decision, this unit does not print a split:

```
CANNOT RINGFENCE
cost of one decision: <n> x $<c> = $<d>
largest rung, 25% of the month: $<b> x 0.25 = $<t>
decisions: $<t> / $<d> = <decimal>, which is below one

A ringfence that cannot pay for one decision is a line drawn around money that
will be spent before it answers anything. No split is printed.

The first test becomes affordable at a monthly budget of:
  $<d> / 0.25 = $<B>
At the budget you named, a decision would have to cost:
  $<t> ... and at <n> purchases to call, that is a cost per purchase of
  $<t> / <n> = $<x> or below.
```

**Refusal 2, no reallocation and no shopping list.** This unit sets the size of
the pot. It does not choose what to test, does not order the tests, and does not
say which campaign the test money comes out of.

**Refusal 3, no claim on the outcome.** It never says what the test money will
find, how many winners it produces, or what happens to the account.

## Method

State this once at the top of the output, before any figure:

> Every division below is counted over the stated population "the one month of
> budget you named". No figure here is spread across months, and no figure here
> is read from any month other than the one in the input.

**Step 1, the zero branch.** A total monthly budget of 0 stops the run:

```
NO BUDGET TO SPLIT
The month you named carries $0.00, so there is nothing to draw a line inside and
no division prints.
```

**Step 2, the cost of one decision.** From the block above. If either input is
missing, print `[NEEDS: <the exact field>]`, withhold every decision figure, and
carry on to Step 3, which does not depend on it.

**Step 3, the ladder.** Four rungs, all four printed on every run, including the
ones the reader will not take:

```
rung   test money            proven money         decisions
10%    $<b> x 0.10 = $<t>    $<b> - $<t> = $<p>   $<t> / $<d> = <decimal> -> <n>
15%    ...
20%    ...
25%    ...
```

Decisions are the division rounded down to a whole number, and the raw decimal is
printed beside it. A part of a decision buys nothing.

**Step 4, the pick.** The chosen rung is **the smallest rung that buys at least
one decision.** Print it, and print the one line that says what the pick means:

> This is the smallest ringfence that can answer one question inside the month.
> The rungs above it are on the table for a reader who wants more than one
> question answered, and each one costs the proven side what it gives the test
> side.

If no rung buys a decision, Refusal 1 has already fired and there is no pick.

**Step 5, the daily figure.** Test money spread evenly:

```
$<t> / 30 = $<x> a day
```

The 30 is this unit's own divisor and it is printed as such. It is not the number
of days in the reader's month, and where the reader states that number, it
replaces the 30 and the substitution is printed.

**Step 6, what the ringfence has to mean to be one.** Print these three lines,
unchanged:

```
The test money is spent whether or not it works, or the ringfence is not a
ringfence.
The proven money does not rescue a test that has run out of its own money.
A test that is stopped before <n> purchases has not bought a decision, and the
money it spent is gone without one.
```

**Step 7, what this does not do.** One line naming that the split is a size and
not a plan, and that choosing what to put in the test pot is a separate piece of
work.

## Output format

Write one file, `test-ringfence.md`.

```
# Test ringfence
month budget: $<b>
population: <the sentence from the Method preamble>

## The cost of one decision
<n> purchases to call x $<c> per purchase = $<d>
<the ceiling paragraph, verbatim>

## The ladder
rung | test money | proven money | decisions (raw) | decisions (whole)
10%  |            |              |                 |
15%  |            |              |                 |
20%  |            |              |                 |
25%  |            |              |                 |

## The split
chosen rung: <p>%
test money:   $<t>
proven money: $<p>
decisions this buys: <n>
test money per day: $<t> / 30 = $<x>

## What makes it a ringfence
<the three lines from Step 6>

## What this does not do
<the line from Step 7>
```

Any field the input did not carry prints `[NEEDS: <the exact thing to supply>]`,
and every figure that depends on it prints `[NEEDS: ...]` in place of a number.
The dollar ladder still prints when the decision column cannot.

## Edge cases

**The reader gives a range for the cost per purchase on the best campaign.** Use
the higher end, because a decision costed at the low end is a decision the money
does not actually buy. Print one line saying the higher end was used and print
both numbers.

**The best campaign is a retargeting campaign.** Print `THE BEST ROW IS
RETARGETING` and one line saying the decision is being priced at a cost per
purchase most new tests will not see. The arithmetic runs unchanged. Where the
reader can supply the lowest cost per purchase among their prospecting campaigns
as well, print the ladder a second time on that figure and label both.

**The month has already started.** Then the budget in the input is a whole month
and the days left are fewer. Print `THE MONTH IS PART SPENT` and
`[NEEDS: the budget still unspent this month, and the days left in it]`, and run
the ladder on the unspent figure with the days left replacing the 30.

**The reader accepts a purchase count below 5.** Print the ladder unchanged, and
print one line saying the decision is priced at that count and that the count is
theirs. This unit does not raise it. Choosing the count is the reader's call and
it is printed back to them beside the cost it sets.

**Two people share the account and only one of them respects the line.** Outside
this unit. Print the split and print nothing about who spends it.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never print a decision count without the division that produced it.
- Never round a decision count up. A part of a decision buys nothing.
- Never print fewer than the four rungs, and never drop a rung because the reader
  would not take it.
- Never divide by a cost per decision of zero or by a monthly budget of zero.
  Both route to a printed branch before the division.
- Never recommend what to test, in what order, or against what.
- Never say what the test money will find or what it will do to the account.
- Never invent a cost per purchase, a budget or a purchase count the input did
  not carry.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-marlowe-supply.md` run literally, line by
line, under the rules above. It is not a separate example.**

```
month budget: $18,000.00
population: the one month of budget you named.

## The cost of one decision
15 purchases to call x $34.00 per purchase = $510.00
This uses your best campaign's cost per purchase as the price of a purchase. A
new thing usually costs more per purchase than your best campaign does, so the
decision count below is a ceiling on what this money buys rather than a plan for
what it will buy.

## The ladder
rung | test money  | proven money | decisions (raw)          | decisions (whole)
10%  | $1,800.00   | $16,200.00   | 1,800.00 / 510.00 = 3.53 | 3
15%  | $2,700.00   | $15,300.00   | 2,700.00 / 510.00 = 5.29 | 5
20%  | $3,600.00   | $14,400.00   | 3,600.00 / 510.00 = 7.06 | 7
25%  | $4,500.00   | $13,500.00   | 4,500.00 / 510.00 = 8.82 | 8

## The split
chosen rung: 10%
test money:   $1,800.00
proven money: $16,200.00
decisions this buys: 3
test money per day: 1,800.00 / 30 = $60.00
This is the smallest ringfence that can answer one question inside the month. The
rungs above it are on the table for a reader who wants more than one question
answered, and each one costs the proven side what it gives the test side.

## What makes it a ringfence
The test money is spent whether or not it works, or the ringfence is not a
ringfence.
The proven money does not rescue a test that has run out of its own money.
A test that is stopped before 15 purchases has not bought a decision, and the
money it spent is gone without one.

## What this does not do
This is a size and not a plan. What goes into the test pot, and in what order, is
separate work and none of it is decided here.
```
