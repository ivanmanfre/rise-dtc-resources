# Fixture A, one month of budget with a cheap best campaign

Invented brand and invented figures. Not a record of any account.
Designed to exercise a paste where all three fields are present.

---

Total monthly ad budget: $18,000.00

Best current campaign, Last 30 Days:
  MS | Prospecting | Broad
  cost per purchase $34.00

Purchases I accept before I call a test: 15
