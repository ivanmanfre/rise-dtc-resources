# Fixture B, two separate months from one reader

Invented brand and invented figures. Not a record of any account.
Two runs, one per block. Designed to exercise a small month against an expensive
decision, and a paste with a field left blank.

---

## Run 1

Total monthly ad budget: $1,600.00

Best current campaign, Last 30 Days:
  DC | Prospecting | Interest
  cost per purchase $92.00

Purchases I accept before I call a test: 12

## Run 2

Total monthly ad budget: $9,000.00

Best current campaign, Last 30 Days:
  DC | Retargeting | Site 14d
  cost per purchase

Purchases I accept before I call a test: 10
