# The DTC Growth Team, manifest

**30 agents. 5 stages. One job each.**

Every agent is one `SKILL.md` that runs on its own. Every agent takes an input you already
have and returns a line no other agent returns. The count is checkable: count the
directories.


## TRACK (6 agents)

| Agent | What it returns |
|---|---|
| `track-01-utm-tag-auditor` | a PASS or BREAK status per link naming the exact defect, with the corrected link printed |
| `track-02-attribution-window-matcher` | the one reporting basis your figures share, plus the named figures that cannot be added to each other |
| `track-03-tracking-break-checker` | a LIVE, STALE or NEVER FIRED status per event, revenue-carrying events ranked first |
| `track-04-post-purchase-survey-writer` | the question, its answer options bound to your live channels, and the option that will absorb answers named with why |
| `track-05-campaign-naming-fixer` | a rename map grouping by that one stated variable, with names that carry no information about it flagged instead of guessed |
| `track-06-agency-report-reader` | the claims that cannot be checked from what was supplied, each with the one-line reply that asks for the exact missing figure |

## SPEND (6 agents)

| Agent | What it returns |
|---|---|
| `spend-01-budget-step-planner` | the next daily budget, the number of days to hold it untouched, and the printed condition that puts it back |
| `spend-02-scale-break-diagnoser` | one named cause with the metric that moved and the metric that held printed side by side, or the printed verdict that these two rows cannot separate the causes |
| `spend-03-spend-shift-planner` | a money-movement table showing what leaves each campaign and what arrives at each, capped per step, with every campaign printed including the ones this unit will not move money |
| `spend-04-policy-risk-checker` | every claim with the policy family it falls under and a replacement line built only from facts you supplied |
| `spend-05-stock-cover-guard` | days of cover per SKU and the daily spend ceiling that keeps it in stock until the restock date |
| `spend-06-test-budget-ringfencer` | the split of the month into proven money and test money with the number of decisions that test money can buy |

## CREATIVE (6 agents)

| Agent | What it returns |
|---|---|
| `creative-01-angle-gap-mapper` | each ad's angle with counts, plus the angles from a fixed list that no live ad occupies |
| `creative-02-ad-brief-writer` | a shot-by-shot brief with a claim boundary block naming exactly what the supplied facts allow |
| `creative-03-ad-hook-writer` | up to twelve opening lines, each tagged with the device it uses and the fact it rests on |
| `creative-04-test-matrix-builder` | a row-by-row matrix with the question it cannot answer printed underneath |
| `creative-05-winner-iteration-planner` | six next variants, each changing one named element, ordered cheapest to shoot first |
| `creative-06-creative-capacity-planner` | the shortfall and a named cut order |

## CONVERT (6 agents)

| Agent | What it returns |
|---|---|
| `convert-01-message-match-checker` | every promise claim classed ANSWERED, PARTIAL or UNANSWERED with the page line that answers it quoted verbatim |
| `convert-02-offer-variant-designer` | four one-term variants with the break-even condition for each printed as arithmetic you can redo |
| `convert-03-objection-order-writer` | the page section order with the objection each section retires named beside it, plus the sections nothing you supplied justifies |
| `convert-04-landing-test-sizer` | the weeks the test needs with every step of the arithmetic printed, or the named branch that says this page cannot be tested at this traffic |
| `convert-05-first-screen-rewriter` | a rewritten first screen with each slot quoting the input line it rests on and [NEEDS:] where no line supports it |
| `convert-06-storefront-app-lister` | per app whether it is visible there, what it costs you a month, and the exact screen to open next, with UNKNOWN printed wherever no observation was supplied |

## DECIDE (6 agents)

| Agent | What it returns |
|---|---|
| `decide-01-scale-or-kill-judge` | SCALE, HOLD, CUT or NOT ENOUGH SPEND for every ad, never a guess where the row is too thin to read |
| `decide-02-change-log-auditor` | EVALUABLE or CONFOUNDED for every change, naming exactly what it collides with |
| `decide-03-cpa-drift-reader` | WITHIN RANGE, DRIFTED or TOO FEW PERIODS |
| `decide-04-target-feasibility-checker` | the required blended return set against your own best and second-best months |
| `decide-05-net-revenue-corrector` | the return on ad spend restated on revenue you actually kept |
| `decide-06-spend-freeze-planner` | the ordered shutdown list, the one campaign that stays on, and the metric that has to recover |

---

Counted from disk on assembly: **30 agent directories, 30 SKILL.md files**.
