---
name: convert-05-first-screen-rewriter
description: "Use when the part of a paid landing page a buyer sees before scrolling does not say what the thing is, to rewrite it into four labelled slots sourced only from your own words. Takes the text above the first scroll on your phone typed exactly, plus the price as shown, and returns a rewritten first screen with each slot quoting the input line it rests on and [NEEDS:] where no line supports it. Triggers on \"rewrite my hero section\", \"fix the top of my landing page\", \"my above the fold is weak\", \"what should my page say first\", \"rewrite my first screen\"."
---

# The DTC Growth Team, CONVERT, unit 05 of 6: the first screen rewriter

## What this does

Rewrites the top of a paid landing page into four labelled slots, and makes
every slot show its working. A slot that no line of your input supports comes
back empty and named, rather than filled with a sentence that sounds right.

Out comes one file, `first-screen.md`.

**The line only this unit produces:** a rewritten first screen in four labelled
slots, what it is, who it is for, what it costs, why keep scrolling, each one
printing the input line it was built from.

Scope is one screen on one paid landing page. Nothing below the first scroll is
read, judged or rewritten, and the product page's images, reviews, description
and specification blocks are all somebody else's job.

## Required input

1. **The text above the first scroll on your phone**, typed exactly as it
   appears, in order. Include the announcement bar, the headline, any
   subheading, button labels, and any badge or line under the button. Type it
   as it reads, including the lines you do not like.
2. **The price as shown**, and the shipping line beside it if there is one.
3. **What the next section down the page is**, in a few words. "The reviews",
   "the four ingredient cards", "the size chart".

Input 3 is the only one that asks you to look below the fold, and it is one
phrase. Without it the fourth slot cannot be written from anything and comes
back as `[NEEDS: what the next section down the page is]`.

If you cannot see where the first scroll ends, hold your phone, open the page,
and type everything above the point where you would have to move your thumb.

## What it refuses

**Refusal 1, a slot with no source.** Every slot quotes the input line it rests
on. If it cannot quote one:

```
[NEEDS: <the exact fact this slot needs>]
slot: <slot name>
Nothing you typed carries this. The slot is printed empty rather than filled,
because a line invented here would go live above the fold of a page you are
paying to send people to.
```

**Refusal 2, not your voice.**

```
NOT YOUR VOICE
This is a draft in neutral register. One screen of text is not enough to learn
how you write, and this unit collected nothing else, so it does not claim to
have written these lines as you. Rewrite them in your own words before they go
up.
```

**Refusal 3, no new facts.** The rewrite carries only what you typed:

```
This unit does not add a benefit, a number, a badge, a guarantee, a delivery
promise or a claim that was not in your input. It rearranges what is there and
names what is missing.
```

## Method

**Step 1, split the input into fragments and class every one.** One typed line
often carries two facts and can feed two slots. Split before classing, print
the split with the source line quoted:

```
from: "Free UK delivery over $150, 30 night trial"
  F1  free delivery over $150
  F2  30 night trial
```

Then state the population once:

```
Population for every count in this file: the fragments of your first-screen
text, counted once each, after the split above. Fragments: <n>.
```

**Step 2, sweep the input, not the draft.** Every fragment lands in exactly one
of five printed classes:

| Class | Definition | What happens to it |
|---|---|---|
| `USED` | it sources a slot | the slot it went to is named |
| `MOOD` | it carries nothing a buyer could check about the product, including the brand name standing on its own | printed, not carried, reason given |
| `UNSOURCED CLAIM` | it claims a result, a superiority or an outcome and nothing else in your input stands behind it | printed, not carried, reason given |
| `CONTROL` | a button label, a link or a menu item | printed, left exactly as it is, never rewritten |
| `NO SLOT HOLDS THIS` | a fact a buyer could check that none of the four slots is for, a returns term or a trial length for instance | printed, quoted, and you decide whether it stays on the screen |

`UNSOURCED CLAIM` is the class that does the work. A first screen reading "the
best night's sleep you will ever have" carries a claim the rest of the input
cannot support, so it does not go into the rewrite and it is printed with one
line saying what would have to be true to keep it.

Nothing is dropped silently. Every fragment you typed appears somewhere in the
output, in exactly one class.

**Step 3, fill the four slots, in this order.** Each slot is one sentence and
each prints the fragment id it rests on:

| Slot | What it has to say | Sourced from |
|---|---|---|
| `WHAT IT IS` | the plainest naming of the object, in the words a buyer would use to a friend | a fragment naming the product |
| `WHO IT IS FOR` | the person or the situation it is for | a fragment naming a person, a use or a condition |
| `WHAT IT COSTS` | the price as shown, and the shipping term if the input carries one | input 2 |
| `WHY KEEP SCROLLING` | one line naming what is directly below | input 3 |

A slot with no fragment behind it prints Refusal 1. Never source a slot from
another slot, from the brand name, or from what a page like this usually says.

**Step 4, print the character count beside each slot.** A count, not a rule:

```
WHAT IT IS   <the line>   <n> characters
```

This unit does not state how long a first screen should be, because that
depends on a phone this unit cannot see. The counts are printed so you can hold
them against your own screen.

**Step 5, print what the rewrite leaves behind.** Every fragment that is not
`USED`, quoted, with one line each:

```
NOT CARRIED: "<fragment>"   <class>   <reason>
```

`NO SLOT HOLDS THIS` is the row to read twice. It is a real fact, currently on
your first screen, that these four slots have nowhere to put. It is not
rubbish and it is not carried, and both of those are true at once.

The reader decides what leaves. This unit never hands back a first screen with
lines quietly missing.

**Step 6, print the slot count.**

```
SLOTS FILLED: <n> of 4
empty slots: <named>, each with its [NEEDS:] line above
```

Four of four is not a target, and three of four is not a failure. The count
states what your input carried, nothing else.

## Output format

Write one file, `first-screen.md`.

```
# First screen: <the page you named>

## Register
<Refusal 2, verbatim>

## The split
<the Step 1 split, source line quoted above its fragments>

## Population
<the Step 1 population line>

## The rewrite
WHAT IT IS          <line>   <n> characters
  from: F<n> "<the fragment, verbatim>"
WHO IT IS FOR       <line>   <n> characters
  from: F<n> "<the fragment, verbatim>"
                  | [NEEDS: who this is for, in your own words]
WHAT IT COSTS       <line>   <n> characters
  from: the price as shown
WHY KEEP SCROLLING  <line>   <n> characters
  from: input 3, "<what you typed>"
                  | [NEEDS: what the next section down the page is]

## Not carried
NOT CARRIED: "<fragment>"   <class>   <reason>

## Fragment classes
USED <n>   MOOD <n>   UNSOURCED CLAIM <n>   CONTROL <n>   NO SLOT HOLDS THIS <n>
                                                          ----
                                                          <N>, the population

## Slots filled
SLOTS FILLED: <n> of 4
empty slots: <named>
```

## Edge cases

**The first screen is an image with words baked into it.** Type the words out
and say they are in the image. The rewrite comes back as text, and turning it
back into an image is a job for whoever makes your images. Print one line
saying which slots currently live inside a picture, because a picture that does
not load takes those slots with it.

**The announcement bar carries the offer.** It is part of what a buyer sees
before scrolling, so it is input. If the shipping threshold lives up there, it
sources `WHAT IT COSTS` and the fragment id says so.

**The price is not on the first screen at all.** That is a finding, not a
problem to solve by moving it. Fill `WHAT IT COSTS` from input 2 and print one
line saying the price is currently below the fold, so the slot as written would
be new on the page rather than a rewrite of something already there.

**Two products on one landing page.** One run per product, or `WHAT IT IS`
becomes a slot describing a range, which is a different page. Say which you
meant and run it once.

**The current first screen is already four clean lines.** Then the run comes
back with four `USED` fragments and a rewrite close to your own. That is a
result. This unit does not change a line to prove it was here.

**No fragment sources a slot.** Print the branch:

```
NOTHING TO REWRITE FROM
Fragments: <n>   USED: 0
Nothing above your first scroll carries a fact any of the four slots is for.
There is nothing here to arrange, and all four slots print [NEEDS:].
```

The branch fires on `USED: 0`, whatever the other classes hold. A screen made
of a brand name, a mood line and a button is a full run of this unit and the
answer is that there is nothing on it to rewrite.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never fill a slot from a fact absent in the input, including a fact you are
  confident about because of the brand name or the category.
- Never claim the output is in the reader's voice. Refusal 2 prints on every
  run, including good ones.
- Never add a number, a guarantee, a delivery term, a badge or a review count.
- Never quote a fragment that is not in the input, including a tidied version
  of one that is.
- Never drop a line silently. Every fragment appears in exactly one printed
  class.
- Never state an ideal length, an ideal headline, or what converts above the
  fold.
- Never read, judge or rewrite anything below the first scroll. Input 3 is a
  few words naming the next section and nothing else crosses that line.
- Never carry an `UNSOURCED CLAIM` into the rewrite because it was already live
  on the page. Being published is not support.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.
