# Fixture, a first screen carrying no facts

Invented brand. Not a real page.
Designed to exercise: the branch where every fragment lands in MOOD and there
is nothing to arrange.

---

**Page:** the paid landing page for the Halden Goods Slow Hour Candle
(/pages/slow-hour)

## Input 1, everything above the first scroll on my phone, typed as it reads

```
Halden Goods

Made for the slow hour

Some mornings deserve better

[ Shop now ]
```

## Input 2, the price as shown

Not shown above the fold

## Input 3, what the next section down the page is

Not supplied
