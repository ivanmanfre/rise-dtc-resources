# Fixture, one first screen typed off a phone

Invented brand. Not a real page.
Designed to exercise: a line carrying two facts that feeds two slots, a claim
nothing else in the input supports, mood lines with nothing checkable in them,
and a slot with no fragment behind it.

---

**Page:** the paid landing page for the Ashlin and Roe Wool Duvet
(/pages/wool-duvet-cold-sleepers)

## Input 1, everything above the first scroll on my phone, typed as it reads

```
FREE UK DELIVERY OVER $150, 30 NIGHT TRIAL

Sleep like you did as a child

Ashlin and Roe

The best night's sleep you will ever have

[ Add to basket ]

Loved by thousands
```

## Input 2, the price as shown

$128, and under the button it says "or 4 payments of $32"

## Input 3, what the next section down the page is

The three ingredient cards, wool, cotton, the farm
