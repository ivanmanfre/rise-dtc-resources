---
name: convert-01-message-match-checker
description: "Use when an ad is getting clicks and the page behind it is not getting orders, to find the promises the ad makes that the page never answers. Takes the ad's primary text and headline plus the page copy down to the first buy button, and returns every promise claim classed ANSWERED, PARTIAL or UNANSWERED with the page line that answers it quoted verbatim. Triggers on \"people click but don't buy\", \"check my ad against my landing page\", \"does my page match my ad\", \"message match check\", \"why is this landing page not converting\"."
---

# The DTC Growth Team, CONVERT, unit 01 of 6: the message match checker

## What this does

Takes the ad apart into the separate things it promises, then goes looking for
each one in the page copy you pasted. Every promise comes back with the page
line that answers it, quoted, or with nothing beside it and the status that
says so.

Out comes one file, `message-match.md`.

**The line only this unit produces:** every promise claim in the ad, with the
page line that answers it quoted verbatim beside it, classed ANSWERED, PARTIAL
or UNANSWERED.

The check is one-directional. It reads the ad's promises and looks for them on
the page. It does not judge the page's own copy, does not rank the promises by
importance, and does not say whether the ad is good. A buyer arrives carrying
the sentence that made them click, and this unit finds out whether the page
says that sentence back.

## Required input

1. **The ad's primary text and headline**, copied from the Primary Text and
   Headline fields on the ad in Ads Manager, or the Headlines and Descriptions
   in Google Ads. One ad per run.
2. **The page copy**, from the top of the page down to the first buy button,
   typed or pasted in order. Include button labels, badges, the price, the
   small print under the price, and anything in a bar across the top of the
   page. Order matters, so paste it as it reads.
3. **One line saying where your paste stops.** For example: "stops at the Add
   to Cart button", or "the whole page down to the footer".

If you cannot supply line 3, the run still happens and every UNANSWERED row
prints `[NEEDS: where your paste stops]` beside it, because the difference
between "the page does not say this" and "you did not paste the part that says
this" is the entire value of the check.

No analytics figure is needed anywhere in this unit.

## What it refuses

**Refusal 1, answered by text you did not paste.** The moment the run is
tempted to credit a page section from memory, it prints this and stops
crediting it:

```
CANNOT COUNT THIS AS ANSWERED
promise: "<the promise claim>"
No line you pasted says this.
[NEEDS: the section of the page that says this]
Status stays UNANSWERED until that text is pasted. A section you remember
writing is not a section this check can read.
```

**Refusal 2, nothing to check.** If the ad carries no promise claim, the run
stops here and no share is printed:

```
NO PROMISE CLAIMS IN THE AD
Promise claims found: 0
Lines read in the ad: <n>

This ad says things about how it feels to own the product and never says a
thing a buyer could arrive and check. There is no match to test, because
nothing was promised.

What the ad is made of: <n> mood lines, <n> questions, <n> calls to action,
<n> lines that are the brand name on its own. Each one is listed below,
unclassed.

- "<line>"   mood line | question | call to action | brand name on its own
- "<line>"   mood line | question | call to action | brand name on its own
(one row per line read, in the ad's own order, primary text first and then the
headline. The four counts above add to "Lines read in the ad")
```

**What one line is, for every tally in this unit.** One line is one sentence.
A paragraph carrying two sentences is two lines, and a sentence standing alone
as its own paragraph is one line. The headline is one line. Count sentences and
not paragraphs, so the number does not move with how the ad happened to be laid
out in the composer. A line that is a brand name with no verb is still one line.

**Refusal 3, no new page copy.** This unit never writes the missing section.
It names the gap and stops:

```
This unit does not write page copy. It names what the page does not answer.
```

## Method

**Step 1, split the ad into promise claims.** One claim is one thing a buyer
could arrive on the page and check as true or false. A sentence carrying two
checkable things becomes two claims. Print the split with the source sentence
quoted above it, so the count can be audited:

```
from: "Free delivery over $50 and a 60 night trial."
  C1  free delivery over $50
  C2  60 night trial
```

What counts as a promise claim, the closed list:

| Form | Example shape |
|---|---|
| a stated fact about the product | what it is made of, what is in the box |
| a number | a price, a weight, a count, a percentage |
| a term | delivery, returns, guarantee, shipping threshold, subscription |
| a named outcome for the buyer | what it does for them |
| a named audience | who it is for |
| a comparison | against another product, another category, another price |
| a time | how long delivery takes, how long results take, how long an offer runs |

What is not a promise claim, and is listed but never classed: mood lines with
nothing checkable in them, questions, calls to action, the brand name on its
own.

**The split test, run before anything is classed.** Two facts in one sentence
are two claims when the page could answer one of them and not the other. Apply
it mechanically: write each candidate fact out as its own short sentence, then
ask whether a single pasted page line confirming the first necessarily confirms
the second. Where it does not, they are two claims and each carries its own
status. Grammar does not decide this. An `and`, a comma, a relative clause and a
subordinate clause all split the same way.

"Made in a mill in Yorkshire that has been running since 1890" becomes "it is
made in a mill in Yorkshire" and "that mill has been running since 1890". A page
line naming Yorkshire does not confirm 1890, so that is two claims, hitting `a
term` and `a time` on the closed list. Run as one claim it would carry one
status, and whichever of the two facts the page left alone would be hidden
inside it.

Never create a claim from a word the ad did not carry. If the split is still
arguable after that test, split it. Two claims each carrying their own status
lose nothing, and the reader can read them back as one. One claim carrying two
facts hides whichever fact the page did not answer, which is the finding this
unit exists to print.

**Step 2, print the population before anything is counted.**

```
Population for every count in this file: every promise claim in the ad you
pasted, counted once, after the split printed in Step 1. Claims: <n>.
```

If the same claim appears twice in the ad, it is counted once and both source
sentences are printed under it.

**Step 3, find each claim on the page.** Walk the pasted page copy in order and
quote the first line that addresses the claim. Quote it verbatim. If no pasted
line addresses it, leave the quote slot empty. Never paraphrase a page line into
a better version of itself.

**Step 4, class each claim.** Exactly one status each:

| Status | Definition | What must be printed with it |
|---|---|---|
| `ANSWERED` | A pasted page line states the same thing the claim states | the page line, verbatim |
| `PARTIAL` | A pasted page line addresses the same subject and changes a number, a condition, a scope or a name | the page line, verbatim, and the named difference |
| `UNANSWERED` | No pasted page line addresses it | `[NEEDS: the section of the page that says this]` |

`PARTIAL` is the row that carries the finding most of the time, so it never
gets folded into either of the other two. An ad saying "free delivery" and a
page saying "free delivery over $50" is PARTIAL, and the difference printed is
"the page adds a threshold the ad did not state".

**Step 5, print the counts, then the shares.** The population sentence prints
directly above them, in the same block, every time. It is never one section
away and never assumed from Step 2. Every class gets its own row over that one
stated population, including the classes with nothing in them:

```
Population: every promise claim in the ad you pasted, counted once, after the
Step 1 split. Claims: <N>.

ANSWERED    <n> claims   <n> / <N> = <decimal>
PARTIAL     <n> claims   <n> / <N> = <decimal>
UNANSWERED  <n> claims   <n> / <N> = <decimal>
                         ---------
                         <N> claims

not classed: <n> lines, listed in full under "Not classed" above. They are
outside the population by definition, because a mood line, a question, a call to
action and a brand name on its own promise nothing a buyer could arrive and
check. They are printed so the ad can be reconciled line by line, and they are
never added into <N>.
```

The count is the figure to read. The share is printed beside it and is not the
finding, because the denominator is set by how finely Step 1 split the ad and
not by anything the reader's account did. Two runs that split one sentence
differently print different shares from the same ad and the same page. The
counts move too, but a count carries its own denominator on its face and a
percentage does not.

There is no single match rate in this file and no score. Three counts and three
shares over one population, and the three counts add to N. Print the raw
division before any rounding.

The denominator is set by the Step 1 split, which is printed in full above it.
Print this line under the shares, always:

```
The denominator is the split printed in Step 1. If you would have split a
sentence differently, recount on your split; these shares move with it.
```

Never say what a good share is. There is no benchmark here and inventing one
would be the same fabrication the unit exists to catch.

**Step 6, name the first repair.** One claim, chosen by a printed rule, not by
judgement:

```
Fix this one first: the highest UNANSWERED claim in the ad's own reading order.
Reading order, because the input does not carry which promise sells hardest,
and picking on importance would be a guess wearing a ranking.
```

If there is no UNANSWERED claim, print the highest PARTIAL instead and say so.
If there is neither, print `NOTHING TO REPAIR IN WHAT YOU PASTED` and stop.

## Output format

Write one file, `message-match.md`.

```
# Message match: <ad name or "the ad you pasted"> against <page name or "the page you pasted">
Paste boundary: <line 3 of the input> | [NEEDS: where your paste stops]

## The split
<the Step 1 split, source sentence quoted above its claims>

## Population
<the Step 2 line>

## The ledger
### C<n>
claim: <the claim, in the ad's own words where possible>
from:  "<the ad sentence it came out of>"
status: ANSWERED | PARTIAL | UNANSWERED
page line: "<verbatim page line>" | [NEEDS: the section of the page that says this]
difference: <what changed>            (PARTIAL only)

## Not classed
- "<line>"   mood line | question | call to action | brand name on its own

## Counts and shares
<the population sentence, then the three count rows and their shares from
Step 5, then the not-classed line, then the denominator line. The population
sentence prints inside this block and not only in the Population section above>

## Fix this one first
C<n>: <the claim>   because <the printed rule, restated>
```

## Edge cases

**The claim is in the ad's image or video, not in the text.** This unit reads
text. Print `[NEEDS: the words on the ad creative, typed out]` once at the top
and run on what you have. Do not describe the creative.

**A claim is answered by a button label or a badge.** That counts. Quote the
label as the page line. A trust badge saying "60 night trial" answers the trial
claim as well as a paragraph would.

**The page paste is empty.** Print the named branch and stop before Step 5:

```
NO PAGE TEXT PASTED
Every claim in this ad is unchecked, not unanswered. This run is a finding
about the paste, not about the page.
```

**The page answers the claim below your paste boundary.** That is what line 3
of the input is for. The status stays UNANSWERED and the `[NEEDS:]` names the
section. Paste further down and rerun.

**The ad promises something the page contradicts.** That is PARTIAL with the
difference printed, and the difference is the whole row. This unit does not
have a CONTRADICTED class, because a contradiction is a difference large enough
to read for yourself once it is printed side by side.

**Two ads, one page.** One run per ad. Claims from two ads in one population
would produce a share over a denominator no single buyer ever saw.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never quote a page line that is not in the paste, in any form, including a
  tidied version of one that is.
- Never credit a page section from memory, from the brand's other pages, or
  from what a page like this usually says.
- Never invent a claim the ad did not carry, and never split a sentence into a
  claim that uses a word the ad did not use.
- Never print a single match rate. Three shares over one stated population, all
  three printed, including the empty ones.
- Never state a benchmark, a typical share, or what good looks like.
- Never write replacement page copy. Refusal 3 fires instead.
- Never rank the claims by how much money each one is worth. The input does not
  carry that.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.
