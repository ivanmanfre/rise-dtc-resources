# Fixture, one ad and the page behind it

Invented brand. Not a real ad, not a real page, no real store.
Exercises the Step 1 split test and the ANSWERED, PARTIAL and UNANSWERED
branches of Step 4.

---

## Input 1, the ad

**Brand:** Merrow Fields
**Ad name:** MF_wool_duvet_cold_sleeper_v3

**Primary text:**

Cold sleepers, this one is for you.

Our wool duvet is filled with British wool from a single farm, so it holds heat
without the clamminess of a synthetic filling.

Free delivery and a 60 night trial. Send it back if it is wrong for you.

Made in a mill in Yorkshire that has been running since 1890.

**Headline:**

The duvet for people who wake up cold

---

## Input 2, the page copy, top of page down to the first buy button

```
Bar across the top: FREE UK DELIVERY OVER $150

The Merrow Fields Wool Duvet

Single farm British wool, washed and carded in Yorkshire.

$128

Warmth rating: 10.5 tog

Filled with 100% British wool from Hollow Beck Farm. No synthetic filling, no
down, no feather.

Wool moves moisture away from you while you sleep, so you wake up dry.

60 nights to try it at home

[ Add to basket ]
```

---

## Input 3, where the paste stops

Stops at the Add to basket button. There are three more sections below it,
including a page section titled "How it is made" and the reviews.
