# Fixture, an ad that promises nothing checkable

Invented brand. Not a real ad, not a real page, no real store.
Exercises Refusal 2.

---

## Input 1, the ad

**Brand:** Halden Goods
**Ad name:** HG_brand_film_15s_v1

**Primary text:**

Some mornings start slowly.

Ever wondered what the good ones have in common?

Halden Goods. Made for the slow hour.

Shop the collection.

**Headline:**

Halden Goods

---

## Input 2, the page copy, top of page down to the first buy button

```
Halden Goods

Made for the slow hour.

$34

[ Shop now ]
```

---

## Input 3, where the paste stops

Stops at the Shop now button.
