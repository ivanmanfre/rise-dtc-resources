---
name: convert-03-objection-order-writer
description: "Use when a paid landing page has all the right sections in the wrong order, to put them in the order your buyers' own doubts arrive. Takes the customer questions and complaint lines you already have in front of you and returns the page section order with the objection each section retires named beside it, plus the sections nothing you supplied justifies. Triggers on \"what order should my landing page be in\", \"reorder my page sections\", \"what objections should my page answer\", \"my page answers the wrong things\", \"what should go above the reviews\"."
---

# The DTC Growth Team, CONVERT, unit 03 of 6: the objection order writer

## What this does

Takes the questions your buyers actually ask, sorts them into a closed list of
page sections, and puts those sections in the order the doubts arrive in a
buyer's head. Sections that nothing in your input justifies are printed
separately, unplaced, with the one search that would tell you whether they
belong.

Out comes one file, `section-order.md`.

**The line only this unit produces:** the page section order, with the
objection each section retires named beside it in the customer's own words.

The order is not a template. Nine sections exist in this unit's list and a run
that places four places four. The page you end up with is the length your own
customer questions support.

## Required input

1. **Support inbox subject lines**, copied from your inbox. Subject lines are
   enough. Whatever the last stretch holds.
2. **Pre-purchase questions**, from DMs, comments, live chat or email. The
   question as they wrote it.
3. **Complaint lines from your own reviews.** The sentence, not the star
   rating.
4. **Which page these sections are for**, in one line. This unit runs on one
   paid landing page at a time.

Paste what you have. Ten lines is a run. Two hundred is a run. The unit never
asks for a number, a rate or an export, and it never asks you to categorise
anything before you paste it.

If you have nothing written down anywhere, this unit has nothing to work from
and says so rather than proceeding on what customers usually ask.

## What it refuses

**Refusal 1, no invented objections.** The unit never places a section because
pages like this usually have one:

```
NOT AN OBJECTION YOU SUPPLIED
section: <section name>
Nothing you pasted raises this. It is printed in UNPLACED below, with the one
search that would tell you whether it belongs on your page.
```

**Refusal 2, no section copy.** This unit orders and names. It does not write
the section:

```
This unit prints the order and the objection each section retires. It does not
write the words that go in the section.
```

**Refusal 3, nothing to order.** If no supplied line carries a pre-purchase
doubt, the run stops and no order is printed:

```
NOTHING TO ORDER
Lines you pasted: <n>
Lines carrying a pre-purchase doubt: 0
Lines that are service requests, order status or post-purchase admin: <n>

Everything you pasted is about an order that already exists. None of it is a
reason somebody did not place one, so there is no doubt sequence in it to put a
page in.

Where the doubts would be, if you want to rerun: the questions people ask
before they buy. Chat, comments and pre-sale email, not the support queue.
```

## Method

**Step 1, split every line that carries more than one thing.** One customer line
often carries two. Split before anything is classed, and print the split with the
source line quoted:

```
from: "Is this safe on a wool rug and how long is delivery"
  O1  safe on a wool rug
  O2  how long is delivery
```

**A line splits on two doubts, and it also splits on a doubt sitting next to
something that is not one.** A review line is very often praise and a complaint
in the same sentence, and one status cannot stand for both. Class each half on
its own, so the praise reaches `UNMAPPABLE` and the doubt reaches its section:

```
from: "Lovely duvet, the storage bag it comes in is flimsy"
  O7  lovely duvet                                   (not a doubt)
  O8  the storage bag it comes in is flimsy          (a doubt)
```

Run as one item, that line lands in whichever section the doubt half points at
and the praise half is swallowed. Run split, both halves are printed and the
counts still add to the population. The same applies to a doubt sitting beside
an order-status request, a reason, or a piece of context. A reason is not a
second doubt: "Can I send it back if it is too warm, I run hot at night" carries
one doubt and one reason for it, and does not split.

**The vagueness test, run on every item after the split.** An item is too vague
to name the doubt when you cannot write the doubt as a sentence starting "I do
not know" using only words the line itself carries. "Does this work" fails the
test, because the line never says what working would mean. "Question about tog
rating" fails it too, because it names a subject and never says what about that
subject the customer wants to know: "I do not know" plus "tog rating" is not a
doubt. "Is the wool washed" passes, because "I do not know whether the wool is
washed" uses only its own words. A subject label is not a doubt, however
classifiable the subject looks.

Never invent a doubt from a word the line did not carry. An item that fails the
vagueness test is kept as one item with `[NEEDS: the sentence the customer
actually wrote]` printed beside it, and is left unplaced. It keeps its own row
in the counts and is never guessed into a section on the strength of its
subject.

**Step 2, state the population once, in words.**

```
Population for every count in this file: the objection items you pasted,
counted once each, after the split printed in Step 1. Items: <n>.
```

**Step 3, class each item into one of exactly nine sections, or out.** The
closed list, in the order doubts arrive:

| # | Section | The doubt it retires |
|---|---|---|
| 1 | `WHAT IT IS` | I do not understand what this thing is |
| 2 | `WHO IT IS FOR` | I am not sure it is meant for someone like me |
| 3 | `HOW IT WORKS` | I do not believe it does what it says |
| 4 | `FIT AND SPECIFICS` | I do not know if it fits my case: size, variant, material, compatibility |
| 5 | `PROOF FROM OTHER BUYERS` | I do not know if anyone like me has bought it |
| 6 | `PRICE AND WHAT YOU GET` | I do not know what I get for the money |
| 7 | `DELIVERY` | I do not know when it arrives or what it costs to get here |
| 8 | `RETURNS AND GUARANTEE` | I do not know what happens if it is wrong |
| 9 | `AFTER YOU BUY` | I do not know what owning it involves: care, refills, cancelling, support |

Anything that is not a pre-purchase doubt goes in one printed class:

`UNMAPPABLE`, with the reason named. Order status, a request to change an
address, a complaint about a specific parcel, a wholesale enquiry, praise with
no doubt in it, spam. These are never folded into a section and never dropped.

A pre-purchase doubt that none of the nine sections holds goes in its own
printed class, `NO SECTION ON THIS LIST HOLDS THIS`, with the item quoted. It is
a doubt, so it is not `UNMAPPABLE`, and the list is closed, so it is not a tenth
section. It gets its own heading in the output and its own row in the counts.

A review complaint maps to the doubt it would have raised before purchase.
"Smaller than the photo suggested" is `FIT AND SPECIFICS`. "Took three weeks to
arrive" is `DELIVERY`. Print the mapping line so the reader can see the move.

**Step 4, place the sections.** A section is placed if at least one item landed
in it. Placed sections print in the numbered order above, which is the order the
doubts arrive, not the order of how many items landed in each.

A section with nothing in it is not placed. It prints in `UNPLACED` with
Refusal 1's text and one search term the reader can run against their own inbox
to find out whether it belongs:

```
UNPLACED: <section>
nothing you supplied raises this
search your inbox for: "<the words a customer would use>"
```

**Step 5, print the counts, and say what they are not.**

```
Population: the objection items you pasted, counted once each, after the Step 1
split. Items: <N>.

WHAT IT IS                          <n> items
WHO IT IS FOR                       <n> items
HOW IT WORKS                        <n> items
FIT AND SPECIFICS                   <n> items
PROOF FROM OTHER BUYERS             <n> items
PRICE AND WHAT YOU GET              <n> items
DELIVERY                            <n> items
RETURNS AND GUARANTEE               <n> items
AFTER YOU BUY                       <n> items
UNMAPPABLE                          <n> items
NO SECTION ON THIS LIST HOLDS THIS  <n> items
[NEEDS: the sentence]               <n> items
                                    ---------
                                    <N> items
```

Twelve rows, always. All nine sections whether or not anything landed in them,
then the three classes that sit outside the nine. Every class prints, including
the ones at zero, and the column adds to the population. A run that has to
invent a row to make the column add up has found a defect in this unit, and the
honest move is to name it rather than to drop the item. Then print this line,
always:

```
These are counts, not shares. There is no percentage in this file, because the
lines you happened to have in front of you are not a sample of your buyers.
```

**Step 6, name the section that gets the most words.** The placed section
holding the most items. Ties print together with one line saying the input does
not separate them. This is the only ranking in the file and it comes from
counting your customers' lines, not from what usually matters.

**Step 7, name what moves.** If the reader supplied their current section order
as an optional extra line, print the move list: which section goes above which,
by name. If they did not, print
`[NEEDS: your current section order, top to bottom]` and stop after Step 6.

## Output format

Write one file, `section-order.md`.

```
# Section order for <the page named in input 4>

## The split
<the Step 1 split, source line quoted above its items>

## Population
<the Step 2 line>

## The order
### 1. <SECTION>
retires: <the doubt, in this unit's words>
in your buyers' words:
  - "<customer line, verbatim>"
  - "<customer line, verbatim>"
items: <n>

### 2. <SECTION>
...

## Unplaced
UNPLACED: <section>
nothing you supplied raises this
search your inbox for: "<words>"

## Unmappable
- "<line>"   <reason: order status | address change | parcel complaint | wholesale | not a doubt | spam>

## No section on this list holds this
- "<item, quoted>"   why none of the nine holds it, in one line
(or "None. Every doubt you supplied landed in one of the nine.")

## Counts
<the Step 5 block: the population sentence, then all twelve rows, then the
total, then the closing line. The population sentence prints inside this block
and not only in the Population section above>

## Gets the most words
<SECTION>, holding <n> items

## What moves
<the Step 7 move list>   | [NEEDS: your current section order, top to bottom]
```

## Edge cases

**Every item lands in one section.** Place that one section and print the other
eight as unplaced. A page with one section in it is a finding, and the finding
is that everything your buyers ask about is one subject. Do not spread the
items to make the page look complete.

**A customer line contradicts another customer line.** Both are placed in the
same section and both are printed. The section has to retire both doubts, and
the reader needs to see that it is being asked to.

**The line is a compliment.** Not a doubt. `UNMAPPABLE`, reason "not a doubt".
Praise for a feature does not license a section, though it often tells you what
to quote inside one, which is a different unit's job. A line that is praise AND
a doubt is not this case. It is split in Step 1 and each half is classed on its
own.

**A doubt that no section on the list holds.** Print it under the
`## No section on this list holds this` heading with the item quoted, and count
it in its own row in Step 5. Never stretch a section's definition to absorb it,
and never add a tenth section. The list is closed so that two runs of this unit
on two different weeks stay comparable. "What is the difference between this and
the one you sold last year" is the shape: it is a real pre-purchase doubt, so it
is not `UNMAPPABLE`, and no section on the list is about the brand's own
previous product.

**Half your items are `FIT AND SPECIFICS` and you sell one size.** Place the
section anyway. The items decide, and the reader knows something about their
own catalogue that the input does not carry.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never place a section that no supplied item landed in. Refusal 1 fires.
- Never invent a customer line, tidy one into better grammar, or merge two into
  a representative one. Verbatim or not at all.
- Never print a percentage anywhere in this file.
- Never reorder the nine sections themselves. The arrival order is fixed so
  that the only thing your input decides is which of them get placed.
- Never write the copy that goes inside a section. Refusal 2 fires.
- Never state what a good page looks like, what a typical store's order is, or
  what converts.
- Never fold `UNMAPPABLE` items into a section to make the counts tidier.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.
