# Fixture, a paste that carries no pre-purchase doubt

Invented brand and invented customers. No real people, no real inbox.
Exercises Refusal 3.

---

**Page these sections are for:** the paid landing page for the Pellwick Ceramic
Mug.

---

## Support inbox subject lines

- Where is my order 10428
- Wrong address on my order
- Order 10391 arrived chipped
- Please cancel order 10455
- Refund not showing on my card yet
- Can you resend the invoice for order 10302
- Duplicate charge on my statement

## Pre-purchase questions, from DMs and chat

- none saved

## Complaint lines from our own reviews

- none pulled yet
