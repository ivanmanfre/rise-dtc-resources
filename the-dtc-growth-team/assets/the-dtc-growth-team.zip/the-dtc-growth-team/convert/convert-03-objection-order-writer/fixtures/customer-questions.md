# Fixture, the customer lines a founder has in front of them

Invented brand and invented customers. No real people, no real inbox.
Exercises the Step 1 split, the vagueness test, the review-complaint mapping,
Refusal 1, UNMAPPABLE, and NO SECTION ON THIS LIST HOLDS THIS.

---

**Page these sections are for:** the paid landing page for the Ashlin and Roe
Wool Duvet.

---

## Support inbox subject lines

- Is the wool washed
- Does this work with a duvet cover I already own
- Question about tog rating
- Where is my order, placed Tuesday
- Change delivery address please
- Is this too warm for summer
- Wholesale enquiry from a hotel group

## Pre-purchase questions, from DMs and chat

- Is this safe for someone with a wool allergy and how long is delivery
- Does it fit a king size or is it only doubles
- Does this work
- I have two dogs, will it survive that
- What is the difference between this and the one you sold last year
- Can I send it back if it is too warm, I run hot at night

## Complaint lines from our own reviews

- Smaller than the photo suggested, ours hangs short on a king bed
- Arrived after three weeks with no update in between
- Lovely duvet, the storage bag it comes in is flimsy
- I did not realise it needs specialist cleaning, that is on me but say it
  louder
- Bought it for my mother and she loves it
