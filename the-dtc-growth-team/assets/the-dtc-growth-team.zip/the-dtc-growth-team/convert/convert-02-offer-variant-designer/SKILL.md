---
name: convert-02-offer-variant-designer
description: "Use when the page is fine and the offer on it has never been changed, to build four versions of that offer that each move one term and to state what each one has to clear to be worth running. Takes your current offer exactly as it appears on the page plus the cost figures behind one order, and returns four one-term variants with the break-even condition for each printed as arithmetic you can redo. Triggers on \"test my offer\", \"should I change my price\", \"free shipping threshold test\", \"what offer should I try next\", \"is this discount worth it\"."
---

# The DTC Growth Team, CONVERT, unit 02 of 6: the offer variant designer

## What this does

Reads the offer as the page states it, works out what one order at that offer
leaves you, and then builds four versions that each move exactly one term. Each
version comes with the condition it has to clear to be worth running, printed
as the division that produced it.

Out comes one file, `offer-variants.md`.

**The line only this unit produces:** four offer variants, each changing one
named term, with the break-even condition each must clear to beat the offer you
are running now.

The break-even condition is the whole point. Any change to an offer that gives
something away has to be paid for by more orders, and the number of extra orders
is knowable before you run anything. This unit prints that number. It does not
predict whether you will get it.

## Required input

**From the page, exactly as a buyer reads it:**

1. **Price as shown.**
2. **The current discount as shown**, if any. The words and the percentage or
   amount, for example "10% off your first order".
3. **What is included.** Everything in the box, as the page lists it.
4. **The guarantee**, in the page's own words, including its length.
5. **The free shipping threshold**, and **what a buyer pays for shipping below
   it**.

**From the Shopify admin, three numbers you type in:**

6. **Cost per item**, from the Cost per item field on the product's page in the
   Shopify admin.
7. **What you pay to ship one order.** The figure you would say if a supplier
   asked you.
8. **Cost per item for anything you would add**, if you want the "what is
   included" variant priced.
9. Optional: **the size of the move you want to test**, per term. "Price to
   $141", "threshold to zero", "guarantee to 60 nights". Where you do not name
   one, the unit applies the printed convention in Step 4.

Any of 6, 7 or 8 missing does not stop the run. It stops the arithmetic on the
variants that need it, and the unit prints which term is missing.

No CSV, no export, no connected account. Eight figures and one optional
sentence, typed.

## What it refuses

**Refusal 1, a break-even that cannot be stated.** Fired per variant, never for
the whole file:

```
BREAK-EVEN NOT STATEABLE FOR THIS VARIANT
variant: <the term it changes>
missing term: <the one thing>
[NEEDS: <the exact figure to supply>]
The variant is printed above with the term it changes. No number is printed for
it, because the number would be invented.
```

**Refusal 2, no contribution to work with.** If one order at the offer as
pasted leaves nothing or less than nothing, the unit stops before it builds
anything:

```
STOP: NO CONTRIBUTION TO WORK WITH
one order at the offer as pasted leaves: <the figure>
<the subtraction, printed in full>

Every break-even in this unit is a share of what one order leaves you. At this
figure there is nothing to take a share of, and a variant that gives more away
has no arithmetic behind it.

What this run says instead: the offer as pasted does not pay for one order
before any variant is applied. That is the finding.
```

**Refusal 3, no forecast.** This unit never says a variant will win:

```
This unit states the condition each variant has to clear. It does not say
whether your buyers will clear it, and it has no input that would let it.
```

## Method

**Step 1, split the pasted offer into terms.** A single page line often carries
two terms. Print the split before anything is priced:

```
from: "Free shipping over $150 and 10% off your first order"
  T1  free shipping threshold: $150
  T2  current discount: 10% off first order
```

The closed list of terms this unit can move, and only these:

| Term | What moving it means |
|---|---|
| `PRICE` | the number on the page changes |
| `DISCOUNT` | the discount is added, removed or resized |
| `THRESHOLD` | the free shipping threshold moves, including to zero |
| `INCLUDED` | one named thing is added to or removed from the box |
| `GUARANTEE` | the guarantee's length or condition changes |

**Step 2, work out what one order leaves you now.** Print the population above
it, then the subtraction:

```
Population for every figure in this file: one order at the offer exactly as you
pasted it. Not an average order, not a month. One order.

price as shown                         <p>
less the discount as shown             <d>
= what the buyer pays                  <p - d>
plus shipping the buyer pays           <s_in>     (zero if the order clears the threshold)
less cost per item                     <c>
less what you pay to ship one order    <s_out>
= what one order leaves you            <M0>
```

If `M0` is zero or below, Refusal 2 fires here and the run stops.
If `c` or `s_out` was never supplied, print `M0` as
`[NEEDS: cost per item]` or `[NEEDS: what you pay to ship one order]` and every
variant below carries Refusal 1.

**Step 3, check the threshold on every variant that moves the price.** A price
change can push the order across the free shipping threshold, which silently
removes the shipping the buyer was paying. Print the check per variant:

```
threshold check: new buyer price <x> against threshold <t> -> below, buyer
still pays <s_in> | at or above, buyer pays nothing and <s_in> leaves the row
```

Skipping this check is how a price rise gets credited with money it gave back.

**Step 4, build four variants, each moving exactly one term.** Take the four
terms from the list in Step 1 that your pasted offer actually carries, in the
order PRICE, THRESHOLD, INCLUDED, GUARANTEE, DISCOUNT, and stop at four.

If the pasted offer carries fewer than four of those terms, build fewer and
print the count honestly:

```
VARIANTS BUILT: <n> of 4
terms your pasted offer does not carry: <named>
[NEEDS: <the term>, if you want a variant that moves it]
```

Never pad to four by inventing a term the page does not state. Never move two
terms in one variant. If a change you want needs two terms to move together,
print it as two variants and say they cannot be read separately if they run
together.

If the pasted offer carries a fifth term that no variant moves, print it:

```
terms your offer carries that no variant moves: <named>
```

**How far each term moves.** Where input 9 named the size of the move, use it.
Where it did not, apply this convention and print the word `convention` beside
the variant:

| Term | The convention, where you did not name a move |
|---|---|
| `PRICE` | up by 10% of the price as shown, rounded to the nearest whole currency unit |
| `DISCOUNT` | removed entirely |
| `THRESHOLD` | moved to zero, so shipping is free on everything |
| `INCLUDED` | the one item you named in input 8 is added |
| `GUARANTEE` | its stated length doubles |

These are conventions so that the arithmetic has something to run on. They are
not recommendations, they are printed as conventions on every variant that uses
one, and naming your own figure in input 9 replaces them.

**Step 5, price each variant.** Repeat the Step 2 subtraction with the one
changed term and print it in full, giving `M1` for that variant.

**Step 6, print the two divisions per variant.** Both over the same stated
population, one order at the offer as pasted:

```
what one order leaves you now              M0 = <figure>
what one order leaves you on this variant  M1 = <figure>
change per order                           M1 - M0 = <figure>

per-order give-up or gain
  (M1 - M0) / M0 = <raw decimal> = <percent> of what an order leaves you today

break-even in orders
  100 x M0 / M1 = <raw decimal>
  for every 100 orders at the offer you run now, this variant has to bring at
  least <the raw decimal rounded UP to a whole order> orders to leave you the
  same money
```

Two named branches, both printed in words when they fire:

- `M0` zero or below: Refusal 2 already stopped the run in Step 2, so the
  first division never runs on a zero denominator.
- `M1` zero or below: print
  `THIS VARIANT NEVER BREAKS EVEN ON VOLUME` and no orders figure. A variant
  where an order leaves you nothing cannot be paid for by selling more of them.
  The per-order give-up line still prints, because its denominator is `M0`.

Round the break-even orders UP to the next whole order, always. Print the raw
decimal beside it. Rounding down here would print a break-even you have not
reached.

**Step 7, name what each variant costs you if nobody responds.** One line per
variant, the arithmetic already done:

```
if order count does not move: <M1 - M0> per order
```

This is the honest downside, and it is the only forecast-shaped line in the
file, because it assumes nothing changes.

**Step 8, name the one to run first.** By a printed rule, not by taste:

```
Run first: the variant with the lowest break-even in orders among those whose
break-even could be stated. Lowest, because it is the one your buyers have to
move least for it to be worth having run.
```

If two tie, print both and say the input does not separate them. If no variant
had a stateable break-even, print `NOTHING TO RUN FIRST` and the list of
missing terms.

## Output format

Write one file, `offer-variants.md`.

```
# Offer variants: <product name as the page states it>

## The offer as pasted
<the Step 1 split, with the source line quoted above its terms>

## What one order leaves you
<the Step 2 subtraction, in full>

## The variants
### V<n>: moves <TERM>
what changes: <one sentence, in the page's own vocabulary>
how far it moves: <input 9, as you named it> | <the figure> convention
the new offer line, as it would read on the page: "<the line>"
threshold check: <the Step 3 line>   (only on variants that move PRICE or THRESHOLD)
<the Step 5 subtraction, in full>
<the Step 6 divisions>
if order count does not move: <figure> per order
                          | BREAK-EVEN NOT STATEABLE FOR THIS VARIANT + [NEEDS: x]

## Variants built
VARIANTS BUILT: <n> of 4
<the missing terms, named>

## Run first
V<n>, because <the Step 8 rule, restated>
```

## Worked case

This runs on an invented offer that is **not** the fixture. Different brand,
different figures, deliberately, so the fixture stays a clean input to run
yourself.

Offer as pasted: price $60, no discount, free shipping threshold $75, buyer
pays $5 shipping below it, cost per item $22, you pay $9 to ship one order.
Input 9 not supplied, so both variants below move by convention.

```
price as shown                         60.00
less the discount as shown              0.00
= what the buyer pays                  60.00
plus shipping the buyer pays            5.00     (60.00 is below the 75.00 threshold)
less cost per item                     22.00
less what you pay to ship one order     9.00
= what one order leaves you            34.00
```

V1 moves PRICE, 60.00 to 66.00, convention, up by 10% of the price as shown
rounded to the nearest whole currency unit.
Threshold check: new buyer price 66.00 against threshold 75.00, below, buyer
still pays 5.00.

```
66.00 + 5.00 - 22.00 - 9.00 = 40.00 = M1
change per order 40.00 - 34.00 = 6.00
per-order gain   6.00 / 34.00 = 0.176471 = 17.6% of what an order leaves you today
break-even       100 x 34.00 / 40.00 = 85.0000
for every 100 orders at the offer you run now, this variant has to bring at
least 85 orders to leave you the same money
if order count does not move: 6.00 per order
```

V2 moves THRESHOLD, 75.00 to 0.00, convention, so the buyer stops paying the
5.00.

```
60.00 + 0.00 - 22.00 - 9.00 = 29.00 = M1
change per order 29.00 - 34.00 = -5.00
per-order give-up -5.00 / 34.00 = -0.147059 = -14.7% of what an order leaves you today
break-even       100 x 34.00 / 29.00 = 117.2414
for every 100 orders at the offer you run now, this variant has to bring at
least 118 orders to leave you the same money
if order count does not move: -5.00 per order
```

Run first, of these two: V1, break-even 85 against V2's 118.

## Edge cases

**The page shows a compare-at price with a line through it.** The price as
shown is the one a buyer would pay. Print the struck price as context in the
offer block and never use it in the subtraction.

**A subscription price and a one-time price on the same page.** Two offers, two
runs. One population is one order at one offer, and mixing the two would produce
a break-even no buyer could ever clear.

**The guarantee variant.** Its break-even needs what a return costs you and how
often returns happen, and neither is in this unit's input. Refusal 1 fires with
`[NEEDS: your refund rate on this product over a stated window, and what a
returned unit costs you]`. The variant still prints, with the term it moves and
no number. A guarantee variant with an invented refund rate is the exact
fabrication this unit refuses.

**The discount is a code, not on-page.** If a buyer cannot see it on the page
before checkout, it is not a term of the offer as pasted. Print it in the offer
block, marked `NOT ON THE PAGE`, and leave it out of the subtraction.

**Cost per item is blank in the Shopify admin.** Common, and it stops the whole
file, because every figure here is a share of what an order leaves you. Print
`[NEEDS: cost per item]` and the one place to fill it in. Do not substitute a
category average.

**You want a bundle variant.** A bundle changes PRICE and INCLUDED together.
Print it as two variants and one line saying they cannot be read separately if
you run them together.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never estimate cost per item, a shipping cost, a refund rate or a return
  cost. Every one of them has a `[NEEDS:]` and the run continues without it.
- Never move two terms in one variant.
- Never pad to four variants by inventing a term the pasted offer does not
  carry. Print the honest count.
- Never divide by a figure that can be zero without the named branch printed
  above it. `M0` at zero or below stops the run. `M1` at zero or below prints
  the named branch instead of an orders figure.
- Never round a break-even in orders down.
- Never predict a response rate, a conversion lift, or which variant your
  buyers will prefer.
- Never state an industry margin, a typical discount, or what a normal
  threshold is.
- Never write a new guarantee, a returns policy or a shipping policy. The unit
  moves a term the page already carries and states what moving it costs.
- Never write the offer line as marketing copy or claim it is in the brand's
  voice. It states the term in plain words and stops.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.
