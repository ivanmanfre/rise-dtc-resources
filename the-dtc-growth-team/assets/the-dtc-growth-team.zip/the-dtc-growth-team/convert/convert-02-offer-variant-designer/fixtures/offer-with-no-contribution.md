# Fixture, an offer where one order leaves nothing

Invented brand. Not a real store, not a real product, no real figures.
Designed to exercise: the zero branch, where one order at the offer as pasted
leaves nothing to take a share of.

---

## From the page

**Product:** Pellwick Ceramic Mug

**Price as shown:** $34

**Discount as shown:** 25% off, site-wide sale banner at the top of the page

**What is included, as the page lists it:**
- the mug

**Guarantee, in the page's words:**
"Returns accepted within 14 days, unused."

**Shipping line, as it appears on the page:**
"Free shipping on everything"

**What a buyer pays for shipping below the threshold:** nothing, there is no
threshold

---

## From the Shopify admin

**Cost per item:** $19

**What you pay to ship one order:** $9

**Cost per item for anything you would add:** not supplied
