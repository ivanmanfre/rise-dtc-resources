# Fixture, an offer as it appears on the page

Invented brand. Not a real store, not a real product, no real figures.
Designed to exercise: one page line carrying two terms, a variant whose
break-even cannot be stated from the input, and a price change that has to be
checked against the free shipping threshold.

---

## From the page

**Product:** Ashlin and Roe Wool Duvet

**Price as shown:** $128

**Discount as shown:** 10% off your first order, applied in the cart

**What is included, as the page lists it:**
- the duvet
- a cotton storage bag

**Guarantee, in the page's words:**
"30 nights to try it at home. If it is wrong for you, send it back."

**Shipping line, as it appears on the page:**
"Free shipping over $150 and 10% off your first order"

**What a buyer pays for shipping below the threshold:** $7.95

---

## From the Shopify admin

**Cost per item:** $47

**What you pay to ship one order:** $12

**Cost per item for anything you would add:** a second cotton storage bag costs
$6
