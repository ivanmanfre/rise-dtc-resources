---
name: convert-04-landing-test-sizer
description: "Use before you set up a page test, to find out how many weeks it would take to show a change of the size you care about at the traffic you actually have. Takes weekly sessions and weekly orders for one page from the same 7 days plus the size of change you care about, and returns the weeks the test needs with every step of the arithmetic printed, or the named branch that says this page cannot be tested at this traffic. Triggers on \"how long should I run this test\", \"do I have enough traffic to A/B test\", \"is this test worth running\", \"how many sessions do I need\", \"can I test my landing page\"."
---

# The DTC Growth Team, CONVERT, unit 04 of 6: the landing test sizer

## What this does

Takes one page's traffic and orders for one week, and the size of change you
would want to act on, and prints how long a two-version test has to run before a
change that size would show. Every step is one line of arithmetic you can redo
on paper.

Out comes one file, `test-size.md`.

**The line only this unit produces:** the number of weeks a change of the size
you named would take to show at your own traffic, and the printed branch for a
page that cannot be tested at that traffic.

At the traffic a single page usually gets, the arithmetic below will often say
the page cannot be tested this quarter. That is the commonest honest answer
here and it is printed as a named branch, with what to do instead, rather than
softened into a smaller number.

## Required input

1. **Weekly sessions on the page**, from the Shopify analytics screen, with the
   date range shown on the screen typed beside it.
2. **Weekly orders from that page**, from the same screen and the same 7 days,
   with its date range typed beside it.
3. **The size of change you care about**, in one of exactly two forms:
   - a relative lift: "20% more orders per session"
   - two rates: "from 2.0% to 2.4%"
4. Optional: **how many versions you would run**, including the current page.
   Two if you do not say.

The two date ranges are required separately even when they look the same. One
figure read off a 7-day screen and one read off a 30-day screen is the single
commonest way this arithmetic goes wrong, and the two ranges printed side by
side is what catches it.

No export, no analytics account connected to anything, no pixel. Two numbers,
two date ranges, one sentence.

## What it refuses

**Refusal 1, no orders to size from.**

```
CANNOT SIZE THIS TEST
weekly sessions: <n>     weekly orders: 0

A test compares two order rates. At zero orders in the window you pasted there
is no rate to compare and no arithmetic that would produce an honest number of
weeks.

The two things to do instead:
1. Paste a longer window. Read the same two figures off a 30-day or 90-day
   screen and rerun. Orders per session over a longer window is still a rate.
2. If the longer window is also zero, this page has never sold. That is not a
   testing question, it is a first-order question, and a test between two
   versions of a page that has never sold cannot answer it.
```

**Refusal 2, two different windows.**

```
WINDOWS DO NOT MATCH
sessions window: <the range you typed>
orders window:   <the range you typed>

These two figures describe different stretches of time, so orders divided by
sessions would not be a rate that anything experienced. Read both off the same
date range and rerun.
```

**Refusal 3, no forecast and no verdict.**

```
This unit sizes the test. It does not say the change will win, it does not say
the change is a good idea, and when the test finishes it does not read the
result. The weeks figure is a plan, and a plan is all it is.
```

## Method

**Step 1, split the input and check the windows.** One pasted line often
carries both figures, for example "4,800 sessions and 96 orders last week".
Split it and print each figure with its own window before anything is divided:

```
sessions: <n>   window: <the range you typed>
orders:   <n>   window: <the range you typed>
```

If either window is missing, print `[NEEDS: the date range shown on the screen
beside this figure]` and stop. If the two ranges differ by a single day,
Refusal 2 fires.

**Step 2, state the population, then take the baseline rate.**

```
Population for every figure in this file: the one 7-day window you pasted, on
this page only. Not the store, not all traffic, not a month.

baseline rate = orders / sessions
              = <O> / <S>
              = <raw decimal to 6 places>
              = <percent to 2 places>
```

Two named branches, checked before the division runs:

- **sessions = 0**: print `NO TRAFFIC ON THIS PAGE`, no division, and one line:
  a page with no sessions in the window you pasted has nothing to split between
  two versions. Stop.
- **orders = 0**: Refusal 1 fires. Stop.

**Step 3, turn the size of change you named into a target rate.** One of two
conversions, printed:

```
if you named a relative lift of <L> percent:
  target rate = baseline x (1 + <L> / 100) = <decimal> = <percent>

if you named two rates:
  target rate = the second rate you named = <decimal> = <percent>
```

If what you named is neither of those two forms, print
`[NEEDS: the size of change, as either a percentage lift or two conversion
rates]` and stop. A change described as "meaningful", "a decent bump" or "worth
doing" cannot be sized, and picking a number on your behalf would make the
weeks figure this unit's invention rather than your decision.

Then the difference the test has to show:

```
difference = target rate - baseline rate
           = <decimal> - <decimal>
           = <decimal to 6 places>
```

**Step 4, the rule, printed in full.** This unit uses one rule and names it:

```
sessions needed per version = 16 x baseline x (1 - baseline) / (difference x difference)
```

That is the whole rule. Sixteen, times the baseline rate, times one minus the
baseline rate, divided by the difference squared. It is arithmetic you can redo
on a phone.

What the sixteen carries, in plain words, printed with the rule every time:

```
The 16 in this rule is what makes it a planning figure rather than a promise.
It builds in two properties:
  if a change the size you named is really there, a test this long shows it
  about 8 times in 10
  if nothing is really there, about 1 test in 20 still comes back looking like
  something
Both are properties of the rule. Neither is a measurement of your store.
```

Then run it:

```
sessions needed per version = 16 x <baseline> x (1 - <baseline>) / (<difference> x <difference>)
                            = <numerator> / <denominator>
                            = <raw decimal>
                            = <rounded UP to a whole session>

versions, including the current page: <v>
total sessions needed = <v> x <per version> = <n>
```

**Step 5, turn sessions into weeks.**

```
weeks = total sessions needed / weekly sessions
      = <n> / <S>
      = <raw decimal to 4 places>
      = <rounded UP to a whole week>
```

Print with it, always:

```
This assumes next week's sessions on this page look like the week you pasted.
A sale, a season, a new audience or a budget change moves the sessions figure,
and the weeks figure moves with it.
```

**Step 6, the branch for a page that cannot be tested at this traffic.** If the
weeks figure is above 12, print the named branch instead of presenting the
number as a plan:

```
CANNOT BE TESTED AT THIS TRAFFIC
weeks the change you named would need: <n>

Twelve weeks is this unit's line, and it is a stated line rather than a
discovered one: past a quarter, the page, the ads pointing at it and the buyers
arriving have all changed enough that the two versions are no longer being
compared under the same conditions.

The smallest change 12 weeks of your traffic could show:
  sessions per version in 12 weeks = 12 x <S> / <v> = <n>
  difference = square root of ( 16 x <baseline> x (1 - <baseline>) / <n> )
             = square root of <decimal>
             = <decimal>
  which is <baseline percent> going to <target percent>, a lift of <n> percent

A change smaller than that is real or not real and this page cannot tell you
which, whatever tool you point at it.
```

**Step 7, the reading rule.** Print with every sized test:

```
The weeks figure is the whole run. Looking at the numbers on day four and
stopping when they look good throws the arithmetic away, because the rule sizes
one look at the end, not a look every morning.
```

## Output format

Write one file, `test-size.md`.

```
# Test size: <the page you named>

## Input as read
sessions: <n>   window: <range>
orders:   <n>   window: <range>
size of change you named: <as you typed it>
versions, including the current page: <v>

## Population
<the Step 2 line>

## The arithmetic
baseline rate = <the division, raw then percent>
target rate   = <the conversion, raw then percent>
difference    = <the subtraction, raw>
sessions needed per version = <the rule, then the substitution, then the result>
total sessions needed = <v> x <per version> = <n>
weeks = <n> / <S> = <raw> = <rounded up>

## What the rule carries
<the Step 4 block, verbatim>

## The answer
<n> weeks at your current traffic
| CANNOT BE TESTED AT THIS TRAFFIC + the Step 6 block
| CANNOT SIZE THIS TEST + Refusal 1
| NO TRAFFIC ON THIS PAGE

## Before you start it
<the Step 5 assumption line>
<the Step 7 reading rule>
```

## Worked case

This runs on an invented page that is **not** the fixture. Different figures,
deliberately, so the fixture stays a clean input to run yourself.

Input: 7,000 weekly sessions, 210 weekly orders, both from 1 to 7 June. Size of
change named: a 15% relative lift. Two versions.

```
baseline rate = 210 / 7000 = 0.030000 = 3.00%
target rate   = 0.030000 x (1 + 15 / 100) = 0.034500 = 3.45%
difference    = 0.034500 - 0.030000 = 0.004500

sessions needed per version
  = 16 x 0.03 x (1 - 0.03) / (0.0045 x 0.0045)
  = 16 x 0.03 x 0.97 / 0.00002025
  = 0.4656 / 0.00002025
  = 22992.5926
  = 22993 sessions per version

total sessions needed = 2 x 22993 = 45986

weeks = 45986 / 7000 = 6.5694 = 7 weeks
```

Seven weeks is under twelve, so the Step 6 branch does not fire and the answer
is seven weeks at this traffic.

## Edge cases

**Orders on the page and orders on the store are different figures.** This unit
wants orders attributed to the page you are testing. If your screen only shows
store-wide orders, print `[NEEDS: orders from this page, not the store]` and
stop. Store orders over page sessions is a rate nothing experienced, and it
runs high, which shortens the weeks figure in the flattering direction.

**Sessions are counted by a different tool than orders.** Print both sources
beside the two figures. If they are different tools, print one line saying so
and run anyway, because the ratio is still yours, but the reader should know
which two screens produced it.

**You want to test three versions.** Say so in input 4. The per-version figure
does not change and the total multiplies, so three versions is half again as
long as two. The arithmetic prints either way.

**Your traffic is seasonal and the week you pasted was a peak.** The weeks
figure is built on that week repeating. Run it twice, once on the peak week and
once on a normal week, and read the two answers as the range you are actually
in. The unit will not average two windows for you, because an average of two
weeks is a third window that never happened.

**The change you want to make is not testable as one change.** A rebuilt page
is not a change of a stated size. Size it anyway if you like, and read the
result as a test of the rebuild against the old page rather than of any part of
it. The unit prints the weeks and does not pretend the result will name which
part worked.

**The weeks figure comes back at one or two.** Check the baseline rate before
believing it. A rate above about 10% on a paid landing page usually means the
orders figure is store-wide, which is the first edge case above.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never pick the size of change on the reader's behalf. It is the one input
  only they can give and the whole answer moves with it.
- Never divide by a baseline that can be zero. Both zero branches are checked
  and printed before the first division runs.
- Never print a weeks figure without the population line above it and the
  assumption line below it.
- Never round the weeks figure down, and never round the sessions per version
  down.
- Never say the test will win, will show something, or is worth running.
- Never print a confidence level, a p-value, a significance claim or a
  probability that the change is real. The rule's two properties are printed in
  words and nothing beyond them is stated.
- Never soften the Step 6 branch by shortening the run. A page that needs 30
  weeks does not need 6 weeks and a smaller claim.
- Never suggest a tool, a testing app or a plugin. This unit sizes the test.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.
