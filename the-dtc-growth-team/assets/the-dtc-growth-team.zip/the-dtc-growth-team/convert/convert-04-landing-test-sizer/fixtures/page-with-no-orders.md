# Fixture, a page with traffic and no orders

Invented brand. Not a real store, not a real analytics screen.
Designed to exercise: the zero-orders branch, where no rate exists to compare.

---

**Page:** the paid landing page for the Pellwick Ceramic Mug
(/pages/pellwick-mug-gift)

**Sessions:** 1,150
**Sessions window shown on the screen:** 8 to 14 July

**Orders:** 0
**Orders window shown on the screen:** 8 to 14 July

**Size of change I care about:** 25% more orders per session

**Versions I would run, including the current page:** 2
