# Fixture, a page whose traffic will not carry the change named

Invented brand. Not a real store, not a real analytics screen.
Designed to exercise: the branch for a page that cannot be tested at this
traffic, including the smallest change twelve weeks could show.

---

**Page:** the paid landing page for the Halden Goods Slow Hour Candle
(/pages/slow-hour)

**Sessions:** 900
**Sessions window shown on the screen:** 15 to 21 July

**Orders:** 18
**Orders window shown on the screen:** 15 to 21 July

**Size of change I care about:** 10% more orders per session

**Versions I would run, including the current page:** 2
