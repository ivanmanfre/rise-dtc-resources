# Fixture, one page's week

Invented brand. Not a real store, not a real analytics screen.
Designed to exercise: a single pasted line carrying both figures, which has to
be split and given two windows before anything is divided.

---

**Page:** the paid landing page for the Ashlin and Roe Wool Duvet
(/pages/wool-duvet-cold-sleepers)

**Pasted from the Shopify analytics screen:**

"4,800 sessions and 96 orders on this page, 1 to 7 July"

**Sessions window shown on the screen:** 1 to 7 July
**Orders window shown on the screen:** 1 to 7 July

**Size of change I care about:** 20% more orders per session

**Versions I would run, including the current page:** 2
