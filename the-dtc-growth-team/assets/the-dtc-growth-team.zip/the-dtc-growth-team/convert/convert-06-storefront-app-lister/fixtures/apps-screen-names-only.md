# Fixture, an Apps screen and nothing else

Invented brand and invented apps. Nothing here is a real product.
Designed to exercise: the run where no observation is supplied and every row
has to come back UNKNOWN.

---

**Page my ads pay for:** /pages/slow-hour, Halden Goods

## Input 1, read off the Apps screen

- Revya Product Reviews
- Cartlift Sticky Basket
- Popfold Email Capture
- Trailmark Order Tracking
- Quillstack Page Builder

## Input 2, description lines

Not typed in.

## Input 3, monthly cost

Not typed in.

## Input 5, what I can see on that page

Not supplied.

## Input 6, apps I do not remember

Not supplied.
