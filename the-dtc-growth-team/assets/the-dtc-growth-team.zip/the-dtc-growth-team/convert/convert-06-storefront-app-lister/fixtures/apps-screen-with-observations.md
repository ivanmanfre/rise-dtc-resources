# Fixture, an Apps screen plus what the founder can see

Invented brand and invented apps. Nothing here is a real product.
Designed to exercise: one observation that could belong to two apps, an app
whose name states a function nobody observed, a missing description line, a
missing monthly cost, and an app the founder does not remember installing.

---

**Page my ads pay for:** /pages/wool-duvet-cold-sleepers, Ashlin and Roe

## Input 1 to 3, read off the Apps screen

| app name | description line on the screen | monthly cost |
|---|---|---|
| Revya Product Reviews | Collect and show customer reviews | $19 |
| Bundlr Volume Discounts | Buy more, pay less, on any product | $29 |
| GeoSwitch Currency | Show prices in the visitor's currency | $9 |
| Popfold Email Capture | Grow your list with on-site forms | $15 |
| Trailmark Order Tracking | (no description shown on the screen) | $12 |
| Sable Wholesale Portal | Wholesale pricing for approved accounts | (not shown) |
| Hemline Size Guide | Size charts for apparel and home | $7 |

## Input 5, what I can see on that page

- a block of star ratings and customer photos about two thirds of the way down.
  I think that is Revya.
- a small popup asking for an email address, appears after a few seconds. Could
  be Popfold or could be Revya, both send email as far as I know.
- a bar at the top showing prices in pounds when I open it on my phone abroad.
  That is GeoSwitch.

I looked for a size chart on that page and there is not one anywhere.

## Input 6, apps I do not remember

- Sable Wholesale Portal. I do not remember installing this and we have never
  had a wholesale account.
- Trailmark Order Tracking. Our previous developer set this up.
