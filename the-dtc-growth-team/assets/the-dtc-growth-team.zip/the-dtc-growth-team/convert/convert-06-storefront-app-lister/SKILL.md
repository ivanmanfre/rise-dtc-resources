---
name: convert-06-storefront-app-lister
description: "Use when nobody can say what is loading on the page your ads pay for, to turn your installed app list into a checkable ledger instead of a worry. Takes the app names off your Shopify Apps screen, plus anything you can actually see on that page, and returns per app whether it is visible there, what it costs you a month, and the exact screen to open next, with UNKNOWN printed wherever no observation was supplied. Triggers on \"what apps are slowing my site\", \"do I need all these Shopify apps\", \"what is loading on my landing page\", \"audit my installed apps\", \"which apps can I remove\"."
---

# The DTC Growth Team, CONVERT, unit 06 of 6: the storefront app lister

## What this does

Turns the list of names on your Apps screen into a ledger with one row per app,
where every row carries what you can see, what you pay, and the one screen that
would tell you the rest.

Out comes one file, `app-ledger.md`.

**The line only this unit produces:** per installed app, whether it is visible
on the page your ads pay for, what would come off that page if it went, and the
one check to run first, with `UNKNOWN` printed wherever no observation was
supplied.

**Read this before you run it.** This unit does not know what your apps do to
your storefront and will not pretend to. It has a list of names, and a name is
not behaviour. Every status in the file comes from something you observed, not
from something the unit recognised. If you supply nothing but names, every row
comes back `UNKNOWN`, and what you get is your app list with the monthly cost
beside each one, the exact screen to open for each, and the order to open them
in. That is the honest ceiling of this unit, printed here so you can decide
before you run it rather than after.

## Required input

1. **Your installed app names**, read straight off the Shopify Apps screen in
   the admin. Type them in the order they appear.
2. **The one-line description printed beside each app** on that screen, if it
   is shown. This is the app's own words about itself and it is carried into
   the file marked as such.
3. **What each app costs you a month**, as the Apps screen shows it.
4. **Which page your ads pay for**, named once.
5. Optional: **anything you can see on that page that you believe belongs to an
   app.** A review block, a bundle picker, a currency selector, a size chart, a
   popup, a sticky bar with a basket in it. Name it in your own words and say
   which app you think it is.
6. Optional: **mark any app you do not remember installing, or do not remember
   using.**

Inputs 5 and 6 are what turn `UNKNOWN` rows into rows that say something. The
run works without them and says less.

Nothing here needs a developer, a speed tool, a code editor or an export.

## What it refuses

**Refusal 1, no behaviour from a name.**

```
UNKNOWN
app: <name>
No observation was supplied for this app, and this unit does not know what it
puts on your storefront. Recognising an app's name is not an observation of
your store.
check: <the check attached to this row>
```

**Refusal 2, never tells you to uninstall.**

```
This unit does not tell you to remove anything. Uninstalling can take a section
off a page, leave a broken block behind in a theme, or end a plan you are
mid-term on, and none of that is visible from a list of names. It prints what
you can see, what you pay, and where to look next.
```

**Refusal 3, no speed ranking.**

```
This unit does not say which app is slowing your page down, and does not order
the list by weight, size or load time. Those are measurements. This input is a
list of names, and a ranking built from names would be a guess with an order
printed on it.
```

## Method

**Step 1, one row per app name, and set every status to UNKNOWN.** That is the
starting state of the ledger and it is what a row stays as unless Step 3 moves
it. Print the population once:

```
Population for every count in this file: the app names you pasted, counted once
each. Apps: <n>.
```

**Step 2, carry the app's own words, marked as its own words.** From input 2:

```
what it says it does: "<the description line, verbatim>"   (the app's words, not an observation)
```

If input 2 was not supplied for a row, print
`[NEEDS: the description line printed beside this app on the Apps screen]`.
Never write the description from what you know about the app.

**Step 3, attach observations, and only observations, to the status.** An
observation is something the reader typed in input 5: a thing they can see on
the page your ads pay for. The three statuses, and the one rule that moves a
row out of `UNKNOWN`:

| Status | What it takes to print it |
|---|---|
| `VISIBLE ON THAT PAGE` | the reader named a thing on that page and attached it to this app. The thing they named is quoted in the row |
| `LOOKED, DID NOT SEE IT` | the reader said they looked at that page for this app and saw nothing of it. Prints with the standing line below |
| `UNKNOWN` | anything else, including every app the reader said nothing about |

The standing line on every `LOOKED, DID NOT SEE IT` row:

```
Not visible is not the same as not loading. An app with nothing on the page can
still be putting code on it, and no screen in your admin shows you that.
```

`AMBIGUOUS OBSERVATION`: if one observation could belong to two of the apps
listed, it attaches to neither. Both rows stay `UNKNOWN`, both print the
observation, and both print
`[NEEDS: which of these two apps puts <the thing> on the page]`.

A name you recognise never sets a status. There is no fourth status for "I am
fairly sure".

**One app, several observations.** A row can carry more than one thing you saw.
Print a status line for every observation on that row, never one status that
swallows the others. Then, so the counts in Step 7 hold, the row is counted
once in the class of its strongest observation, by this printed precedence:

```
VISIBLE ON THAT PAGE  >  AMBIGUOUS OBSERVATION  >  LOOKED, DID NOT SEE IT  >  UNKNOWN
```

The precedence is mechanical and is printed on any row that uses it, together
with the line `this row also carries: <the other observations and their
statuses>`. It orders evidence, and it is not a judgement about the app.

**Step 4, fill the removal column from the observation, never from knowledge.**

```
what would come off that page: <the thing the reader named, quoted>   (VISIBLE rows)
what would come off that page: [UNKNOWN UNTIL CHECKED]                (every other row)
```

This column is never written from what an app of that kind normally does.

**Step 5, attach exactly one check per row.** The closed list, four checks, each
one a screen you can open now:

| Check | Where | What it settles |
|---|---|---|
| `A` app embeds | Shopify admin, Online Store, Themes, Customize, then the App embeds panel | whether this app has an embed switched on across the storefront |
| `B` the page's own template | the same Customize screen, open the template your paid page uses, look for a section or block carrying the app's name | whether this app has a piece placed on that page specifically |
| `C` the page itself | open the paid page on your phone and look for the thing this app is meant to show | whether it renders for a buyer at all |
| `D` the app's support | ask them: does your app load anything on a page where none of your features are used | the only one of the four that no screen of yours can answer |

Which check attaches, by rule:

| Row state | Check |
|---|---|
| `UNKNOWN`, no description supplied | `A`, and the `[NEEDS:]` for the description |
| `UNKNOWN`, description supplied | `A` |
| `LOOKED, DID NOT SEE IT` | `D` |
| `VISIBLE ON THAT PAGE` | `B` |
| `AMBIGUOUS OBSERVATION` | `C` |

One check per row. A row with four checks on it does not get run.

**Step 6, order the rows for a reader who will only do three of them.** The
printed rule:

```
Work through them in this order:
1. rows marked VISIBLE ON THAT PAGE, because you can see what they cost you and
   what would go if they went
2. rows you marked as not remembered or not used, because they are the ones
   nobody is defending
3. everything else, in the order you pasted it
```

That order comes from what you told the unit. It is not a ranking of impact and
the file says so on the line under it.

**Step 7, print the counts, every class, including the empty ones.**

```
Population: the app names you pasted, counted once each. Apps: <N>.

VISIBLE ON THAT PAGE     <n>
LOOKED, DID NOT SEE IT   <n>
AMBIGUOUS OBSERVATION    <n>
UNKNOWN                  <n>
                         ----
                         <N>

monthly cost of the apps you listed: <sum>   | [NEEDS: the monthly cost for <named apps>]
```

The sum prints only when every row carries a cost. If any row is missing one,
print the `[NEEDS:]` with the apps named and no total, because a total missing
three rows reads as the answer to a question nobody asked.

These are counts, not shares. No percentage prints in this file. A percentage
of an app list is a number about your admin screen, not about your page.

**Step 8, the zero branch.**

```
NOTHING TO LIST
Apps pasted: 0
The Apps screen in your Shopify admin lists what is installed. This unit runs
on that list and has nothing to run on.
```

## Output format

Write one file, `app-ledger.md`.

```
# Installed apps against <the page named in input 4>

## What this file can and cannot say
<the paragraph from What this does, restated in two lines>

## Population
<the Step 1 line>

## The ledger
### <app name>
status: UNKNOWN | VISIBLE ON THAT PAGE | LOOKED, DID NOT SEE IT | AMBIGUOUS OBSERVATION
observation: "<what you named>" | none supplied
this row also carries: <further observations, each with its own status>   (only where there is more than one)
what it says it does: "<the description line>" | [NEEDS: the description line printed beside this app on the Apps screen]
what would come off that page: "<the thing you named>" | [UNKNOWN UNTIL CHECKED]
monthly cost: <figure> | [NEEDS: what this app costs you a month]
not remembered: yes | no
check: <A | B | C | D>, <the screen, written out>
<the standing line, on LOOKED rows only>

## Order to work through
<the Step 6 list, with the rows named in it>

## Counts
<the Step 7 block>

## What this unit refused to do
<Refusal 2 and Refusal 3, verbatim>
```

## Edge cases

**You believe an app is admin only and never touches the storefront.** That is
a belief, not an observation, so the row stays `UNKNOWN`. Print the reader's
line beside it, quoted and labelled as theirs, and attach check `A`, which is
the screen that would settle it. This is the commonest place the unit is asked
to agree with a reasonable assumption, and agreeing would make every other
`UNKNOWN` in the file worthless.

**Two apps that appear to do the same job.** Print both rows, both statuses,
both costs. Print one line saying two rows claim the same job. The unit does
not say which to keep, because keeping one is a removal decision and Refusal 2
covers it.

**An app that was uninstalled from the theme but is still on the Apps screen.**
It appears in this ledger, because the ledger is of what the Apps screen lists.
Check `A` or `B` is what tells you whether anything of it is still placed.

**An app installed by an agency or a developer who is gone.** Mark it in input
6 as not remembered. It moves up the order in Step 6. The unit still refuses to
say what it does.

**You can see something on the page and cannot say which app puts it there.**
That is `AMBIGUOUS OBSERVATION` even when only one app is a plausible owner.
Plausible is the word this whole unit exists to keep out of the status column.
Check `C` attaches, and the `[NEEDS:]` names both candidates.

**Every row comes back UNKNOWN.** Expected, on a run with names only. The file
is still a list with costs, checks and an order. Read the counts line, do the
first three checks, and rerun with what you saw in input 5. Two runs is the
intended shape of this unit.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- `UNKNOWN` is the default status and the only status a row can hold without a
  quoted observation from the reader. A recognised name never moves a row.
- Never describe what an app does, from knowledge, in any field. The
  description field carries the reader's pasted line or a `[NEEDS:]`, and it is
  labelled as the app's own words either way.
- Never state or imply what an app does to page speed, page weight or load
  time. Refusal 3 fires.
- Never tell the reader to uninstall, disable, pause or replace an app.
  Refusal 2 fires.
- Never rank the list by impact, cost or risk. The only order in the file is
  the Step 6 order, built from what the reader supplied.
- Never total the monthly cost while any row is missing one.
- Never invent an app that is not on the pasted list, and never split one app
  into two rows because it has two features.
- Never let one status swallow another on a row carrying several observations.
  Every observation prints its own status line, and the counts use the printed
  precedence.
- Never print a percentage in this file.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, streamline, empower, utilize, supercharge.
