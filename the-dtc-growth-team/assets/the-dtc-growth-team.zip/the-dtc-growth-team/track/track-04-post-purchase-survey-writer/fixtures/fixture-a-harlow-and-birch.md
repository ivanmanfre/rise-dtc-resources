# Fixture A, five campaigns and two organic channels

Invented brand and invented campaign names. Not a record of any account.
Designed to exercise normal normalization, including two pairs of campaigns
that collapse into the same channel option.

---

Brand: Harlow & Birch

Live campaigns, from the Campaigns screen of each ad account:
Meta - Prospecting - Broad
Meta - Retargeting - 14d
Google - Brand Search
Google - Shopping
TikTok - UGC - Spark Ads

Organic channels we post on:
Instagram organic
Email newsletter
