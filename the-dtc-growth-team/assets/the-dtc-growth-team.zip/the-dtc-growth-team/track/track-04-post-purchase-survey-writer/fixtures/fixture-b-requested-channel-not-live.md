# Fixture B, one live channel and a request for one that is not

Invented brand and invented campaign names. Not a record of any account.
Designed to exercise Refusal 1: the brief asks for a "Podcast" option, and no
podcast channel appears anywhere in the pasted input.

---

Brand: Oleander & Ash

Live campaigns, from the Campaigns screen of each ad account:
Google - Brand Search
Google - Nonbrand Search

Organic channels we post on:
Referral, word of mouth

One-sentence brief: "Can you add an option for our podcast sponsorships too,
people mention hearing about us there."
