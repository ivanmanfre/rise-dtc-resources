---
name: track-04-post-purchase-survey-writer
description: "Use when you want a post-purchase \"how did you hear about us\" question that a founder can actually read a report from, instead of a wall of free text. Takes your live channel list, read off the Campaigns screen of each ad account plus any organic channel you post on, and returns the question, its answer options bound to your live channels, and the option that will absorb answers named with why. Triggers on \"write me a post-purchase survey question\", \"how did you hear about us options\", \"what channels should this survey list\", \"fix my attribution survey\", \"my survey answers don't tell me anything\"."
---

# The DTC Growth Team, TRACK, unit 04 of 06 (agent 04 of 30)

## What this does

Writes the single question you show a customer right after they buy, with an
answer list bound to the channels you can prove are live, so the answers can
actually be counted afterward.

Out comes one file, `post-purchase-survey.md`.

**The line only this unit produces:** the post-purchase question, its answer
options bound to your live channels, and the option that will absorb answers
named with the reason it absorbs them.

This unit writes a closed-option survey. It never writes a free-text-only
question, for the reason printed in Refusal 2 below, and it never writes an
option for a channel it cannot see in your input.

## Required input

1. **Your live channel list**, taken from the campaign names on the Campaigns
   screen of each ad account you run (Meta, Google, TikTok, or others).
2. **Any organic channel you post on** that is not an ad account (your own
   Instagram, a newsletter, a podcast you host, word of mouth you actively
   ask for).

Paste both as a plain list. If one pasted line names more than one channel
(`Meta, Google, TikTok - evergreen`), split it into its separate channel names
before anything else runs; see Step 2.

## What it refuses

**Refusal 1, no option for a channel that is not live.** Refuses to write an
answer option for any channel not present in the input, whether the channel
is one you asked for by name or one this unit might otherwise have guessed
at:

```
NO OPTION WRITTEN: CHANNEL NOT IN YOUR LIVE LIST
requested or considered channel: <name>
This channel does not appear in the campaign or organic list you pasted, so
writing an option for it would ask customers to pick a source you are not
running. Add it to your input if it is live, or leave it out.
```

**Refusal 2, no free-text-only survey.** This refusal is not conditional; it
prints on every run because the rule it states is permanent:

```
NO FREE-TEXT-ONLY SURVEY
Free-text answers do not aggregate: fifty customers write "a friend told me"
fifty different ways, and no report can group them into one row. This unit
writes closed options only. Where a category still feels wrong for a
customer, "Something else" is the closed option that carries them, not an
open text box.
```

## Method

**Step 1, the zero-input branch.** If no channel and no organic channel was
pasted, stop:

```
NO SURVEY WRITTEN
[NEEDS: your live channel list]
A survey with no channels behind it has nothing to bind its options to.
```

**Step 2, split grouped lines.** Any pasted line naming more than one channel
is split into one channel name per line before Step 3 runs. A campaign name
that only encodes one channel plus other detail (`Meta - UGC - Retargeting`)
stays whole here and goes to Step 3's normalization instead.

**Step 3, normalize each campaign name to a channel.** Read the platform token
from each campaign name (the part naming Meta, Google, TikTok, Pinterest, or
similar) and print a mapping line for every campaign: `<campaign name> ->
<channel>`. Two campaigns that normalize to the same channel collapse into one
option; the mapping table still shows both source lines, so the collapse is
auditable rather than silent.

**Step 4, add the organic channels.** Each pasted organic channel becomes its
own option, unnormalized, printed as given.

**Step 5, the fixed absorbing option.** Every survey this unit writes carries
exactly one absorbing option, always labelled `Something else`, appended
after the channel options. It absorbs two things: any respondent whose real
source is not among the channels you are running (because you are not asking
them to lie), and any respondent who cannot isolate one channel. Every other
option is bound to a channel you can verify is live; this one is not, which
is why it is the one that absorbs what the others cannot honestly claim.

**Step 6, the refusal check.** If your one-sentence brief for this run asks
for an option this unit was not given a matching channel for, Refusal 1
fires for that one option and the rest of the survey still prints.

## Output format

Write one file, `post-purchase-survey.md`.

```
# Post-purchase survey

## The question
"How did you hear about us?"

## Answer options
- <channel option 1>
- <channel option 2>
- ...
- Something else

## Absorbing option
Something else absorbs: any source not among the channels above, and any
respondent who cannot isolate one channel. It is the only option not bound to
a channel this unit can verify is live.

## Channel mapping
<campaign name> -> <channel option>
<campaign name> -> <channel option>
(organic channels print as given, with no mapping line, since they were not
normalized from a campaign name)

## Refused
<any Refusal 1 blocks that fired, or "none" if the brief asked for nothing
outside the live list>

## Structural rule
<Refusal 2, printed verbatim, every run>
```

## Edge cases

**Two organic channels are effectively the same thing worded differently**
(`Instagram`, `our IG page`). This unit does not merge them on its own
judgement; it prints both as pasted and leaves the merge decision to you,
because collapsing wording is a step this unit cannot verify without asking
which one you mean.

**A campaign name carries no recognizable platform token** (`Q3 Push v2`).
Print it in the mapping table with channel `[NEEDS: which channel does "<name>"
belong to]` rather than guessing from context.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write an answer option for a channel absent from the input.
- Never write a free-text-only question. Refusal 2 is permanent, not
  conditional.
- Never merge two differently-worded channels into one option without being
  told they are the same channel.
- Never omit the absorbing option. Every survey this unit writes carries one.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-harlow-and-birch.md` run literally,
line by line, under the rules above. It is not a separate example.**

Pasted campaign names and organic channels for a brand called Harlow &
Birch.

```
Step 2, split: no grouped lines in this paste.

Step 3, normalize:
  Meta - Prospecting - Broad -> Meta
  Meta - Retargeting - 14d -> Meta (collapses with the line above)
  Google - Brand Search -> Google
  Google - Shopping -> Google (collapses with the line above)
  TikTok - UGC - Spark Ads -> TikTok

Step 4, organic:
  Instagram organic
  Email newsletter

Step 5, absorbing option: Something else, appended.
```

```
# Post-purchase survey

## The question
"How did you hear about us?"

## Answer options
- Meta
- Google
- TikTok
- Instagram organic
- Email newsletter
- Something else

## Absorbing option
Something else absorbs: any source not among the channels above, and any
respondent who cannot isolate one channel. It is the only option not bound to
a channel this unit can verify is live.

## Channel mapping
Meta - Prospecting - Broad -> Meta
Meta - Retargeting - 14d -> Meta
Google - Brand Search -> Google
Google - Shopping -> Google
TikTok - UGC - Spark Ads -> TikTok
Instagram organic (organic, no mapping)
Email newsletter (organic, no mapping)

## Refused
none

## Structural rule
NO FREE-TEXT-ONLY SURVEY
Free-text answers do not aggregate: fifty customers write "a friend told me"
fifty different ways, and no report can group them into one row. This unit
writes closed options only. Where a category still feels wrong for a
customer, "Something else" is the closed option that carries them, not an
open text box.
```
