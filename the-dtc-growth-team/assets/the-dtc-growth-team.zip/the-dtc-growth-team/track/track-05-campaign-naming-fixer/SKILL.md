---
name: track-05-campaign-naming-fixer
description: "Use when your campaign names don't tell you what you're actually trying to learn, so the report can't group by it either. Takes your current campaign and ad set names, copied from the Campaigns screen, plus one sentence saying what you want to be able to compare, and returns a rename map grouping by that one stated variable, with names that carry no information about it flagged instead of guessed. Triggers on \"fix my campaign naming\", \"rename these campaigns so I can compare X\", \"my campaign names don't tell me anything\", \"how should I name these to compare audiences\", \"clean up my campaign naming convention\"."
---

# The DTC Growth Team, TRACK, unit 05 of 06 (agent 05 of 30)

## What this does

Reads your current campaign and ad set names against the one thing you said
you want to be able to compare, and renames each one so your report can group
by that variable, or names exactly what is missing when it cannot.

Out comes one file, `naming-fix.md`.

**The line only this unit produces:** a rename map from each current campaign
name to a name that groups by one stated variable, with the variable named
once at the top.

This unit renames for one variable at a time. If you want to compare two
things, run it twice and keep the two rename maps separate; a name that
encodes two variables at once is a name nobody can filter on cleanly.

## Required input

1. **Your current campaign and ad set names**, copied from the Campaigns
   screen.
2. **One sentence saying what you want to be able to compare** (for example,
   "which audience type is driving purchases" or "which funnel stage each
   campaign targets").

## What it refuses

**Refusal, no rename without information to rename on.** Refuses to rename a
campaign whose current name carries no information about the variable you
named. Instead of guessing, it prints the one question that would let it:

```
NOT RENAMED: NO INFORMATION ABOUT THE STATED VARIABLE
current name: "<name>"
Nothing in this name relates to <variable>.
[NEEDS: the <variable> value for "<name>"]
```

## Method

**Step 1, name the variable.** Print it once, at the top of the output, in
the reader's own words tightened to a short label. Every row below is
evaluated against this one variable and no other.

**Step 2, read the tokens.** Split each name on structural delimiters only
(`|`, `-`, `_`, `/`); words containing a plain space stay together, because a
space inside "Lookalike 1%" is part of one token, not a separator between two.

**Step 3, class each name.** Read the tokens and decide, for the one stated
variable, which of three applies:

- **a single token (or the whole name) plainly carries one value** of the
  variable. Record the value.
- **no token relates to the variable at all.** The Refusal fires.
- **more than one token plausibly carries a different value of the same
  variable** (for example a name that reads as both "Prospecting" and
  "Retargeting" at once). This is not resolved by picking the more likely
  one. Both candidates print, and the row is not renamed:

```
NOT RENAMED: AMBIGUOUS
current name: "<name>"
candidates for <variable>: "<value 1>" and "<value 2>"
[NEEDS: which value applies, "<value 1>" or "<value 2>", for "<name>"]
```

One name carrying two candidate facts gets two printed candidates, never one
picked silently. This is the same rule as splitting a grouped input line:
the name is not allowed to resolve to a single status when it plainly carries
more than one.

**Step 4, the rename.** For every name that resolved to a single value in
Step 3, the new name is:

```
<value> | <original name>
```

This is the whole rule, stated once, applied identically to every row. Two
names that resolve to the same value get the same prefix; that is not an
error, it is the grouping working.

**Step 5, the counts.** State the population once, in words, above the
counts: *every campaign or ad set name you pasted, counted once.*

```
RENAMED:        <n> / <n>
AMBIGUOUS:       <n> / <n>
UNCLASSIFIABLE:  <n> / <n>
```

All three print even when zero.

## Output format

Write one file, `naming-fix.md`.

```
# Naming fix
Grouping variable: <variable, named once>
population: every campaign or ad set name you pasted, counted once = <n>

## Rename map
<original name>  ->  <value> | <original name>
<original name>  ->  <value> | <original name>

## Not renamed: ambiguous
<the AMBIGUOUS blocks from Step 3>

## Not renamed: no information
<the Refusal blocks from Step 3>

## Counts
RENAMED:        <n> / <n>
AMBIGUOUS:       <n> / <n>
UNCLASSIFIABLE:  <n> / <n>
```

## Edge cases

**The stated variable is itself ambiguous** ("performance" is not a value
that lives in a name; it is a result). Print `[NEEDS: a variable with values
a name can carry, not an outcome]` and stop before Step 2 runs on anything.

**Two different-looking tokens turn out to name the same value** ("Broad" and
"Interest-Wide" both meaning the same audience type in this account). This
unit does not merge them on its own judgement. Print both as separate values
found, and leave the merge decision to the reader, because collapsing two
tokens into one value is a call this unit cannot verify from the name alone.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never rename a name that carries no information about the stated variable.
  The Refusal fires instead.
- Never pick one candidate value for a name that plausibly carries two. Print
  both and ask.
- Never fold two variables into one rename pass.
- Never invent a value not present as a token (or the whole name) in the
  original.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-holbrook-supply.md` run literally, line
by line, under the rules above. It is not a separate example.**

Variable: "which audience type is driving purchases: prospecting versus
retargeting versus lookalike." Six names pasted for a brand called Holbrook
Supply.

```
Grouping variable: audience type (prospecting / retargeting / lookalike)
population: every campaign or ad set name you pasted, counted once = 6

1. "HB | Prospecting | Broad | Video"
   token "Prospecting" carries the value plainly.
   -> RENAMED: "Prospecting | HB | Prospecting | Broad | Video"

2. "HB | Retargeting | 30d Viewers"
   token "Retargeting" carries the value plainly.
   -> RENAMED: "Retargeting | HB | Retargeting | 30d Viewers"

3. "HB | Lookalike 1% | Purchasers"
   token "Lookalike 1%" carries the value "Lookalike."
   -> RENAMED: "Lookalike | HB | Lookalike 1% | Purchasers"

4. "HB | Prospecting-Retargeting Combo Test"
   both "Prospecting" and "Retargeting" appear as candidates.
   -> NOT RENAMED: AMBIGUOUS
      candidates for audience type: "Prospecting" and "Retargeting"
      [NEEDS: which value applies, "Prospecting" or "Retargeting", for
      "HB | Prospecting-Retargeting Combo Test"]

5. "Campaign - Copy 2"
   no token relates to audience type at all.
   -> NOT RENAMED: NO INFORMATION ABOUT THE STATED VARIABLE
      [NEEDS: the audience type value for "Campaign - Copy 2"]

6. "HB | Lookalike 3% | Engaged 180d"
   token "Lookalike 3%" carries the value "Lookalike."
   -> RENAMED: "Lookalike | HB | Lookalike 3% | Engaged 180d"
```

```
Counts
RENAMED:        4 / 6
AMBIGUOUS:       1 / 6
UNCLASSIFIABLE:  1 / 6
```
