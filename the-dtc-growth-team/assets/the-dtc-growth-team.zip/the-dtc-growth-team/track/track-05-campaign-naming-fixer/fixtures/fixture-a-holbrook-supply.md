# Fixture A, six names and one variable sentence

Invented brand and invented campaign names. Not a record of any account.
Designed to exercise a clean rename, an ambiguous name carrying two
candidate values, and a name that carries no information about the variable
at all.

---

Brand: Holbrook Supply

What I want to be able to compare: which audience type is driving purchases,
prospecting versus retargeting versus lookalike.

Current campaign and ad set names:
HB | Prospecting | Broad | Video
HB | Retargeting | 30d Viewers
HB | Lookalike 1% | Purchasers
HB | Prospecting-Retargeting Combo Test
Campaign - Copy 2
HB | Lookalike 3% | Engaged 180d
