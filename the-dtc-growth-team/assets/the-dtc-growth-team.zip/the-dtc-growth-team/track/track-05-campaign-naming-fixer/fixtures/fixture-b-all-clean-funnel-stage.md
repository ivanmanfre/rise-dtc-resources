# Fixture B, four names that all rename cleanly

Invented brand and invented campaign names. Not a record of any account.
Designed to exercise the zero-baseline branch on the other two classes:
AMBIGUOUS: 0 / 4 and UNCLASSIFIABLE: 0 / 4 should still print as their own
rows rather than being left off the output.

---

Brand: Ferro & Quill

What I want to be able to compare: which funnel stage each campaign targets,
top of funnel versus middle versus bottom.

Current campaign and ad set names:
FQ | TOF | Broad Interest
FQ | MOF | Video Viewers 25%
FQ | BOF | Cart Abandoners
FQ | BOF | Past Purchasers 180d
