# Fixture B, three figures that share nothing

Invented brand and invented figures. Not a record of any account.
Designed to exercise the NOTHING COMPARABLE branch: no two figures share both
an attribution setting and a date range, so no fraction should print for a
shared basis.

---

Brand: Oswin Provisions

Meta Ads Manager screen
  attribution setting shown at top: "1-day click"
  Purchases: 47          date range: Aug 1 - Aug 7

Google Ads screen, Conversions column
  attribution setting: "Data-driven, 30-day click, 1-day view"
  Conversions: 33         date range: Jul 1 - Jul 31

TikTok Ads Manager screen
  attribution setting: "7-day click, 1-day view"
  Purchases: 19          date range: Aug 1 - Aug 7
