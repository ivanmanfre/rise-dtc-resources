# Fixture A, five figures pasted from three screens

Invented brand and invented figures. Not a record of any account.
Designed to exercise a comparable group, a same-setting-different-range pair
that still fails the refusal, and one UNSTATED figure.

---

Brand: Marrow & Fen

Meta Ads Manager screen
  attribution setting shown at top: "7-day click, 1-day view"
  Purchases: 212        date range: Jun 1 - Jun 30

Meta Ads Manager screen (second ad set, same account)
  attribution setting shown at top: "7-day click, 1-day view"
  Purchases: 198         date range: Jun 1 - Jun 30

Google Ads screen, Conversions column
  attribution setting (from the column header): "Data-driven, 30-day click, 1-day view"
  Conversions: 84         date range: Jun 1 - Jun 30

Google Ads screen, Conversions column (pulled the next day, date preset left on "this month to date")
  attribution setting (from the column header): "Data-driven, 30-day click, 1-day view"
  Conversions: 91         date range: Jun 1 - Jul 1

Shopify analytics screen
  attribution setting: (screen shows no attribution window field)
  Total orders: 340        date range: Jun 1 - Jun 30
