---
name: track-02-attribution-window-matcher
description: "Use before you add, compare or explain the gap between two numbers from different ad platforms, to check whether they are even measuring the same window. Takes the conversion figure and the attribution setting printed beside it from each platform screen, and returns the one reporting basis your figures share, plus the named figures that cannot be added to each other. Triggers on \"why don't my platform numbers add up\", \"can I compare Meta and Google conversions\", \"why is my blended number higher than any one platform\", \"what attribution window am I even looking at\", \"can these two figures be added together\"."
---

# The DTC Growth Team, TRACK, unit 02 of 06 (agent 02 of 30)

## What this does

Reads the conversion figure and the attribution setting printed beside it on
each platform screen you paste, and sorts them into the ones that are counting
the same thing and the ones that are not.

Out comes one file, `attribution-match.md`.

**The line only this unit produces:** the one reporting basis your pasted
figures share, and the named figures that cannot be added to each other.

This unit never adds, blends or averages a figure. It only says which figures
are allowed to be added, by someone else, afterward.

## Required input

For each platform, three things read off the same screen:

1. **The conversion figure**, whatever it is named on that screen (Purchases,
   Conversions, Web Orders).
2. **The attribution setting printed beside it.** On Meta this is the line at
   the top of Ads Manager reading something like "7-day click, 1-day view".
   On Google Ads this is the Conversions column's attribution setting, shown
   when you click the column header. On Shopify or a landing analytics screen
   this is usually unstated; paste what the screen shows, even if that is
   nothing.
3. **The date range shown on that screen**, exactly as displayed.

Paste one block per platform. Up to 8 figures total.

Never look up or infer an attribution setting that is not printed on the
screen you are reading. If the screen does not show one, say so; do not
assume it matches the platform's own default.

## What it refuses

**Refusal, no comparison across different dates.** Refuses to compare any two
figures whose date ranges differ by even one day:

```
NOT COMPARABLE: DATE RANGES DIFFER
figure A: <platform>, <metric>, <value>   range: <range A>
figure B: <platform>, <metric>, <value>   range: <range B>
These ranges are not the same window, even by one day, so nothing below
compares them.
```

This refusal is not conditional on how close the ranges look. A one-day
difference fires it exactly as a one-month difference does.

## Method

State this once at the top of the output, before any classification:

> Every figure below is counted over the population "every reported figure
> you pasted, counted once." A figure is placed in exactly one class.

**Step 1, read the attribution setting per figure.** If the screen printed
one, record it verbatim. If the screen printed nothing, or you cannot read it
from what was pasted, the figure is `UNSTATED`. `UNSTATED` is its own class,
not a fourth option folded into "not comparable" or into "comparable"; a
figure that is `UNSTATED` cannot be placed in either.

**Step 2, group the remaining figures.** Two figures are in the same
comparable group only if both of these hold at once:

- their attribution settings are the identical string (or the same setting
  under the two platforms' own vocabularies, stated in one line why they are
  the same, never assumed silently), and
- their date ranges are the identical range, start and end.

Any figure that shares its exact setting and exact range with at least one
other pasted figure joins that group. A figure with no match sits alone.

**Step 3, the fires.** For every pair of figures whose date ranges differ,
even by one day, the Refusal fires and both ranges print, per pair, whether or
not their attribution settings would otherwise have matched.

**Step 4, name the basis.** If one group has two or more figures in it, that
group's shared attribution setting and date range is "the one reporting basis
your pasted figures share." Print it once, in words, at the top of the
result. If more than one group of two or more exists, print each group
separately; there is no single sentence forcing one basis when your paste
genuinely contains two.

**Step 5, the zero-baseline branch.** If no group has two or more figures,
i.e. every figure sits alone or is `UNSTATED`, print the named branch and stop
before any comparison sentence:

```
NOTHING COMPARABLE
Every figure you pasted has its own attribution setting, its own date range,
or both. No two of them can be added, and no fraction is printed below.
```

**Step 6, the counts.** Over the stated population from the preamble:

```
COMPARABLE (in a group of 2 or more): <n> / <n>
STANDS ALONE (no match): <n> / <n>
UNSTATED: <n> / <n>
```

The three counts sum to the total figures pasted. `UNSTATED` never counts
toward either of the other two.

## Output format

Write one file, `attribution-match.md`.

```
# Attribution window match
population: every reported figure you pasted, counted once = <n>

## Figures read
### Figure <k>
platform: <name>          metric: <name>          value: <n>
attribution setting: "<verbatim>" | UNSTATED (screen did not print one)
date range: <range as shown>

## Shared basis (or NOTHING COMPARABLE)
<the basis sentence from Step 4, or the branch from Step 5>

## Not comparable
### Pair <figure k> / <figure j>
range <A> vs range <B> differ, so this pair does not compare
  (only pairs where the date ranges differ print here; a shared-setting,
  shared-range pair belongs in the shared basis section above, not here)

## Counts
COMPARABLE: <n> / <n>
STANDS ALONE: <n> / <n>
UNSTATED: <n> / <n>
```

## Edge cases

**Two platforms use different words for the same window** (Meta's "7-day
click" versus a report that says "last-touch, 7 day"). Only group them if you
can state in one line why the two phrases name the same window. Where that
line cannot be written honestly, treat them as different settings and leave
the figures apart.

**A figure has no attribution setting because the screen genuinely has none**
(a raw Shopify order count has no click window at all). This is `UNSTATED`,
not a fourth silently-dropped class. It still prints in the Figures Read
section and in the UNSTATED count.

**All figures are from one platform.** The method is unchanged; grouping
still runs on setting and range, only within the one platform's screens.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never add, blend, average or sum two figures. This unit sorts figures into
  classes; it does not arrive at a total.
- Never assume an attribution setting the screen did not print, including the
  platform's own stated default.
- Never treat a one-day date range difference as close enough. The refusal is
  binary, not a tolerance.
- Never fold UNSTATED figures into COMPARABLE or STANDS ALONE.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-marrow-and-fen.md` run literally, line
by line, under the rules above. It is not a separate example.**

Five figures pasted for a brand called Marrow & Fen.

```
population: every reported figure you pasted, counted once = 5

Figure 1: Meta, Purchases, 212
  attribution setting: "7-day click, 1-day view"
  date range: Jun 1 - Jun 30

Figure 2: Meta, Purchases, 198
  attribution setting: "7-day click, 1-day view"
  date range: Jun 1 - Jun 30

Figure 3: Google Ads, Conversions, 84
  attribution setting: "Data-driven, 30-day click, 1-day view"
  date range: Jun 1 - Jun 30

Figure 4: Google Ads, Conversions, 91
  attribution setting: "Data-driven, 30-day click, 1-day view"
  date range: Jun 1 - Jul 1

Figure 5: Shopify, Total orders, 340
  attribution setting: UNSTATED (screen shows no attribution window at all)
  date range: Jun 1 - Jun 30
```

Reading order: Figures 1 and 2 share the identical setting string and the
identical range, Jun 1 - Jun 30. They form a comparable group.

Figure 3 shares Figure 4's setting string but not its range (Jun 1 - Jun 30
vs Jun 1 - Jul 1, one day apart at the end). The refusal fires on that pair.
Figure 3 therefore stands alone; Figure 4 stands alone.

Figure 5 is UNSTATED and is placed in neither group.

```
Shared basis
Figures 1 and 2 share the reporting basis "7-day click, 1-day view" over
Jun 1 - Jun 30. These two Meta figures can be added to each other. Nothing
else in this paste shares a basis with them or with each other.

Not comparable
Pair Figure 3 / Figure 4
range Jun 1 - Jun 30 vs range Jun 1 - Jul 1 differ, so this pair does not
compare, even though both figures use "Data-driven, 30-day click, 1-day view."

Counts
COMPARABLE: 2 / 5
STANDS ALONE: 2 / 5
UNSTATED: 1 / 5
```
