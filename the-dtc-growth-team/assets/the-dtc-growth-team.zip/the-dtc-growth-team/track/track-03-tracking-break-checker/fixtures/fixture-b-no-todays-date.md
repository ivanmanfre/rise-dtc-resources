# Fixture B, today's date not supplied

Invented brand and invented events. Not a record of any account.
Designed to exercise the today's-date gate: rows needing a day count cannot
class, while a zero-history row and a missing-field row are unaffected
because they never needed today's date in the first place.

---

Brand: Halloway & Vine

Events Manager overview:
Purchase: last received 2026-08-10
Initiate Checkout: last received 12 days ago
Return Initiated: last received -
Lead: (no last-received value shown on the screen)
