# Fixture A, six lines off an overview screen, one grouped

Invented brand and invented events. Not a record of any account.
Designed to exercise LIVE, STALE, an explicit zero-history marker, a missing
date field, and one line that groups two events together and has to be split
before it can be classed.

---

Brand: Corrigan Supply
Today's date: 2026-08-14

Events Manager overview:
Purchase: last received 2026-08-13
Add to Cart: last received 5 days ago
Checkout Started / Subscribe: last received 2026-08-01
Page View: last received Today
Warranty Registration: last received -
Payment Info Added: (no last-received value shown on the screen)
