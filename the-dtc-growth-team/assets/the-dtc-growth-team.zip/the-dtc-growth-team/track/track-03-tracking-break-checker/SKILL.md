---
name: track-03-tracking-break-checker
description: "Use when you want to know which of your tracked events stopped reporting without anyone noticing. Takes the event names and the last-received date beside each, read straight off the Events Manager overview screen, plus today's date, and returns a LIVE, STALE or NEVER FIRED status per event, revenue-carrying events ranked first. Triggers on \"is my tracking still working\", \"check my pixel events\", \"why did my conversions drop\", \"has any of my tracking broken\", \"audit my events manager\"."
---

# The DTC Growth Team, TRACK, unit 03 of 06 (agent 03 of 30)

## What this does

Reads the event names and the last-received date beside each, exactly as the
Events Manager overview screen shows them, and says which are still reporting,
which have gone quiet, and which never fired at all.

Out comes one file, `tracking-break-check.md`.

**The line only this unit produces:** the last-received date per tracked
event with a LIVE, STALE or NEVER FIRED status, revenue-carrying events ranked
first.

This unit does not open the pixel helper, does not check the tag itself, and
does not say why an event stopped. It reads the date the overview screen
already shows and classes it.

## Required input

1. **Every event name and the "last received" date beside it**, read off the
   Events Manager overview screen (or the equivalent overview for the
   platform you use). Paste the block as it appears; several shapes are
   accepted, see Step 3.
2. **Today's date.**

If a line on the screen names more than one event bound to the same value
(some overview screens group events, e.g. "Purchase / Subscribe: 5 days ago"),
paste the line as shown. This unit splits it before classing; see Step 2.

## What it refuses

**Refusal, no calling an event dead with no date to call it on.** Refuses to
declare an event broken when the screen shows no last-received date at all
for it:

```
MISSING FIELD, NOT A STATUS
event: <name>
The screen you pasted does not carry a last-received value for this event at
all, so this unit cannot say LIVE, STALE or NEVER FIRED.
[NEEDS: the last received date for this event]
```

This is different from the screen itself showing a dash or "Never": that is
the platform's own zero-history signal, and it classes as `NEVER FIRED`
cleanly (see Step 4). The refusal fires only when the event name was pasted
with no date field attached to it whatsoever.

## Method

State this once at the top of the output:

> Every event below is counted over the population "every event row after
> line-splitting, counted once."

**Step 1, today's date gate.** If today's date was not supplied, print
`[NEEDS: today's date]` once at the top. Any row whose classification needs a
day count (Step 4's LIVE / STALE branch) prints `[NEEDS: today's date]` as its
status instead of a class. Rows that resolve without a day count (an explicit
zero-history marker, or a missing date field) are unaffected and still class
normally.

**Step 2, split grouped lines.** If one pasted line names more than one event
sharing a single last-received value, split it into one row per event name
before anything else runs. Each split row carries the same last-received
value and is classed independently in every later step; if only one of the
grouped events turns out to be revenue-carrying (Step 5), that difference has
to survive the split.

**Step 3, read the date, several shapes accepted.** Recognized forms: an
absolute date (`12 Aug 2026`, `2026-08-12`), a relative phrase (`3 days ago`,
`Today`, `Yesterday`), or one of the zero-history markers (`-`, `Never`,
`No data yet`, `No events yet`, or the field left visibly blank on an
otherwise populated screen). Print which shape was read for each row. A shape
that matches none of these is not a value this unit can class; treat it the
same as a missing field and fire the Refusal.

**Step 4, class each row.** Exactly one of four:

| class | rule |
|---|---|
| `NEVER FIRED` | the screen showed one of the zero-history markers |
| `LIVE` | a parseable date, 0 or 1 days before today |
| `STALE` | a parseable date, 2 or more days before today |
| `[NEEDS: the last received date for this event]` | no date field was pasted for this event at all |

**Step 5, revenue-carrying, by name match.** A row is revenue-carrying if its
event name contains, case-insensitively, any of: `purchase`, `order`,
`checkout`, `subscribe`, `payment`. This is a name match against the pasted
event name only; it is not a check of what the event actually fires on, and
the output says so once. Anything not matching is `NOT REVENUE-NAMED`.

**Step 6, rank.** Print the revenue-carrying rows first, in the order they
were pasted (after any Step 2 splitting), then the not-revenue-named rows, in
the order they were pasted. Ranking changes print order only; it does not
change any row's class.

**Step 7, the counts.** Over the stated population:

```
LIVE:        <n> / <n>
STALE:       <n> / <n>
NEVER FIRED: <n> / <n>
NEEDS DATE (missing field, per-event): <n> / <n>
```

All four print even when zero. They sum to the total row count.

## Output format

Write one file, `tracking-break-check.md`.

```
# Tracking break check
today: <date> | [NEEDS: today's date]
population: every event row after line-splitting, counted once = <n>

## Revenue-carrying events
### <event name>
last received: <value as read>     shape: <absolute | relative | zero-history marker>
status: LIVE | STALE | NEVER FIRED | [NEEDS: the last received date for this event]

## Other events
### <event name>
last received: <value as read>     shape: <...>
status: LIVE | STALE | NEVER FIRED | [NEEDS: the last received date for this event]

## Counts
LIVE:        <n> / <n>
STALE:       <n> / <n>
NEVER FIRED: <n> / <n>
NEEDS DATE:  <n> / <n>
```

## Edge cases

**The screen shows a last-received value but it is in the future** (a typo,
or a timezone artefact). Print the value as read, class it `LIVE`, and add a
`NOTE: last-received date is after today, printed exactly as shown` line
rather than silently correcting it.

**Every revenue-carrying event is STALE or NEVER FIRED and every other event
is LIVE.** No special handling; the ranking already surfaces this because the
revenue-carrying group prints first regardless of its own statuses.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never call an event NEVER FIRED or STALE from a missing date field. That is
  the Refusal, not a class.
- Never invent today's date from context. If it was not supplied, the day-count
  classes cannot print.
- Never guess what an event fires on beyond matching its pasted name against
  the closed revenue-carrying list in Step 5.
- Never reorder rows within the revenue-carrying or the other group. Ranking
  is group-level only.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-corrigan-supply.md` run literally, line
by line, under the rules above. It is not a separate example.**

Today: 2026-08-14. Six lines pasted, one of which names two events together.

```
today: 2026-08-14
population: every event row after line-splitting = 7

Line 1: Purchase: 2026-08-13          -> 1 day before today -> LIVE
Line 2: Add to Cart: 5 days ago       -> STALE
Line 3: Checkout Started / Subscribe: 2026-08-01
  split into:
    Checkout Started: 2026-08-01     -> 13 days before today -> STALE
    Subscribe: 2026-08-01            -> 13 days before today -> STALE
Line 4: Page View: Today              -> 0 days before today -> LIVE
Line 5: Warranty Registration: -      -> zero-history marker -> NEVER FIRED
Line 6: Payment Info Added: (no last-received field pasted)
  -> [NEEDS: the last received date for this event]
```

Revenue-carrying, by name match (contains purchase, order, checkout,
subscribe or payment): Purchase, Checkout Started, Subscribe, Payment Info
Added. Not revenue-named: Add to Cart, Page View, Warranty Registration.

```
Revenue-carrying events, printed first
Purchase              2026-08-13   LIVE
Checkout Started      2026-08-01   STALE
Subscribe             2026-08-01   STALE
Payment Info Added    (no field)   [NEEDS: the last received date for this event]

Other events
Add to Cart            5 days ago    STALE
Page View               Today        LIVE
Warranty Registration   -            NEVER FIRED

Counts
LIVE:        2 / 7
STALE:       3 / 7
NEVER FIRED: 1 / 7
NEEDS DATE:  1 / 7
```
