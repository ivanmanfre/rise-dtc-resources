# Fixture B, four links that should all pass

Invented brand and invented links. Not a record of any account.
Exercises the zero-baseline branch of the counts block.

---

Platform: Meta
https://corwinandvale.com/products/candle-set?utm_source=meta&utm_medium=paid_social&utm_campaign=eoy_prospecting

Platform: Meta
https://corwinandvale.com/products/candle-set?utm_source=meta&utm_medium=paid_social&utm_campaign=eoy_retargeting

Platform: Google
https://corwinandvale.com/collections/gifts?utm_source=google&utm_medium=cpc&utm_campaign=brand_search

Platform: TikTok
https://corwinandvale.com/products/travel-tin?utm_source=tiktok&utm_medium=paid_social&utm_campaign=ugc_test
