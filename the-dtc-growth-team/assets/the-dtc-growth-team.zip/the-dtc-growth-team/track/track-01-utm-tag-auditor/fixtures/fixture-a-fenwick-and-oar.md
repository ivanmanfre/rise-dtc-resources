# Fixture A, nine links pasted as one block

Invented brand and invented links. Not a record of any account.
Exercises the CHARACTER, DUPLICATE and MISSING branches and Refusal 3.

---

Platform: Meta
https://fenwickandoar.com/products/dark-roast?utm_source=meta&utm_medium=paid_social&utm_campaign=prospecting_broad

Platform: Meta
https://fenwickandoar.com/products/dark-roast&utm_source=meta&utm_medium=paid_social

Platform: Meta
https://fenwickandoar.com/products/subscription?utm_source=meta&utm_medium=paid_social&utm_source=facebook

Platform: Google
https://fenwickandoar.com/pages/gift-set?utm_source=google&utm_campaign=holiday

Platform: Meta
https://fenwickandoar.com/products/dark-roast?utm_source=meta&utm_medium=paid social&utm_campaign=prospecting

Platform: TikTok
https://fenwickandoar.com/products/sampler?utm_source=meta&utm_source=tiktok&utm_campaign=cross promo

Platform: Meta
https://fenwickandoar.com/products/cold-brew?variant=41822?utm_source=meta&utm_medium=paid_social

Platform: Google
https://fenwickandoar.com/collections/beans?utm_source=google&utm_medium=cpc&utm_campaign=oat&honey_launch

Platform: Meta
https://bit.ly/3xF9k2Q
