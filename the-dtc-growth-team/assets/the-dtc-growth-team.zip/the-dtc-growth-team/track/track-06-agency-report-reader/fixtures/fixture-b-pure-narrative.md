# Fixture B, a report with no claims at all

Invented sender. Not a record of any account or any agency. Designed to
exercise the zero-baseline branch: every sentence is narrative, so NO CLAIMS
TO CHECK should print and no fraction should appear.

---

Subject: Quick check-in

Hope you're doing well. It's been a busy month on our end getting everything
set up the way we like it. The team has really enjoyed working on this
account and we're excited about where things are headed. Let us know if you
want to hop on a call to chat through anything.
