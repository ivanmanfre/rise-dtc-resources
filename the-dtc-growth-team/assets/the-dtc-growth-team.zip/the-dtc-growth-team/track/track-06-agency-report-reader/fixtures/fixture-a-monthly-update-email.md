# Fixture A, a five-sentence monthly update email

Invented sender and invented figures. Not a record of any account or any
agency. Designed to exercise a checkable claim whose own arithmetic does not
match what the report states, two narrative sentences, one plain uncheckable
claim, and one compound sentence carrying two uncheckable claims that has to
be split before it can be classed.

---

Subject: Your July update

Great month for the brand overall, the team is really proud of this one.

We drove a 34% increase in purchases this month, from 120 in June to 150 in
July.

ROAS improved to 4.2 this month.

We also lowered cost per acquisition by 18% and increased average order
value by 9%.

Looking forward to another strong month ahead.
