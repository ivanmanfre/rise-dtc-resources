---
name: track-06-agency-report-reader
description: "Use when you've just been sent a marketing report or update email and want to know which lines you can actually verify before you reply. Takes the summary numbers and the sentences around them, typed or pasted from the report, and returns the claims that cannot be checked from what was supplied, each with the one-line reply that asks for the exact missing figure. Triggers on \"is this report legit\", \"what should I ask my agency about this update\", \"can I verify these numbers\", \"what's missing from this report\", \"help me reply to this marketing update\"."
---

# The DTC Growth Team, TRACK, unit 06 of 06 (agent 06 of 30)

## What this does

Reads the report or update you were sent, sentence by sentence, and sorts
every claim in it into one that shows its own working and one that does not,
so you know exactly what to ask for before you reply.

Out comes one file, `report-check.md`.

**The line only this unit produces:** the claims in the report that cannot be
checked from what was supplied, each with the one-line reply that asks for
the exact missing figure.

This unit rules only on whether a claim is checkable. It does not rule on
whether the reported work was good or bad, and it says so in every output.

## Required input

**The summary numbers and the sentences around them**, typed or pasted from
the report or the email you were sent. Paste the section that makes the
claims, not a summary of it; this unit reads sentence by sentence, and a
paraphrase defeats it the same way a summarized proposal defeats a promise
audit.

## What it refuses

**Refusal, no verdict on the work.** Refuses to say whether the reported work
was good or bad. It rules only on whether each claim is checkable, and prints
this refusal, in these words, on every run:

```
This unit rules only on whether each claim is checkable. It does not rule on
whether the reported work was good or bad.
```

## Method

**Step 1, split into sentences.** Read the pasted text sentence by sentence.

**Step 2, tag each sentence.** Two tags:

- `CLAIM`: states a fact, a result, a number or a comparison.
- `NARRATIVE`: carries no checkable content ("great month," "the team is
  excited," "looking ahead to next month"). Routed out, printed separately,
  with the reason "no checkable content," never silently dropped.

**Step 3, split a sentence that carries more than one claim.** A sentence
naming two separate results ("we lowered CPA by 18% and raised AOV by 9%")
is split into one claim row per result before classing. Each half is judged
for checkability on its own; one being checkable does not carry the other.

**Step 4, class each CLAIM.** Exactly one of two:

- `CHECKABLE`: the report itself states the raw figures the claim's own
  arithmetic rests on (a baseline and a result, a numerator and a
  denominator, two dated figures being compared).
- `UNCHECKABLE`: the report states only the derived claim (a percent, a
  ratio, a "improved to X") with the raw figures behind it absent from what
  was supplied.

**Step 5, re-derive every CHECKABLE claim.** Using only the figures the report
itself supplied, redo the claim's arithmetic and print the raw division:

```
report states: <the claim, verbatim>
figures supplied: <baseline> and <result>
recomputed: (<result> - <baseline>) / <baseline> = <decimal> = <percent>
status: MATCH | ARITHMETIC MISMATCH (report says <x>, this computes to <y>)
```

This checks whether the report's own sentence agrees with the report's own
numbers. It says nothing about whether the underlying numbers are real; that
question is outside what a report alone can answer, and this unit does not
answer it.

**Step 6, the reply for every UNCHECKABLE claim.** One line, naming the exact
figures that would make it checkable:

```
claim: "<the claim, verbatim>"
reply: "Can you share the <baseline figure> and <result figure> behind this
<the specific number or percent named in the claim>?"
```

**Step 7, the zero-baseline branch.** If Step 2 tags zero sentences as
`CLAIM`, stop before any count prints:

```
NO CLAIMS TO CHECK
Every sentence in what you pasted is narrative. There is nothing here with a
number or a result attached to verify, and no fraction is printed below.
```

**Step 8, the counts.** State the population once, in words, above the
counts: *every claim sentence in the report you pasted, after splitting any
sentence that carried more than one claim, counted once. Narrative sentences
carry no checkable content and are routed out, printed separately, never
folded into either class below.*

```
CHECKABLE:   <n> / <n>
UNCHECKABLE: <n> / <n>
```

## Output format

Write one file, `report-check.md`.

```
# Report check
population: every claim sentence in the report you pasted, after splitting
  any sentence with more than one claim, counted once = <n>
narrative sentences routed out (no checkable content): <n>

## Checkable claims
### Claim <k>
report states: "<verbatim>"
recomputed: <the division from Step 5>
status: MATCH | ARITHMETIC MISMATCH (<report figure> vs <recomputed figure>)

## Uncheckable claims
### Claim <k>
claim: "<verbatim>"
reply: "<the one-line ask from Step 6>"

## Narrative, routed out
- "<sentence>"

## Counts
CHECKABLE:   <n> / <n>
UNCHECKABLE: <n> / <n>

## Refusal
This unit rules only on whether each claim is checkable. It does not rule on
whether the reported work was good or bad.
```

## Edge cases

**A claim compares two periods but only names one of them** ("purchases are
up compared to last month," with no last-month figure printed anywhere in the
report). This is `UNCHECKABLE`; the comparison period is one of the missing
figures named in the reply.

**A claim's arithmetic checks out but the underlying figures still look
suspicious to you** (a purchase count that seems too high for the spend
stated). This unit's MATCH status says only that the report's sentence agrees
with the report's own numbers. Whether those numbers themselves are accurate
is outside what a report alone can answer, and MATCH is not a claim that they
are.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never say a reported claim is false. `ARITHMETIC MISMATCH` states that the
  report's own sentence disagrees with the report's own numbers, nothing
  about the numbers' accuracy.
- Never rule on whether the reported work was good or bad. The refusal
  prints, verbatim, every run.
- Never invent the baseline or result figure behind an uncheckable claim.
- Never fold a narrative sentence into the claim count, in either direction.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, supercharge, harness, utilize.

## Worked case

**This is fixture `fixtures/fixture-a-monthly-update-email.md` run literally,
line by line, under the rules above. It is not a separate example.**

```
Sentence 1: "Great month for the brand overall, the team is really proud of
this one." -> NARRATIVE, routed out.

Sentence 2: "We drove a 34% increase in purchases this month, from 120 in
June to 150 in July." -> CLAIM, CHECKABLE.
  recomputed: (150 - 120) / 120 = 30 / 120 = 0.25 = 25%
  status: ARITHMETIC MISMATCH (report says 34%, this computes to 25%)

Sentence 3: "ROAS improved to 4.2 this month." -> CLAIM, UNCHECKABLE.
  reply: "Can you share the ad spend and revenue figures this 4.2 ROAS is
  computed from, and last month's ROAS to compare against?"

Sentence 4: "We also lowered cost per acquisition by 18% and increased
average order value by 9%." -> two claims, split before classing.
  Claim 4a: "lowered cost per acquisition by 18%" -> UNCHECKABLE.
    reply: "Can you share the June and July cost per acquisition figures
    this 18% is computed from?"
  Claim 4b: "increased average order value by 9%" -> UNCHECKABLE.
    reply: "Can you share the June and July average order value figures
    this 9% is computed from?"

Sentence 5: "Looking forward to another strong month ahead." -> NARRATIVE,
routed out.
```

```
Counts
population: every claim sentence in the report you pasted, after splitting
  any sentence with more than one claim, counted once = 4
narrative sentences routed out: 2

CHECKABLE:   1 / 4
UNCHECKABLE: 3 / 4
```
