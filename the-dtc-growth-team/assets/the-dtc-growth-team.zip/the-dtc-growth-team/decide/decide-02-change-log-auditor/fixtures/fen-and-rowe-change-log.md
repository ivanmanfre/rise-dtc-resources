# Fixture, one month of changes

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise the split-per-line rule, a same-day collision, a next-day collision
and the not-yet-elapsed branch, alongside one clean evaluable change.

Today's date for this run: Aug 28

Changes this month:
- Jul 20: switched the landing page URL on Prospecting to the new offer page
- Aug 3: raised the daily budget on Prospecting from $150 to $220 and launched
  a new hook video creative on the same campaign
- Aug 12: turned off the Best Sellers retargeting audience segment
- Aug 13: raised the price of the Everyday Serum from $38 to $42
- Aug 24: installed the Upsell Bear app on the Shopify checkout
