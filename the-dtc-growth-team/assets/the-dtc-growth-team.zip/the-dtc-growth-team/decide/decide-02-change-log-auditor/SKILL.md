---
name: decide-02-change-log-auditor
description: "Use when several things changed in your account or on your site this month and you want to know which of them you can actually learn anything from. Takes the list of what you changed and when, and returns EVALUABLE or CONFOUNDED for every change, naming exactly what it collides with. Triggers on \"what did I even change this month\", \"can I tell if that budget change worked\", \"audit my change log\", \"which of my changes can I read\", \"did I break my own test by changing too much at once\"."
---

# The DTC Growth Team, DECIDE, unit 02 of 6: the change log auditor

## What this does

Takes the list of what changed in your account or on your site this month and
rules, per change, on whether it is judgeable at all.

**The line only this unit produces:** per change, the date, the metric window
it owns, and an EVALUABLE or CONFOUNDED status, with the exact thing it
collides with named beside it.

**Standing refusal, true on every run of this unit:** this unit never says
what a metric move was caused by. It rules only on whether a change is
judgeable. Take an EVALUABLE change to your own numbers if you want to read
what it did.

## Required input

1. **What you changed and when**, for the stated month: budgets, creatives,
   audiences, page edits, price changes, apps installed. One line per change,
   with a date. Dates from memory or the platform's edit-history screen.
2. **Today's date**, or the date you are running this audit from.

A single line may carry more than one change (see Step 1). This unit splits
those before classing; it does not average or merge them.

## What it refuses

**Refusal 1, nothing to audit.** If the paste carries zero dated changes,
stop:

```
NO CHANGES SUPPLIED
Nothing pasted for this month carries both a change and a date. There is
nothing here to rule on.
```

**Refusal 2, never rules on cause.** If asked what a change did to a number,
this unit still only prints the standing refusal above and the change's
EVALUABLE or CONFOUNDED status. It does not attribute.

## Method

**Step 1, split every line into one change per fact.** A line reading "raised
the budget on X and launched a new creative on X" is two changes, same date,
same campaign, different facts. Print both as separate rows before doing
anything else. This is the rule the whole unit sits on: one input line
carrying several facts gets several statuses, never one status standing in
for all of them.

**Step 2, population.** State it once, in words: *every change, after
splitting, that carries a date, counted once each.* A change with no date
prints `[NEEDS: the date this change happened]` and is excluded from
classing.

**Step 3, the read window.** This unit uses one flat window for every change,
7 days from the change's own date, regardless of change type. A shorter or
type-specific window is a media-buying judgment call outside this unit's
scope, so it is not made here.

**Step 4, the collision rule.** Two changes collide if the distance between
their dates is 7 days or fewer, counted either direction. Where a change
collides with one or more other changes, it is CONFOUNDED and every colliding
change is named, by date and description.

**Step 5, the elapsed-time branch.** Where a change collides with nothing else
but its own 7-day window has not fully passed as of today's date, it is also
CONFOUNDED, collision named as `elapsed time (needs <n> more day(s))`, where
`<n> = 7 - (today's date - the change's date)`. This is not a collision with
another change; it is named as its own reason so it is never confused with
one.

**Step 6, EVALUABLE.** A change is EVALUABLE only when it collides with no
other change and its 7-day window has fully elapsed as of today's date.

**Step 7, the metric window each change owns.** For an EVALUABLE change, print
its date through date + 7 days as the window. A CONFOUNDED change prints the
same window with `(unreadable, see collision)` appended.

## Output format

```
# Change log audit, month of <month>, run as of <today's date>
Population: <the Step 2 sentence, filled in>

## Changes
### <date>, "<change, one fact>"
window this change owns: <date> to <date + 7d>
status: EVALUABLE | CONFOUNDED
collides with: <the other change(s), by date and description> | elapsed time (needs <n> more day(s)) | none

## Excluded, no date
[NEEDS: the date this change happened] for "<change text>"

## Counts
EVALUABLE:  <n> / <total> = <decimal> = <percent>
CONFOUNDED: <n> / <total> = <decimal> = <percent>

This unit does not rule on cause. Take an EVALUABLE change to your own
numbers if you want to read what it did.
```

## Worked case

This worked case is the literal fixture run in
`fixtures/fen-and-rowe-change-log.md`, verified line by line against the
rules above. Today's date for this run: Aug 28.

Supplied lines, after Step 1 splitting:
1. Jul 20, "switched the landing page URL on Prospecting to the new offer page"
2. Aug 3, "raised the daily budget on Prospecting from $150 to $220" (split from a two-fact line)
3. Aug 3, "launched a new hook video creative on Prospecting" (split from the same line)
4. Aug 12, "turned off the Best Sellers retargeting audience segment"
5. Aug 13, "raised the price of the Everyday Serum from $38 to $42"
6. Aug 24, "installed the Upsell Bear app on the Shopify checkout"

Distances checked against every other change, 7-day rule:
- #1 (Jul 20) vs #2 (Aug 3): 14 days apart. No collision with anything.
  Window Jul 20 to Jul 27, fully elapsed by Aug 28. -> **EVALUABLE**.
- #2 (Aug 3) vs #3 (Aug 3): 0 days apart -> collide.
  vs #4 (Aug 12): 9 days apart, no collision. -> **CONFOUNDED**, collides with
  #3 (same day, new creative launch).
- #3 (Aug 3) vs #2 (Aug 3): 0 days apart -> collide. -> **CONFOUNDED**,
  collides with #2 (same day, budget raise).
- #4 (Aug 12) vs #5 (Aug 13): 1 day apart -> collide. -> **CONFOUNDED**,
  collides with #5 (price change, 1 day later).
- #5 (Aug 13) vs #4 (Aug 12): 1 day apart -> collide. vs #6 (Aug 24): 11 days
  apart, no collision. -> **CONFOUNDED**, collides with #4 (audience turned
  off, 1 day earlier).
- #6 (Aug 24) vs every other change: nearest is #5 at 11 days, no collision.
  Window Aug 24 to Aug 31. Today is Aug 28, so only 4 of 7 days have passed.
  -> **CONFOUNDED**, collides with elapsed time (needs 3 more day(s)).

Counts, population = 6 changes, 0 excluded, total = 6:
EVALUABLE: 1 / 6 = 0.167 = 16.7%
CONFOUNDED: 5 / 6 = 0.833 = 83.3%

The EVALUABLE row and the CONFOUNDED row both print with real entries in this
fixture; a second fixture, `fixtures/no-changes-this-month.md`, exercises
Refusal 1.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never attribute a metric move to any change, in any wording. The standing
  refusal prints on every run.
- Never merge two facts on one input line into a single status. Split first,
  per Step 1, always.
- Never invent a date, a change, an app name or a price the input did not
  carry.
- Never shrink or lengthen the 7-day window for a specific change type. It is
  flat across the whole unit.
- No em dashes. No exclamation marks.
- Audience word is DTC, never "ecom". Brand referenced only as RISE DTC where
  a brand name is needed at all.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `we don't X we Y`, `stop X start Y`, `less X more
  Y`). No "Most [group]" claims. No time-to-value claim, no price anchor, no
  effort claim.
