---
name: decide-05-net-revenue-corrector
description: "Use when the return your ad platform reports feels too good next to what actually hit your bank account. Takes gross revenue, discounts, refunds and ad spend for one matched window and returns the return on ad spend restated on revenue you actually kept. Triggers on \"what's my real ROAS after discounts and refunds\", \"my platform ROAS looks better than my bank account\", \"restate my return net of refunds\", \"is my ad platform lying to me about revenue\"."
---

# The DTC Growth Team, DECIDE, unit 05 of 6: the net revenue corrector

## What this does

Takes the gross revenue your ad platform is crediting itself for and restates
the return on ad spend on the revenue you actually kept, after discounts and
refunds for the same window.

**The line only this unit produces:** return on ad spend restated on revenue
net of discounts and refunds, with the gross figure printed beside it and the
gap between the two named.

This restates one window. It does not decompose a change across two periods,
and it does not tell you which channel, campaign or ad the discounts and
refunds belong to.

## Required input

For **one stated window**, all four of:
1. **Gross revenue**, from the Shopify analytics screen.
2. **Discounts given**, from the same screen, same window.
3. **Refunds**, from the same screen, same window.
4. **Ad spend**, from Ads Manager, for the same window.

## What it refuses

**Refusal, the windows don't match.** If the Shopify window and the Ads
Manager window are different date ranges, stop, and print both:

```
WINDOWS DON'T MATCH, NOTHING RESTATED
Shopify window:    <date range>
Ads Manager window: <date range>

This unit only restates a return where the revenue and the spend describe the
same days. Repull one of the two screens on the matching window and paste
again.
```

## Method

**Step 1, population.** State it once, in words: *one stated window, one ad
account, the four figures you pasted for that window.*

**Step 2, the zero-spend branch.** If ad spend for the window is $0, no
return can be computed on either side:

```
NO SPEND THIS WINDOW
gross revenue: $<gross>   discounts: $<discounts>   refunds: $<refunds>
ad spend: $0

Revenue happened. No ad spend bought it in this window, so there is no return
to state, gross or net. Treat this as a missing line, never as a zero value.
```

Discounts and refunds still print on their own lines even in this branch;
only the two return figures are withheld.

**Step 3, gross return.**

```
gross ROAS = gross revenue / ad spend = $<gross> / $<spend> = <gross return>x
```

**Step 4, net revenue.** Discounts and refunds each print as their own line,
never folded into one "adjustments" figure:

```
discounts given this window:  $<discounts>
refunds this window:          $<refunds>
net revenue = gross revenue - discounts - refunds
            = $<gross> - $<discounts> - $<refunds>
            = $<net>
```

**Step 5, net return.**

```
net ROAS = net revenue / ad spend = $<net> / $<spend> = <net return>x
```

**Step 6, the gap.**

```
gap = gross ROAS - net ROAS = <gross return>x - <net return>x = <gap>x
```

## Output format

```
# Net revenue correction, window: <window>
[if windows don't match: the Refusal block only, stop here]
[if ad spend = $0: the Step 2 block, stop here]

gross ROAS = <the Step 3 division>
discounts given: $<discounts>
refunds:         $<refunds>
net revenue = <the Step 4 subtraction>
net ROAS = <the Step 5 division>

## The gap
gross <gross return>x vs net <net return>x, gap: <gap>x
```

## Worked case

This worked case is the literal fixture run in
`fixtures/fen-and-rowe-week.md`, verified line by line against the rules
above.

Window: Aug 1 to Aug 7. Both screens pulled on this same window.

gross revenue: $18,400   discounts: $1,200   refunds: $640   ad spend: $4,100.

gross ROAS = $18,400 / $4,100 = 4.488x.
net revenue = $18,400 - $1,200 - $640 = $16,560.
net ROAS = $16,560 / $4,100 = 4.039x.
gap = 4.488x - 4.039x = 0.449x.

A second fixture, `fixtures/fen-and-rowe-mismatched-windows.md`, exercises
the window-mismatch refusal, and a third, `fixtures/fen-and-rowe-no-spend.md`,
exercises the zero-spend branch.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never restate a return across two different date ranges. The Refusal fires
  instead, every time.
- Never fold discounts and refunds into one figure. Each prints on its own
  line, always.
- Never compute a return against $0 ad spend. The Step 2 branch fires
  instead, and no division prints.
- Never decompose the gap across more than the one stated window. This is a
  restatement of one window, not a period-over-period ledger.
- No em dashes. No exclamation marks.
- Audience word is DTC, never "ecom". Brand referenced only as RISE DTC where
  a brand name is needed at all.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `we don't X we Y`, `stop X start Y`, `less X more
  Y`). No "Most [group]" claims. No time-to-value claim, no price anchor, no
  effort claim.
