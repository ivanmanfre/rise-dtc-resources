# Fixture, two screens pulled on different windows

Invented for testing. Note: designed to exercise the window-mismatch refusal.

Shopify analytics window: Aug 1 to Aug 7
- gross revenue: $18,400
- discounts given: $1,200
- refunds: $640

Ads Manager window: Jul 25 to Jul 31
- ad spend: $3,950
