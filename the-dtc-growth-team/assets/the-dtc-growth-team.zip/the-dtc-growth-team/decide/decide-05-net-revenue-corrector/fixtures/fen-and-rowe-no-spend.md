# Fixture, a window with organic revenue and no ad spend

Invented for testing. Note: designed to exercise the zero-spend branch.

Window: Aug 8 to Aug 14 (both screens pulled on this window)

Shopify analytics:
- gross revenue: $2,150
- discounts given: $0
- refunds: $95

Ads Manager, same window:
- ad spend: $0 (campaigns were off this window)
