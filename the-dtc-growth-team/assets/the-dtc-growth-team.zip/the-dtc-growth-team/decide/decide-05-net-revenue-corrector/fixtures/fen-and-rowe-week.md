# Fixture, one matched week

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise the ordinary restatement path with both windows matching.

Window: Aug 1 to Aug 7 (both screens pulled on this window)

Shopify analytics:
- gross revenue: $18,400
- discounts given: $1,200
- refunds: $640

Ads Manager, same window:
- ad spend: $4,100
