# Fixture, a month where nothing is actually losing money

Invented for testing. Same account shape as `fen-and-rowe-october-losing.md`,
minus the zero-purchase campaign, at a looser afford figure. Note: designed
to exercise the NOTHING TO FREEZE branch.

Cost per purchase I can afford: $50.00
Need the bleeding stopped by: Nov 1

Current month, per-campaign rows:
| campaign | spend | purchases |
|---|---|---|
| Prospecting - Video | $6,200 | 240 |
| Prospecting - Static | $4,100 | 95 |
| Retargeting | $1,800 | 88 |
| Interest - Wellness | $2,650 | 61 |
