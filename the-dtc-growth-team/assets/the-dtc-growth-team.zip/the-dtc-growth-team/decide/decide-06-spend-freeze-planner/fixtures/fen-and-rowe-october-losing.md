# Fixture, a month where every campaign is over budget

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise the never-turn-off-everything refusal and the zero-purchase,
spend-ongoing status, together.

Cost per purchase I can afford: $20.00
Need the bleeding stopped by: Nov 1

Current month, per-campaign rows:
| campaign | spend | purchases |
|---|---|---|
| Prospecting - Video | $6,200 | 240 |
| Prospecting - Static | $4,100 | 95 |
| Retargeting | $1,800 | 88 |
| Lookalike - Broad | $3,300 | 0 |
| Interest - Wellness | $2,650 | 61 |
