---
name: decide-06-spend-freeze-planner
description: "Use when this month's ad spend is genuinely losing money and you need an order to shut things down in, rather than a panic that turns everything off at once. Takes your per-campaign spend and cost per purchase, the cost per purchase you can afford, and a deadline, and returns the ordered shutdown list, the one campaign that stays on, and the metric that has to recover. Triggers on \"help me stop the bleeding this month\", \"what order do I turn campaigns off in\", \"my account is losing money, what do I cut first\", \"plan a spend freeze\"."
---

# The DTC Growth Team, DECIDE, unit 06 of 6: the spend freeze planner

## What this does

Reads the current month's per-campaign spend and cost per purchase and plans
the stop, in order, keeping exactly one campaign alive so the account still
produces something to read.

**The line only this unit produces:** the ordered shutdown list, the single
metric that must recover, and the date the freeze is judged.

## Required input

1. **Per-campaign spend and cost per purchase for the current month**, from
   Ads Manager, one row per campaign.
2. **The cost per purchase you can afford.**
3. **The date you need the bleeding stopped by.**

## What it refuses

**Refusal, never turns off every campaign at once.** Where every campaign in
the paste is over the affordable cost per purchase (or has zero purchases
with spend ongoing), this unit does not print a shutdown list that empties
the account:

```
ONE CAMPAIGN STAYS ON
"<campaign name>" stays on, at $<its cost per purchase> against $<afford>.

Every other campaign you pasted is over what you can afford. This one is
closest to it. The account needs at least one live campaign to keep
producing purchases to read; a fully dark account cannot tell you when to
turn anything back on.
```

**Named branch, nothing to freeze.** Where every campaign in the paste is at
or under the affordable cost per purchase, there is no freeze to plan:

```
NOTHING TO FREEZE
Every campaign you pasted is at or under the cost per purchase you can
afford. This unit plans a stop for money that is losing you money, and none
of what you pasted is.
```

## Method

**Step 1, population.** State it once, in words: *every campaign row you
pasted for the current month, counted once.*

**Step 2, the zero-purchase class.** A campaign with spend > $0 and 0
purchases has no cost per purchase to compute (nothing to divide by). This is
not a gap; it is a decidable, fully bad state, printed as its own status:

```
"<campaign name>": spend $<spend>, 0 purchases -> ZERO READ, SPEND ONGOING
```

Every campaign in this status is ranked first in the shutdown order,
automatically, ahead of any cost-per-purchase comparison.

**Step 3, overage, for every campaign with purchases > 0.**

```
overage = cost per purchase / afford = $<cpp> / $<afford> = <overage>x
```

A campaign is a shutdown candidate if overage > 1.0.

**Step 4, the nothing-to-freeze check.** If no campaign is ZERO READ, SPEND
ONGOING and every campaign has overage <= 1.0, the named branch fires and
Steps 5 through 7 do not run.

**Step 5, the refusal check.** If every campaign in the paste is either ZERO
READ, SPEND ONGOING or has overage > 1.0, the Refusal fires: the campaign
with the lowest overage among the purchase-bearing rows stays on, printed
with its overage. If at least one campaign has overage <= 1.0, no forced
stay-on choice is needed; the affordable campaigns are simply not shutdown
candidates and nothing forces the account dark.

**Step 6, the order.** Shutdown candidates, worst first: every ZERO READ,
SPEND ONGOING campaign, then every remaining candidate sorted by overage,
highest first.

**Step 7, the metric that must recover.**

```
blended CPA = total spend across every pasted campaign / total purchases across every pasted campaign
            = $<total spend> / <total purchases>
            = $<blended CPA>

Must fall to $<afford> or below.
```

A zero-purchase campaign's spend adds to the numerator and nothing to the
denominator, which is exactly why it drags this figure hardest.

## Output format

```
# Spend freeze plan, current month, judged by: <deadline date>
Afford: $<afford>
[if nothing to freeze: that block only, stop here]
[if refusal fires: the "ONE CAMPAIGN STAYS ON" block]

## Shutdown order
1. "<campaign>"  <ZERO READ, SPEND ONGOING | overage <n>x>
2. "<campaign>"  overage <n>x
...

## Stays on
"<campaign>"  <its cost per purchase or ZERO READ status>  reason: <printed reason>

## Metric that must recover
<the Step 7 division>

## Judged by
<the deadline date supplied>
```

## Worked case

This worked case is the literal fixture run in
`fixtures/fen-and-rowe-october-losing.md`, verified line by line against the
rules above.

Afford: $20.00. Judged by: Nov 1.

- "Prospecting - Video": spend $6,200, purchases 240. CPA = $6,200 / 240 =
  $25.83. overage = $25.83 / $20.00 = 1.292x.
- "Prospecting - Static": spend $4,100, purchases 95. CPA = $4,100 / 95 =
  $43.16. overage = $43.16 / $20.00 = 2.158x.
- "Retargeting": spend $1,800, purchases 88. CPA = $1,800 / 88 = $20.45.
  overage = $20.45 / $20.00 = 1.0225x.
- "Lookalike - Broad": spend $3,300, purchases 0 -> ZERO READ, SPEND ONGOING.
- "Interest - Wellness": spend $2,650, purchases 61. CPA = $2,650 / 61 =
  $43.44. overage = $43.44 / $20.00 = 2.172x.

Every campaign is either ZERO READ, SPEND ONGOING or overage > 1.0 -> Refusal
fires. Lowest overage among purchase-bearing rows: Retargeting at 1.0225x.
**"Retargeting" stays on**, reason: closest to the cost per purchase you can
afford, and the account needs one live campaign to keep producing purchases
to read.

Shutdown order, worst first:
1. "Lookalike - Broad" (ZERO READ, SPEND ONGOING)
2. "Interest - Wellness" (overage 2.172x)
3. "Prospecting - Static" (overage 2.158x)
4. "Prospecting - Video" (overage 1.292x)

Metric that must recover:
total spend = $6,200 + $4,100 + $1,800 + $3,300 + $2,650 = $18,050.
total purchases = 240 + 95 + 88 + 0 + 61 = 484.
blended CPA = $18,050 / 484 = $37.29. Must fall to $20.00 or below.

Judged by: Nov 1.

A second fixture, `fixtures/fen-and-rowe-october-healthy.md`, exercises the
NOTHING TO FREEZE branch on the same account shape at a looser afford figure.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never print a shutdown list that turns off every campaign in the paste. The
  Refusal fires instead, every time the data would otherwise force it.
- Never compute a cost per purchase against 0 purchases. ZERO READ, SPEND
  ONGOING is its own printed status, ranked first, never averaged in as a
  division.
- Never fold ZERO READ, SPEND ONGOING campaigns into the overage ranking as
  if they had a comparable number. They are always first, by rule, not by
  arithmetic.
- Never invent an affordable cost per purchase, a deadline or a campaign name
  the input did not carry.
- No em dashes. No exclamation marks.
- Audience word is DTC, never "ecom". Brand referenced only as RISE DTC where
  a brand name is needed at all.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `we don't X we Y`, `stop X start Y`, `less X more
  Y`). No "Most [group]" claims. No time-to-value claim, no price anchor, no
  effort claim.
