# Fixture, three campaigns' weekly CPA

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise all three classes (WITHIN RANGE, DRIFTED, TOO FEW PERIODS) in one
paste, with the same weekly date preset used every time.

Prospecting - Video (weekly, same preset each time)
- week ending Jul 6: $22
- week ending Jul 13: $19
- week ending Jul 20: $24
- week ending Jul 27 (current): $31

Retargeting - Static (weekly, same preset each time)
- week ending Jul 6: $14
- week ending Jul 13: $16
- week ending Jul 20: $15
- week ending Jul 27 (current): $15

Lookalike - Broad (weekly, same preset each time)
- week ending Jul 20: $27
- week ending Jul 27 (current): $33
