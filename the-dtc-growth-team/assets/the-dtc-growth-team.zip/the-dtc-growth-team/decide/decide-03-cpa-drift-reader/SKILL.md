---
name: decide-03-cpa-drift-reader
description: "Use when this week's cost per purchase looks worse and you can't tell if that's a real problem or just how this campaign always moves. Takes at least four consecutive equal-length periods of cost per purchase for one campaign and returns WITHIN RANGE, DRIFTED or TOO FEW PERIODS. Triggers on \"is my CPA actually getting worse\", \"is this campaign drifting or is this normal\", \"read my weekly CPA and tell me if something changed\", \"has this campaign's cost per purchase gotten worse\"."
---

# The DTC Growth Team, DECIDE, unit 03 of 6: the CPA drift reader

## What this does

Reads a campaign's cost per purchase across its own trailing periods and rules
whether the current period is genuinely worse than anything that campaign has
already produced, or still inside what it has already shown you.

**The line only this unit produces:** per campaign, this period's cost per
purchase set against its own trailing periods, classed WITHIN RANGE, DRIFTED
or TOO FEW PERIODS.

This never compares one campaign to another and never uses a benchmark that
did not come from the campaign's own history.

## Required input

For each campaign you want read: the cost per purchase for at least 4
consecutive periods of equal length (for example, 4 consecutive weeks), read
off the same date preset each time so the periods are actually comparable.
The most recent period supplied is treated as "current"; every period before
it is "trailing".

## What it refuses

**Refusal, below the minimum.** A campaign with fewer than 4 total periods
supplied cannot establish a trailing range at all:

```
TOO FEW PERIODS
campaign: "<name>"
periods supplied: <n>          minimum: 4
periods still needed: <4 - n>

This campaign does not have enough of its own history pasted to say whether
the current period is normal for it.
```

## Method

**Step 1, group and sort.** Group rows by campaign. Sort each campaign's
periods chronologically. The last one is current; the rest are trailing.

**Step 2, population, per campaign.** State it once, in words, for each
campaign: *the trailing periods pasted for this campaign, excluding the
current one, counted once each.* If total periods < 4, Refusal fires and no
population statement or division follows for that campaign.

**Step 3, trailing stats.** For campaigns with >= 4 total periods (so >= 3
trailing):

```
trailing mean = sum of trailing CPAs / count of trailing periods
             = ($<a> + $<b> + $<c> [+ ...]) / <n>
             = $<mean>
trailing max = $<highest trailing CPA>
trailing min = $<lowest trailing CPA>
```

**Step 4, the rule.** WITHIN RANGE means the current period's cost per
purchase is at or below the worst cost per purchase this campaign has already
produced in its own trailing history. A current period better than anything
in the trailing history is also WITHIN RANGE, because this unit only flags a
cost per purchase that is worse than the campaign's own past, never one that
is unusually good.

```
current CPA $<x> vs trailing max $<max>
$<x> <= $<max>  -> WITHIN RANGE
$<x> >  $<max>  -> DRIFTED
```

**Step 5, print every class.** Every campaign you pasted appears in exactly
one class: WITHIN RANGE, DRIFTED or TOO FEW PERIODS. None are dropped for
being unremarkable.

## Output format

```
# CPA drift read, run as of <today's date>

## <campaign name>
periods supplied: <n>
[if TOO FEW PERIODS: the Refusal block, stop here for this campaign]
[if >= 4 periods:]
trailing periods: $<a>, $<b>, $<c> [, ...]
trailing mean = <the Step 3 division>
trailing max: $<max>   trailing min: $<min>
current period: $<x>
comparison: $<x> vs trailing max $<max> -> WITHIN RANGE | DRIFTED

## Counts
WITHIN RANGE:   <n> / <total campaigns>
DRIFTED:        <n> / <total campaigns>
TOO FEW PERIODS: <n> / <total campaigns>
```

## Worked case

This worked case is the literal fixture run in
`fixtures/fen-and-rowe-three-campaigns.md`, verified line by line against the
rules above.

**"Prospecting - Video"**: 4 periods, weekly, ending Jul 6 ($22), Jul 13
($19), Jul 20 ($24), Jul 27 (current, $31).
trailing periods: $22, $19, $24. trailing mean = ($22 + $19 + $24) / 3 =
$65 / 3 = $21.67. trailing max: $24. current $31 vs trailing max $24: $31 >
$24 -> **DRIFTED**.

**"Retargeting - Static"**: 4 periods, weekly, ending Jul 6 ($14), Jul 13
($16), Jul 20 ($15), Jul 27 (current, $15).
trailing periods: $14, $16, $15. trailing mean = ($14 + $16 + $15) / 3 = $45 /
3 = $15.00. trailing max: $16. current $15 vs trailing max $16: $15 <= $16 ->
**WITHIN RANGE**.

**"Lookalike - Broad"**: 2 periods supplied, ending Jul 20 ($27) and Jul 27
($33, current).
periods supplied: 2, minimum 4, periods still needed: 2 -> **TOO FEW
PERIODS**.

Counts, population = 3 campaigns pasted:
WITHIN RANGE: 1 / 3 = 0.333 = 33.3%
DRIFTED: 1 / 3 = 0.333 = 33.3%
TOO FEW PERIODS: 1 / 3 = 0.333 = 33.3%

All three classes print with real entries in this one fixture paste.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never class a campaign with fewer than 4 total periods. The Refusal fires
  instead, every time.
- Never compare one campaign's cost per purchase against another campaign's
  history. Every comparison is a campaign against its own past only.
- Never invent a benchmark, an industry-typical range, or a standard for what
  counts as drift. The only range that exists is the one built from the
  pasted periods.
- Never divide by a trailing count you did not actually count from the paste.
- No em dashes. No exclamation marks.
- Audience word is DTC, never "ecom". Brand referenced only as RISE DTC where
  a brand name is needed at all.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `we don't X we Y`, `stop X start Y`, `less X more
  Y`). No "Most [group]" claims. No time-to-value claim, no price anchor, no
  effort claim.
