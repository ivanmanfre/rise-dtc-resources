# Fixture, a target the account's own history has never produced

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise the NOT REACHED branch against the account's own best month on
record.

Target: $60,000 for October
Gross margin: 22%

Monthly ad spend and revenue:
- June: revenue $28,000, ad spend $7,400
- July: revenue $31,500, ad spend $8,100
- August: revenue $26,900, ad spend $6,050
- September: revenue $33,200, ad spend $9,700
