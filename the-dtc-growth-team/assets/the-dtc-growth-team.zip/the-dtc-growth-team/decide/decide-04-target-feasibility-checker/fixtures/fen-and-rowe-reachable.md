# Fixture, a target the same history clears twice

Invented for testing. Fen & Rowe is not a real brand. Same account history as
`fen-and-rowe-not-reached.md`, a lower target. Note: designed to exercise the
REACHABLE branch, for contrast against the same account's unreached target.

Target: $40,000 for October
Gross margin: 30%

Monthly ad spend and revenue:
- June: revenue $28,000, ad spend $7,400
- July: revenue $31,500, ad spend $8,100
- August: revenue $26,900, ad spend $6,050
- September: revenue $33,200, ad spend $9,700
