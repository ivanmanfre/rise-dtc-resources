# Fixture, a founder who only has two months of numbers

Invented for testing. Note: designed to exercise Refusal 1, too little
history to rule.

Target: $45,000 for October
Gross margin: 28%

Monthly ad spend and revenue:
- August: revenue $26,900, ad spend $6,050
- September: revenue $33,200, ad spend $9,700
