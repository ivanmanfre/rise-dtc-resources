---
name: decide-04-target-feasibility-checker
description: "Use before you commit to a revenue target for a coming month, to see what that target actually requires and whether your own account has ever produced it. Takes your target, your margin and your monthly ad spend and revenue history and returns the required blended return set against your own best and second-best months. Triggers on \"can I actually hit this revenue target\", \"is this month's goal realistic\", \"what would I need to spend to hit $X\", \"have I ever actually done this before\", \"check this target against my own numbers\"."
---

# The DTC Growth Team, DECIDE, unit 04 of 6: the target feasibility checker

## What this does

Takes a revenue target and states what blended return on ad spend it requires
under a stated spend ceiling, then sets that requirement against every month
of your own pasted history, including the months that hurt the case.

**The line only this unit produces:** the ad spend and blended return a
stated revenue target requires, set against the best and second-best figures
in your own pasted history.

## Required input

1. **The revenue target and the month it is for.** One number, one month.
2. **Your gross margin percentage.** One number, as a percent (for example
   35%).
3. **Monthly ad spend and revenue, for every month you have**, read off Ads
   Manager and the Shopify analytics screen. At least 3 months, or the unit
   cannot establish whether a return happened once or repeatedly.

## What it refuses

**Refusal 1, too little history to rule.** Fewer than 3 months of ad spend and
revenue supplied:

```
REACHABILITY UNKNOWN
months supplied: <n>          minimum: 3
months still needed: <3 - n>

This unit will not call a target reachable or not on fewer than 3 months of
your own history. A single good month proves the month happened. It does not
prove it repeats.
```

**Refusal 2, the math is undefined at this margin.** Gross margin of 0% or
below:

```
ZERO OR NEGATIVE MARGIN, NO SPEND CEILING TO SET
margin supplied: <n>%

At this margin there is no dollar amount of margin to reinvest in ad spend
without going net-negative on the target itself. This unit will not print a
required spend or a required return against a margin of zero or below.
```

## Method

**Step 1, the spend ceiling.** This unit sets the ad spend ceiling as the
full gross margin dollars on the target, stated plainly as a ceiling and not
a plan:

```
allowable ad spend = target revenue x margin
                    = $<target> x <margin as decimal>
                    = $<allowable spend>
```

If your own affordable ad spend for this target is a different, smaller
number, use that number instead; this unit only states the ceiling implied by
spending the full margin.

**Step 2, the required blended return.** Shown as a division, and printed even
though the target cancels out of it under this ceiling, because that
cancellation is itself the finding:

```
required blended return = target revenue / allowable ad spend
                         = $<target> / $<allowable spend>
                         = 1 / margin
                         = 1 / <margin as decimal>
                         = <required return>x
```

State this plainly in the output: under a full-margin spend ceiling, the
required blended return only depends on margin, not on the size of the
target. A bigger target requires more allowable dollars spent, at the same
required return.

**Step 3, population.** State it once, in words: *every month of ad spend and
revenue you pasted, counted once each, including the ones that hurt the
case.*

**Step 4, each month's own blended return.**

```
month's blended return = revenue / ad spend = $<rev> / $<spend> = <return>x
```

Print every month, sorted highest return to lowest. No month is omitted for
being a bad month.

**Step 5, the class.** This is the step built so the honest, unflattering
answer is the one that falls out of the arithmetic, not the one that has to
be argued for. A single lucky month does not clear this unit. Let B = the
best month's return, S = the second-best month's return, R = the required
return from Step 2:

| Condition | Class | What it means |
|---|---|---|
| R <= S | **REACHABLE** | required return has been met or beaten at least twice |
| S < R <= B | **REACHED ONCE ONLY** | required return has been hit exactly once, an outlier, not a pattern |
| R > B | **NOT REACHED** | required return has never been hit in the pasted history |

REACHABLE requires beating the required return at least twice. A single best
month clearing R without a second month clearing it prints REACHED ONCE ONLY,
never REACHABLE. This is deliberate: one outlier month is not evidence a
target repeats, and the honest label for that says so instead of rounding it
up to a yes.

## Output format

```
# Target feasibility, target $<target> for <month>
margin: <margin>%
[if Refusal 1 or 2 fired: that block only, stop here]

allowable ad spend = <the Step 1 division>
required blended return = <the Step 2 division>

## Your own history, every month
<month>: revenue $<rev> / spend $<spend> = <return>x
<month>: revenue $<rev> / spend $<spend> = <return>x
[... every month, sorted highest to lowest return]

best: <return>x (<month>)   second-best: <return>x (<month>)

## Verdict
REACHABLE | REACHED ONCE ONLY | NOT REACHED
<the Step 5 comparison, filled in>
```

## Worked case

This worked case is the literal fixture run in
`fixtures/fen-and-rowe-not-reached.md`, verified line by line against the
rules above.

Target: $60,000 for October. Margin: 22%.

allowable ad spend = $60,000 x 0.22 = $13,200.
required blended return = $60,000 / $13,200 = 1 / 0.22 = 4.545x.

History, 4 months pasted:
- June: revenue $28,000 / spend $7,400 = 3.784x
- July: revenue $31,500 / spend $8,100 = 3.889x
- August: revenue $26,900 / spend $6,050 = 4.446x
- September: revenue $33,200 / spend $9,700 = 3.423x

Sorted highest to lowest: August 4.446x, July 3.889x, June 3.784x, September
3.423x.
best = 4.446x (August), second-best = 3.889x (July).
required 4.545x vs best 4.446x: 4.545 > 4.446 -> **NOT REACHED**.

This is the unflattering branch: the required return has never been produced,
not even once, in four pasted months including the account's best month on
record. A second fixture, `fixtures/fen-and-rowe-reachable.md`, exercises the
same history against a lower target where REACHABLE genuinely fires, and a
third, `fixtures/fen-and-rowe-too-few-months.md`, exercises Refusal 1.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never call a target REACHABLE on fewer than two pasted months clearing the
  required return. One month clearing it is REACHED ONCE ONLY, never rounded
  up.
- Never drop a bad month from the printed history to make the comparison read
  better. Every pasted month prints, sorted by return, regardless of what it
  does to the case.
- Never substitute an industry-typical margin, return or CAC for one the
  reader did not supply.
- Never call a target reachable on fewer than 3 months of pasted history.
  Refusal 1 fires instead.
- Never print a required spend or return against a margin of zero or below.
  Refusal 2 fires instead.
- No em dashes. No exclamation marks.
- Audience word is DTC, never "ecom". Brand referenced only as RISE DTC where
  a brand name is needed at all.
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `we don't X we Y`, `stop X start Y`, `less X more
  Y`). No "Most [group]" claims. No time-to-value claim, no price anchor, no
  effort claim.
