# Fixture, one week of live ads

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise all four verdict classes in one paste, including the below-minimum
row.

Window: Aug 21 to Aug 27
Cost per purchase I can afford: $30.00

| ad name | spend | purchases |
|---|---|---|
| Prospecting - UGC Hook A | $2,400 | 62 |
| Retargeting - Static B | $540 | 24 |
| Lookalike - Video C | $310 | 7 |
| Interest - Wellness D | $870 | 30 |
