# Fixture, a paste with an incomplete row

Invented for testing. Fen & Rowe is not a real brand. Note: designed to
exercise the [NEEDS:] exclusion path where a row is missing its purchase
count.

Window: Aug 21 to Aug 27
Cost per purchase I can afford: $30.00

| ad name | spend | purchases |
|---|---|---|
| Prospecting - UGC Hook A | $2,400 | 62 |
| Retargeting - Static B | $540 | (export cut off before this column) |
| Interest - Wellness D | $870 | 30 |
