# Fixture, hook request for Marrow & Ash, MECHANISM angle

Invented for testing. Marrow & Ash is not a real brand. Note: this fixture
carries no guarantee, founder or review fact on purpose, to exercise the
device 10-12 skip.

---

Angle: MECHANISM

Product facts:
- What it is: a 15 lb weighted blanket, glass micro-bead fill sewn into individual channels, cotton duvet cover.
- What it does: evenly distributes pressure across the body to reduce nighttime movement.
- Price: $129.
- What's in the box: the weighted insert, the duvet cover, a care card.

Audience: people who wake up at 3am and can't fall back asleep.
