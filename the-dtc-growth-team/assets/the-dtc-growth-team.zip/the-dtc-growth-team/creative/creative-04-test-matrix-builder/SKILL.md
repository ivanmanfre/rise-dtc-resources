---
name: creative-04-test-matrix-builder
description: "Use when you are about to test a creative variable and want the test laid out so exactly one thing changes per cell. Takes the variable you want to learn about, how many creatives you can produce this month, your current ad as the control, and the cost per purchase you accept, and returns a row-by-row matrix with the question it cannot answer printed underneath. Triggers on \"build me a creative test matrix\", \"lay out this ad test properly\", \"am I testing one thing at a time\", \"what should this month's test rows be\", \"can I test hook and visual together\"."
---

# The DTC Growth Team, CREATIVE, unit 04 of 6: the test matrix

## What this does

Turns one named variable and a producible creative count into a row-by-row test matrix where exactly one thing changes per row, with the control row named and the question the matrix cannot answer printed underneath it.

**The line only this unit produces:** a test matrix where every row is a single-variable change from a named control, with the population of rows fixed to the creative count you actually stated, and the limitation of that specific matrix printed in words rather than implied.

## Required input

1. **The variable you want to learn about**, in one sentence (for example: "hook," "visual opening shot," "offer"). One variable. If the sentence names more than one, see What it refuses.
2. **The number of creatives you can produce this month.**
3. **The cost per purchase you accept.**
4. **A description of your current ad, to serve as the control row.** This is something you already have without opening a dashboard: the copy and a line on the visual of the ad you're running now. If you do not supply it, the control row is printed as a gap rather than guessed.

## What it refuses

**Refusal 1, cannot test what you cannot produce.** Fewer than 2 creatives producible this month:

```
CANNOT BUILD A MATRIX
Creatives producible this month: <n>

A test needs a control and at least one variant to compare it to, two
creatives minimum. <n> producible this month leaves nothing to lay into
rows. Come back when you can produce at least 2.
```

**Refusal 2, one matrix per variable.** The stated variable names two or more things (joined by "and," "or," a comma, or a slash, where each side is itself a plausible creative element such as hook, visual, offer, format, audience, CTA, price, angle):

```
CANNOT BUILD ONE MATRIX: TWO VARIABLES NAMED
variable as stated: "<what you wrote>"
detected: <VARIABLE A>, <VARIABLE B>

Testing both in the same rows changes two things per row, and a row that
changes two things never tells you which one moved the number. Two matrices
are needed instead, one per variable, each still changing one thing per row.

## Matrix A: <VARIABLE A>
Creatives allocated: [NEEDS: how many of the <n> creatives go to the <VARIABLE A> matrix]

## Matrix B: <VARIABLE B>
Creatives allocated: [NEEDS: how many of the <n> creatives go to the <VARIABLE B> matrix]

Supply the split and re-run each matrix on its own.
```

## Method

**Step 1, state the population.** "The creatives you can produce this month, counted once, all following the same test."

**Step 2, check the count.** Fewer than 2, Refusal 1 fires and nothing further is built.

**Step 3, check the variable.** Two or more named, Refusal 2 fires and no single matrix is built.

**Step 4, build the control row.** Row 1 is CONTROL, using the supplied description of your current ad. Not supplied, print `[NEEDS: a description of your current ad to serve as the control row]` in Row 1's place, and continue building the remaining rows regardless.

**Step 5, build the variant rows.** One row per remaining creative, up to the stated count, each reading: "change <variable> to `[NEEDS: variant content, the actual <variable> you will use]`. Everything else matches the control." This unit lays out the structure of the test; it does not write the variant's actual copy or visual, because that content was not supplied as input.

**Step 6, name what the matrix cannot answer.** Every row in this matrix holds every axis constant except the stated variable. Print the other axes by name (format, offer, audience, and any other named creative element not equal to the stated variable) and the sentence: "This matrix can tell you whether `<variable>` moves cost per purchase. It cannot tell you whether `<other axes>` move it too, because every row holds those constant."

**Step 7, state the read threshold in words.** "A row reads as a candidate winner only when its cost per purchase lands at or under the `<cost per purchase you accepted>`. This matrix does not say how many purchases a row needs before that reading is reliable."

## Output format

```
# Test matrix: <variable>
Creatives producible this month: <n>
Cost per purchase accepted: <$x>

## Matrix
Row 1 (CONTROL): <control description> | [NEEDS: a description of your current ad to serve as the control row]
Row 2: change <variable> to [NEEDS: variant 2 content]. Everything else matches the control.
Row 3: change <variable> to [NEEDS: variant 3 content]. Everything else matches the control.
(continue to Row <n>)

## What this matrix cannot answer
<the Step 6 sentence, with the held-constant axes named>

## Reading the results
<the Step 7 sentence>
```

## Worked case

This worked case IS the fixture run at `fixtures/marrow-ash-hook-matrix.md`, re-run literally against the method above and verified line by line before shipping.

Variable: "hook," a single variable, Refusal 2 does not fire. Creatives producible: 4, at or above the 2-creative minimum, Refusal 1 does not fire. Control description supplied (the current best-performing ad's copy and a two-sentence visual description), so Row 1 is filled rather than gapped.

Matrix: Row 1 CONTROL (filled from the supplied description). Rows 2-4: three variant rows, each reading "change hook to `[NEEDS: variant content]`," since the fixture supplies only the count of creatives, not the actual replacement hook copy for each row, that copy is unit 03's job, not this one's.

What this matrix cannot answer: held-constant axes printed as visual, offer, format, audience, since only hook is the stated variable.

Reading the results: printed against the fixture's stated $42 cost per purchase accepted.

Second fixture, `fixtures/marrow-ash-compound-variable.md`, exercises Refusal 2 directly: the stated variable is "hook and visual," detected as two elements, and the unit stops before building a single matrix, printing the two-matrix branch with both creative allocations gapped.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write the actual replacement copy or visual for a variant row. This unit lays out structure; it does not invent creative content the input did not supply.
- Never build a matrix where any row changes two things. Refusal 2 fires instead, every time the input demands it.
- Never state a statistical significance threshold, a sample size that guarantees a reliable read, or a time-to-value claim about how fast the test resolves.
- Never invent the control row from a guess. Gap it.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.
