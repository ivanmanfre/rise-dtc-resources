# Fixture, compound variable request

Invented for testing. Note: exercises Refusal 2, the two-variables-named
branch.

---

Variable to learn about: hook and visual

Creatives producible this month: 5

Cost per purchase accepted: $42

Current ad (control):
Copy: "You lie there at 11pm replaying the day instead of sleeping. The Ash
Blanket's glass beads apply even pressure across your body. Shop the
blanket."
Visual: A phone-shot bedroom at night, the blanket being pulled up over
someone in bed, cut to the product on a plain background with the price on
screen.
