# Fixture, test matrix request for Marrow & Ash

Invented for testing. Marrow & Ash is not a real brand. Note: this fixture
supplies a control description on purpose, to run the clean path with no
Row 1 gap.

---

Variable to learn about: hook

Creatives producible this month: 4

Cost per purchase accepted: $42

Current ad (control):
Copy: "You lie there at 11pm replaying the day instead of sleeping. The Ash
Blanket's glass beads apply even pressure across your body. Shop the
blanket."
Visual: A phone-shot bedroom at night, the blanket being pulled up over
someone in bed, cut to the product on a plain background with the price on
screen.
