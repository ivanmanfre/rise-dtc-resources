---
name: creative-02-ad-brief-writer
description: "Use when you have picked an angle and need a brief someone can shoot from without asking a question. Takes the angle, the product facts you can stand behind, and the format you are shooting, and returns a shot-by-shot brief with a claim boundary block naming exactly what the supplied facts allow. Triggers on \"write me an ad brief\", \"turn this angle into a shoot brief\", \"brief for the UGC video\", \"what can I actually claim in this ad\", \"brief this angle without overclaiming\"."
---

# The DTC Growth Team, CREATIVE, unit 02 of 6: the ad brief

## What this does

Turns one angle and a list of product facts into a shot-by-shot brief, with a claim boundary block that names every claim the supplied facts allow and refuses every line that would say more than the facts support.

**The line only this unit produces:** a claim boundary block generated from this shoot's own supplied facts, with every brief line traced back to one named fact or printed as `[NEEDS: the fact behind this claim]` in the line's place. Nothing here judges an ad that already ran; it exists before the shoot.

## Required input

1. **The angle you picked.** One of the eight named in unit 01 (Angle Gap Mapper), or a plain description if you did not run that unit first.
2. **Product facts you can stand behind**, each on its own line. At minimum: what it is, what it does, price, what is in the box. Optional, only if you actually have them: guarantee terms, a founder detail, review or rating data, a named comparison point.
3. **The format you are shooting.** One of: UGC talking-to-camera video, static image, carousel.

Never supply a claim you cannot back with a fact you are willing to name. If you want a line in the brief, the fact behind it goes in this list first.

## What it refuses

**Refusal 1, no line without a fact.** Every brief line traces to one supplied fact. Where no supplied fact supports a slot, the slot prints:

```
[NEEDS: the fact behind this claim]
attempted: <what this slot needed to say>
```

**Refusal 2, cannot brief an angle with nothing behind it.** Each angle has one minimum required fact type (table below). If that fact type is absent from the supplied facts:

```
CANNOT BRIEF THIS ANGLE
angle: <angle>
required fact type: <fact type>
facts supplied that support it: 0

<Angle> claims need a fact this shoot does not have. Supply the missing fact
type, or pick a different angle from the facts you actually supplied.
```

## Angle to required fact type

| Angle | Minimum required fact type |
|---|---|
| PROBLEM/SOLUTION | what it does |
| MECHANISM | a material or process fact |
| SOCIAL PROOF | a review or rating fact |
| COMPARISON | what it does, plus a described alternative |
| OFFER | a price or guarantee fact |
| IDENTITY | an audience description |
| URGENCY/SCARCITY | a stock or date fact |
| FOUNDER/ORIGIN | a founder detail |

## Method

**Step 1, state the population.** "The product facts you supplied, counted once each, plus the angle and the format."

**Step 2, gate the angle.** Check the required fact type for the picked angle against the supplied facts. Absent, fires Refusal 2 and stops. Present, continue.

**Step 3, build the claim boundary block.** For every supplied fact, restate it as one allowed claim sentence. This block is the only source of content the brief may draw from. Print the fact types you were not given, by name, as NOT ALLOWED.

**Step 4, build the shot list.** Five fixed slots, in this order, regardless of format:

1. **HOOK.** Draws from the picked angle's primary allowed claim.
2. **PROBLEM/CONTEXT.** Draws from a "what it does" fact restated as the problem it removes. Absent, Refusal 1.
3. **PRODUCT IN USE.** Draws from a "what it is" or material/process fact. Absent, Refusal 1.
4. **PROOF/DIFFERENTIATOR.** Draws from a review, guarantee, or comparison fact. Absent, Refusal 1.
5. **CTA.** Draws from the price fact. Absent, Refusal 1.

For each slot, write one line and name the fact it rests on. A slot with no supporting fact prints Refusal 1's block instead of a line, and the brief still ships with the other slots filled.

**Step 5, format direction.** Append one line of shooting or layout direction per slot, matched to the stated format. This line is craft direction, not a claim, and carries no new fact.

**Step 6, list unused facts.** Any supplied fact not used in a slot is printed under "facts not used," so nothing supplied silently disappears from the record.

## Output format

```
# Ad brief: <angle>
Format: <UGC video | static image | carousel>

## Claim boundary block
ALLOWED:
- <fact 1, restated as a claim>
- <fact 2, restated as a claim>
NOT ALLOWED (not supplied): <fact types absent, or "none, every optional type was supplied">

## Shot list
1. HOOK (<direction>)
   line: "<line>"          source: <fact used>
2. PROBLEM/CONTEXT (<direction>)
   line: "<line>" | [NEEDS: the fact behind this claim]     source: <fact used>
3. PRODUCT IN USE (<direction>)
   line: "<line>" | [NEEDS: the fact behind this claim]     source: <fact used>
4. PROOF/DIFFERENTIATOR (<direction>)
   line: "<line>" | [NEEDS: the fact behind this claim]     source: <fact used>
5. CTA (<direction>)
   line: "<line>" | [NEEDS: the fact behind this claim]     source: <fact used>

## Facts not used
- <fact>
(or: "None. Every supplied fact appears in a slot.")
```

## Worked case

This worked case IS the fixture run at `fixtures/marrow-ash-mechanism-brief.md`, re-run literally against the method above and verified line by line before shipping.

Angle: MECHANISM. Required fact type: a material or process fact. Supplied facts include "15 lb weighted blanket, glass micro-bead fill, cotton duvet cover" (what it is), which carries a material/process fact. Refusal 2 does not fire.

Claim boundary block, from the four supplied facts (what it is, what it does, price, what's in the box). No guarantee, review, or founder fact was supplied, so those are printed under NOT ALLOWED.

Shot list:
1. HOOK, drawn from the MECHANISM angle's primary claim (the glass micro-bead fill): filled, source named.
2. PROBLEM/CONTEXT, drawn from the "what it does" fact (evenly distributes pressure to reduce nighttime movement): filled, source named.
3. PRODUCT IN USE, drawn from the "what it is" fact: filled, source named.
4. PROOF/DIFFERENTIATOR: no review, guarantee, or comparison fact was supplied. Refusal 1 fires here: `[NEEDS: the fact behind this claim]`.
5. CTA, drawn from the price fact ($129): filled, source named.

Facts not used: "what's in the box" (blanket, duvet cover, care card) is not called by any of the five slots in this brief and is printed under facts not used, not silently dropped.

Second fixture, `fixtures/marrow-ash-social-proof-no-reviews.md`, exercises Refusal 2 directly: angle picked is SOCIAL PROOF and no review or rating fact was supplied, so the unit stops at the gate and never reaches the shot list.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a claim, a number, a date, a guarantee term or a founder detail the supplied facts did not carry.
- Never soften Refusal 2 into a brief built on a guessed fact.
- Never write "in your voice." This unit writes a neutral draft brief for the reader to rewrite in their own words. No voice sample is collected here.
- No self-audit step. If a slot is compliant it says so by simply printing a filled line; nothing sweeps the finished brief a second time to check itself.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.
