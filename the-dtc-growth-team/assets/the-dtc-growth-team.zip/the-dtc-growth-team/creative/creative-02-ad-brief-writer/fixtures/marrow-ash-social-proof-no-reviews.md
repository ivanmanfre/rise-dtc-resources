# Fixture, brief request with no review fact supplied

Invented for testing. Note: exercises Refusal 2, the CANNOT BRIEF THIS ANGLE
gate.

---

Angle picked: SOCIAL PROOF

Product facts:
- What it is: a 15 lb weighted blanket, glass micro-bead fill, cotton duvet cover.
- What it does: evenly distributes pressure across the body to reduce nighttime movement.
- Price: $129.
- What's in the box: the weighted insert, the duvet cover, a care card.

Format: static image.
