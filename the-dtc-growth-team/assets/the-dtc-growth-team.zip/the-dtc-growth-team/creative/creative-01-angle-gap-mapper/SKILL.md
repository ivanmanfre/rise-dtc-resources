---
name: creative-01-angle-gap-mapper
description: "Use before briefing new creative, to see which sales angles your live ads already occupy and which ones nothing is running against. Takes the ad name and primary text of your own live ads and returns each ad's angle with counts, plus the angles from a fixed list that no live ad occupies. Triggers on \"what angles am I even running\", \"map my current ad angles\", \"which angle has nobody touched\", \"audit my live ads by angle\", \"what am I not saying in my ads\"."
---

# The DTC Growth Team, CREATIVE, unit 01 of 6: the angle gap map

## What this does

Reads the primary text of every live ad you paste and assigns each one to exactly one angle from a fixed eight-angle list, based on the first claim-bearing sentence in it. Ads with no claim at all get their own row instead of a forced angle.

**The line only this unit produces:** the angles from the fixed list that zero of your live ads occupy, printed by name, next to the angles that are occupied and by which ads. This is an absence finding read off your own running creative, not a mining exercise over reviews or a judgment on how any ad is performing.

## Required input

1. **The ad name and primary text of each live ad**, copied from the Ads screen, up to 15 ads. Text only, exactly as it runs. An ad with a name but no text is still counted, it just cannot be classified.

Never supply spend, results, click-through rate, or any performance number. This unit does not read them and a performance number changes nothing about which angle an ad occupies.

## What it refuses

**Refusal 1, nothing to map.** If zero ads are pasted:

```
NO ADS SUPPLIED
Ads pasted: 0

There is no live creative to map, so there is nothing to compare against the
angle list and no absence to report. Absence is only meaningful measured
against ads that exist.
```

**Refusal 2, no forced angle.** An ad's text is refused an angle assignment, and printed in the UNCLASSIFIABLE row instead, whenever no sentence in it matches any of the eight angle tests below:

```
UNCLASSIFIABLE
"<ad name>": "<the ad's primary text>"
No sentence in this ad names a problem, a mechanism, a proof point, a
comparison, a price or guarantee term, an audience, a time or stock pressure,
or a founder account. Assigning the nearest-sounding angle would be a guess,
not a reading.
```

## The eight angles, fixed order

The order below is also the tie-break order: if one sentence matches more than one test, the earlier-numbered angle wins.

| # | Angle | The test |
|---|---|---|
| 1 | PROBLEM/SOLUTION | The sentence states a problem the buyer has, before or instead of any product-feature sentence. |
| 2 | MECHANISM | The sentence names a component, material or process and how it works. |
| 3 | SOCIAL PROOF | The sentence carries a review count, a rating, a quote, or names what other buyers experienced. |
| 4 | COMPARISON | The sentence contrasts the product against a described category alternative, without naming a specific competitor brand. |
| 5 | OFFER | The sentence states a number tied to money, a discount, a bundle or a guarantee condition. |
| 6 | IDENTITY | The sentence names a person type, a role, or a way of living the buyer joins, rather than a product fact. |
| 7 | URGENCY/SCARCITY | The sentence names a date, a countdown or a stock level. |
| 8 | FOUNDER/ORIGIN | The sentence is a first-person account of why the writer built or started something. |

## Method

**Step 1, state the population.** "Every ad you pasted, counted once each, up to 15. Ads pasted beyond 15 are not read; name them as not read rather than silently dropping them."

**Step 2, sort ads that carry no text.** An ad with a name but empty or missing primary text is printed in its own NO TEXT SUPPLIED row with `[NEEDS: primary text for this ad]`. It is not classified and it is not counted as UNCLASSIFIABLE, because UNCLASSIFIABLE means text was read and carried no claim, which is a different fact than no text existing.

**Step 3, find the first claim-bearing sentence per ad.** Read the primary text sentence by sentence, in order. The first sentence that matches any of the eight tests decides the ad's angle, using the tie-break order above when a sentence matches more than one test. Stop reading that ad once a match is found.

**Step 4, class ads with no matching sentence.** If no sentence in the ad matches any test, the ad goes to UNCLASSIFIABLE (Refusal 2), not to the nearest angle.

**Step 5, tally.** Count ads per angle, over the population from Step 1 minus the NO TEXT SUPPLIED ads. Print every ad's name and its matched claim sentence under its angle.

**Step 6, name the absence.** Any of the eight angles with zero ads is printed as UNRUN. An angle can show phrasing that touches it in a losing tie-break (Step 3) and still be UNRUN, because UNRUN is about which angle is the ad's primary, first-matched angle, not about which words appear anywhere in the text. State this plainly when it happens.

## Output format

```
# Angle gap map
Ads pasted: <n>   Ads read (cap 15): <n>   Ads not read (beyond cap): <n or 0>

## Occupied angles
### <ANGLE NAME>, <count> ad(s)
- "<ad name>": "<matched claim sentence>"

(repeat per occupied angle, in the fixed order 1-8)

## Angles nobody is running
- <ANGLE NAME>
(or: "None. All 8 angles have at least one live ad.")

## No text supplied
- <ad name>: [NEEDS: primary text for this ad]
(or: "None. Every pasted ad carried text.")

## Unclassifiable
- <ad name>: "<verbatim primary text>"
(or: "None. Every ad with text matched an angle.")

## Counts
Population for classification: ads read minus no-text ads = <n> - <n> = <n>
Classified (matched an angle): <n> / <n>
Unclassifiable: <n> / <n>
No text supplied: <n> / <n> (of ads read)
Angles occupied: <n> / 8
Angles unrun: <n> / 8
```

## Worked case

This worked case IS the fixture run at `fixtures/marrow-ash-live-ads.md`, re-run literally against the method above and verified line by line before shipping.

Eight ads pasted, all read (under the cap of 15).

- **Ad A, "Sleep Better Tonight."** First sentence: "You lie there at 11pm replaying the day instead of sleeping." A problem stated before any product-feature sentence. Matches test 1. -> **PROBLEM/SOLUTION.**
- **Ad B, "How It Actually Works."** First sentence names 15 pounds of glass micro-beads sewn into individual channels and how weight distributes. Matches test 2 before anything else. -> **MECHANISM.**
- **Ad C, "1,900 Five-Star Reviews."** First sentence carries a review count and a rating ("Over 1,900 buyers rated... five stars"). Matches test 3. -> **SOCIAL PROOF.**
- **Ad D, "The Other Kind Goes Flat."** First sentence describes a category alternative (plastic-pellet weighted blankets) without naming a brand, and contrasts it with the product. Matches test 4. -> **COMPARISON.**
- **Ad E, "Weekend Ship Sale."** First sentence states both a discount ("$30 off... through Sunday") and a date. This matches test 5 (OFFER) and test 7 (URGENCY/SCARCITY) in the same sentence. Tie-break: angle 5 is earlier than angle 7 in the fixed order, so OFFER wins. -> **OFFER.** Note for the reader: urgency language is present in the copy and still does not occupy the URGENCY/SCARCITY angle, because that angle is about which claim is primary, not which words appear.
- **Ad F, "Built For My Own Kid."** First sentence is a first-person account of why the writer started sewing the product. Matches test 8. -> **FOUNDER/ORIGIN.**
- **Ad G, "Our Bestseller."** No sentence states a problem, mechanism, proof, comparison, price, audience, timing or founder account. It names the product and three adjectives. -> **UNCLASSIFIABLE.**
- **Ad H, "Retargeting, Static 4."** Primary text field is empty. -> **NO TEXT SUPPLIED**, `[NEEDS: primary text for this ad]`.

Tally: PROBLEM/SOLUTION 1 (A), MECHANISM 1 (B), SOCIAL PROOF 1 (C), COMPARISON 1 (D), OFFER 1 (E), IDENTITY 0, URGENCY/SCARCITY 0, FOUNDER/ORIGIN 1 (F).

Occupied angles: 6 / 8. Unrun angles: IDENTITY, URGENCY/SCARCITY, 2 / 8.

Counts: ads pasted 8, ads read 8, no text supplied 1 (H), classification population = 8 - 1 = 7, classified 6 (A-D, wait: A, B, C, D, E, F = 6), unclassifiable 1 (G). 6 + 1 = 7, matches the classification population. No arithmetic disagreement between this worked case and a literal run of the fixture.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never assign an angle to an ad by resemblance or vibe. Only the fixed eight tests decide, in the fixed tie-break order.
- Never fold UNCLASSIFIABLE or NO TEXT SUPPLIED ads into an angle's count to make an angle look occupied.
- Never invent a ninth angle. If an ad's real message needs one, it still gets read against the eight, and UNCLASSIFIABLE is the honest outcome.
- Never treat an UNRUN angle as a recommendation to run it. This unit reports absence. It does not rank angles or say which one to build next.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.
