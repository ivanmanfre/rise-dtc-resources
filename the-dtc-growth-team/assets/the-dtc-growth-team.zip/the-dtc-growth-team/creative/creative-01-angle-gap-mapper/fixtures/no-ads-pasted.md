# Fixture, zero ads pasted

Invented for testing. Note: exercises Refusal 1, the zero-ads branch.

---

Ads pasted: none. The reader opened the unit before pulling anything from the
Ads screen.
