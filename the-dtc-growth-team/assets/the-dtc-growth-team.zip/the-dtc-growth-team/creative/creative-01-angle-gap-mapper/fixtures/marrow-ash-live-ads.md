# Fixture, live ads for Marrow & Ash

Invented for testing. Marrow & Ash is not a real brand and the Ash Blanket is
not a real product. Note: this set is built to exercise the tie-break rule
(Ad E), the UNCLASSIFIABLE branch (Ad G) and the no-text gap (Ad H) in the
same pull.

---

**Ad A, "Sleep Better Tonight"**
Primary text: You lie there at 11pm replaying the day instead of sleeping. The Ash Blanket's glass beads apply even pressure across your body, the same principle occupational therapists use for anxiety. Shop the blanket.

**Ad B, "How It Actually Works"**
Primary text: The Ash Blanket uses 15 pounds of glass micro-beads sewn into individual channels so weight never shifts to one side. That's deep pressure stimulation, the same input your body gets from a firm hug. Machine washable cover included.

**Ad C, "1,900 Five-Star Reviews"**
Primary text: Over 1,900 buyers rated the Ash Blanket five stars for one reason: they finally stopped waking up at 3am. Sarah from Ohio wrote, "I haven't slept this well since college." Try it for 30 nights.

**Ad D, "The Other Kind Goes Flat"**
Primary text: Plastic-pellet weighted blankets clump in the wash and go flat within a year. The Ash Blanket's glass beads keep their shape wash after wash. Compare the two before you buy either.

**Ad E, "Weekend Ship Sale"**
Primary text: $30 off the Ash Blanket through Sunday, free shipping included. Every order ships in the same box as our original. Sale ends when the timer hits zero.

**Ad F, "Built For My Own Kid"**
Primary text: I started sewing these on our kitchen table in 2019 because my youngest couldn't fall asleep without someone lying on top of him. Ash Blanket is what came out of that. It ships from the same small warehouse we started in.

**Ad G, "Our Bestseller"**
Primary text: The Ash Blanket. Weighted. Washable. Yours.

**Ad H, "Retargeting, Static 4"**
Primary text: (empty, no text entered on this ad)
