---
name: creative-06-creative-capacity-planner
description: "Use when a test plan asks for more creative than you know you can actually make. Takes the number of cells your test plan requires, what you can shoot in a week, whether you have creators on hand, and your editing hours per week, and returns the shortfall and a named cut order. Triggers on \"can I actually make what this test plan needs\", \"how many creatives short am I\", \"what do I cut if I can't hit the test plan\", \"do I have the capacity for this test\", \"editing hours versus what the matrix wants\"."
---

# The DTC Growth Team, CREATIVE, unit 06 of 6: the capacity check

## What this does

Compares the number of creative cells one test plan requires this month against what you can actually produce, and prints the cut order for whatever does not fit.

**The line only this unit produces:** the number of cells your production capacity can fill against the number one specific test plan requires, with the cut order for the shortfall named, and every capacity number traced to an input you supplied rather than a rate this unit invented.

## Required input

1. **Cells required.** From unit 04 (Test Matrix Builder) or your own plan. Either a bare count, or a named list of the cells in the order you would run them if everything fit. A named list is what lets this unit print a cut order; a bare count only lets it print a shortfall number.
2. **What you can shoot in a week.** A count of creative cells, reflecting who is actually available to you right now.
3. **Whether you have creators on hand.** YES, NO, or AMBIGUOUS.
4. **Your editing hours per week.**

## What it refuses

**Refusal, nothing to plan around.** Cells required is 0:

```
NOTHING TO PLAN
Cells required: 0

There is no shortfall to size without a test plan asking for cells. Go back
to the test matrix and state how many creatives it needs.
```

**Trust rule, not a runtime branch.** This unit trusts the "what you can shoot in a week" number as already reflecting who is available to you. If creators on hand is NO, make sure the number you supplied excludes anything only a hired creator could do. This unit does not invent a lower number on your behalf; it prints the AMBIGUOUS path (below) when it cannot tell.

## Method

**Step 1, state the population.** "The cells this one test plan requires this month."

**Step 2, gate zero.** Cells required is 0, the refusal above fires and nothing further is built.

**Step 3, state the month assumption.** This unit assumes a 4-week production month. Print this assumption every time: "If your month runs longer or shorter than 4 weeks, scale the capacity figure by (your weeks / 4) yourself."

**Step 4, branch on creators on hand.**
- YES or NO: one capacity path. Monthly shoot capacity = shoot cells/week (as supplied) x 4 weeks.
- AMBIGUOUS: print the plan twice.
  - WITH CREATORS: monthly shoot capacity = shoot cells/week (as supplied) x 4 weeks, computed exactly as the YES/NO path.
  - WITHOUT CREATORS: this unit was given only one shoot-capacity number and cannot tell how much of it depends on outside creators, so it prints `[NEEDS: what you could shoot in a week using only people you employ directly, no outside creators]` in place of a capacity number, and no shortfall arithmetic runs on this branch.

**Step 5, gate editing hours.** Editing hours per week is 0: print `EDITING BLOCKED`, and force capacity to 0 cells with the reason "0 editing hours means nothing shot gets finished, regardless of shoot capacity." Editing hours per week is above 0: print the figure beside the capacity number with the line "this unit does not know your minutes-per-edit, so editing hours is shown for your own judgment and is not used to compute the capacity number above." No conversion rate is invented in either case.

**Step 6, compute the shortfall.** For every branch that has a real capacity number (not the WITHOUT CREATORS gap branch): shortfall = cells required - capacity, over the stated population from Step 1. Capacity at or above cells required prints shortfall 0 in words, "capacity covers the plan," not a negative number.

**Step 7, print the cut order.** Shortfall is 0, print "None. Capacity covers the plan, nothing to cut," regardless of whether a named list was supplied. Shortfall is above 0 and a named list of cells was supplied: starting from the last-listed cell and moving backward toward the front, one cell at a time, the last-listed cell is named first in the cut order, continuing until the shortfall count is removed. Shortfall is above 0 and only a bare count was supplied: print `[NEEDS: the named list of cells in the order you would run them, so the cut order can name which ones]`.

## Output format

```
# Creative capacity check
Cells required this month: <n>
Assumption: 4-week production month (scale by your-weeks/4 if different)

## Capacity
<one labelled branch, or two if AMBIGUOUS>
shoot cells/week: <n> x 4 weeks = <n> cells/month
editing hours/week: <n>   (<EDITING BLOCKED | context only, not used in the math above>)
capacity: <n> cells/month | 0 (EDITING BLOCKED) | [NEEDS: what you could shoot in a week using only people you employ directly]

## Shortfall
required <n> - capacity <n> = <n> cells short   (or "0. Capacity covers the plan.")

## Cut order
1. <cell name> (cut first)
2. <cell name>
(continue until the shortfall count is named, or:)
[NEEDS: the named list of cells in the order you would run them, so the cut order can name which ones]
```

## Worked case

Two fixtures, both re-run literally against the method above and verified line by line before shipping.

**`fixtures/marrow-ash-capacity-named-list.md`.** Cells required: 8, supplied as a named list in run order. Creators on hand: YES, single capacity path. Shoot cells/week: 1. Monthly capacity: 1 x 4 = 4. Editing hours/week: 6, above 0, printed as context, not used in the math. Shortfall: 8 - 4 = 4 cells short. Cut order: HOOK variant H (last-listed) cut first, then G, then F, then E, working backward from the end of the supplied list.

**`fixtures/marrow-ash-capacity-ambiguous.md`.** Cells required: 6, a bare count only, no named list. Creators on hand: AMBIGUOUS. Two branches print: WITH CREATORS, using the supplied shoot cells/week (1) x 4 = 4 monthly capacity, shortfall 6 - 4 = 2 cells short; WITHOUT CREATORS, capacity printed as `[NEEDS: what you could shoot in a week using only people you employ directly, no outside creators]`, no shortfall computed on this branch. Cut order on the WITH CREATORS branch: shortfall is above 0 and cells required was supplied as a bare count with no named list, so cut order prints `[NEEDS: the named list of cells in the order you would run them, so the cut order can name which ones]` rather than naming specific cells.

## Hard guardrails

- Where the input does not carry a value this format asks for, print `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a minutes-per-edit or hours-per-cell conversion rate. Editing hours are shown, never divided into a capacity number, unless they are exactly 0.
- Never compute a WITHOUT CREATORS capacity number from the single shoot-capacity figure supplied. Gap it instead.
- Never print a negative shortfall. Capacity at or above requirement prints "0, capacity covers the plan."
- Never name a specific cell as cut without a supplied named list to cut from.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve, harness, supercharge, game-changer, streamline, empower, utilize.
