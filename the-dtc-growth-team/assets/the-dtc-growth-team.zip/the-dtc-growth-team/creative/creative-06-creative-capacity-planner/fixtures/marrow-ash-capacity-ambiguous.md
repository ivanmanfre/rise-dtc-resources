# Fixture, capacity check with ambiguous creators on hand

Invented for testing. Note: cells required is a bare count only (no named
list), and creators on hand is AMBIGUOUS, to exercise the double-plan branch
and the cut-order gap at the same time.

---

Cells required this month: 6

What you can shoot in a week: 1 cell.

Creators on hand: AMBIGUOUS. We have a friend who sometimes helps shoot on
weekends but she's not on payroll and isn't always free.

Editing hours per week: 5.
