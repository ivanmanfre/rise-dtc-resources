# Fixture, capacity check with a named cell list

Invented for testing. Marrow & Ash is not a real brand. Note: cells required
is supplied as a named, ordered list on purpose, to exercise the named cut
order.

---

Cells required this month, named list in run order:
1. HOOK variant A
2. HOOK variant B
3. HOOK variant C
4. HOOK variant D
5. HOOK variant E
6. HOOK variant F
7. HOOK variant G
8. HOOK variant H

What you can shoot in a week: 1 cell.

Creators on hand: YES, one part-time editor helps on Fridays.

Editing hours per week: 6.
