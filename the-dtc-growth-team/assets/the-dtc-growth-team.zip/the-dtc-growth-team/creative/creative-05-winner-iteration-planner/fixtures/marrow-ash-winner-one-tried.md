# Fixture, best ad with one element already tried

Invented for testing. Marrow & Ash is not a real brand. Note: only one
element has been tried, so this run exercises the full six-variant path
with no shortfall.

---

Best current ad, copy:
"You lie there at 11pm replaying the day instead of sleeping. The Ash
Blanket's glass beads apply even pressure across your body, the same
principle occupational therapists use for anxiety. $129, ships in 2 days.
Shop the blanket."

Visual, two sentences:
A phone-shot bedroom at night lit by a bedside lamp. The blanket is pulled
up over someone lying down, then the shot cuts to the folded blanket on a
plain background with the price overlaid as text.

Already tried: we already tried a new CTA line on this one, twice.
