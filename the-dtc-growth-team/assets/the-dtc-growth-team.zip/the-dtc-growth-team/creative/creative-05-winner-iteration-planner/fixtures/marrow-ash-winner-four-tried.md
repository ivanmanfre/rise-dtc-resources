# Fixture, best ad with four elements already tried

Invented for testing. Note: four of the eight elements are already tried,
so this run exercises the shortfall branch (fewer than 6 untried).

---

Best current ad, copy:
"You lie there at 11pm replaying the day instead of sleeping. The Ash
Blanket's glass beads apply even pressure across your body, the same
principle occupational therapists use for anxiety. $129, ships in 2 days.
Shop the blanket."

Visual, two sentences:
A phone-shot bedroom at night lit by a bedside lamp. The blanket is pulled
up over someone lying down, then the shot cuts to the folded blanket on a
plain background with the price overlaid as text.

Already tried: we changed the hook line three times, tried two different
CTAs, tested mentioning the price up front instead of at the end, and added
a line about our review count last month.
