# The ChatGPT Ads Launch Kit

Five ChatGPT skills for a DTC brand on Shopify that wants to run ads inside
ChatGPT and get the setup right the first time.

OpenAI named Shopify its first ecommerce partner for ChatGPT Ads. The ChatGPT Ads
app, built by OpenAI, has been in the Shopify App Store since September 3, 2026.
It is live for US-based merchants, and OpenAI says it "will be available
internationally in markets where ChatGPT Ads are available starting September
23".

Each skill is one `SKILL.md` file. You paste what you already have, a robots.txt
file, a product export, a product page, your order economics, and it hands back
one thing you can act on. Nothing connects to your store or your ad account.

Built by the team at RISE DTC. Platform rules last read from OpenAI on
2026-09-19. The channel is in beta and the rules move; each skill names the
article a rule came from so you can re-read it.

## The one rule every skill follows

No invented numbers and no invented facts. OpenAI states that ChatGPT Ads "does
not yet have performance benchmarks across advertisers, industries, or campaign
types", so this kit carries none. Every figure is computed from a number you
gave it, with the arithmetic shown. Every line of copy rests on a fact quoted
from your own store. When an input is missing, the skill prints `[NEEDS: the
thing it is missing]` and carries on with what it can answer.

## The five

| # | skill | you paste | you get back |
|---|---|---|---|
| 1 | `chatgpt-ads-readiness-check` | where the company is based, what you sell, your robots.txt, browser, budget, any error on screen | PASS, FAIL, REVIEW or CANNOT CHECK on 14 setup items, each tied to the OpenAI rule behind it |
| 2 | `chatgpt-ads-click-math` | the cost per purchase you can afford, your bid, your daily budget, your own conversion rate | the conversion rate a click has to hit, your cost per purchase at the bid, the most a day and a week can bill, and the cost of a readable test |
| 3 | `catalog-rewriter-for-chatgpt` | product rows from a Shopify export | a count out of seven of the facts each product states, a rewritten title and description built only from those facts, and a CSV ready to import |
| 4 | `shopper-question-bank` | one product page plus your FAQ, shipping and returns text | up to 30 pre-purchase questions, each answered with your own sentence quoted, or marked for you to answer |
| 5 | `ad-variations-and-context-hints` | one product's facts and your audience in a sentence | up to eight title and description pairs on eight different angles, plus context hints in the phrase shape OpenAI asks for |

Five folders. Count them.

## Where to start

Run `chatgpt-ads-readiness-check` first. Two of its items take a minute to fix
and block everything after them. A robots.txt that shuts out OpenAI's ad crawlers
makes an ad ineligible to run, and OpenAI's setup guide names Chrome or Safari
as the browsers to connect from.

Then `chatgpt-ads-click-math`, before you set a budget. It needs the cost per
purchase you can afford. If nobody has worked that out for the brand,
`break-even-and-affordable-cpa` in the RISE DTC 15 skills kit does it from your
order economics: resources.risedtc.com/dtc-chatgpt-skills/

Then the copy side, in order: 3, 4, 5. Each one's output is the next one's input.

## Install

Three routes. Route 1 is the real install and needs a ChatGPT Business, Enterprise or Edu
seat. Route 2 works on every plan including Free, and needs no setup at all. Route 3 is for
people already working in a terminal.

### Route 1, ChatGPT Business, Enterprise or Edu

Per OpenAI's help center, "Skills are available to eligible ChatGPT Business, Enterprise,
Healthcare, and Edu users". Free, Plus and Pro accounts do not have the Skills upload yet.
If yours does not, use Route 2.

1. Unzip the kit.
2. In ChatGPT, open the sidebar, go to **Plugins**, open the **Skills** tab, then **Create**.
3. Choose **Upload from your computer** and upload one skill folder. Each folder is one
   skill, so upload them one at a time, as many as you want.
4. ChatGPT scans every upload. Some come back marked **Needs Review**.

Then type `@chatgpt-ads-readiness-check` in a chat and paste your store details underneath.
You can also just ask for the job in plain words: a skill triggers on its own when your
request matches its description.

### Route 2, any ChatGPT plan, including Free, Plus and Pro

No setup at all.

1. Open the skill folder you want and its `SKILL.md` file.
2. Copy the whole file and paste it into a new chat.
3. Paste your own details underneath it and send.

Every file is written to work as a standalone prompt. On Plus and above you can instead paste
the file into a Project's instructions, so every chat inside that project carries the skill.

### Route 3, Codex or Claude Code

```
cp -R chatgpt-ads-launch-kit/* ~/.agents/skills/
```

That is the Codex path. Codex invokes a skill with `$chatgpt-ads-readiness-check`. For
Claude Code, copy to `~/.claude/skills/` instead:

```
cp -R chatgpt-ads-launch-kit/* ~/.claude/skills/
```

Both pick the folders up on the next start.

## The fixtures

Every skill ships a `fixtures/` folder holding two or three pastes made up for testing. Run a
skill on its fixture first to see the shape of the output before you feed it your own store.
The brands in the fixtures are invented. No client data is anywhere in this kit.

## What these will not do

- They do not connect to Shopify, to ChatGPT Ads Manager or to anything else. You paste, they read.
- They do not tell you whether OpenAI will approve your store. Only OpenAI decides that.
- They do not predict what a campaign will return. Nobody has published what this channel returns.
- They do not fill a missing input with a benchmark. They name the missing field.
- They do not write a fact about your product that your own store does not state.

## The unpaid side

Ads are one way to be in a ChatGPT conversation. Being recommended without paying
is the other, and it is a different job: resources.risedtc.com/guides/chatgpt-visibility/

## Questions

RISE DTC built these for its own media buyers. If you want one tuned to your
account, or a skill for a problem that is not here, that is what the team does.

risedtc.com
