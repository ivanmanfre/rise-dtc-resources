# Fixture, a US store with two fixable blockers

Invented for testing. Tarn & Alder is not a real brand.

Store: Tarn & Alder
1. Billed company based in: United States
2. Billing currency: USD
3. What we sell:
   - solid wood dining tables
   - table linens
4. robots.txt:
```
User-agent: *
Disallow: /cart
Disallow: /checkout
Disallow: /admin

User-agent: OAI-SearchBot
Disallow: /

Sitemap: https://tarnandalder.example/sitemap.xml
```
5. Browser: Firefox
6. I can install apps in Shopify: yes. I can manage the Ads Manager account: yes.
7. Ads Manager account: not yet. I have the organization, account name, website, country and currency ready.
8. Planned daily budget: $40. Planned max CPC bid: $3.50, fixed bidding.
9. Countries I want to target: United States and Canada
10. Error on screen: none
