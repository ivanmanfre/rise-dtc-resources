# Fixture, a German store with a mixed catalog and a connection error

Invented for testing. Brightwater Goods is not a real brand.

Store: Brightwater Goods
1. Billed company based in: Germany
2. Billing currency: EUR
3. What we sell:
   - scented soy candles
   - hard kombucha, 4.5% ABV
   - magnesium sleep supplement, sold as "fall asleep faster"
4. robots.txt:
```
User-agent: *
Disallow: /cart
Disallow: /checkout
```
5. Browser: Chrome
6. I can install apps in Shopify: yes. I can manage the Ads Manager account: yes.
7. Ads Manager account: yes, it exists
8. Planned daily budget: 15 EUR. No bid decided yet.
9. Countries I want to target: Germany
10. Error on screen: "Unable to verify this connection attempt. Return to Shopify Admin and try again."
