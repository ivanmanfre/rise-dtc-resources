---
name: chatgpt-ads-readiness-check
description: "Use before you install the ChatGPT Ads app on a Shopify store, or when the install or the first campaign is stuck. Takes a short description of the store (where the billed company is based, what it sells, the robots.txt file, the browser, the budget, any error on screen) and returns a PASS, FAIL, REVIEW or CANNOT CHECK line for each of 14 setup items, every one tied to the OpenAI article it comes from. Triggers on \"is my store ready for ChatGPT ads\", \"ChatGPT Ads app won't connect\", \"unable to verify this connection attempt\", \"we don't currently serve ads for this industry\", \"can I run ChatGPT ads in my country\", \"check my store before I set up ChatGPT ads\"."
---

# The ChatGPT Ads Launch Kit, 1 of 5: the readiness check

## What this does

Walks the published setup path for ChatGPT Ads on Shopify and marks each item
against what you pasted.

**The line only this unit produces:** one status per setup item, with the
sentence from OpenAI that the item rests on, so you can see which blockers are
yours to fix and which are on OpenAI's side.

Every rule here was read from OpenAI's help center, its ad policies and the
Shopify App Store listing on 2026-09-19. They will change. Each item names its
source so you can re-read it. Nothing connects to your store; you paste, this
reads.

## Required input

Paste what you have. A missing answer produces CANNOT CHECK for the items that
need it, never a guess.

1. Country where the company that will be billed is legally based.
2. Billing currency.
3. What the store sells, one line per product category.
4. The store's `robots.txt`, pasted whole (open `yourstore.com/robots.txt`).
5. Browser you install from.
6. Whether you can install apps in Shopify, and whether you can manage the Ads
   Manager account.
7. Whether an Ads Manager account already exists.
8. Planned daily budget, and planned max CPC bid if you will use fixed bidding.
9. Countries you want to target.
10. Any error message on screen, pasted word for word.

## The four statuses

| status | meaning |
|---|---|
| PASS | what you pasted meets the published rule |
| FAIL | what you pasted breaks the published rule; the fix is printed |
| REVIEW | the rule says approval is case by case, or OpenAI decides; this unit cannot settle it |
| CANNOT CHECK | the input needed was not pasted; `[NEEDS: ...]` names it |

## The 14 items

**1. Billing country.** Rule: "the legal entity that will advertise and be
billed must be based in a country listed as available" (OpenAI Help, "Ads
Manager Availability"). The 56 countries listed on 2026-09-19: Algeria,
Australia, Austria, Bahrain, Belgium, Brazil, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Egypt, Estonia, Finland, France, Germany, Greece,
Hungary, Iceland, India, Iraq, Ireland, Israel, Italy, Japan, Jordan, Korea,
Kuwait, Latvia, Lebanon, Liechtenstein, Lithuania, Luxembourg, Malta, Mexico,
Morocco, Netherlands, New Zealand, Norway, Oman, Poland, Portugal, Qatar,
Romania, Saudi Arabia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tunisia,
Turkey, United Arab Emirates, United Kingdom, United States. In the list = PASS.
Absent = FAIL, with: "You can still sign up at ads.openai.com and OpenAI says it
will notify you."

**2. App availability for the store.** Rule: "US-based Shopify merchants can use
the new ChatGPT Ads app", and "The app will be available internationally in
markets where ChatGPT Ads are available starting September 23" (OpenAI,
"Reimagining advertising with AI"). United States = PASS. Any other country
in the item 1 list = REVIEW, with: "OpenAI states availability from September 23, 2026. If
the app does not install before that, this is the reason."

**3. Product category.** Read each category line against OpenAI's ad policies
and give each its own status.
- PASS where it sits inside the verticals OpenAI names as supported at this
  stage: "lifestyle and household goods, local services, travel and experiences,
  and digital products or education", or the wellness allowances: "fitness
  equipment or workout programs, general nutrition products, and supplements
  widely sold through major retailers", "fitness equipment, wearable devices,
  menstrual products", "CBD topicals with no THC", "hemp clothing".
- FAIL where the policy disallows it: alcohol "over 0.5% ABV", "cigarettes,
  vaping, or nicotine products", "marijuana or THC products", "sexual health
  products", "diet pills, detox programs", weapons, gambling.
- REVIEW where approval is case by case: "Dietary supplements" under health
  services, any product sold on a health claim, financial or legal services.
- CANNOT CHECK where the line is too vague to place. Never stretch a category
  into PASS.
Fix printed for a FAIL category: "Keep this category out of the campaign. In the
Shopify app choose 'single product' or select products by hand, and leave these
out. The policy also applies to the landing page an ad points to."
Always add under this item: "A PASS here reads the published policy only.
OpenAI reviews each advertiser and can still decline. One merchant reported on
the App Store listing on 2026-09-16 that a home decor store received 'We don't
currently serve ads for this industry' and that the appeal email did not
arrive."

**4. robots.txt does not shut out OpenAI's ad crawlers.** Rule: landing pages
"must not block OpenAI user agents (OAI-AdsBot and OAI-SearchBot)" (OpenAI Help,
"Create Ads for ChatGPT Ads"), and "Ads or landing pages that cannot be reviewed
or evaluated by our systems are not eligible to run" (Ad policies). Read the
pasted file group by group:
- FAIL if a group naming `OAI-AdsBot` or `OAI-SearchBot` contains `Disallow: /`.
- FAIL if the `User-agent: *` group contains a bare `Disallow: /` and no group
  names the two OpenAI agents with an `Allow`.
- PASS otherwise. Path-level disallows such as `/cart` or `/checkout` do not
  fail this item.
- Print the exact lines that decided it.
Fix printed for a FAIL: "Delete the `Disallow: /` line from the group that names
the OpenAI agent, or delete that group. In Shopify this file is edited through
the `robots.txt.liquid` theme template."
Always add under this item: "robots.txt is one way to block a crawler. A firewall, a bot
protection app or an IP rule can also block it, and OpenAI's troubleshooting
page names blocked IP addresses as a cause of rejected ads. That cannot be read
from this paste."

**5. Browser.** Rule: "Confirm you are using either Chrome or Safari as a
browser" (OpenAI Help, "Set up ChatGPT Ads for Shopify"). Chrome or Safari =
PASS. Anything else = FAIL. Fix printed: "Install and connect from Chrome or
Safari."

**6. Permissions.** Rule: you need "Permission to install and manage apps in
Shopify" and "Permission to manage your Ads Manager account" (same article).
Both yes = PASS. Either no = FAIL naming which.

**7. Account details ready.** Rule: to create an account you confirm
"organization, account name, website, industry, country, currency, and time
zone" (same article). Existing account = PASS. No account: PASS only if all
seven are in the paste; otherwise CANNOT CHECK naming the missing ones.

**8. Daily budget meets the minimum.** Minimums by billing currency (OpenAI
Help, "Create Campaigns for ChatGPT Ads"): USD 25, CAD 25, AUD 25, NZD 25,
EUR 15, GBP 15, CHF 20, AED 65, BRL 40, CZK 350, DKK 110, HUF 5,500, ILS 60,
INR 725, JPY 2,500, KRW 25,000, MXN 150, NOK 160, PLN 65, QAR 70, RON 80,
SAR 50, SEK 175. Print `<budget> vs minimum <min>`. Currency not in the table =
CANNOT CHECK.

**9. Daily budget covers the bid.** Rule: with a daily budget and fixed bidding,
"the daily budget must also be at least the highest effective per-event bid"
(OpenAI Help, "Daily Budgets"). Budget >= bid = PASS. No bid pasted = CANNOT
CHECK.

**10. Budget increment inside Shopify.** Rule: in the Shopify app budgets move
in "fixed increments of $25", while Ads Manager accepts other amounts (OpenAI's
example is $28). A budget that is a multiple of 25 = PASS. Otherwise REVIEW,
with: "Set this budget in Ads Manager at ads.openai.com."

**11. Target countries.** Two rules (OpenAI Help, "Create Campaigns for ChatGPT
Ads"). "Some new self-serve ad accounts can initially advertise only in their
home country", until identity verification is approved and a required spend is
reached. And new product-feed campaigns "support geographic targeting and
exclusions only at country level". Home country only = PASS. Any other country
on a new account = REVIEW. A state, city or postcode target on a product
campaign = FAIL.

**12. Spend ceiling understood.** Not a check of the store; a line every report
prints from the pasted budget. "Your maximum daily spend is twice your daily
budget" and "Your maximum seven-day spend is seven times your daily budget"
(OpenAI Help, "Daily Budgets"). Print `2 x <D> = <amount> in a day, 7 x <D> =
<amount> in a Sunday to Saturday week`. Status is PASS when a budget was pasted,
CANNOT CHECK when not.

**13. Decisions that cannot be changed later.** Print, always, status REVIEW:
"The campaign objective, the billing model and the conversion event cannot be
changed after the campaign is created. A different choice means a new campaign"
(OpenAI Help, "Conversion-optimized Campaigns").

**14. The error on screen.** Match the pasted message against these. No message
pasted = PASS with "no error reported".
- "Unable to verify this connection attempt. Return to Shopify Admin and try
  again." or "Data sources are temporarily unavailable." = REVIEW. "Other
  merchants reported the same message on the App Store listing between
  2026-09-16 and 2026-09-18. OpenAI's published checks: use Chrome or Safari,
  and confirm the app is connected to the correct Ads Manager account. If it
  persists, OpenAI asks you to write to ads-support@openai.com with the Ads
  Manager account you are trying to connect."
- "We don't currently serve ads for this industry" = the status of item 3, plus:
  "The message says an appeal link is sent by email. If none arrives, write to
  ads-support@openai.com."
- Any other message = CANNOT CHECK, with `[NEEDS: OpenAI support, ads-support@openai.com, quoting the message word for word]`.

## After the install, what is normal

Print this block at the end of every report, unchanged:

```
- Product sync takes time. "Sync time varies based on catalog size and system conditions."
- The Products tab stays empty until a product campaign has delivered. That is expected.
- Allow 24 hours after launch before treating zero impressions as a fault. Reporting can lag delivery by up to 7 hours.
- Ads are not shown to ChatGPT Plus, Pro or Business accounts, or to accounts identified as under 18.
- OpenAI publishes no performance benchmarks for this channel yet.
```

## What it refuses

**Refusal 1, nothing pasted.**

```
NOTHING TO CHECK
No store details were pasted. Send the ten inputs listed under "Required input",
or as many as you have.
```

**Refusal 2, never promises approval.** No wording in any report says the store
"will be approved", "is eligible" or "is ready to run". The strongest statement
allowed is: `<n> of 14 items PASS on what you pasted.`

## Output format

```
# ChatGPT Ads readiness, <store>
Read against OpenAI's published rules as of 2026-09-19.

| # | item | status | what decided it |
|---|---|---|---|
| 1 | Billing country | <status> | <one line> |
...
| 14 | Error on screen | <status> | <one line> |

## Counts
PASS: <n> / 14    FAIL: <n> / 14    REVIEW: <n> / 14    CANNOT CHECK: <n> / 14

## Fix these first
<every FAIL, in item order, with its fix. "(none)" when there are none.>

## Only OpenAI can settle these
<every REVIEW, in item order>

## Still needed from you
<every [NEEDS:], in item order>

## After the install, what is normal
<the fixed block>
```

Item 3 counts once in the totals, at its most severe category status, in the
order FAIL, REVIEW, CANNOT CHECK, PASS. The table row for item 3 shows that one
status. Directly after the table, under the heading `### Item 3, by category`,
each category prints on its own line with its own status and the policy words
that decided it. In "Fix these first" and "Only OpenAI can settle these", each
FAIL or REVIEW category is listed by name.

The notes that items 3 and 4 always add print after that, under `### Notes`.

Money prints the way the reader wrote it: `$40`, `15 EUR`. The fix for a FAIL is
the sentence this file gives for that item, word for word. Where an item gives
none, print the rule sentence again and nothing more.

## Worked case

The literal run of `fixtures/tarn-and-alder-us-store.md`.

| # | item | status | what decided it |
|---|---|---|---|
| 1 | Billing country | PASS | United States is in the list |
| 2 | App availability | PASS | US-based merchant |
| 3 | Product category | PASS | "solid wood dining tables" and "table linens" sit in lifestyle and household goods |
| 4 | robots.txt | FAIL | the group `User-agent: OAI-SearchBot` contains `Disallow: /` |
| 5 | Browser | FAIL | Firefox; OpenAI names Chrome or Safari |
| 6 | Permissions | PASS | both yes |
| 7 | Account details | CANNOT CHECK | no account yet; `[NEEDS: industry, time zone]` |
| 8 | Minimum budget | PASS | 40 vs minimum 25 USD |
| 9 | Budget covers bid | PASS | 40 >= 3.50 |
| 10 | Shopify increment | REVIEW | 40 is not a multiple of 25; set it in Ads Manager |
| 11 | Target countries | REVIEW | United States and Canada on a new account; Canada waits on verification and spend |
| 12 | Spend ceiling | PASS | 2 x 40 = $80 in a day, 7 x 40 = $280 in a week |
| 13 | Permanent decisions | REVIEW | fixed text |
| 14 | Error on screen | PASS | no error reported |

Counts: PASS 8 / 14, FAIL 2 / 14, REVIEW 3 / 14, CANNOT CHECK 1 / 14. 8 + 2 + 3
+ 1 = 14.

Fix these first: item 4, remove `Disallow: /` from the `OAI-SearchBot` group or
delete the group; item 5, install from Chrome or Safari.

The second fixture, `fixtures/brightwater-de-mixed-catalog.md`, is a German
store on Chrome selling candles, hard kombucha at 4.5% ABV and a magnesium sleep
supplement, with the connection error pasted. Item 2 is REVIEW (listed country,
September 23). Item 3 prints three lines: candles PASS, hard kombucha FAIL
(over 0.5% ABV), sleep supplement REVIEW (dietary supplement, sold on a sleep
claim), and counts once as FAIL. Item 8 reads 15 vs minimum 15 EUR, PASS. Item
14 is REVIEW with the published checks.

## Hard guardrails

- Never state that a store is approved, eligible or ready. Only OpenAI decides.
- Never place a category in PASS by stretching it. Vague = CANNOT CHECK.
- Never invent a rule. Every status rests on a sentence quoted in this file.
- Merchant reviews are reported as merchant reports with their date, never as a
  finding of this unit and never as a rate.
- Never give a status for an input that was not pasted. `[NEEDS: ...]` instead.
- No em dashes. No exclamation marks. Audience word is DTC, never "ecom".
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `stop X start Y`, `less X more Y`). No "Most
  [group]" claims. No time-to-value claim.
