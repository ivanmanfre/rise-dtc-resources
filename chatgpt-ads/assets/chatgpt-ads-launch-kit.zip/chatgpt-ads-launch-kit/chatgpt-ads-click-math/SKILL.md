---
name: chatgpt-ads-click-math
description: "Use before you put a dollar into ChatGPT Ads, to see whether a click at your bid can pay for itself on your own order economics. Takes the cost per purchase you can afford, the max CPC bid you plan to set, your daily budget and, where you have it, your own click-to-purchase rate, and returns the conversion rate the channel has to hit, your cost per purchase at the bid, the most you can spend in a day and a week, and what it costs to reach a readable test. Triggers on \"is ChatGPT Ads worth testing for my store\", \"what CPC can I afford on ChatGPT ads\", \"how much budget do I need to test ChatGPT ads\", \"what conversion rate do I need at a $4 click\", \"run the click math\"."
---

# The ChatGPT Ads Launch Kit, 2 of 5: click math

## What this does

Runs the arithmetic between a bid and an order, on your numbers, before the
campaign exists.

**The line only this unit produces:** the click-to-purchase rate your store has
to reach for a click at your bid to cost no more than the purchase you can
afford, printed beside the rate you already have.

Every figure about how ChatGPT Ads bills comes from OpenAI's help center, read
2026-09-19, and is quoted in the "Platform facts" block below with its article.
OpenAI states that ChatGPT Ads "does not yet have performance benchmarks across
advertisers, industries, or campaign types". This unit therefore carries no
benchmark of any kind. The only conversion rate it will use is one you supply.

The cost per purchase you can afford is an input here and never an output. If
nobody has set it for the brand, `break-even-and-affordable-cpa` in the RISE DTC
15 skills kit works it out from contribution margin.

## Platform facts this unit relies on

| fact | source |
|---|---|
| Clicks campaigns are billed per valid click. You set a maximum CPC bid at the ad group. | OpenAI Help, "Ads in ChatGPT: The Basics" |
| "For CPC campaigns, we recommend starting with a maximum bid of $3-$5 USD per click." A recommendation. No minimum bid is published. | same article |
| The auction is "relevance-weighted, second-price". Your bid is a ceiling on what a click costs, so every figure below computed at the bid is the most expensive case. | same article |
| Minimum daily budget by billing currency: USD 25, CAD 25, AUD 25, NZD 25, EUR 15, GBP 15. | OpenAI Help, "Create Campaigns for ChatGPT Ads" |
| A daily budget is a seven day average. One day can bill up to 2 x the daily budget. A Sunday to Saturday week bills no more than 7 x the daily budget. | OpenAI Help, "Daily Budgets" |
| With a daily budget and fixed bidding, the daily budget must be at least your highest bid. | same article |
| Conversion campaigns bill per click or per 1,000 impressions. "You do not pay per conversion." For their bid cap, "There is no recommended bid amount at this time." | OpenAI Help, "Conversion-optimized Campaigns" |

These can change. The articles are dated; check them before you launch.

## Required input

1. **A, the cost per purchase you can afford**, one number, in your billing
   currency.
2. **B, the maximum CPC bid you plan to set.**
3. **D, the daily budget you plan to set**, and the billing currency.
4. **V, your own click-to-purchase rate**, optional. Purchases divided by paid
   clicks, read off a channel you already run to the same product pages, with
   the channel and the window named. Without it this unit still prints the rate
   you need. It does not print a verdict.

## What it refuses

**Refusal 1, no affordable figure.**

```
NO AFFORDABLE COST PER PURCHASE SUPPLIED
Every line below is a comparison against that number. Work it out first
(break-even-and-affordable-cpa in the RISE DTC 15 skills kit), then come back.
```

**Refusal 2, budget under the published minimum.** Where D is below the minimum
for the stated currency in the table above:

```
BUDGET BELOW THE PUBLISHED MINIMUM
daily budget: <currency> <D>      published minimum: <currency> <min>
Ads Manager will not accept this budget. Nothing below is computed.
```

Where the currency is not one of the six in the table, print
`[NEEDS: the minimum daily budget for <currency>, from the table in OpenAI's
"Create Campaigns for ChatGPT Ads" article]` and carry on.

**Refusal 3, never borrows a conversion rate.** Where V is missing, the block
below prints once, under `## Verdict`. The three sections that need V (`## Your
cost per purchase at the bid`, `## The bid your rate supports`, `## Cost of a
readable test`) each print the single line `Needs your own rate. See Verdict.`
and nothing else. Steps 1, 2 and 7 still run in full.

```
NO VERDICT
[NEEDS: your own click-to-purchase rate, from a paid channel you already run to
these product pages, with the channel and the window named]
No benchmark exists for this channel, so none is used.
```

## Method

**The rounding convention.** Every division is carried at full precision and
rounded only when printed, half-up. Money prints to two decimals with the
currency symbol, rates to two decimals of a percent, days to one decimal, and
counts of clicks or purchases per day to two decimals. A rate you supplied is
echoed in the header exactly as you wrote it. A printed figure is never fed into a
later line; the later line uses the unrounded value and says so where the last
cent could differ.

**Step 1, the rate you need.**

```
break-even click-to-purchase rate = B / A = <B> / <A> = <decimal> = <percent>
```

At this rate a click at your full bid costs exactly the purchase you can afford.

**Step 2, what the budget buys at the bid.**

```
clicks per day at the bid = D / B = <D> / <B> = <n>
most you can be billed in one day = 2 x D = <amount>
most you can be billed in one Sunday to Saturday week = 7 x D = <amount>
```

If D < B, add: `Your daily budget is under your bid. With fixed bidding Ads
Manager requires the daily budget to be at least the highest bid.`

**Step 3, your cost per purchase at the bid.** Only when V is supplied.

```
cost per purchase at the bid = B / V = <B> / <V> = <amount>
your rate came from: <the channel and the window you named>
```

**Step 4, the three bands.** Same bands as the scale-or-kill judge in the 15
skills kit, so the two read the same way.

| Band | Rule | Verdict |
|---|---|---|
| Clearly under | cost per purchase <= 0.85 x A | PENCILS AT THIS BID |
| At the edge | 0.85 x A < cost per purchase <= A | EDGE |
| Over | cost per purchase > A | DOES NOT PENCIL AT THIS BID |

Print the comparison in full: `<cost per purchase> vs afford <A>, 0.85 x afford
= <0.85A>`.

**Step 5, the bid your own rate supports.**

```
highest bid that stays at or under afford = A x V = <A> x <V> = <amount>
highest bid that stays clearly under      = 0.85 x A x V = 0.85 x <A> x <V> = <amount>
```

Where either is below $3.00 in USD, add one line and no more: `OpenAI's
suggested starting range is $3 to $5. A bid under it may limit delivery; Ads
Manager shows bid-strength guidance at the ad group.`

**Step 6, the cost of a readable test.** Ten purchases is the read minimum used
across the RISE DTC kits.

```
purchases per day at the bid = (D / B) x V = <n>
days to 10 purchases = 10 / <purchases per day> = <days>
spend to 10 purchases = 10 x B / V = <amount>
```

**Step 7, what this cannot see.** Always print these three lines:

```
- Computed at your full bid. The auction is second-price, so a click can cost less.
- V came from another channel. A reader arriving from a ChatGPT conversation may buy at a different rate. Nobody has published that rate.
- Purchases that follow an ad view with no click are not in this math.
```

## Output format

```
# ChatGPT Ads click math, <brand>
Afford: <A>    Bid: <B>    Daily budget: <D> <currency>    Your rate: <V or "not supplied">

## The rate you need
<Step 1>

## What the budget buys
<Step 2>

## Your cost per purchase at the bid
<Step 3, or "Needs your own rate. See Verdict.">

## Verdict
<Step 4, or the Refusal 3 block>

## The bid your rate supports
<Step 5>

## Cost of a readable test
<Step 6>

## What this cannot see
<Step 7>
```

## Worked case

The literal run of `fixtures/tarn-and-alder-dining.md`.

Afford A = $210.00. Bid B = $3.50. Daily budget D = $50 USD (minimum 25, passes).
V = 1.9% (Meta prospecting to the same product pages, Aug 1 to Aug 31).

- Break-even rate = 3.50 / 210 = 0.016667 = **1.67%**.
- Clicks per day at the bid = 50 / 3.50 = **14.29**. One day bills at most
  2 x 50 = **$100**. One week at most 7 x 50 = **$350**.
- Cost per purchase at the bid = 3.50 / 0.019 = **$184.21**.
- $184.21 vs afford $210.00, 0.85 x afford = $178.50. $178.50 < $184.21 <=
  $210.00 -> **EDGE**.
- Highest bid at or under afford = 210 x 0.019 = **$3.99**. Clearly under =
  0.85 x 210 x 0.019 = **$3.39**. Both are inside OpenAI's $3 to $5 range, so
  the under-range line does not print.
- Purchases per day = 14.285714... x 0.019 = **0.27**. Days to 10 purchases =
  10 / 0.271429 = **36.8**. Spend to 10 purchases = 10 x 3.50 / 0.019 =
  **$1,842.11** (multiplied at the unrounded quotient; 10 x the printed $184.21
  would give $1,842.10).

The second fixture, `fixtures/hollin-and-pike-candles.md`, is the other side:
afford $32.00, bid $4.00, V 2.4%. Break-even rate 4.00 / 32 = 12.50%. Cost per
purchase 4.00 / 0.024 = $166.67 -> DOES NOT PENCIL AT THIS BID. Highest bid at
or under afford = 32 x 0.024 = $0.77, and the under-range line prints. The
third, `fixtures/sedge-supply-no-rate.md`, carries no V and exercises Refusal 3:
break-even rate 3.00 / 58 = 5.17%, clicks per day 25 / 3.00 = 8.33, no verdict.

## Hard guardrails

- Never print a conversion rate, CPC, CPM or cost per purchase the reader did
  not supply or that was not computed from what they supplied. No benchmark, no
  "typical", no "average store".
- Never call the channel good or bad. The verdict is about one bid against one
  afford figure at one supplied rate.
- Never state a minimum bid. OpenAI publishes a recommendation only.
- Never predict delivery, impressions or clicks actually served. Step 2 is what
  the budget could buy at the bid, a ceiling.
- Where an input is missing, print `[NEEDS: <what to supply>]`. Never fill it.
- No em dashes. No exclamation marks. Audience word is DTC, never "ecom".
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `stop X start Y`, `less X more Y`). No "Most
  [group]" claims. No time-to-value claim.
