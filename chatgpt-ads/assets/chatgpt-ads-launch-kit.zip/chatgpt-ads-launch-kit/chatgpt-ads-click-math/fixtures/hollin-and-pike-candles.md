# Fixture, a low order value brand where the bid does not pencil

Invented for testing. Hollin & Pike is not a real brand.

Brand: Hollin & Pike (soy candles)
Cost per purchase I can afford: $32.00
Max CPC bid I plan to set: $4.00
Daily budget: $40, billing currency USD
My click-to-purchase rate: 2.4% (Meta prospecting to the same product pages, Jul 1 to Jul 31)
