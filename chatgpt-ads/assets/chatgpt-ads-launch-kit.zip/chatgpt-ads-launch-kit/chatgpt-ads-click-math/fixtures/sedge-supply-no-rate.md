# Fixture, no conversion rate supplied

Invented for testing. Sedge Supply is not a real brand. Designed to exercise
Refusal 3: the unit prints the rate needed and no verdict.

Brand: Sedge Supply (canvas work aprons)
Cost per purchase I can afford: $58.00
Max CPC bid I plan to set: $3.00
Daily budget: $25, billing currency USD
My click-to-purchase rate: I do not know it
