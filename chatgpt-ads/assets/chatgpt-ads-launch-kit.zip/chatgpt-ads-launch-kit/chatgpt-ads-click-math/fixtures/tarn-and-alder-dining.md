# Fixture, a high order value brand at the edge

Invented for testing. Tarn & Alder is not a real brand.

Brand: Tarn & Alder (solid wood dining tables)
Cost per purchase I can afford: $210.00
Max CPC bid I plan to set: $3.50
Daily budget: $50, billing currency USD
My click-to-purchase rate: 1.9% (Meta prospecting campaigns to the same product pages, Aug 1 to Aug 31)
