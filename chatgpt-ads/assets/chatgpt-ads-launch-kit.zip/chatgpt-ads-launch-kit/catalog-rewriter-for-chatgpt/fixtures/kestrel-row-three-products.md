# Fixture, three product rows: one rich, one thin, one with a health claim

Invented for testing. Kestrel Row is not a real brand.

| Handle | Title | Body (HTML) | Type | Tags | Option values | Variant Price |
|---|---|---|---|---|---|---|
| washed-linen-apron | The Everyday Apron - Premium Quality | `<p>Our best-selling apron, made for home cooks and potters. 100% European flax linen, 245 gsm. One size, 86 cm long, adjustable cross-back straps. Machine wash cold, tumble dry low. OEKO-TEX Standard 100 certified.</p>` | Aprons | linen, kitchen | Color: Oat, Ink | 68.00 |
| stoneware-mug-set | Luxurious Mug Set | `<p>Elevate your mornings with our luxurious mugs. Perfect for everyone.</p>` | Drinkware | bestseller | Set of 4 | 54.00 |
| calm-tea-blend | Calm Evening Tea | `<p>A loose-leaf blend of chamomile, lemon balm and lavender. 80 g tin, about 40 cups. Steep one teaspoon for five minutes in water just off the boil. Reduces anxiety and cures insomnia.</p>` | Tea | herbal, caffeine-free | 80 g tin | 19.00 |
