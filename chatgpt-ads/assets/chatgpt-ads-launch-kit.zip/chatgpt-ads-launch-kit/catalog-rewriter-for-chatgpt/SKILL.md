---
name: catalog-rewriter-for-chatgpt
description: "Use when your Shopify catalog is about to become the source of your ChatGPT product ads and the titles and descriptions were written for a storefront grid. Takes product rows pasted from a Shopify export and returns, per product, which of seven facts a shopper asks about are present, a rewritten title and description built only from facts already in the row, the facts the owner still has to supply, and a CSV block ready for import. Triggers on \"rewrite my product titles for ChatGPT\", \"get my Shopify catalog ready for ChatGPT ads\", \"my product descriptions are thin\", \"make my product feed conversational\", \"which products are missing details\"."
---

# The ChatGPT Ads Launch Kit, 3 of 5: the catalog rewriter

## What this does

The ChatGPT Ads app builds product ads from your Shopify catalog. The listing
says it will "Create ads using your Shopify product catalog in just a few
clicks", and OpenAI's announcement says "Products are already integrated through
Shopify Catalog". So the words a shopper sees start as the words in your product
rows.

OpenAI's guidance for ad copy is that it "explains the practical value of what
you offer, who it is for, and when it may be helpful" and that titles should
"prioritize clear, useful details over broad marketing language" (OpenAI Help,
"Create Ads for ChatGPT Ads"). This unit reads each product row against that
and rewrites it from the facts the row already carries.

**The line only this unit produces:** per product, a count out of seven of the
facts present, each quoted from your row, and a rewrite that uses those facts
and nothing else.

It does not claim a rewrite changes delivery, ranking or price per click.
OpenAI publishes nothing that would support such a claim.

## Required input

Product rows, one per product, pasted as a table or as CSV lines from a Shopify
product export. Facts are read from five columns: Title, Body (HTML) or
description, Type, Tags and Option values. Handle identifies the row and is
never a fact source, because a handle is a URL slug and often outlives the
product it named. Variant Price is carried through untouched. Extra columns are
ignored. Up to 25
products a pass.

## The seven facts

A slot is PRESENT only where the row states it. Quote the words that fill it.

| # | slot | filled by |
|---|---|---|
| 1 | WHAT | the plain product noun a shopper would type ("dining table", "work apron") |
| 2 | WHO | who it is for, stated in the row |
| 3 | WHEN | the use, occasion or problem it answers, stated in the row |
| 4 | MADE OF | material, ingredients or construction, including fabric weight (gsm, oz) and what it is free of ("caffeine-free") |
| 5 | SIZE | dimensions, capacity, the item's own weight, count, or the size range |
| 6 | CARE OR FIT | care instructions, how to prepare or use it, compatibility, or what it works with |
| 7 | PROOF POINT | one of exactly four things: a warranty or guarantee length, a named certification, a stated place of manufacture, a test or lab figure. Nothing else fills this slot |

An adjective is never a fact. "Premium", "luxurious", "perfect for everyone",
"high quality" fill no slot. A tag fills a slot only where it is a plain fact
("linen", "queen size").

WHEN is filled by a named time, occasion or job, whether it sits in a sentence
or inside the product's own name: "Evening" in "Calm Evening Tea" fills it;
"for kneeling work in the garden" fills it. A mood word does not: "Everyday",
"Classic", "Signature" fill nothing. A slogan does not either: "Elevate your
mornings" states no use, so it fills nothing.

## What it refuses

**Refusal 1, no rows.**

```
NO PRODUCT ROWS SUPPLIED
Nothing pasted carries a Handle and a Title. There is nothing to rewrite.
```

**Refusal 2, never writes a fact the row does not carry.** A missing slot stays
missing. The rewrite is built from PRESENT slots only, and each missing slot
prints as `[NEEDS: <slot>, <the question to answer>]` for the owner.

**Refusal 3, the thin row.** A row with 3 or fewer slots PRESENT gets no
rewritten description:

```
TOO THIN TO REWRITE
"<title>"  <n> / 7 facts present
A description built from <n> facts would be padding. Supply the [NEEDS:] lines
first, then run this row again.
```

Its title is still rewritten by Step 4 where WHAT is present. A thin row is
left out of the CSV block, so an import cannot carry its old description through
looking like a rewrite.

## Method

**Step 1, read every row, route the incomplete ones.** A row needs Handle and
Title. One missing either prints `[NEEDS: <field>] for "<title or handle>"` and
is excluded from every count below.

**Step 2, fill the seven slots.** For each slot print PRESENT with the quoted
words and the column they came from, or MISSING.

**Step 3, score.** `<n> / 7 facts present`. 3 or fewer routes to Refusal 3.

**Step 4, the rewritten title.** Order: WHAT, then MADE OF (SIZE where MADE OF
is missing), then WHO (WHEN where WHO is missing). Drop every adjective that
fills no slot. Keep the brand's own product name where there is one, placed
first, followed by a comma. A product name is a title that is more than the
plain noun plus adjectives: "The Everyday Apron" and "Calm Evening Tea" are
names; "Luxurious Mug Set" is an adjective on a noun and is not. Where the name
already contains the WHAT noun or the WHEN word, do not repeat it. Print
the character count. No character limit is stated because OpenAI's articles do
not publish one; check the limit Ads Manager shows you.

**Step 5, the rewritten description.** Two to four sentences. Sentence one says
what it is and who or when it is for. The remaining sentences carry the other
PRESENT slots, one fact per clause. Every noun phrase must trace to a quoted
slot. No claim of superiority, no comparison to other brands, no health claim.

**Step 6, the health and policy flag.** Where a row's own words make a health,
medical or weight claim, print under that product: `POLICY FLAG: this row makes
a health claim ("<quoted words>"). OpenAI's ad policies restrict health claims.
The rewrite leaves the claim out.` Where the product's own name carries a word
tied to that claim ("Calm" beside "reduces anxiety"), the name is kept, because
renaming a product is the owner's call, and one more line prints: `The product
name "<name>" sits beside that claim. OpenAI reviews the ad and its landing page
together.`

**Step 7, the CSV block.** One line per product rewritten in full, three
columns: `Handle,Title,Body (HTML)`. Body wrapped in `<p>` tags, double quotes
escaped by doubling. Thin rows and excluded rows are not in the block. Under it
print `Not in the CSV: <handles>, too thin to rewrite` where any exist.

**Step 8, the import warning.** Always print, unchanged:

```
Before you import: this changes the title and description on your storefront and
on every channel that reads your catalog, ChatGPT Ads included. Export your
current products first so you can put them back. Shopify only overwrites
existing products when you tick the option to overwrite products with matching
handles.
```

## Output format

```
# Catalog rewrite, <store>
Population: every row pasted with a Handle and a Title, counted once.

## <handle>
Original title: "<title>"
| slot | status | quoted from the row |
|---|---|---|
| WHAT | PRESENT | "<words>" (Title) |
...
Facts present: <n> / 7
New title: "<title>" (<chars> characters)
New description: <text, or the Refusal 3 block>
[NEEDS: ...]
<POLICY FLAG where it applies>

## Counts
Rows read: <n>    Rewritten in full: <n>    Too thin: <n>    Excluded: <n>
Slot most often missing: <slot>, missing in <n> / <rows read>  (a tie prints every tied slot, in slot order)

## CSV
<the block>

## Before you import
<the fixed warning>
```

## Worked case

The literal run of `fixtures/kestrel-row-three-products.md`.

**`washed-linen-apron`**, original title "The Everyday Apron - Premium Quality".
WHAT PRESENT "apron" (Title). WHO PRESENT "for home cooks and potters"
(Body). WHEN MISSING. MADE OF PRESENT "100% European flax linen, 245 gsm"
(Body). SIZE PRESENT "One size, 86 cm long, adjustable cross-back straps"
(Body). CARE OR FIT PRESENT "Machine wash cold, tumble dry low" (Body). PROOF
POINT PRESENT "OEKO-TEX Standard 100 certified" (Body). Facts present: 6 / 7.
New title: "The Everyday Apron, 100% European flax linen, for home cooks and
potters" (72 characters). The name already holds the WHAT noun, so "apron"
is not repeated. "245 gsm" is fabric weight and sits in MADE OF. New description: "A cross-back apron for home cooks
and potters, cut from 100% European flax linen at 245 gsm. One size, 86 cm long,
with adjustable straps. Machine wash cold and tumble dry low. OEKO-TEX Standard
100 certified." `[NEEDS: WHEN, what job or mess is it built for?]`

**`stoneware-mug-set`**, original title "Luxurious Mug Set". WHAT PRESENT "mug
set" (Title). SIZE PRESENT "Set of 4" (Option values). Everything else MISSING:
"stoneware" appears only in the Handle, which is never a fact source, and
"Elevate your mornings" is a slogan. Facts present: 2 / 7 -> TOO THIN TO
REWRITE. "Luxurious Mug Set" is an adjective on a noun, so there is no product
name to keep. New title: "Mug set, set of 4" (17 characters). Five `[NEEDS:]`
lines print, and the row is left out of the CSV.

**`calm-tea-blend`**, original title "Calm Evening Tea". WHAT PRESENT "tea"
(Title). WHO MISSING. WHEN PRESENT "Evening" (Title). MADE OF PRESENT
"chamomile, lemon balm and lavender" (Body), with "caffeine-free" (Tags). SIZE
PRESENT "80 g tin, about 40 cups" (Body). CARE OR FIT PRESENT "Steep one
teaspoon for five minutes in water just off the boil" (Body). PROOF POINT
MISSING. Facts present: 5 / 7. The body says "Reduces anxiety and cures
insomnia" -> POLICY FLAG; the rewrite carries the ingredients, the tin size and
the steeping instructions and leaves the claim out. The product name line prints too, because "Calm" sits
beside that claim. New title: "Calm Evening Tea, chamomile, lemon balm and
lavender" (52 characters). The name already holds WHAT and WHEN, and WHO is
missing, so the title ends after MADE OF.

Counts: rows read 3, rewritten in full 2, too thin 1, excluded 0. Slot most
often missing: a three-way tie, so all three print in slot order: WHO, WHEN and
PROOF POINT, each missing in 2 / 3.

## Hard guardrails

- Never add a fact, a material, a dimension, a use or an audience the row did
  not state. `[NEEDS: ...]` instead.
- Never claim the rewrite improves delivery, relevance, ranking, click rate or
  cost. Nothing published supports it.
- Never state a character limit.
- Never write a health, medical or weight claim, even where the row carries one.
- Never compare to another brand.
- No em dashes. No exclamation marks. Audience word is DTC, never "ecom".
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `stop X start Y`, `less X more Y`). No "Most
  [group]" claims. No time-to-value claim.
