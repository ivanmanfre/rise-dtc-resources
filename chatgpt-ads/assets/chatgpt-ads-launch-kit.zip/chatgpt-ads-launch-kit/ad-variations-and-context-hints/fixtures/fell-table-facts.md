# Fixture, one product's facts with slogans mixed in

Invented for testing. Tarn & Alder is not a real brand.

Audience: couples in their thirties furnishing a first family home in the UK.
Landing page URL: https://tarnandalder.example/

Product page text, The Fell Table, 200 cm:

A beautiful, timeless dining table of heirloom quality. Solid European oak, made
to order in our workshop. Seats six comfortably, eight at a push. Length 200 cm,
width 90 cm, height 75 cm. Top thickness 4 cm. Finish: clear hardwax oil. Wipe
with a damp cloth and re-oil once a year. 10 year structural guarantee. Ships
flat in two boxes; legs bolt on with the supplied Allen key in about 20 minutes
with two people. Delivered to the room of your choice by two-person courier. The
Fell is our straight-edge table; the Beck has a live edge and comes only in
180 cm.
