---
name: ad-variations-and-context-hints
description: "Use when you are filling in a ChatGPT Ads ad group and need titles, descriptions and context hints that rest on facts about the product instead of slogans. Takes one product's facts and the audience in a sentence, and returns up to eight title and description pairs, each on a different named angle and each tied to the fact it rests on, plus a set of context hints written in the phrase shape OpenAI asks for. Triggers on \"write ChatGPT ad copy for my product\", \"context hints for ChatGPT ads\", \"ad variations for ChatGPT Ads Manager\", \"what do I put in the context hints field\", \"write titles and descriptions for a ChatGPT ad group\"."
---

# The ChatGPT Ads Launch Kit, 5 of 5: ad variations and context hints

## What this does

Writes the three text fields an ad group asks for: titles, descriptions and
context hints. It follows OpenAI's published guidance line by line, and the
guidance is quoted here so you can check it.

- "Build for coverage, not just one message: a high volume and diverse set of
  ads (multiple title/copy variations per offering) allows the system to
  identify more opportunities where your ads may be relevant."
- "Keep creatives distinct from each other: each title and description variation
  for a given offering should introduce a different angle rather than repeating
  the same message."
- Titles: "prioritize clear, useful details over broad marketing language."
- Descriptions: "add new information rather than repeating the same message."
  (all four: OpenAI Help, "Create Ads for ChatGPT Ads")
- Context hints: "Write clear, specific phrases that describe what you offer, who
  it helps, or when it may be useful. For example, 'cushioned everyday running
  shoes for beginners training for their first 5K' adds more useful context than
  'running shoes.'" They "are not exact-match keywords or targeting rules, and
  they do not guarantee delivery". (OpenAI Help, "Create ad groups")

**The line only this unit produces:** per variation, the angle it takes and the
product fact it rests on, so no two variations say the same thing and none says
something the product cannot back.

## Required input

1. **The product facts.** The product page, or the seven-slot output of
   `catalog-rewriter-for-chatgpt`, or the ANSWERED lines of
   `shopper-question-bank`.
2. **The audience in one sentence.**
3. **The landing page URL** the ads will point to.

## The eight angles

One variation per angle at most. An angle with no fact under it is skipped.

| # | angle | needs this fact |
|---|---|---|
| 1 | USE CASE | a stated use, occasion or job, in a sentence or inside the product's own name ("Evening" in "Calm Evening Tea") |
| 2 | WHO IT IS FOR | an audience the brand states on the product page. The audience sentence you supply shapes the context hints and never stands in for this fact |
| 3 | MATERIAL OR SPEC | a material, ingredient or measured specification |
| 4 | SIZE AND FIT | dimensions, capacity or a size range |
| 5 | CARE AND USE | care instructions, how to prepare or use it, or a stated lifespan |
| 6 | GUARANTEE | a warranty, guarantee or returns term |
| 7 | WHAT IS INCLUDED | contents, delivery terms or assembly facts |
| 8 | CHOOSING WITHIN THE RANGE | a stated difference from the brand's own other products |

## What it refuses

**Refusal 1, no facts.**

```
NO PRODUCT FACTS SUPPLIED
Every variation rests on a fact about the product. Paste the product page, or
the output of catalog-rewriter-for-chatgpt, first.
```

**Refusal 2, the unsupported angle.** An angle whose fact is absent prints:

```
SKIPPED: <angle>
[NEEDS: <the fact this angle rests on>]
```

It is never written on a guess. Fewer than eight variations is a correct result.

**Refusal 3, the claims ads cannot carry.** No health, medical or weight claim;
no "best", "number one" or any superlative; no comparison to another brand; no
price or discount the input did not state. Where the input itself carries a
health claim, print `LEFT OUT: "<the claim>", OpenAI's ad policies restrict
health claims` under `## Left out`. A measured fact the brand states about the
product ("bolts together in about 20 minutes") is a product fact and may be
used. A promise about what the ad or the purchase will do for the buyer is never
written.

## Method

**Step 1, list the facts.** Number every checkable fact in the input, quoted, as
F1, F2, and so on. Adjectives are not facts.

**Step 2, map facts to angles.** For each of the eight angles name the fact
numbers that support it, or route it to Refusal 2.

**Step 3, write one variation per supported angle.**
- Title: the product noun plus the angle's fact. No slogan.
- Description: one or two sentences that add a second fact the title did not
  use, where one exists. It never repeats the title's fact.
- The title carries one lead fact, the description one more. Print `rests on:
  F<lead>, F<second>` and the character count of each field.
- Length. OpenAI's ad format guide says "Headline: Aim for 16 characters" and
  "Description: Aim for 32 characters" (OpenAI Help, "Ads in ChatGPT: The
  Basics", the labelled example ad). These are targets OpenAI gives, and no hard
  limit is published. Write each title as close to 16 as its fact allows and
  each description as close to 32. Drop the brand's product name from the title
  where it will not fit; the advertiser name already shows above the ad. Print
  the count beside each field, and print `LONG` beside a title over 24 or a
  description over 48. Those two thresholds are this kit's own flag, one and a
  half times the guide.

**Step 4, the distinctness check.** Print a two column grid, one row per
variation: the angle, then its lead fact number. No two variations may share a
lead fact. Where two do, rewrite the later one on its next supporting fact, or
skip it. A fact may appear as the second fact in more than one description, and
where it does the two descriptions must be worded differently.

**Step 5, context hints.** Five to ten phrases, each in OpenAI's shape: what it
is, who it helps or when it is useful, in one plain noun phrase. Each must rest
on numbered facts, and where the audience sentence supplies the who or the when,
print `audience: yes` beside it. No single-word hints, no bare category names,
no competitor names.

**Step 6, the landing page line.** Print: `Point these ads at <URL>. OpenAI asks
for the most relevant destination, a product or collection page, and the page
must not block OAI-AdsBot or OAI-SearchBot.` Where the URL is a homepage, add:
`This is a homepage. OpenAI advises against defaulting to one.`

**Step 7, the image reminder.** Print, unchanged: `Images: PNG or JPG, square,
no larger than 1200 x 1200, at a public URL that opens the image itself (OpenAI
Help, "Troubleshooting Common Issues").`

## Output format

```
# Ad variations and context hints, <product>
Audience: <the sentence>

## Facts
F1 "<quoted>"
...

## Variations
### 1. <ANGLE>
Title: <title> (<chars>)
Description: <description> (<chars>)
rests on: F<n>, F<n>
...

## Skipped angles
<the Refusal 2 blocks, or "(none)">

## Left out
<the LEFT OUT lines, or "(none)">

## Distinctness grid
<variation x lead fact>

## Context hints
1. <phrase>   rests on: F<n>   audience: yes|no
...

## Landing page
<Step 6>

## Images
<Step 7>
```

## Worked case

Run on `fixtures/fell-table-facts.md`. The copy is written fresh each run, so
wording differs between runs. What does not differ, for this fixture:

- None of "beautiful", "timeless" or "heirloom quality" from the paste appears
  in the fact list. How finely the rest is split into numbered facts can differ
  between runs.
- WHO IT IS FOR is SKIPPED, because the paste never says who the table is for: `[NEEDS: who the table is for, stated by the
  brand]`. The audience sentence you supply shapes the context hints. It is not
  a product fact and cannot stand in for one.
- The GUARANTEE variation rests on "10 year structural guarantee" and says
  nothing about returns, because the fixture carries no returns term.
- The URL in the fixture is a homepage, so the homepage line prints.
- Titles come out short: "Solid oak dining table" is 22 characters, over the
  16 guide and under the LONG flag at 24.
- Every context hint is a phrase of several words, for example "solid oak dining
  table that seats six to eight for a family kitchen". "dining table" alone
  would fail Step 5.

The second fixture, `fixtures/calm-tea-with-health-claim.md`, carries "Reduces
anxiety and cures insomnia". That sentence prints under LEFT OUT and appears in
no title, description or hint.

## Hard guardrails

- Never write a variation on an angle with no supporting fact.
- Never reuse a title's lead fact in another title.
- Never call 16 and 32 limits. They are OpenAI's "aim for" targets. Never state
  or imply a delivery effect, a relevance score or an expected click rate.
- Never treat context hints as keywords. Phrases only.
- Never write a health, medical or weight claim, a superlative, or a comparison
  to another brand.
- No em dashes. No exclamation marks. Audience word is DTC, never "ecom".
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `stop X start Y`, `less X more Y`). No "Most
  [group]" claims. No time-to-value claim.
