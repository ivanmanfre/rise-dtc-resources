---
name: shopper-question-bank
description: "Use when shoppers are about to meet your products inside a conversation and you need to know which of their questions your store already answers in writing. Takes one product page plus the FAQ, shipping and returns text, and returns up to 30 pre-purchase questions across ten fixed classes, each answered only with a quoted line from your own store and where it lives, or marked for the owner to answer. Triggers on \"what will people ask ChatGPT about my product\", \"build a question bank for my product\", \"which buyer questions does my product page not answer\", \"prepare answers for a sponsored agent\", \"pre-sale FAQ from my product page\"."
---

# The ChatGPT Ads Launch Kit, 4 of 5: the shopper question bank

## What this does

An ad in ChatGPT appears under a conversation in which someone is already asking
questions. OpenAI's own example is a shopper who sees a dining table and wonders
"whether it fits their space, how many people it seats, or how to care for its
finish" (OpenAI, "Reimagining advertising with AI"). This unit lists the
questions a shopper asks before buying your product and checks each against what
your store already says in writing.

**The line only this unit produces:** per question, ANSWERED with the store's own
sentence quoted and its location named, or `[NEEDS: owner]`, plus the count of
each.

Three uses for the output: the unanswered questions are the gaps on the product
page; the answered ones are checked facts for ad titles and descriptions
(`ad-variations-and-context-hints` in this kit takes them); and the whole bank is
the brief a Sponsored Agent would need. On that last one, be exact: OpenAI says
Sponsored Agents "are now being tested with select advertisers in the United
States". No application route is published. This unit prepares the material. It
gives no access.

## Required input

1. **The product page text**, top to bottom, including the spec table.
2. **Store-wide text where it exists:** FAQ, shipping policy, returns policy,
   warranty or guarantee. Label each block with where it lives.
3. **The product's category in a few words.**

## The ten classes

Write up to three questions per class, in a shopper's words, specific to this
product, each drawing on a different fact where the page allows. A class is
skipped and named only where the product cannot have it (no CARE class for a
gift card). Classes 6 to 9 apply to every physical product: where the shipping,
returns, warranty or price text was not pasted, the questions are still written
and resolve to `[NEEDS: owner]`. Class 10 is written as one question where no
sibling product is named, and resolves to `[NEEDS: owner]`.

| # | class | what it covers |
|---|---|---|
| 1 | FIT AND SIZE | dimensions, sizing, capacity, will it fit |
| 2 | MATERIALS | what it is made of, ingredients, sourcing |
| 3 | CARE | cleaning, maintenance, lifespan in use |
| 4 | USE AND COMPATIBILITY | what it works with, how to use or assemble it |
| 5 | WHO IT IS FOR | the person or situation it suits, and who it does not suit |
| 6 | SHIPPING | cost, speed, regions, how it arrives |
| 7 | RETURNS | window, condition, who pays, exchanges |
| 8 | WARRANTY | guarantee length and what it covers |
| 9 | PRICE AND OFFERS | bundles, subscriptions, payment plans, what is included |
| 10 | CHOOSING WITHIN THE RANGE | how this differs from the brand's own other products |

## What it refuses

**Refusal 1, no product page.**

```
NO PRODUCT PAGE SUPPLIED
A question bank is built against one product's page. Paste the page text first.
```

**Refusal 2, never answers from outside the paste.** An answer is a quotation
from the pasted text. Where the text does not answer the question, the line is
`[NEEDS: owner]`. General knowledge about the product type is never used, even
where the answer seems obvious.

**Refusal 3, never half-answers.** Where the store's text addresses the question
only in part, the status is PARTIAL, the covered part is quoted, and the
uncovered part is named.

## Method

**Step 1, write the questions.** Up to three per class, thirty at most. Each must
be one a shopper could plausibly ask about this product. No question about
anything the page gives no reason to expect (no allergy question for a table).

**Step 2, search the paste for each answer.** A quotation is word for word. Line
breaks and extra spaces in the paste are ignored. Name the nearest heading the
quote sits under ("product page, Care"), or just "product page" where there are
no headings. Status is one of:
- ANSWERED: the quoted sentence states the thing asked. Quote it and name the
  block. A nearby fact the shopper would have to reason from is PARTIAL: box
  dimensions do not answer "will it fit through my doorway", because the page
  never states a clearance.
- PARTIAL: quote what is covered; name what is not.
- `[NEEDS: owner]`: nothing in the paste addresses it.

**Step 3, flag contradictions.** Where two pasted blocks disagree (the page says
30 days, the policy says 14), the question's own line reads `CONTRADICTION, see
below` followed by `[NEEDS: owner]`, and both quotes print once, under
`## Contradictions`. Where it is unclear whether two blocks describe the same
thing (a "made to order" table against a policy on "made-to-order items in a
custom size"), the status is PARTIAL and the uncovered part names the doubt.

**Step 4, flag claims that ads cannot carry.** Where an ANSWERED line is a
health, medical or weight claim, mark it `NOT FOR ADS` and cite: OpenAI's ad
policies restrict "claims related to the prevention, diagnosis, or treatment of
physical or mental health conditions".

**Step 5, count.** Over all questions written:

```
ANSWERED: <n> / <total>    PARTIAL: <n> / <total>    [NEEDS: owner]: <n> / <total>
```

and per class, the same three counts.

**Step 6, the page gaps.** List the `[NEEDS: owner]` and PARTIAL questions in
class order under "Add these to the product page". This is the action list.

## Output format

```
# Shopper question bank, <product>
Built only from the text pasted. Nothing here comes from outside it.

## 1. FIT AND SIZE
Q: <question>
   ANSWERED: "<quoted sentence>" (<block>)
Q: <question>
   [NEEDS: owner]
...

## Classes skipped
<class>, <why it does not apply>

## Contradictions
<both quotes, or "(none)">

## Counts
<Step 5>

## Add these to the product page
<Step 6>
```

## Worked case

Run on `fixtures/tarn-and-alder-oak-table.md`. The questions are written fresh
each run, so their wording and their number differ from run to run. What does
not differ is how a given question resolves against this fixture. These six
resolve the same way every time:

- FIT AND SIZE, "How many people does it seat?" ANSWERED: "Seats six
  comfortably, eight at a push." (product page, overview).
- FIT AND SIZE, "Will it fit through a standard doorway?" PARTIAL: "Ships flat in
  two boxes, the largest 185 x 95 x 12 cm." (product page, delivery) covers the
  box size; the page never states a doorway or stairwell clearance.
- CARE, "How do I care for the finish?" ANSWERED: "Wipe with a damp cloth. Re-oil
  once a year with any hardwax oil." (product page, care).
- CARE, "Does it mark from hot dishes?" `[NEEDS: owner]`.
- RETURNS, "How long do I have to return it?" CONTRADICTION: product page says
  "30 day returns", returns policy says "Furniture may be returned within 14
  days of delivery." -> `[NEEDS: owner]`.
- WARRANTY, "How long is the guarantee?" ANSWERED: "10 year structural
  guarantee." (product page, overview).

Counts are printed over however many questions the run wrote, and the three
figures always sum to that total. A run that wrote 24 and printed 13, 4 and 7
is consistent; one that printed 13, 4 and 8 is not.

The second fixture, `fixtures/no-policies-pasted.md`, carries a product page and
no store-wide text. Classes 6, 7 and 8 return `[NEEDS: owner]` on every question,
with one added line: `[NEEDS: the shipping, returns and warranty text, pasted
with where each lives]`.

## Hard guardrails

- Never answer from general knowledge. A quotation from the paste, or
  `[NEEDS: owner]`.
- Never soften a contradiction into an answer.
- Never say or imply that Sponsored Agents are available to the reader.
- Never write more than three questions in a class or thirty in all.
- Never count a PARTIAL as ANSWERED.
- No em dashes. No exclamation marks. Audience word is DTC, never "ecom".
- Banned in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
- No corrective-contrast phrasing (`isn't X, it's Y`, `not just`, `more than
  just`, `instead of just`, `stop X start Y`, `less X more Y`). No "Most
  [group]" claims. No time-to-value claim.
