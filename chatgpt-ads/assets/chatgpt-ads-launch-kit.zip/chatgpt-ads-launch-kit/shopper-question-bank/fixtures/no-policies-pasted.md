# Fixture, a product page with no store-wide text

Invented for testing. Sedge Supply is not a real brand. Designed to exercise the
path where shipping, returns and warranty cannot be answered at all.

Category: canvas work apron

## Product page: The Bench Apron

A waxed canvas work apron for woodworkers and gardeners. 16 oz cotton canvas,
brass rivets, leather cross-back straps. One size, 92 cm long, fits chest sizes
86 to 127 cm. Two chest pockets, one hammer loop, a split leg for kneeling.
Brush clean. Re-wax once a year. Do not machine wash.
