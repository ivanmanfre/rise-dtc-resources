# Fixture, one product page plus store policies, with a planted contradiction

Invented for testing. Tarn & Alder is not a real brand.

Category: solid wood dining table

## Product page: The Fell Table, 200 cm

Overview: A solid European oak dining table, made to order in our workshop.
Seats six comfortably, eight at a push. 10 year structural guarantee. 30 day
returns.

Specifications: Length 200 cm. Width 90 cm. Height 75 cm. Top thickness 4 cm.
Weight 68 kg. Finish: clear hardwax oil.

Care: Wipe with a damp cloth. Re-oil once a year with any hardwax oil.

Delivery: Ships flat in two boxes, the largest 185 x 95 x 12 cm. Legs bolt on
with the supplied Allen key, about 20 minutes with two people. Made to order,
dispatched in 4 to 6 weeks.

## FAQ (store-wide, /pages/faq)

Do you deliver outside the UK? Not at the moment. We deliver to mainland UK
only.
Can I pay in instalments? Yes, Klarna is available at checkout on orders over
£500.
Which table is right for me? The Fell is our straight-edge table. The Beck has
a live edge and is only available in 180 cm.

## Shipping policy (/policies/shipping-policy)

Furniture delivery is a flat £65 to mainland UK by two-person courier, to the
room of your choice.

## Returns policy (/policies/refund-policy)

Furniture may be returned within 14 days of delivery. The customer pays the
return courier. Made-to-order items in a custom size cannot be returned.
