# Level 8: The Multi-Agent Team

**What you build:** several agents handing off across the process.
**When:** Week 4, Days 22 to 24 of the 30-day plan.
**Time to set up:** about 4 hours.
**Where you run it:** Claude Code, with subagents in your brand folder's `.claude/agents/`.

---

## What to build

One agent doing everything ends up doing each part badly: its instructions get long, its tools get broad, and its mistakes are hard to trace. A team splits the process into jobs, gives each job its own agent with its own tools and rules, and passes the work between them in files.

Your media buying team has five agents:

| Agent | Job | Reads | Writes | Tools |
|---|---|---|---|---|
| `angle-researcher` (Level 7) | Research and scored angles | brain, data | `pipeline/angles-[date].md` | Read, Grep, Glob, WebFetch, WebSearch, Write |
| `brief-writer` | Briefs and hooks for chosen angles | angles file, brain | `pipeline/briefs-[date].md` | Read, Grep, Glob, Write |
| `copywriter` | Primary text, headlines, descriptions | briefs file, brain | `pipeline/copy-[date].md` | Read, Grep, Glob, Write |
| `claim-checker` | Checks every claim before anything ships | briefs, copy, claim sources | `pipeline/claim-check-[date].md` | Read, Grep, Glob, Write |
| `performance-analyst` | Weekly read, budget steps, report | data, brain | `reports/week-[date].md` | Read, Grep, Glob, Write |

The main Claude Code session is the coordinator. It starts each agent in order, checks that the hand-off file exists and has the right header, and stops at the points where you decide.

The loop the team runs:

```
performance-analyst ── what worked and what did not ──┐
        ^                                             v
   (ads run)                                 angle-researcher
        ^                                             |
   YOU launch ads                        YOU pick angles (Checkpoint 2)
        ^                                             v
   claim-checker <── copywriter <── brief-writer <────┘
        |
   YOU approve (Checkpoint 3)
```

Each agent does its own job and nothing else. The copywriter never picks angles. The claim-checker passes, fails and suggests, and leaves the rewriting to the copywriter. The analyst recommends budgets with the sums and leaves the change to you.

## Before you start

- The research agent from Level 7, working.
- Your skills from Level 6 installed.
- The `pipeline/` and `reports/` folders in your brand folder.

## Step-by-step setup

1. **Create the four new agent files** in `.claude/agents/` from the briefs below.
2. **Create the coordinator skill,** `run-creative-cycle`, from the template below, in `.claude/skills/run-creative-cycle/SKILL.md`. This is what you call to start the team.
3. **Add the hand-off rules to `CLAUDE.md`** (template below), so every agent and the coordinator use the same file names and headers.
4. **Dry run.** Start Claude Code in the brand folder and say: "Run run-creative-cycle up to Checkpoint 2." Check that `angles-[date].md` appears and the coordinator stops.
5. **Make your Checkpoint 2 decision** in the file: fill in "Decided by me".
6. **Continue.** Say: "Continue run-creative-cycle from Checkpoint 2." The coordinator runs brief-writer, copywriter and claim-checker in order, and stops at Checkpoint 3.
7. **Read the claim-check file first.** If there are FAILs, say "Send the FAILs back to copywriter" and let the loop fix them. Approve when it is clean.
8. **Run the analyst on its own** every Monday: "Use the performance-analyst agent on this week's data."
9. **Time each run.** Note how long each agent took and what you changed afterwards. An agent whose output you rewrite every time needs a tighter brief.

## Copy-paste prompts

### Prompt 8.1: start the cycle

```
Run run-creative-cycle. Month: [MONTH]. Test budget: $[ ]. Focus segment: [SEGMENT or ALL]. Stop at Checkpoint 2.
```

### Prompt 8.2: continue after your decision

```
I have filled in "Decided by me" in pipeline/angles-[date].md. Continue run-creative-cycle from Checkpoint 2 and stop at Checkpoint 3.
```

### Prompt 8.3: the team audit

Run this after every full cycle.

```
Read every pipeline file from the last cycle. For each agent:
- did its output have the right header and every required section?
- how many lines did the next agent or I have to change?
- which rule in its brief, if added, would have prevented the most common change?
Print a table and one proposed rule per agent. Do not edit any agent file.
```

## Project and skill templates

### Hand-off rules for `CLAUDE.md`

```
## Team hand-offs
- Every pipeline and report file starts with: title and date, Written by, Read from, Data flags, Waiting on.
- Agents write only inside pipeline/ or reports/.
- An agent that cannot finish writes its file anyway, with [NEEDS: ...] where it stopped, and says so in "Waiting on".
- Checkpoints 2 and 3 are human. The coordinator stops and waits there, every time.
- No agent changes anything in Ads Manager, Google Ads, Shopify, or any live system.
```

### Coordinator skill: `.claude/skills/run-creative-cycle/SKILL.md`

```
---
name: run-creative-cycle
description: Use to run the monthly creative cycle for this brand with the agent team, from research to claim-checked copy. Starts angle-researcher, then stops for the media buyer at Checkpoint 2; on "continue", runs brief-writer, copywriter and claim-checker, then stops at Checkpoint 3. Triggers on "run the creative cycle", "start this month's creative", "continue the cycle".
---

# Run the creative cycle

1. Run the data-check skill. If a voice, competitors or live-ads file is STALE or MISSING, tell me and ask whether to continue.
2. Start the angle-researcher agent with the month, test budget and segment I gave.
3. Confirm pipeline/angles-[date].md exists and has the hand-off header. Show me the RECOMMENDED list.
4. STOP. Checkpoint 2. Wait for me to fill in "Decided by me" and say continue.
5. On continue: read "Decided by me". Start brief-writer with only the angles I kept.
6. Confirm briefs file and header. Start copywriter.
7. Confirm copy file and header. Start claim-checker.
8. If claim-check has FAILs, send only the failing lines back to copywriter once, then run claim-checker again.
9. STOP. Checkpoint 3. Show me the claim-check summary: PASS count, FAIL count, DELETE count.
Never skip a checkpoint. Never start an agent whose input file is missing.
```

### Agent brief: `.claude/agents/brief-writer.md`

```
---
name: brief-writer
description: Writes creative briefs and hooks for angles the media buyer has already chosen. Use after Checkpoint 2 of the creative cycle. Never chooses angles.
tools: Read, Grep, Glob, Write
---
You write briefs a creator or designer can shoot from without asking a question.
Input: pipeline/angles-[date].md (only the angles listed in "Decided by me"), CLAUDE.md, brain/.
For each angle write: angle sentence and segment; claim boundary (allowed claims with sources, and what may not be said); six hooks tagged with device and source; one UGC video brief of 20 to 40 seconds, shot by shot with spoken lines, on-screen text and seconds; one static brief (headline, subline, visual, proof element); the question the test answers; deliverables (ratios 9:16, 4:5, 1:1, lengths, file names).
Rules: every line traces to a quote or fact in the files. [NEEDS: x] for gaps. Write only pipeline/briefs-[date].md with the hand-off header, then stop.
```

### Agent brief: `.claude/agents/copywriter.md`

```
---
name: copywriter
description: Writes ad copy from finished briefs. Use after brief-writer in the creative cycle, or when claim-checker sends lines back.
tools: Read, Grep, Glob, Write
---
Input: pipeline/briefs-[date].md, CLAUDE.md, brain/. When called with claim-check FAILs, input is only those lines and their reasons.
For each brief: 5 primary texts (first line under about 125 characters, each using a different hook from the brief), 5 headlines under 40 characters, 5 descriptions under 30 characters; for Google search if the brief asks, 10 headlines under 30 characters and 4 descriptions under 90 characters.
Rules: stay inside each brief's claim boundary. Follow "How we sound" in the brand brief. No numbers, reviews or results not in the files. Write only pipeline/copy-[date].md with the hand-off header, then stop.
```

### Agent brief: `.claude/agents/claim-checker.md`

```
---
name: claim-checker
description: Checks every factual line in briefs and copy against the brand's claim sources, banned claims and ad platform policy. Use before anything is sent to a creator or launched. Passes, fails and suggests; never rewrites the files it checks.
tools: Read, Grep, Glob, Write
---
Input: pipeline/briefs-[date].md, pipeline/copy-[date].md, brain/claim-sources.md, the banned claims in CLAUDE.md.
For every line that states a fact, result, comparison or promise: PASS with the source name, or FAIL with the reason (no source, banned, stronger than the source allows, platform policy risk: health, before-and-after, personal attributes, income). For each FAIL give one rewrite using only a supported fact, or DELETE.
Rules: you never edit the briefs or copy files. Write only pipeline/claim-check-[date].md with the hand-off header and a summary line: PASS n, FAIL n, DELETE n. Then stop.
```

### Agent brief: `.claude/agents/performance-analyst.md`

```
---
name: performance-analyst
description: Reads the week's ad and store data and writes the weekly performance report with scale, hold and cut verdicts, budget steps and contribution after ads. Use every Monday after the data refresh, or when asked how the account did.
tools: Read, Grep, Glob, Write
skills:
  - weekly-ad-read
  - weekly-report
---
Input: data/data-index.md and the newest ads-7d, ads-30d and store-7d files; CLAUDE.md and brain/.
Steps: run data-check; run weekly-ad-read on ads-7d; for SCALE ad sets, propose the next daily budget as a step of no more than 20% with the hold period (the larger of 7 days and 10 purchases at the new budget) and the revert condition; compare platform and store numbers; write contribution after ads for this week and last; list the angles behind SCALE and CUT ads for the next research run.
Rules: every number with its file and its sum. Recommend only. You never change a budget or an ad. Write only reports/week-[date].md with the hand-off header, then stop.
```

## Agent brief and guardrails

The team-level guardrails, on top of each agent's own:

- **Separate duties.** The agent that writes copy never checks it. The agent that recommends budgets never sets them.
- **Files as the only hand-off.** Agents do not pass work to each other in conversation. Every hand-off is a file you can open.
- **Human checkpoints are fixed.** The coordinator skill stops at 2 and 3 every time. Nobody edits that out to save a minute.
- **One retry.** When the claim-checker fails lines, they go back to the copywriter once. A second failure comes to you.
- **Read-only on live systems.** No agent in this team has a tool or connector that can change an ad account or a store.

## A real media buying workflow: the monthly cycle with the team

1. **Day 1, Monday.** Refresh data (Level 4). Performance-analyst writes the week's report. You act on the CUT list in Ads Manager.
2. **Day 1, afternoon.** Prompt 8.1. The researcher runs while you do other work. You pick angles at Checkpoint 2.
3. **Day 2.** Prompt 8.2. Briefs, copy and claim check come back. You approve at Checkpoint 3 and send briefs to creators.
4. **Days 3 to 10.** Creative is produced. You build the ads from the copy file and launch.
5. **Every Monday after.** Performance-analyst reports. New ads show NOT ENOUGH SPEND until each reaches 10 purchases, then SCALE, HOLD or CUT.
6. **Next month, Day 1.** The researcher reads the analyst's list of winning and losing angles as input. The loop closes.

## Where the Paid Ads System fits

The Complete Claude Paid Ads System includes a ready team of 30 agents in five teams of six, each one `SKILL.md` with one job. You can use them as the specialists your five agents call, or as a bigger team from day one:

- **Track** (for the analyst's data checks): `track-01-utm-tag-auditor`, `track-03-tracking-break-checker`, `track-06-agency-report-reader`.
- **Spend** (for the analyst's budget steps): `spend-01-budget-step-planner`, `spend-02-scale-break-diagnoser`, `spend-05-stock-cover-guard`, and `spend-04-policy-risk-checker` for the claim-checker.
- **Creative** (for the researcher, brief-writer and copywriter): `creative-01-angle-gap-mapper`, `creative-02-ad-brief-writer`, `creative-03-ad-hook-writer`, `creative-05-winner-iteration-planner`.
- **Convert** (for the page the ads send people to): `convert-01-message-match-checker`, `convert-05-first-screen-rewriter`.
- **Decide** (for the analyst's verdicts): `decide-01-scale-or-kill-judge`, `decide-02-change-log-auditor`, `decide-05-net-revenue-corrector`.

Those 30 are written as skills, so install them into `~/.claude/skills/` or `.claude/skills/` (Level 6) and add them to each agent's `skills:` list.

## Move up to Level 9 when

- The team has run one full cycle, start to finish, and you launched ads from its output.
- Prompt 8.3 shows each agent's output needed only small changes.
- You notice you are the one starting every run at the same time each week. Level 9 starts them for you.

## Common mistakes

- **Agents talking to each other in chat.** You lose the record. Make every hand-off a file.
- **Removing checkpoints once it works.** The checkpoints are why it keeps working.
- **One brief for every brand.** Keep agent briefs brand-free and let each brand folder's `CLAUDE.md` and `brain/` supply the facts.
