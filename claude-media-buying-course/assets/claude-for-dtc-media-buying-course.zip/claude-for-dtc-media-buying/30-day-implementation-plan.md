# The 30-Day Implementation Plan

Ten levels in 30 days, for one brand, working about an hour a day around your normal media buying. Each day has one job and one thing to check before you move on. If a day slips, move the rest down a day. Do not skip a level: each one is the input to the next.

The plan assumes you run ads on Meta, and Google where noted, for a DTC brand with a Shopify store (or similar). Days that need Claude Code say so. If you only use claude.ai, stop at Level 6 and use the claude.ai versions in Levels 7 and 9.

---

## Week 1: prompts and the brain (Levels 1 to 3)

| Day | Level | Do this | Done when |
|---|---|---|---|
| 1 | 1 | List last week's tasks and count them. Pick your highest-frequency task. Fill the fixed inputs in Prompt 1.A, 1.B or 1.C. Run it on real data. | You have one output and you checked two lines of it by hand. |
| 2 | 1 | Fix the prompt from what you found. Run it again. Save it where you can paste it in five seconds. Write the skill version block under it. | The saved prompt runs with no edits. |
| 3 | 2 | Create `prompt-library.md` with the fixed inputs block. Paste prompts 2.1 to 2.10. Run 2.1 (customer research) and 2.2 (competitor ad analysis). | Two outputs saved, one per stage. |
| 4 | 2 | Run 2.3 to 2.6 on the outputs from Day 3. Read 2.7 to 2.10 and fill their inputs for next week. | Angles, hooks, one brief and copy saved. |
| 5 | 3 | Create the Project "Media buying: [Brand]". Run Prompt 3.1 on your existing material to draft the brand brief. | A draft brief with every [NEEDS: ...] listed. |
| 6 | 3 | Fill the [NEEDS] gaps. Paste the brief into project instructions. Upload `prompt-library.md`, `product-facts.md`, `claim-sources.md`, `customer-quotes.md`. | The three test questions in Level 3 come back right. |
| 7 | 3 | Work inside the Project for all your media buying today. Note anything you still had to paste. | Your list of repeated pastes (it becomes Week 2). |

**If you use Claude Code:** on Day 6, also create the brand folder with `CLAUDE.md` and `brain/`. You will need it from Day 18.

## Week 2: data and the pipeline (Levels 4 and 5)

| Day | Level | Do this | Done when |
|---|---|---|---|
| 8 | 4 | Build and save the Ads Manager report view. Export 7-day and 30-day files. Export store numbers for the same 7 days. | Three dated files. |
| 9 | 4 | Build the voice file, the competitor file (Meta Ad Library) and the live-ads file. Write `data-index.md`. Put all files where Claude reads them. | All five file types in place. |
| 10 | 4 | Run Prompt 4.1 (data check) and fix every flag. Run Prompt 4.2 (platform versus store). Add the data rules to your brief. | Data check clean. |
| 11 | 5 | Add pipeline prompts 5.1 to 5.5. Work out how many angles your test budget can read. Run 5.1. Do Checkpoint 1. | `research-[date].md` saved, with your cuts noted. |
| 12 | 5 | Run 5.2. Do Checkpoint 2 and write why you picked each angle. | `angles-[date].md` with "Decided by me" filled in. |
| 13 | 5 | Run 5.3 and 5.4 for the chosen angles. Run 5.5 (claim check). Fix every FAIL. | Briefs and copy with zero FAILs. |
| 14 | 5 | Send the briefs to creators and designers. Run your Level 1 weekly read as usual. | Briefs sent. First real pipeline output in production. |

## Week 3: skills and the research agent (Levels 6 and 7)

| Day | Level | Do this | Done when |
|---|---|---|---|
| 15 | 6 | Pick your first five skills. Run Prompt 6.1 on each prompt to write its `SKILL.md`. Move brand facts out of them. | Five skill folders. |
| 16 | 6 | Add a fixture (example input and checked output) to each skill. Install them (claude.ai Customize > Skills, or `~/.claude/skills/`). If you use The Complete Claude Paid Ads System, install the skills you need from it too. | Skills installed and turned on. |
| 17 | 6 | Test each skill by name and by need. Rewrite any description Claude did not pick. Run Prompt 6.2 on each fixture. | Every skill picked by need, every fixture MATCH. |
| 18 | 7 | (Claude Code) Create `.claude/agents/angle-researcher.md` from the brief. Write `data/research-sources.md`. Create `pipeline/`. | Agent file in place. |
| 19 | 7 | Run the agent with Prompt 7.1. Do something else while it runs. Review with Prompt 7.2. | First agent-written angles file, checked. |
| 20 | 7 | Tighten the brief with Prompt 7.3. Run it again on the same data. Compare the top angles. | Top angles stable between runs. |
| 21 | 7 | Run your weekly read. Note which angles from Day 12 have reached 10 purchases yet. | Week 3 read saved. |

## Week 4: the team, the schedule and the system (Levels 8 to 10)

| Day | Level | Do this | Done when |
|---|---|---|---|
| 22 | 8 | (Claude Code) Create brief-writer, copywriter, claim-checker and performance-analyst. Add the hand-off rules to `CLAUDE.md`. | Five agent files. |
| 23 | 8 | Create the `run-creative-cycle` skill. Dry run to Checkpoint 2 with Prompt 8.1. | Coordinator stops at Checkpoint 2. |
| 24 | 8 | Decide at Checkpoint 2. Continue with Prompt 8.2 to Checkpoint 3. Run performance-analyst on this week's data. Run Prompt 8.3. | A full cycle's files, plus one weekly report from the analyst. |
| 25 | 9 | Choose your scheduling route (Desktop scheduled task, cloud routine, or `claude -p` on a scheduler). Set up how fresh data reaches `data/`. Add the run log rule. | Data arrives without you, or your 10-minute Monday refresh is booked. |
| 26 | 9 | Create the spend guard and the weekly report as scheduled runs. Click Run now on each and approve their tools. | Both ran once, each with a log line. |
| 27 | 9 | Add the winner check. Read every scheduled output so far. Fix any instructions that stalled or used stale data. | Three scheduled runs, no stalls. |
| 28 | 10 | Lay out the final folder. Add the operating rhythm and the decision table to `CLAUDE.md`. Close the loop in the researcher's brief. | Folder matches the Level 10 layout. |
| 29 | 10 | Run Prompt 10.1 (system check). Fix every FAIL. Add the angle refresh and monthly report as scheduled runs. | System check passes every line. |
| 30 | 10 | Review the month: what ran, what you rewrote, what you still did by hand. Book the first monthly retro (Prompt 10.2) for the end of next month. | Your list of the next three improvements. |

---

## Where each level sits

| Level | Name | Days |
|---|---|---|
| 1 | The Saved Prompt | 1 to 2 |
| 2 | The Prompt Library | 3 to 4 |
| 3 | The Permanent Brain | 5 to 7 |
| 4 | The Connected Data | 8 to 10 |
| 5 | The Research-to-Creative Pipeline | 11 to 14 |
| 6 | The Skill Stack | 15 to 17 |
| 7 | The Research Agent | 18 to 21 |
| 8 | The Multi-Agent Team | 22 to 24 |
| 9 | The Automated Workflows | 25 to 27 |
| 10 | The Complete System | 28 to 30 |

## Rules for the 30 days

- **Real data only.** Every test in this plan runs on your own exports, reviews and ads. A demo input tells you nothing about your account.
- **Check two lines by hand every time** until a prompt, skill or agent has earned your trust.
- **Keep your normal media buying going.** The plan fits around it. The weekly read (Level 1) runs every Monday from Day 1.
- **Write down every decision** at the checkpoints. Month two runs on what month one learned.
