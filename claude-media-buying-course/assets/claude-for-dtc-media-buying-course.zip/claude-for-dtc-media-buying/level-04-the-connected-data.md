# Level 4: The Connected Data

**What you build:** your reviews, competitor ads and ad exports plugged in.
**When:** Week 2, Days 8 to 10 of the 30-day plan.
**Time to set up:** about 3 hours, then 20 minutes a week to refresh.
**Where you run it:** your Claude Project from Level 3, or the Claude Code folder from Level 3.

---

## What to build

Your brain knows who you are. It does not know what happened this week. Level 4 gives Claude a fixed place where your raw data lives, with fixed names, refreshed on a fixed day.

Five data sources cover most media buying decisions:

| Source | Where it comes from | File name | Refresh |
|---|---|---|---|
| Ad performance | Ads Manager export at ad level, last 7 and last 30 days | `ads-7d-[date].csv`, `ads-30d-[date].csv` | Weekly |
| Store numbers | Shopify (or your store) orders and revenue for the same windows | `store-7d-[date].csv` | Weekly |
| Customer voice | Reviews, post-purchase survey answers, support tickets, ad comments | `voice-[date].md` | Every 2 weeks |
| Competitor ads | Ad text and start dates copied from the Meta Ad Library | `competitors-[date].md` | Every 2 weeks |
| Live ads | The primary text, headline and hook of every ad now running | `live-ads-[date].md` | Weekly |

"Plugged in" means Claude reads these files where they sit. You stop pasting the same export into a new chat every day.

There are three ways to do it. Pick the one that fits how you work:

1. **Project knowledge (claude.ai).** Upload the files to your Project. Simple, and it works on any plan. You replace the files by hand each week.
2. **Google Drive connector (claude.ai).** Claude's Google Workspace connectors include Google Drive. In a private Project you can add Google Docs to project knowledge from Drive, and they stay synced with the latest version. Keep your voice file, competitor file and live-ads file as Google Docs and they refresh on their own when you edit them. Claude reads the text only and skips images inside the doc.
3. **A data folder (Claude Code).** Put the files in a `data/` folder inside the brand folder from Level 3. Claude Code reads any file in its working folder, including CSVs. This is the setup Levels 7 to 10 build on.

Check Customize > Connectors on claude.ai for other connectors on your plan. If your ad platform or store has no connector there, exports work fine, and every step in this course assumes exports.

## Before you start

- The brain Project or folder from Level 3.
- Access to Ads Manager, your store admin, your review app, and the Meta Ad Library.
- A list of 5 to 10 competitors, named.

## Step-by-step setup

1. **Build your Ads Manager export view once.** In Ads Manager, set the level to Ads, choose columns: ad name, ad set name, campaign name, amount spent, impressions, link clicks, purchases, purchase conversion value, and the date range. Save it as a saved report so next week's export is one click.
2. **Export last 7 days and last 30 days.** Name the files `ads-7d-[date].csv` and `ads-30d-[date].csv` with the export date.
3. **Export the store numbers** for the same two windows: orders, gross sales, discounts, refunds, net sales, new versus returning customers if you have it.
4. **Build the voice file.** Paste your latest reviews, survey answers and ticket excerpts into one document, each block labelled by source.
5. **Build the competitor file.** For each competitor, open their page in the Meta Ad Library, and copy the text of every active ad with its start date. One heading per brand.
6. **Build the live-ads file.** For every ad running now: ad name, primary text, headline, the hook (first line spoken or shown), the angle.
7. **Put the files where Claude reads them** (project knowledge, Google Docs in the Project, or `data/`).
8. **Write the data index** (template below) and add it to the same place. It tells Claude what each file is, which dates it covers, and when it goes stale.
9. **Run Prompt 4.1, the data check,** and fix whatever it flags.
10. **Put the refresh on your calendar.** Monday morning for the weekly files, every other Monday for voice and competitors.

## Copy-paste prompts

### Prompt 4.1: the data check

```
Read data-index.md and every data file it lists. For each file print:
- file name, the date range it covers, number of rows or items
- STALE if its date is older than the refresh period in the index
- MISSING if the index lists it and the file is not there
- any column the weekly read needs that is not in the file (ad name, spend, purchases, purchase value)
Then print one line: which of my prompts cannot run today and why.
Do not analyse the data yet.
```

### Prompt 4.2: platform versus store

```
Use ads-7d and store-7d from the data files.
1. Total ad spend and total platform-reported purchase value, with the sums.
2. Store net sales and orders for the same dates.
3. Platform ROAS = platform purchase value / spend. MER = store net sales / spend. Show both sums.
4. The gap between platform purchases and store orders, as a count and as a share of store orders, with the sum.
5. One sentence on what the gap means for how much I trust platform numbers this week.
Use only these files. Print [NEEDS: x] for anything missing.
```

### Prompt 4.3: what changed in the customer voice

```
Compare voice-[newest date] with voice-[previous date].
1. Themes that appear in the new file and not the old one, with quotes and counts.
2. Themes that grew or shrank, with counts from each file.
3. Any new complaint about delivery, quality or the offer, quoted.
Only use the two files. Show every count.
```

### Prompt 4.4: competitor movement

```
Compare competitors-[newest date] with competitors-[previous date].
1. For each brand: new ads, ads that stopped, ads still running from before (with start dates).
2. Angles that more brands use now than before.
3. Offers that changed (price, discount, bundle, guarantee).
Only use the two files. Show every count.
```

## Project and skill templates

### `data-index.md`

```
# Data index: [BRAND]
| File | What it is | Source | Covers | Refresh every | Owner |
|---|---|---|---|---|---|
| ads-7d-YYYY-MM-DD.csv | Ad-level results, last 7 days | Ads Manager saved report "[name]" | 7 days to export date | 7 days | [name] |
| ads-30d-YYYY-MM-DD.csv | Ad-level results, last 30 days | same | 30 days | 7 days | |
| store-7d-YYYY-MM-DD.csv | Orders and net sales | Shopify > Analytics > Reports | 7 days | 7 days | |
| voice-YYYY-MM-DD.md | Reviews, survey, tickets, comments | [review app], [survey tool], [help desk] | since last file | 14 days | |
| competitors-YYYY-MM-DD.md | Active competitor ad text + start dates | Meta Ad Library | active on that date | 14 days | |
| live-ads-YYYY-MM-DD.md | Our running ads: text, headline, hook, angle | Ads Manager | on that date | 7 days | |

Rules for Claude:
- Always use the newest file of each type unless I name one.
- If the newest file is older than its refresh period, say STALE before using it.
```

### Project instructions addition

Add this to your Level 3 brief under "How you work":

```
- Data files are listed in data-index.md. Read the index first.
- Never mix date ranges in one sum. If two files cover different dates, say so.
- Platform numbers and store numbers disagree. Name which one a figure comes from every time.
```

### Skill template

The data check is your first candidate for a skill, because every later workflow starts with it:

```
---
name: data-check
description: Use at the start of any media buying session to confirm which data files are present, fresh and complete before analysis. Reads data-index.md and the files it lists, and returns STALE, MISSING and missing-column flags plus the prompts that cannot run today.
---
[paste Prompt 4.1 here]
```

## Agent brief and guardrails

Agents at Level 7 and above read this folder without you watching. Set the rules now:

- **Read-only.** Nothing Claude does touches the data files except the refresh you do by hand (or the export automation at Level 9).
- **Name the file behind every number.** "Spend $4,210.00 (ads-7d-2026-10-05.csv)" is checkable. "Spend was about $4k" is not.
- **Stale data is a stop.** A verdict on a 3-week-old export is worse than no verdict.
- **No customer personal data.** Strip names, emails and addresses from reviews and tickets before they go in the voice file.

## A real media buying workflow: the Monday data refresh

1. Monday, 8:40. Run the Ads Manager saved report for 7 and 30 days. Save both CSVs with today's date.
2. Export store numbers for the same 7 days.
3. Update the live-ads file with anything launched or paused last week.
4. Every other Monday: add new reviews and survey answers to a new voice file, and copy new competitor ads into a new competitor file.
5. Drop the files in place and run Prompt 4.1.
6. Run Prompt 4.2. If the gap between platform and store is much bigger than last week, check tracking before you trust any ad-level verdict.
7. Run your Level 1 weekly read on `ads-7d`. You are done with data by 9:15.

## Where the Paid Ads System fits

- The **Track** team in The Complete Claude Paid Ads System checks the data before you read it: `track-01-utm-tag-auditor`, `track-02-attribution-window-matcher`, `track-03-tracking-break-checker`.
- The `roas-vs-mer-reader` skill is the full version of Prompt 4.2.
- The `utm-tag-auditor` skill catches broken UTMs that make store and platform numbers disagree.
- Prompt P48 (Find Where Platform Revenue and Shopify Disagree) goes deeper when the gap is large.

## Move up to Level 5 when

- Prompt 4.1 comes back clean two weeks in a row.
- You no longer paste an export into a chat. You say "use ads-7d".
- You have at least one voice file and one competitor file. Level 5 turns them into ads.

## Common mistakes

- **Files without dates in the name.** You will not know which export Claude read.
- **Mixing windows.** A 7-day spend divided by 30-day purchases gives a number that means nothing. The index and the brief rule stop this.
- **Skipping the competitor file.** It is the only way to know which angles are already crowded before you pay to find out.
