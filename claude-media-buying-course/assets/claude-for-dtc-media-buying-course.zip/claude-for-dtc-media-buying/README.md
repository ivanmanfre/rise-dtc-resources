# Claude for DTC Media Buying: the 10 levels

Built by the team at RISE DTC.

A practical course for running DTC media buying with Claude, in ten levels, from one saved prompt to a complete system that keeps your tests and scaling moving with far less of the work done by hand. It is built for founders who run their own ads, media buyers and creative strategists.

You can get value from it within 10 minutes: Level 1 gives you one prompt you can run on this week's ads today.

## The 10 levels

| Level | Name | What you build | When |
|---|---|---|---|
| 1 | The Saved Prompt | One reusable prompt for your highest-frequency task | Week 1 |
| 2 | The Prompt Library | A saved prompt for every stage of the process | Week 1 |
| 3 | The Permanent Brain | A brand brief Claude reads every time | Week 1 |
| 4 | The Connected Data | Your reviews, competitor ads and ad exports plugged in | Week 2 |
| 5 | The Research-to-Creative Pipeline | Raw research turned into finished angles, briefs and copy | Week 2 |
| 6 | The Skill Stack | Every repeatable task packaged as a skill | Week 3 |
| 7 | The Research Agent | An agent that researches, scores and preps angles for you | Week 3 |
| 8 | The Multi-Agent Team | Several agents handing off across the process | Week 4 |
| 9 | The Automated Workflows | The workflows run on a schedule, automatically | Week 4 |
| 10 | The Complete System | Everything connected into one media buying process | Week 4 |

## What every level includes

- What to build, explained
- Step-by-step setup
- Copy-and-paste prompts
- Project and skill templates
- Agent briefs and guardrails
- A real media buying workflow
- Criteria for when to move up
- Where it sits in the 30-day implementation plan (`30-day-implementation-plan.md`)

## What it covers

Customer research, competitor ad analysis, angle creation, hook writing, creative briefs, ad copywriting, campaign build, retargeting, scaling and performance reporting.

## Files

```
README.md
30-day-implementation-plan.md
level-01-the-saved-prompt.md
level-02-the-prompt-library.md
level-03-the-permanent-brain.md
level-04-the-connected-data.md
level-05-the-research-to-creative-pipeline.md
level-06-the-skill-stack.md
level-07-the-research-agent.md
level-08-the-multi-agent-team.md
level-09-the-automated-workflows.md
level-10-the-complete-system.md
```

## What you need

- **Levels 1 to 6:** a Claude account. Projects are on every plan (free accounts can create up to five). Skills on claude.ai need code execution turned on.
- **Levels 7 to 10:** Claude Code, for subagents, the agent team and scheduled runs. Level 7 and Level 9 also describe a route for claude.ai only. Cloud routines (Level 9) are in research preview on Pro, Max, Team and Enterprise plans.
- Access to your ad platform, your store admin, your reviews and the Meta Ad Library.

The Claude features in this course are Projects, project knowledge and instructions, the Google Drive connector, Skills (`SKILL.md`), Claude Code, subagents, `CLAUDE.md`, Desktop scheduled tasks, cloud routines and `claude -p`. They are described as Anthropic's documentation describes them at the time of writing. Features change: if a menu has moved, check Anthropic's docs.

## The one rule everything follows

No invented numbers. Every prompt, skill and agent in this course uses only what you paste or what sits in your files, shows its arithmetic so you can redo it by hand, and prints `[NEEDS: the missing input]` instead of filling a gap with a benchmark or an average. Example figures in the lessons are labelled as examples. Use your own.

## What this course will not do

- It does not connect Claude to your ad account with write access, and no agent or scheduled run in it changes a budget, pauses an ad or edits your store. Claude prepares the decision with its numbers. You make it.
- It does not predict your future CPA or ROAS.
- It does not fill missing inputs with industry averages.

## The next step: The Complete Claude Paid Ads System

This course is the on-ramp. The lessons point by exact name to the skills, agents, prompts and playbooks in **The Complete Claude Paid Ads System** from RISE DTC: 18 playbooks, 15 skills, 50 prompts and 30 AI agents, free at:

https://resources.risedtc.com/claude-paid-ads-system/

## Questions

RISE DTC runs paid growth for DTC brands. If you want this system run on your account, that is what the team does.

risedtc.com

RISE DTC is not affiliated with Anthropic. Claude is a trademark of Anthropic.
