# Level 10: The Complete System

**What you build:** everything connected into one media buying process.
**When:** Week 4, Days 28 to 30 of the 30-day plan.
**Time to set up:** about 3 hours to connect and test. After that, your weekly time goes on the decisions in the decision table.
**Where you run it:** your brand folder in Claude Code (with scheduled runs), plus your claude.ai Project for ad hoc questions.

---

## What to build

Levels 1 to 9 built the parts. Level 10 connects them so the output of every stage is the input of the next, the loop closes every month, and your own time goes to the decisions only you should make.

The complete loop, across all ten stages of media buying:

```
 DATA IN (Level 4, automated at Level 9)
   ads exports . store exports . reviews and surveys . competitor ads . live ads
      |
 1 CUSTOMER RESEARCH ---- 2 COMPETITOR AD ANALYSIS          (angle-researcher)
      \                       /
       3 ANGLE CREATION  ->  CHECKPOINT 2: you pick angles
                |
       4 HOOK WRITING  ->  5 CREATIVE BRIEFS                 (brief-writer)
                |
       6 AD COPYWRITING                                      (copywriter)
                |
       claim check  ->  CHECKPOINT 3: you approve            (claim-checker)
                |
       creators produce  ->  7 CAMPAIGN BUILD: you launch    (prompt 2.7)
                |
       8 RETARGETING by objection                            (prompt 2.8)
                |
       ads run  ->  spend guard daily                        (scheduled)
                |
       10 PERFORMANCE REPORTING weekly                       (performance-analyst)
                |
       9 SCALING: budget steps  ->  you apply them           (performance-analyst)
                |
       winners and losers by angle  ->  back to 1 next month
```

What runs without you: data checks, the spend guard, the weekly report with verdicts and budget steps, the winner check, the monthly angle research, and the whole brief, copy and claim-check chain once you say continue.

What stays with you: picking angles, approving what ships, launching ads, and applying budget changes and pauses in the ad platform. The system prepares each decision with its numbers. You make it.

## Before you start

- Levels 1 to 9 in place for one brand.
- One full creative cycle and at least two weekly reports already run.

## Step-by-step setup

1. **Lay out the final folder** (template below) and move any stray files into it.
2. **Write the operating rhythm into `CLAUDE.md`** (template below). Every agent and scheduled run then knows the week's shape.
3. **Close the loop.** Add one step to the angle-researcher brief: "Read the two newest reports/week-*.md files and reports/month-*.md. Treat angles with only CUT ads in the last 90 days as tested and do not recommend them. Treat angles with SCALE ads as proven: suggest one new angle next to each."
4. **Connect retargeting.** Add retargeting to the monthly cycle: after Checkpoint 3, run prompt 2.8 on the top objections in the newest research file and save `pipeline/retargeting-[date].md`.
5. **Write the decision table** (template below) into `CLAUDE.md`, so every report ends with the decisions it is asking you for, and nothing else.
6. **Run Prompt 10.1, the system check.** Fix everything it flags.
7. **Run one full month** on the system. Keep a list of every time you had to do something the system should have prepared.
8. **At month end, run Prompt 10.2** and turn the top three items on your list into changes: a new skill, a tighter agent brief, or a new scheduled run.
9. **Add a second brand,** if you run more than one: copy the folder layout, write a new brain and data index, and reuse every skill and agent unchanged.

## Copy-paste prompts

### Prompt 10.1: the system check

```
Check this brand folder as one system. Print a table with PASS or FAIL and the reason for each:
1. CLAUDE.md has: brand brief, How you work, Team hand-offs, Scheduled runs, Operating rhythm, Decision table.
2. brain/ has product-facts, claim-sources, customer-quotes, and the numbers section is dated within 30 days.
3. data/data-index.md lists every file type, and the newest file of each type is within its refresh period.
4. Every skill named in any agent brief or scheduled run is installed.
5. Every agent named in run-creative-cycle exists in .claude/agents/.
6. reports/run-log.md has a line for every scheduled run in the last 7 days.
7. The newest angles file reads the newest reports (check its "Read from" line).
8. No agent brief gives a tool that can change a live system.
Do not fix anything. Only check.
```

### Prompt 10.2: the monthly retro

```
Read reports/month-[month].md, reports/run-log.md for the month, every pipeline file from the month, and my notes below.
1. Runs that failed or ran on stale data, and why.
2. Outputs I rewrote heavily, by agent or skill.
3. Decisions the reports asked me for, and how long each took me to act on.
4. From my notes: things I did by hand that the system could have prepared.
Propose at most three changes, each as: what to change (skill, agent brief, scheduled run, data source), the exact new or changed lines, and which problem above it fixes.
My notes: [PASTE]
```

### Prompt 10.3: onboard a new brand

```
I am adding a new brand to this system. Here is everything I have on it: [PASTE]. Using the layout and templates in this folder:
1. Draft CLAUDE.md for the new brand, with [NEEDS: x] for every missing fact.
2. Draft brain/product-facts.md, brain/claim-sources.md and brain/customer-quotes.md from the material.
3. Draft data/data-index.md with the file names this system uses.
4. List the exports I need to set up before the first weekly report can run.
Do not copy any fact from the other brand's files.
```

## Project and skill templates

### The final folder

```
media-buying-[brand]/
  CLAUDE.md                  brand brief, how you work, hand-offs, schedule, rhythm, decision table
  .claude/
    skills/                  your skills (Level 6) plus any from the Paid Ads System
    agents/                  angle-researcher, brief-writer, copywriter, claim-checker, performance-analyst
  brain/                     product-facts, claim-sources, customer-quotes
  data/                      data-index + dated exports
  pipeline/                  angles, briefs, copy, claim-check, retargeting (dated)
  reports/                   guard, week, winners, month, run-log
  scheduled/                 the instructions for each scheduled run
```

### Operating rhythm for `CLAUDE.md`

```
## Operating rhythm
Daily 7:10      spend guard (scheduled)            -> I pause flagged ads
Mon 7:10        weekly report (scheduled)          -> I act on CUT, apply budget steps
Wed 7:10        winner check (scheduled)           -> I brief replacements for RISING winners
1st Mon 9:10    angle refresh to Checkpoint 2      -> I pick angles, say continue
1st Mon pm      briefs, copy, claim check          -> I approve at Checkpoint 3, send briefs
Days 3-10       creative arrives                   -> I build and launch (prompt 2.7)
1st of month    monthly report (scheduled)         -> I send it to the founder / client
```

### Decision table for `CLAUDE.md`

```
## Decisions I make (every report ends with only these)
| Decision | Prepared by | Shown with |
|---|---|---|
| Pause an ad | spend guard, weekly report | spend, purchases, cost per purchase vs affordable CPA |
| Raise a budget | weekly report | current budget, next budget, hold days, revert condition |
| Pick angles | angle refresh | scorecard, claim check, affordable angles sum |
| Approve creative and copy | claim-checker | PASS / FAIL / DELETE counts and every FAIL line |
| Launch | campaign build (2.7) | pre-launch checklist |
| Change the affordable CPA | monthly retro | margin inputs and the sum |
```

### Skill template: the system check as a skill

Save Prompt 10.1 as `system-check/SKILL.md` and add it as a scheduled run on the first of each month, before the monthly report.

## Agent brief and guardrails

The full system runs on the guardrails you built level by level. The complete list, in one place, for `CLAUDE.md`:

1. Use only the brain, the data files and what I paste. No benchmarks or averages.
2. Show every sum. Name the file behind every number.
3. Print [NEEDS: the missing input] and stop that step. Never guess.
4. Stale data stops a run.
5. Agents and scheduled runs write only to pipeline/ and reports/.
6. Nothing in this system changes an ad account, a budget, a store or any live system. People do that.
7. Checkpoints 2 and 3 are always human.
8. Every hand-off is a file with the standard header.
9. Every scheduled run writes a line to the run log.
10. Every claim in anything that ships has a source in claim-sources.md.

## A real media buying workflow: one month on the complete system

**Week 1.** Monday: the weekly report and the angle file are both waiting. You spend 20 minutes on verdicts and budget steps in Ads Manager, and 15 minutes on Checkpoint 2. The briefs, copy and claim check come back that afternoon. You approve and send briefs to creators.

**Week 2.** The spend guard flags one new ad that spent past your affordable CPA with no purchases. You pause it. Monday's report shows the rest of the new ads at NOT ENOUGH SPEND. Creative arrives. You build the new ads from the copy file and launch.

**Week 3.** Monday's report puts two of the new ads into SCALE and one into CUT. Budget steps are ready with hold periods. Wednesday's winner check flags last month's best ad as RISING two weeks in a row. You ask brief-writer for a replacement on the same angle.

**Week 4.** The monthly report is ready on the first. You forward it. You run the monthly retro, and change one agent brief. The next angle refresh reads this month's winners and losers.

Your time for the month went on decisions. Everything else was prepared for you. Track how long each decision took in the retro.

## Where the Paid Ads System fits

The Complete Claude Paid Ads System is the full library this course plugs into. Once your loop runs, it is where each stage gets deeper:

| Stage | Playbook | Skills | Agents | Prompts |
|---|---|---|---|---|
| Customer research | 01, 02 | `customer-researcher` | | P01 to P06 |
| Competitor ad analysis | 03 | `competitor-researcher` | | P07, P08 |
| Angle creation | 04, 05 | `angle-gap-mapper` | `creative-01-angle-gap-mapper` | P09 to P14 |
| Hook writing | 06 | `hook-generator` | `creative-03-ad-hook-writer` | P15 to P17 |
| Creative briefs | 07, 08 | `ad-brief-generator`, `ugc-script-writer` | `creative-02-ad-brief-writer` | P18 to P24 |
| Ad copywriting | 09 | | `spend-04-policy-risk-checker` | P25 to P27 |
| Landing page | 10 | `message-match-checker`, `cro-auditor` | Convert team | P28 to P30 |
| Campaign build | 11, 12 | `ad-account-hygiene-auditor`, `utm-tag-auditor` | Track team | P31 to P34 |
| Testing | 13 | `scale-or-kill-judge` | `decide-01-scale-or-kill-judge` | P35 to P37 |
| Retargeting | 14 | | | P38, P39 |
| Scaling | 15, 16, 17 | `budget-step-planner`, `winner-iteration-planner` | Spend team | P40 to P46 |
| Performance reporting | 18 | `break-even-and-affordable-cpa`, `roas-vs-mer-reader` | Decide team | P47 to P50 |

Get it free at resources.risedtc.com/claude-paid-ads-system/.

## You are done when

- One full month has run on the system, with every scheduled run in the log.
- Your weekly time on the account is spent on the decision table and little else.
- Prompt 10.1 passes every line.
- Next month's angle file names this month's winners and losers in its "Read from" line.

## Common mistakes

- **Automating the decisions.** The system is fast because it prepares decisions well. Keep the decisions human.
- **Never running the retro.** Small problems in week 1 become the way things work by month 3.
- **Letting the brain go stale.** A new offer, a new price or a new margin changes every verdict. Update "Our numbers" the day it changes.
