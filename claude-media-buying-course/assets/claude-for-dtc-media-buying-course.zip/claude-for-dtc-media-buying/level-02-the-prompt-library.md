# Level 2: The Prompt Library

**What you build:** a saved prompt for every stage of the process.
**When:** Week 1, Days 3 and 4 of the 30-day plan.
**Time to set up:** about 2 hours, spread over two days.
**Where you run it:** any Claude plan, in a normal chat.

---

## What to build

Level 1 gave you one prompt that works. Level 2 gives every stage of media buying its own saved prompt, all in one file, all numbered, all written with the same rules.

The ten stages this course uses, in order:

| # | Stage | What it decides |
|---|---|---|
| 2.1 | Customer research | What your buyers say, in their words |
| 2.2 | Competitor ad analysis | What the market already says, and what nobody says |
| 2.3 | Angle creation | Which arguments your ads will make |
| 2.4 | Hook writing | The first line of each argument |
| 2.5 | Creative briefs | What gets filmed or designed |
| 2.6 | Ad copywriting | Primary text, headlines, descriptions |
| 2.7 | Campaign build | How the account is laid out before launch |
| 2.8 | Retargeting | What people who did not buy see next |
| 2.9 | Scaling | Which winners get more money, and how fast |
| 2.10 | Performance reporting | What happened, in money, and what changes next week |

When the library is finished, you never start a stage from a blank chat again.

## Before you start

- Your saved prompt from Level 1. It becomes one of the ten.
- One real input for each stage you run this week (reviews, competitor ad text, an Ads Manager export).
- Your fixed inputs, written once in a block at the top of the file: product, price, affordable CPA, allowed claims with sources, banned claims.

## Step-by-step setup

1. **Create one file called `prompt-library.md`.** A plain document works. So does a Google Doc.
2. **Paste the fixed inputs block at the top** (template below). Every prompt in the library refers to it with "use my fixed inputs", so you update your affordable CPA in one place.
3. **Paste the ten prompts below** under numbered headings 2.1 to 2.10. Put your Level 1 prompt in its matching slot and delete the version below if yours is better.
4. **Test each prompt once on real data,** in the order of the table. The output of one stage is often the input of the next (reviews become angles, angles become hooks). Save each output as a note named after its stage, for example `2.1-language-bank.md`.
5. **Fix each prompt once** after its test, the same way you did at Level 1.
6. **Add a "last used" date under each heading.** A prompt nobody used for a month is a stage you are skipping.

## The fixed inputs block

Paste this at the top of `prompt-library.md` and fill it in.

```
FIXED INPUTS (every prompt below uses these)
Brand and product: [NAME, WHAT IT IS, PRICE]
Offer running now: [OFFER]
Contribution margin per order after product, shipping, fees and discounts: [$]
Affordable CPA (the most one purchase can cost before you lose money): [$]
Claims I can make, each with its source: [LIST]
Claims I must never make: [LIST]
Markets and platforms: [e.g. US, Meta and Google]
```

If you do not have the margin or the affordable CPA, the `break-even-and-affordable-cpa` skill in The Complete Claude Paid Ads System works them out from numbers you already have.

## Copy-paste prompts

Every prompt ends with the same three rules. They are written out in full so each one works when pasted on its own.

### 2.1 Customer research

```
Use my fixed inputs. Here are [N] customer comments (reviews, survey answers, support tickets, ad comments):
[PASTE]
1. List the benefits customers name, each with a word-for-word quote and a count of how many comments mention it.
2. List the objections and hesitations, same format.
3. List before and after states ("before I used it I..." / "now I..."), quoted.
4. Pull 10 phrases I could put in an ad as written.
5. Name the most-mentioned thing that my product page does not say: [PASTE PAGE TEXT or write NONE].
Rules: use only what I paste. Show every count. Print [NEEDS: x] for anything missing.
```

### 2.2 Competitor ad analysis

```
Use my fixed inputs. Here is the text of [N] competitor ads copied from the Meta Ad Library, each with brand name and the date it started running:
[PASTE]
1. For each ad: the angle (problem/solution, mechanism, social proof, comparison, offer, identity, urgency, founder story), the hook, the offer, the call to action.
2. Count how many ads use each angle, across all brands.
3. List the ads running longest. Long-running ads are the ones the brand keeps paying for.
4. Name the angles no competitor uses.
Rules: use only what I paste. Show every count. Print [NEEDS: x] for anything missing.
```

### 2.3 Angle creation

```
Use my fixed inputs. My customer language bank: [PASTE 2.1 OUTPUT]. Angles competitors use and angles nobody uses: [PASTE 2.2 OUTPUT].
1. Write 8 angles. Each has: angle type, one sentence (who, what problem, what changes), the customer quote it rests on, the product fact that backs it, the objection it answers.
2. Mark any angle whose claim is outside my allowed claims as NEEDS PROOF.
3. Score each 0 to 2 on: customer quotes (0-1 = 0, 2-4 = 1, 5+ = 2), claim check, whether my account already runs it (yes = 0, once = 1, no = 2), whether competitors run it (crowded = 0, some = 1, none = 2). Show the total.
Rules: use only what I paste. Show every score. Print [NEEDS: x] for anything missing.
```

### 2.4 Hook writing

```
Use my fixed inputs. Angle: [PASTE ONE ANGLE FROM 2.3]. Customer phrases: [PASTE].
1. Write 12 opening lines, 12 words or fewer, for a video's first 3 seconds or a static ad's headline.
2. Tag each with its device (question, callout, before and after, objection, number, confession) and the customer phrase or product fact it rests on.
3. Remove any hook that claims something outside my allowed claims, and say why.
Rules: use only what I paste. No invented results. Print [NEEDS: x] for anything missing.
```

### 2.5 Creative briefs

```
Use my fixed inputs. Angle: [PASTE]. Chosen hooks: [PASTE 3]. Format: [UGC video / founder video / static / carousel]. Length: [SECONDS].
Write a brief a creator or designer can shoot from without asking me a question:
1. Goal of the ad in one sentence and the one action the viewer should take.
2. Shot by shot (or frame by frame): what is on screen, what is said, on-screen text, seconds.
3. Three hook versions for the first 3 seconds, so we can test them.
4. A claim boundary block: what the creator can say, what they cannot say.
5. Deliverables: aspect ratios, lengths, file names.
Rules: use only what I paste. Print [NEEDS: x] for anything missing.
```

### 2.6 Ad copywriting

```
Use my fixed inputs. Angle: [PASTE]. Hook used in the creative: [PASTE].
1. Write 5 primary texts. First line under 125 characters. Each one opens differently.
2. Write 5 headlines under 40 characters and 5 descriptions under 30 characters.
3. Check every line against my allowed and banned claims. Print PASS or the failing line.
Rules: use only what I paste. No invented numbers or reviews. Print [NEEDS: x] for anything missing.
```

### 2.7 Campaign build

```
Use my fixed inputs. Monthly budget: [$]. Ads ready to launch: [LIST WITH ANGLE]. Current campaigns, if any: [PASTE NAMES AND DAILY BUDGETS].
1. Propose a campaign layout: which campaigns, what each one is for, daily budget each, and which ads go where.
2. Name each campaign and ad set with one naming pattern: [e.g. market_objective_angle_date].
3. Write a pre-launch checklist: pixel and conversion event, UTMs on every link, exclusions, landing page loads on mobile, offer matches the ad.
4. Show how many purchases each test ad set can reach in 7 days at my affordable CPA (daily budget x 7 / affordable CPA), with the sum.
Rules: use only what I paste. Show every sum. Print [NEEDS: x] for anything missing.
```

### 2.8 Retargeting

```
Use my fixed inputs. Top objections from my customer research: [PASTE FROM 2.1]. Audiences I can build: [e.g. viewed product 7 days, added to cart 14 days].
1. For each audience, name the objection most likely stopping them, using only the objections I pasted.
2. Write one ad concept per audience that answers that objection with a fact or a customer quote I supplied.
3. Say how long each audience should see the ad and when it should stop.
Rules: use only what I paste. No invented discounts. Print [NEEDS: x] for anything missing.
```

### 2.9 Scaling

```
Use my fixed inputs. Ads in the SCALE group from my weekly read: [PASTE WITH SPEND, PURCHASES, COST PER PURCHASE]. Their current daily budgets: [PASTE]. Stock on hand for the product: [UNITS or NONE].
1. For each ad set, propose the next daily budget as a step of no more than 20% above today's.
2. Say how many days to leave it untouched: the larger of 7 days and the days the new budget needs to buy 10 purchases at my affordable CPA (10 x affordable CPA / new daily budget, rounded up). Show the sum.
3. Print the condition that sends it back to the old budget: cost per purchase above my affordable CPA over the hold period.
4. If I gave stock, show how many days of stock the new spend leaves, with the sum.
Rules: use only what I paste. Show every sum. Print [NEEDS: x] for anything missing.
```

### 2.10 Performance reporting

```
Use my fixed inputs. This week's totals: ad spend [$], Shopify revenue [$], orders [n], new customers [n], refunds [$]. Last week's same figures: [PASTE]. Per-ad verdicts from my weekly read: [PASTE].
1. Contribution after ads = orders x contribution margin per order - ad spend. Show the sum for both weeks.
2. MER = Shopify revenue / ad spend, both weeks, with the sum.
3. What changed between the weeks, in three sentences, using only these figures.
4. Three decisions for next week, each tied to a line above.
Rules: use only what I paste. Show every sum. Print [NEEDS: x] for anything missing.
```

## Project and skill templates

**Project template (Level 3 preview).** The library is built to live inside a Claude Project. At Level 3 you will upload `prompt-library.md` as project knowledge and add one line to the project instructions: "When I say 'run 2.4', use prompt 2.4 from prompt-library.md with my fixed inputs."

**Skill template.** Each numbered prompt is a future skill. Name them now so the names match later:

| Prompt | Future skill name |
|---|---|
| 2.1 | `language-bank` |
| 2.2 | `competitor-ad-read` |
| 2.3 | `angle-builder` |
| 2.4 | `hook-writer` |
| 2.5 | `creative-brief` |
| 2.6 | `ad-copy` |
| 2.7 | `campaign-build-plan` |
| 2.8 | `retargeting-plan` |
| 2.9 | `budget-step` |
| 2.10 | `weekly-report` |

If you plan to use The Complete Claude Paid Ads System, you do not need to write most of these as skills yourself. Its `customer-researcher`, `competitor-researcher`, `angle-gap-mapper`, `hook-generator`, `ad-brief-generator`, `budget-step-planner` and `scale-or-kill-judge` skills already cover stages 2.1, 2.2, 2.3, 2.4, 2.5, 2.9 and the weekly read.

## Agent brief and guardrails

Two rules make the library safe to hand to an agent later:

1. **Every prompt names its input and its output.** An agent can only pick up a stage if it knows what file to read and what file to write. Add an "Input:" and "Output:" line under each heading now, for example "Input: 2.1-language-bank.md. Output: 2.3-angles.md."
2. **Every prompt carries the same three rules** (use only what I paste, show every sum, print [NEEDS: x]). An agent that inherits those three rules cannot fill a gap with a made-up number.

## A real media buying workflow: one new angle, start to launch

1. Paste 30 recent reviews into 2.1. Save the output as `2.1-language-bank.md`.
2. Copy 15 competitor ads from the Meta Ad Library into 2.2. Save the output.
3. Feed both outputs into 2.3. Pick the angle with the highest score.
4. Run 2.4 on that angle. Pick 3 hooks.
5. Run 2.5 for one UGC video and one static. Send the briefs to your creator and designer.
6. When the creative comes back, run 2.6 for copy.
7. Run 2.7 to place the new ads in the account and check everything before launch.
8. The next Monday, run your Level 1 read. The new ads show as NOT ENOUGH SPEND until each reaches 10 purchases.

## Where the Paid Ads System fits

The Complete Claude Paid Ads System has 50 prompts, P01 to P50, in 20 categories. The library above is the short version. When a stage matters more to your account, swap in the longer prompts:

- 2.1 Customer research: P04 to P06
- 2.2 Competitor ad analysis: P07 and P08
- 2.3 Angle creation: P12 to P14
- 2.4 Hook writing: P15 to P17
- 2.5 Creative briefs: P18, P19, P23 and P24
- 2.6 Ad copywriting: P25 to P27
- 2.7 Campaign build: P31 and P32
- 2.8 Retargeting: P38 and P39
- 2.9 Scaling: P43 and P44
- 2.10 Performance reporting: P49 and P50

## Move up to Level 3 when

- All ten prompts have run at least once on your real data.
- You have pasted your fixed inputs block more than five times this week. That paste is what Level 3 removes.
- At least one stage's output fed the next stage without you rewriting it.

## Common mistakes

- **Ten prompts, ten styles.** Keep the same three rules and the same output habits in every prompt, or the outputs will not chain.
- **Fixed inputs typed into each prompt.** Keep them in one block, or your affordable CPA will be different in three places by next month.
- **Skipping stages you find boring.** Campaign build and reporting are where money leaks. Run them too.
