# Level 3: The Permanent Brain

**What you build:** a brand brief Claude reads every time.
**When:** Week 1, Days 5 to 7 of the 30-day plan.
**Time to set up:** 2 to 3 hours, most of it gathering facts you already have.
**Where you run it:** a Claude Project on claude.ai (Projects are on every plan; free accounts can create up to five). Claude Code users can do the same with a `CLAUDE.md` file, shown below.

---

## What to build

At Level 2 you pasted your fixed inputs into every chat. At Level 3 Claude already knows them.

A Claude Project is a workspace with its own chats, its own instructions and its own knowledge files. Anything you put in the project instructions applies to every chat you start inside the Project. Files you upload as project knowledge are there for Claude to read in every chat too.

You will build one Project per brand, called something like "Media buying: [Brand]". It holds:

1. **Project instructions:** the brand brief (who you sell to, what you can claim, your numbers, your rules). Short and always read.
2. **Project knowledge:** your prompt library from Level 2, your product facts, your best customer quotes, and your claim sources. Longer and read when needed.

From here on, every media buying chat for that brand starts inside that Project.

## Before you start

Gather these. Most take minutes to copy from somewhere you already keep them.

- Product facts: what each product is, what it is made of, prices, sizes, shipping times, guarantee.
- The source for every claim you make in ads (a lab test, a certification, a review count on your site).
- Your contribution margin per order and your affordable CPA (from Level 2's fixed inputs).
- Your top 3 customer segments, even as rough descriptions.
- Your best 20 to 30 customer quotes (from Level 2, stage 2.1).
- Your ad platform policies that affect you (for example health, weight loss or before-and-after rules).
- `prompt-library.md` from Level 2.

## Step-by-step setup

1. **Create the Project.** On claude.ai, open Projects and create a new one. Name it "Media buying: [Brand]".
2. **Write the project instructions.** Copy the brand brief template below, fill every bracket, and paste it into the project instructions. Keep it under two pages. It is read on every message, so every line should earn its place.
3. **Upload the knowledge files.** Add `prompt-library.md`, a `product-facts.md` file, a `claim-sources.md` file, and a `customer-quotes.md` file (templates below). Plain text or markdown is easiest for Claude to read; PDFs and docs work too.
4. **Test it with three questions** in a new chat inside the Project:
   - "What is my affordable CPA and where does it come from?"
   - "Write 3 hooks for our main product." Check that every hook stays inside your allowed claims.
   - "Can we say [a claim you are not allowed to make]?" The answer should be no, with the reason from your brief.
5. **Fix the brief** where any answer was wrong or vague. The fix is almost always a missing or unclear line in the instructions.
6. **Move your saved prompts in.** From now on, type "run 2.4 on this angle" inside the Project. You no longer paste the fixed inputs.
7. **Set a monthly review date.** Prices, offers and margins change. A brain with last quarter's affordable CPA gives last quarter's verdicts.

## Copy-paste prompts

### Prompt 3.1: build the brand brief from what you already have

Run this in a new chat inside the Project, before you write the instructions by hand.

```
I am setting up a Claude Project for media buying on my brand. Below is everything I have: product pages, my about page, an old brief, notes. Build a brand brief using only this material, with these headings:
1. What we sell (products, prices, offer)
2. Who buys (up to 3 segments, each with their reason to buy and their main hesitation, quoted where possible)
3. What we can claim (each claim with its source)
4. What we must never claim
5. Our numbers (contribution margin per order, affordable CPA)
6. How we sound (5 rules, each with an example line from our own material)
7. Platform rules that affect us
For any heading my material does not cover, print [NEEDS: what is missing]. Do not fill a gap with a guess.
Material:
[PASTE]
```

### Prompt 3.2: the brain check

Run this once a month inside the Project.

```
Read the project instructions and every knowledge file. Then list:
1. Any number that appears twice with different values.
2. Any claim in customer-quotes.md or prompt-library.md that is not in the allowed claims list.
3. Any heading in the brief that still says [NEEDS: ...].
4. Any fact that mentions a date, price or offer, so I can check it is still true.
Do not fix anything. Only list.
```

## Project and skill templates

### The brand brief (paste into project instructions)

```
# Media buying brain: [BRAND]

## Who you are working for
You help [NAME/ROLE] run paid ads for [BRAND], a DTC brand selling [PRODUCT CATEGORY] on [Meta / Google / TikTok] in [MARKETS].

## What we sell
[PRODUCT 1]: [one line], [price]
[PRODUCT 2]: [one line], [price]
Offer running now: [OFFER, end date]

## Who buys
Segment A: [description]. Buys because: "[quote]". Hesitates because: "[quote]".
Segment B: ...
Segment C: ...

## What we can claim (source in claim-sources.md)
- [claim] [source short name]
- ...

## What we never claim
- [claim or word]
- No results, figures or reviews that are not in the knowledge files.

## Our numbers
Contribution margin per order: $[ ]
Affordable CPA: $[ ]
Updated: [DATE]

## How we sound
1. [rule] Example: "[line]"
2. ...

## How you work
- Use only facts from these instructions, the knowledge files, and what I paste in the chat.
- Show every sum so I can redo it.
- If an input is missing, print [NEEDS: the missing input] and stop that step.
- When I say "run 2.x", use that prompt from prompt-library.md.
- You never tell me to change a budget or turn off an ad without showing the numbers that decide it.
```

### Knowledge file: `product-facts.md`

```
# Product facts: [BRAND]
## [PRODUCT]
- What it is:
- What it is made of / how it works:
- Sizes, variants, prices:
- Shipping time and cost by market:
- Guarantee and returns:
- What it does not do (things customers assume):
```

### Knowledge file: `claim-sources.md`

```
# Claim sources
| Claim, as we are allowed to write it | Source | Where the proof lives | Date checked |
|---|---|---|---|
```

### Knowledge file: `customer-quotes.md`

```
# Customer quotes (word for word, never edited)
| Quote | Source (review, survey, ticket) | Date | Segment | Theme |
|---|---|---|---|---|
```

### For Claude Code users: `CLAUDE.md`

Claude Code reads a `CLAUDE.md` file at the start of every session in that folder. Make a folder called `media-buying-[brand]`, put the brand brief above into `CLAUDE.md`, and put the knowledge files in a `brain/` subfolder. Add one line to `CLAUDE.md`: "Knowledge files are in brain/. Read the one you need before answering." The rest of this course uses this folder layout for Claude Code.

### Skill template

The brain holds the facts and the skills hold the method. When you write skills at Level 6, keep brand facts out of the skill and keep them in the brain, so one skill works for every brand you run.

## Agent brief and guardrails

Your brain's "How you work" section is the guardrail set every later agent inherits. Three lines in it matter most:

- **Only facts from the brain and the paste.** An agent that is allowed to "fill in" a claim will, sooner or later, write one your brand cannot prove.
- **[NEEDS: ...] over guesses.** You want a gap to be loud.
- **Numbers before recommendations.** No "turn this off" without the sum that decides it.

If you run ads for several brands, give each brand its own Project or folder. Never mix two brands' facts in one brain.

## A real media buying workflow: the Tuesday creative request

1. Your creative strategist asks for five new static ad concepts for Segment B.
2. Inside the Project, type: "Run 2.3 for Segment B only, using customer-quotes.md. Then run 2.4 on the top two angles."
3. Claude uses the segment's quotes and your allowed claims without being told what they are.
4. Type: "Now write 5 static concepts from the top 5 hooks: headline, subline, visual, proof element. Mark the claim source for each."
5. Every concept arrives with its claim source. Your strategist can check any line against `claim-sources.md` in seconds.
6. Save the concepts to a knowledge file called `concepts-[date].md` so next month's brief can see what you already tried.

## Where the Paid Ads System fits

- Upload the `playbooks/` folder from The Complete Claude Paid Ads System as project knowledge. Claude can then walk you through any of the 18 stages with your brain's numbers already filled in.
- Playbooks 01 (Market & Customer Research), 02 (Customer Psychology) and 04 (Offer & Positioning) are the best inputs for writing the "Who buys" and "What we sell" sections well.
- The `break-even-and-affordable-cpa` skill gives you the two numbers in "Our numbers".

## Move up to Level 4 when

- You start every media buying chat inside the Project.
- The three test questions come back right with no correction.
- You notice you are still pasting the same exports (reviews, ad reports, competitor ads) every week. Level 4 makes those live in the Project too.

## Common mistakes

- **A brain that is too long.** Instructions are read on every message. Keep the always-needed facts there and move the rest to knowledge files.
- **Claims without sources.** A claim with no source will get used anyway. Put the source next to it or delete it.
- **Never updating the numbers.** Date the numbers section and check it every month with Prompt 3.2.
