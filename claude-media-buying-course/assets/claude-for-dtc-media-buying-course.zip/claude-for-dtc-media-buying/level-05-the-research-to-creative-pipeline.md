# Level 5: The Research-to-Creative Pipeline

**What you build:** raw research turned into finished angles, briefs and copy.
**When:** Week 2, Days 11 to 14 of the 30-day plan.
**Time to set up:** about 3 hours. After that, one full run takes 60 to 90 minutes.
**Where you run it:** your Claude Project, or your Claude Code brand folder.

---

## What to build

At Level 2 each stage had its own prompt, and you carried the output from one to the next by hand. At Level 5 the stages run as one pipeline with fixed hand-off files, a claim boundary that travels with every angle, and three checkpoints where you decide.

The pipeline:

```
voice + competitors + live ads      (Level 4 data)
        |
   [5.1 Research]  -> research-[date].md        language bank, competitor map, gaps
        |
   CHECKPOINT 1: you confirm the gaps are real
        |
   [5.2 Angles]    -> angles-[date].md          8 angles, scored, claim-checked
        |
   CHECKPOINT 2: you pick 3
        |
   [5.3 Briefs]    -> briefs-[date].md          one brief per angle, with hooks
        |
   [5.4 Copy]      -> copy-[date].md            primary text, headlines, descriptions
        |
   CHECKPOINT 3: claim check, then send to creators
```

Each stage reads only the file before it plus the brain. That keeps each step checkable, and it means you can re-run one stage without re-running the rest.

## Before you start

- Level 3 brain with allowed and banned claims filled in.
- Level 4 files: a current voice file, competitor file and live-ads file.
- Your monthly test budget and affordable CPA, so the pipeline knows how many angles you can afford to test.

## Step-by-step setup

1. **Add the four pipeline prompts below to your prompt library** as 5.1 to 5.4.
2. **Create a `pipeline/` folder** (or a knowledge section named "Pipeline") where each run's files go, dated.
3. **Work out how many angles you can afford.** Each angle needs about 10 purchases before you can read it (the same minimum the weekly read uses). Angles you can test this month = monthly test budget / (10 x affordable CPA), rounded down. Write that number into prompt 5.2.
4. **Run 5.1** on your Level 4 files. Read the output. At Checkpoint 1, delete any "gap" that you know is wrong (for example an angle you tested and dropped last quarter).
5. **Run 5.2.** At Checkpoint 2, pick the angles to brief. Pick no more than the number from step 3.
6. **Run 5.3** for the chosen angles.
7. **Run 5.4** for the same angles.
8. **Run Prompt 5.5, the claim check,** on the briefs and copy together. Fix every FAIL before anything goes to a creator.
9. **Save the run.** Keep all five files. Next month's 5.1 reads last month's angles so it does not suggest the same ones twice.

## Copy-paste prompts

### 5.1 Research

```
Read the newest voice, competitors and live-ads files, and the brain.
Write research-[today].md with these sections:
A. Language bank: top 10 benefits and top 10 objections, each with a word-for-word quote and a count.
B. Competitor map: for each of these angles (problem/solution, mechanism, social proof, comparison, offer, identity, urgency/scarcity, founder/origin) the number of competitor ads using it.
C. Our map: the same count for our live ads.
D. Gaps: angles with zero or one competitor ad AND zero of our live ads.
E. Previous angles: list angles from the last pipeline run, if a previous angles file exists, with what happened to them if I noted it.
Rules: use only the files. Show every count. Print [NEEDS: x] for anything missing.
```

### 5.2 Angles

```
Read research-[date].md and the brain. I can afford to test [N] angles this month.
Write angles-[today].md:
1. 8 angles. At least 5 must sit in the gaps from section D. For each:
   - type, and one sentence: who, what problem, what changes
   - the customer quote it rests on (word for word, with its count)
   - the product fact that backs it, from product-facts or claim-sources
   - the objection it answers
   - claim check: SUPPORTED (every claim has a source), PARTIAL, or UNSUPPORTED
2. Score each 0 to 2 on five lines and total them:
   quotes (0-1 = 0, 2-4 = 1, 5+ = 2); segment (lowest value = 0, middle = 1, highest contribution = 2);
   claim check (UNSUPPORTED = 0, PARTIAL = 1, SUPPORTED = 2); our account (running = 0, once = 1, empty = 2);
   market (crowded = 0, some = 1, empty = 2).
3. Sort by total. Mark the top [N] as RECOMMENDED. Never recommend an UNSUPPORTED angle.
Rules: use only the files. Show every score.
```

### 5.3 Briefs

```
Read angles-[date].md, the brain, and research-[date].md. Brief these angles: [LIST].
For each angle write one brief in briefs-[today].md:
1. Angle sentence and the segment it speaks to.
2. Claim boundary: every claim the creator may make, with its source; everything they may not say.
3. Six hooks for the first 3 seconds, each tagged with its device and the quote or fact it rests on.
4. One UGC video brief (20 to 40 seconds): shot by shot, spoken lines, on-screen text, seconds per shot.
5. One static ad brief: headline, subline, visual, proof element.
6. What we will learn: the question this test answers.
Rules: every line traces to a quote or a fact in the files. Print [NEEDS: x] for anything missing.
```

### 5.4 Copy

```
Read briefs-[date].md and the brain. For each brief write, in copy-[today].md:
1. 5 primary texts. First line under about 125 characters and able to stand alone. Each uses a different hook from the brief.
2. 5 headlines under 40 characters.
3. 5 descriptions under 30 characters.
4. For Google search, if I run it: 10 headlines under 30 characters and 4 descriptions under 90 characters.
Rules: stay inside each brief's claim boundary. No numbers, reviews or results that are not in the files.
```

### 5.5 Claim check

```
Read briefs-[date].md and copy-[date].md, plus claim-sources.md and the banned claims in the brain.
For every line that states a fact, result, comparison or promise:
- PASS with the source name, or
- FAIL with the reason (no source, banned claim, stronger than the source allows, platform policy risk)
Then list every FAIL line with a rewrite that uses only a supported fact. If no rewrite is possible, say DELETE.
```

## Project and skill templates

### Project instructions addition

```
## Pipeline
- Pipeline files live in pipeline/ (or the Pipeline section) and are dated.
- Each stage reads only the file named in its prompt plus the brain.
- Never skip the claim check (5.5) before a brief goes to a creator.
```

### Hand-off file header (put at the top of every pipeline file)

```
# [stage] [date]
Read from: [files, with dates]
Brain version: [date in the "Our numbers" section]
Decided by me at checkpoint: [what I kept, what I cut, and why]
```

The "Decided by me" line is the one that matters six months later, when you want to know why an angle was never tested.

### Skill templates

The five prompts become five skills at Level 6. Write them with one input and one output each:

| Stage | Skill name | Reads | Writes |
|---|---|---|---|
| 5.1 | `pipeline-research` | voice, competitors, live-ads | research-[date].md |
| 5.2 | `pipeline-angles` | research | angles-[date].md |
| 5.3 | `pipeline-briefs` | angles, research | briefs-[date].md |
| 5.4 | `pipeline-copy` | briefs | copy-[date].md |
| 5.5 | `claim-check` | briefs, copy, claim-sources | claim-check-[date].md |

## Agent brief and guardrails

At Level 7, an agent runs 5.1 and 5.2 for you. It inherits these guardrails:

- **Checkpoints stay human.** The agent can prepare angles. You pick which ones get money.
- **Unsupported never ships.** An angle marked UNSUPPORTED can be listed, and it can never be recommended or briefed.
- **Every line carries its source.** A quote without a count, or a claim without a source, is a failed output.
- **The pipeline never writes to the ad account.** Its last output is a file a human sends to a creator.

## A real media buying workflow: the monthly creative sprint

1. First Monday of the month, after the Level 4 refresh: run 5.1. Spend 10 minutes on Checkpoint 1.
2. Run 5.2. Pick the angles your test budget can read (for example, a $2,000 test budget at a $50 affordable CPA reads 2,000 / (10 x 50) = 4 angles).
3. Run 5.3 and 5.4 for those angles.
4. Run 5.5. Fix every FAIL.
5. Send the briefs to creators and designers the same day. Ask for 3 hook versions per video.
6. When creative arrives, use the copy file to build the ads (Level 2, prompt 2.7).
7. In four weeks, the weekly reads tell you which angles earned a SCALE. Write the results into the next month's "Previous angles" section.

The dollar figures in step 2 are an example. Use your own.

## Where the Paid Ads System fits

This pipeline is the short route through playbooks 01 to 09 of The Complete Claude Paid Ads System. The matching pieces:

- 5.1: `customer-researcher` and `competitor-researcher` skills, prompts P04 to P08.
- 5.2: `angle-gap-mapper` skill, prompts P12 to P14, and the angle scorecard in playbook 05 (Angle Development).
- 5.3: `ad-brief-generator`, `hook-generator` and `ugc-script-writer` skills, prompts P18 to P24.
- 5.4: prompts P25 to P27.
- 5.5: `spend-04-policy-risk-checker` agent, and `convert-01-message-match-checker` to check the landing page answers what the ad promises.

## Move up to Level 6 when

- You have run the full pipeline once, start to finish, and sent real briefs to creators.
- The claim check found problems you would have missed.
- You find yourself copying the same long prompts in the same order. Level 6 packages them as skills so you call them by name.

## Common mistakes

- **Briefing more angles than you can read.** Four unread tests teach you nothing. Use the affordable-angles sum.
- **Letting the model pick at checkpoints.** It can rank. You decide, and you write down why.
- **Skipping 5.5 because the copy "looks fine".** The lines that look fine are the ones nobody checks.
