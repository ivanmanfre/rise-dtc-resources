# Level 1: The Saved Prompt

**What you build:** one reusable prompt for your highest-frequency task.
**When:** Week 1, Days 1 and 2 of the 30-day plan.
**Time to first result:** about 10 minutes.
**Where you run it:** any Claude plan, in a normal chat.

---

## What to build

Most media buyers start with Claude the same way. They type a fresh request every time, get a different shape of answer every time, and stop using it after a week.

Level 1 fixes one task. You pick the task you do most often, write the prompt for it once, test it on real data, and save it where you can paste it in five seconds. From then on, that task always comes back in the same format, with the same checks, and you can compare this week's answer with last week's.

One prompt, used every week, beats a folder of prompts you never open.

## Before you start

You need:

- A Claude account (any plan).
- A list of what you did last week. Open your calendar, your Slack, or your task list.
- For the task you pick, one real example of the input: a CSV export from Ads Manager, 20 customer reviews, or the text of one winning ad.

## Step-by-step setup

1. **Find your highest-frequency task.** Write down every media buying task you did last week and how many times you did it. Typical entries: reading yesterday's numbers, writing new hooks, writing primary text variants, answering "why did CPA go up", building the weekly report. Pick the one with the highest count. If two tie, pick the one you like least.

2. **Pick the matching prompt below.** Three are written for you:
   - **Prompt 1.A, the weekly ad read** (performance reporting). Pick this if you open Ads Manager every morning.
   - **Prompt 1.B, hooks from customer reviews** (hook writing). Pick this if you brief or write creative every week.
   - **Prompt 1.C, primary text variants from a winning ad** (ad copywriting). Pick this if you launch new ad copy every week.

   If your task is none of these, use the blank template at the end of this section.

3. **Fill the fixed inputs once.** Every prompt has a few inputs that rarely change (your product, your affordable cost per purchase, your brand's banned claims). Type them into the prompt now, so the saved version already has them. Leave only the weekly inputs in [BRACKETS].

4. **Run it on real data.** Paste the prompt into a new Claude chat, paste this week's input under it, and send.

5. **Check the answer by hand.** Pick two lines of the output and check them against your data. If the prompt does arithmetic, redo one sum on a calculator. If it quotes a review, find that review. Any line you cannot trace back is a reason to tighten the prompt before you rely on it.

6. **Fix the prompt once.** Add one sentence for each problem you found (for example "Only quote reviews word for word"). Run it again.

7. **Save it.** Put the final prompt in one place you open every day: a pinned note, a text expander snippet, or a document called `saved-prompts.md`. At Level 3 this file moves into a Claude Project.

8. **Use it for the rest of the week.** Every time the task comes up, paste the saved prompt. Do not retype it.

## Copy-paste prompts

### Prompt 1.A: the weekly ad read

```
You are reading my ad account's last 7 days. Use only the rows I paste. Do not use industry benchmarks or averages.

Fixed inputs:
- Product and price: [PRODUCT, PRICE]
- The most I can pay for one purchase and still make money (affordable CPA): [$ AMOUNT]
  If I have not filled this in, print [NEEDS: affordable CPA] and stop after step 1.

Weekly input, exported from Ads Manager at ad level (ad name, spend, purchases, purchase value, impressions, link clicks):
[PASTE ROWS]

Do this:
1. List any row missing ad name, spend or purchases as [NEEDS: field] for that ad, and leave it out of everything below.
2. For every ad with fewer than 10 purchases, print NOT ENOUGH SPEND with its spend so far. No verdict.
3. For every ad with 10 or more purchases, print cost per purchase as spend / purchases with the sum shown.
4. Sort those ads into:
   SCALE if cost per purchase is at or under 0.85 x affordable CPA
   HOLD if it is above 0.85 x affordable CPA and at or under affordable CPA
   CUT if it is above affordable CPA
5. Print all four groups (SCALE, HOLD, CUT, NOT ENOUGH SPEND) even if a group is empty.
6. Finish with three lines: total spend, total purchases, blended cost per purchase, each with the sum shown.

Rules: show every sum. Never round a number and then reuse the rounded number. If a figure is not in my paste, say so.
```

### Prompt 1.B: hooks from customer reviews

```
Write ad hooks for [PRODUCT] using only my customers' words.

Fixed inputs:
- What the product does, in one sentence: [SENTENCE]
- Claims I am allowed to make, with their source: [LIST]
- Claims I must never make: [LIST]

Weekly input, 20 or more reviews pasted as text:
[PASTE REVIEWS]

Do this:
1. Pull the 10 phrases customers repeat most. For each, quote it word for word and count how many reviews say it or something with the same meaning.
2. Write 12 hooks of 12 words or fewer. Each hook must rest on one quoted phrase. Print the phrase under the hook.
3. Tag each hook with its device: question, callout, before and after, objection, number, or confession.
4. Remove any hook that makes a claim outside my allowed list. Print what you removed and why.
5. Rank the rest by the count of the phrase each rests on.

Rules: no invented results, no invented numbers, no quotes a customer did not write.
```

### Prompt 1.C: primary text variants from a winning ad

```
Write new primary text for a Meta ad, built on an ad that is already working.

Fixed inputs:
- Product and offer: [PRODUCT, OFFER]
- Claims I am allowed to make, with their source: [LIST]
- Words and claims I must never use: [LIST]

Weekly input:
- The winning ad's primary text, headline and first line of the video or image text: [PASTE]
- Its last 7 days: spend [$], purchases [n], cost per purchase [$]

Do this:
1. Name the angle the winning ad uses in one sentence (who it speaks to, what problem, what changes).
2. Name the three parts of the copy doing the work: the opening line, the proof, the call to action.
3. Write 6 variants. Each changes exactly one of those three parts and keeps the other two. Label which part changed.
4. Keep each variant under 125 characters before the "See more" cut for the first two lines.
5. Check every variant against my allowed claims and print PASS or the line that fails.

Rules: keep the same angle. Do not add new claims, numbers or reviews.
```

### Blank template for any other task

```
Task: [WHAT YOU WANT DONE, ONE SENTENCE]
Fixed inputs: [THINGS THAT RARELY CHANGE]
This week's input: [PASTE]
Do this:
1. [STEP]
2. [STEP]
3. [STEP]
Output format: [TABLE / LIST / FIXED HEADINGS]
Rules: use only what I paste. Show every sum. Print [NEEDS: x] for any missing input.
```

## Project and skill templates

**Project template (for later).** You do not need a Project yet. When you reach Level 3, create a Project and add `saved-prompts.md` as a knowledge file. Then you can type "run 1.A on these rows" inside that Project and skip the paste.

**Skill template (for Level 6).** Write the saved prompt so it can become a skill without edits. A skill is a folder with a `SKILL.md` file whose top block names the job and says when to use it:

```
---
name: weekly-ad-read
description: Use when reading the last 7 days of ad-level rows from Ads Manager to decide which ads to scale, hold or cut. Takes pasted rows and an affordable CPA and returns every ad in one of four groups with the sums shown.
---

[paste the body of Prompt 1.A here]
```

Save that block now, next to the prompt. At Level 6 you will install it.

## Agent brief and guardrails

At Level 1 Claude only answers when you ask. The guardrails you write now carry through every level. Put these three lines at the bottom of every saved prompt:

- Use only what I paste. No benchmarks, no averages, no "typical" figures.
- Show every sum so I can redo it by hand.
- Print [NEEDS: the missing input] and stop the affected step, never guess.

**Agent brief you will reuse later:** "Your job is [the task]. Your input is [the paste]. Your output is [the fixed format]. You never change anything in the ad account." Keep that sentence. At Level 7 it becomes the first line of an agent file.

## A real media buying workflow: the Monday read

1. Monday, 9:00. Open Ads Manager, set the date range to the last 7 days, set the breakdown to ad level.
2. Export or copy these columns: ad name, amount spent, purchases, purchase conversion value, impressions, link clicks.
3. Open a new Claude chat, paste Prompt 1.A, paste the rows, send.
4. Read the CUT group first. For each ad, open it in Ads Manager and check that nothing else explains it (a paused ad set, a broken link, an out-of-stock product). Then turn it off.
5. Read the SCALE group. Note these ads for Level 2's scaling prompt. Do not raise budgets on the same day you cut.
6. Paste the three closing lines into your weekly notes, so next Monday has something to compare with.

Total time once the prompt is saved: about 15 minutes.

## Where the Paid Ads System fits

This course is the on-ramp to **The Complete Claude Paid Ads System** from RISE DTC (18 playbooks, 15 skills, 50 prompts, 30 AI agents), free at resources.risedtc.com/claude-paid-ads-system/.

- Prompt 1.A is a short version of the `scale-or-kill-judge` skill. Use the skill once you want the full output with every refusal and count.
- If you do not know your affordable CPA yet, run the `break-even-and-affordable-cpa` skill first. Every verdict in this course depends on that number.
- Prompt 1.B is a short version of the `hook-generator` skill and prompts P15 to P17.

## Move up to Level 2 when

- You have used the same saved prompt at least three times.
- You checked two lines of its output by hand each time and found nothing you could not trace back.
- You caught yourself retyping a different request for another task. That task is the next prompt.

## Common mistakes

- **Saving the prompt before testing it.** Run it on real data first, then save the fixed version.
- **Leaving fixed inputs in brackets.** Every bracket left in the saved prompt is a thing you will forget to fill one day.
- **Trusting a number you did not check.** Redo one sum every time until the prompt has earned it.
