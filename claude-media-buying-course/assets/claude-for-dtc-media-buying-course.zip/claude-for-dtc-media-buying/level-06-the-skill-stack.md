# Level 6: The Skill Stack

**What you build:** every repeatable task packaged as a skill.
**When:** Week 3, Days 15 to 17 of the 30-day plan.
**Time to set up:** about 3 hours for your first five skills.
**Where you run it:** claude.ai (Skills are available on Free, Pro, Max, Team and Enterprise plans and need code execution turned on) or Claude Code.

---

## What to build

A skill is a folder with a `SKILL.md` file in it. The top of the file names the skill and says when to use it. The body holds the instructions. Claude reads the short description all the time and loads the full instructions only when the task calls for it, so you can install dozens of skills without crowding every chat.

Three things change when your prompts become skills:

1. **You call a job by name.** "Run weekly-ad-read on ads-7d" replaces pasting a long prompt.
2. **Claude can pick the skill itself.** Ask "which ads should I turn off?" and Claude can reach for the right skill because its description matches.
3. **Skills work across brands.** The method sits in the skill. The facts sit in each brand's brain (Level 3). One `hook-writer` skill serves every brand you run.

Your skill stack at the end of this level: 5 to 10 skills that cover the stages you run every week, plus any of the 15 skills and 30 agents from The Complete Claude Paid Ads System you want to add.

## Before you start

- Your prompt library (Level 2) and pipeline prompts (Level 5), tested.
- The skill names you chose at Level 2 and Level 5.
- For claude.ai: code execution turned on in your settings. On Team and Enterprise, an owner must turn on both "Code execution and file creation" and "Skills" in organization settings first.
- For Claude Code: Claude Code installed and working.

## Step-by-step setup

1. **Pick your first five skills.** Take the five prompts you ran most in the last two weeks. For most media buyers: `weekly-ad-read` (1.A), `data-check` (4.1), `hook-writer` (2.4), `claim-check` (5.5), `weekly-report` (2.10).
2. **Make one folder per skill,** named exactly as the skill: `weekly-ad-read/`, `data-check/`, and so on. Lowercase, words joined by hyphens.
3. **Write each `SKILL.md`** using the template below. The description is the most important part: it is how Claude decides when to use the skill. Say what the skill takes in, what it gives back, and the phrases you would type when you need it.
4. **Move brand facts out.** If a prompt has your product name, price or affordable CPA typed into it, replace those with "read from the brain". The skill should work for any brand.
5. **Add a test file** in each folder: `fixtures/example-input.md` with one real (anonymised) input, and `fixtures/expected-output.md` with the output you checked by hand. This is how you know a later edit did not break the skill.
6. **Install the skills.**
   - **claude.ai:** zip each skill folder. Go to Customize > Skills, click "+", choose "Create skill" then "Upload a skill", and upload the zip. Make sure the skill is turned on.
   - **Claude Code, for you on this machine:** copy each folder into `~/.claude/skills/`, so the file sits at `~/.claude/skills/weekly-ad-read/SKILL.md`.
   - **Claude Code, for one brand folder or a team repository:** copy the folders into `.claude/skills/` inside that folder, and commit it so your team gets them.
7. **Test each skill by name and by need.** Once by name ("run data-check"). Once by need, without naming it ("are my files up to date?"). If Claude does not pick the skill the second time, rewrite the description with the words you actually typed.
8. **Compare against the fixture.** Run the skill on `example-input.md`. The output should match `expected-output.md` on every number.

## Copy-paste prompts

### Prompt 6.1: turn a saved prompt into a skill

```
Turn this prompt into a SKILL.md file.
- Frontmatter: name (lowercase, hyphens, [NAME]) and description (one paragraph: when to use it, what it takes in, what it returns, then "Triggers on" and 4 to 6 phrases a media buyer would type).
- Body sections: What this does, Required input, What it refuses (the cases where it stops and prints [NEEDS: x]), Method (numbered steps), Output format (fixed headings), Rules.
- Replace every brand-specific fact with "read from the brand brief".
- Keep every rule from the original prompt.
Prompt:
[PASTE]
```

### Prompt 6.2: test a skill against its fixture

```
Run the [SKILL NAME] skill on fixtures/example-input.md.
Then compare your output with fixtures/expected-output.md line by line.
Print MATCH or DIFFERENT for each number and each verdict. For every DIFFERENT, show both values.
```

### Prompt 6.3: the stack audit

Run this once a month.

```
List every skill you can see that relates to media buying. For each:
- name, one line on what it does
- which stage it covers (research, competitors, angles, hooks, briefs, copy, campaign build, retargeting, scaling, reporting, tracking)
- any other skill whose description overlaps with it
Then list the stages with no skill.
```

## Project and skill templates

### The `SKILL.md` template

```
---
name: weekly-ad-read
description: Use when reading the last 7 days of ad-level results to decide which ads to scale, hold or cut. Takes the newest ads-7d export (or pasted rows) and the affordable CPA from the brand brief, and returns every ad in one of four groups (SCALE, HOLD, CUT, NOT ENOUGH SPEND) with every sum shown. Triggers on "weekly read", "which ads should I turn off", "what do I scale this week", "read my ads", "scale or kill".
---

# Weekly ad read

## What this does
Sorts every ad from one 7-day window into four groups using one number you already know: the most one purchase can cost.

## Required input
1. Ad-level rows for one 7-day window: ad name, spend, purchases. From ads-7d-[date].csv or pasted.
2. Affordable CPA, read from the brand brief.

## What it refuses
- No affordable CPA: print [NEEDS: affordable CPA in the brand brief] and stop.
- A row without ad name, spend or purchases: print [NEEDS: field] for that row and leave it out.
- Mixed date windows: stop and ask for one window.

## Method
1. Drop incomplete rows (see above), and state how many rows remain.
2. Fewer than 10 purchases: NOT ENOUGH SPEND. Show spend so far.
3. 10 or more purchases: cost per purchase = spend / purchases, sum shown.
4. SCALE if at or under 0.85 x affordable CPA. HOLD if above that and at or under affordable CPA. CUT if above affordable CPA.

## Output format
SCALE / HOLD / CUT / NOT ENOUGH SPEND, each as a table (ad name, spend, purchases, cost per purchase), every group printed even if empty. Then totals with sums.

## Rules
- Use only the rows and the brief. No benchmarks.
- Show every sum. Never reuse a rounded number.
```

### The folder layout

```
weekly-ad-read/
  SKILL.md
  fixtures/
    example-input.md
    expected-output.md
```

### Project template

In a claude.ai Project, skills sit alongside the Project: the brain gives the facts, the skill gives the method. Add one line to the project instructions: "For media buying jobs, prefer my installed skills over writing a fresh answer, and name the skill you used."

## Agent brief and guardrails

Skills are what your agents will call at Level 7 and 8. Before an agent uses a skill, the skill needs:

- **A description that says when not to use it.** For example: "Not for campaign-level decisions; use budget-step for those." This stops an agent grabbing the nearest skill.
- **Refusals written out.** Every case where the skill stops and prints [NEEDS: x] instead of guessing.
- **A fixed output format.** An agent reading a skill's output needs the same headings every time.
- **No write actions.** None of the skills in this course change anything in Ads Manager, Shopify or anywhere else. They read and they report.

## A real media buying workflow: Monday in five calls

With the stack installed, a Monday morning inside your brand Project (or brand folder in Claude Code) is five short requests:

1. "Run data-check." Everything present and fresh.
2. "Run weekly-ad-read on ads-7d." Four groups.
3. "Run budget-step on the SCALE ad sets." Next budgets and hold periods.
4. "Run hook-writer on the angle behind our best SCALE ad." Twelve new hooks for the next round.
5. "Run claim-check on those hooks." Anything that fails is gone before a creator sees it.

## Where the Paid Ads System fits

The Complete Claude Paid Ads System gives you 15 skills and 30 agents already written in this exact format, each with its own `SKILL.md`, ready to install the same way:

- The 15 skills are in `dtc-claude-skills/`: `competitor-researcher`, `customer-researcher`, `angle-gap-mapper`, `ad-brief-generator`, `hook-generator`, `winner-iteration-planner`, `ugc-script-writer`, `message-match-checker`, `cro-auditor`, `utm-tag-auditor`, `break-even-and-affordable-cpa`, `roas-vs-mer-reader`, `ad-account-hygiene-auditor`, `budget-step-planner`, `scale-or-kill-judge`.
- The 30 agents are in `the-dtc-growth-team/`, five teams of six (Track, Spend, Creative, Convert, Decide).
- To install all 45 in Claude Code, from the folder where you unzipped that kit, use the `cp -R <dir>/* ~/.claude/skills/` commands in its README. Use that exact form: a trailing slash (`cp -r <dir>/*/`) on macOS flattens the folders so every `SKILL.md` overwrites the last.

If a system skill covers the same job as one of yours, keep one. Two skills with overlapping descriptions make Claude's choice harder.

## Move up to Level 7 when

- You have at least five skills installed and each has passed its fixture test.
- Claude picks the right skill when you describe the need without naming it.
- You notice a job that needs several skills in a row, plus some reading and judging in between. That is an agent's job.

## Common mistakes

- **Vague descriptions.** "Helps with ads" will never be picked. Name the input, the output and the words you type.
- **Brand facts inside skills.** Every brand after the first will get the wrong price.
- **Skipping fixtures.** You will edit a skill in two months and break a sum without noticing.
