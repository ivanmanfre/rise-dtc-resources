# Level 7: The Research Agent

**What you build:** an agent that researches, scores and preps angles for you.
**When:** Week 3, Days 18 to 21 of the 30-day plan.
**Time to set up:** about 3 hours, including two test runs.
**Where you run it:** Claude Code, as a subagent. A claude.ai version for people who do not use Claude Code is at the end of the setup.

---

## What to build

Up to Level 6, you ran every step and Claude answered. An agent is different: you give it a goal, a set of tools and a set of rules, and it decides the steps itself. It reads files, looks things up, runs your skills, checks its own work and hands you a finished file.

Your research agent does the work of pipeline stages 5.1 and 5.2 on its own:

1. Reads the brain, the data index and the newest voice, competitor and live-ads files.
2. Checks the files are fresh (your `data-check` skill).
3. Visits the public pages you list (competitor product pages, their review pages, forum threads you point it to) to fill gaps in the competitor and voice files.
4. Builds the language bank and the angle map.
5. Writes eight angles, scores them on the five-line scorecard, and claim-checks each one.
6. Preps the top angles for briefing: hooks, claim boundary, and the question each test answers.
7. Writes one file, `angles-[date].md`, and stops.

You start it, then go and do something else. You come back to a file with every quote counted, every score shown and every claim sourced.

In Claude Code, this kind of agent is called a **subagent**. It is a markdown file with a short header (name, description, which tools it may use, which model) and a body that works as its instructions. It runs in its own context, so its long reading does not fill up your main conversation.

## Before you start

- Claude Code installed, and the brand folder from Level 3 (with `CLAUDE.md`, `brain/`, `data/`, and a `pipeline/` folder).
- Your skills from Level 6 installed, at least `data-check` and `claim-check`.
- A list of public URLs the agent may read: competitor product pages, their review pages, relevant forum threads. Put them in `data/research-sources.md`.

## Step-by-step setup

1. **Create the agents folder** inside your brand folder: `.claude/agents/`. (Use `~/.claude/agents/` instead if you want the agent in every folder on this machine.)
2. **Create `angle-researcher.md`** in that folder and paste the agent brief below.
3. **Limit its tools.** The brief gives it Read, Grep, Glob, WebFetch, WebSearch and Write. It has no Bash tool, so it cannot run commands. Its instructions only allow writing inside `pipeline/`. The `skills:` lines load your `data-check` and `claim-check` skills into the agent when it starts, so it follows the same method you do.
4. **Write `data/research-sources.md`:** one URL per line, with a label ("Competitor A product page", "Reddit thread on [problem]"). The agent reads only these pages plus search results it finds for the questions in its brief.
5. **Start a Claude Code session in the brand folder** and ask: "Use the angle-researcher agent to prepare this month's angles." You can also @-mention it: `@agent-angle-researcher`. To run it as a whole separate session, open a second terminal in the brand folder and run `claude --agent angle-researcher`.
6. **Check the first run by hand.** Open `angles-[date].md`. Pick three quotes and find them in the voice file. Redo one score. Open one claim's source. If anything fails, add a rule to the brief that would have stopped it.
7. **Run it a second time** on the same data. The top angles should be the same or very close. If they jump around, the scorecard lines in the brief need tighter definitions.
8. **Decide the cadence.** Most brands run it once or twice a month, after the competitor and voice files are refreshed. At Level 9 it runs on a schedule.

**No Claude Code?** In your claude.ai Project, paste the agent brief body (everything under the header) into a new chat with web search turned on, followed by "Run this now." Claude works through the steps in that chat, reading your project knowledge. You wait for it in the chat, and the rest works the same.

## Copy-paste prompts

### Prompt 7.1: start a run

```
Use the angle-researcher agent. Month: [MONTH]. Test budget for angles this month: $[ ]. Focus segment, if any: [SEGMENT or ALL]. Angles already tested in the last 90 days and their verdicts: [PASTE or "see previous angles files"].
```

### Prompt 7.2: review the agent's work

```
Read pipeline/angles-[date].md. For 5 random quotes, find each one word for word in the data files and print FOUND with the file name or NOT FOUND. For each RECOMMENDED angle, open its claim sources and print whether the source supports the claim as written. Redo the score for the top angle and show whether it matches.
```

### Prompt 7.3: tighten the brief

```
Here is the angle-researcher brief and the problems I found in its last output:
[PASTE BRIEF]
[PASTE PROBLEMS]
Add the fewest rules that would have prevented each problem. Do not remove existing rules. Show only the changed lines.
```

## Project and skill templates

### The agent brief: `.claude/agents/angle-researcher.md`

```
---
name: angle-researcher
description: Researches customer language and competitor ads for one DTC brand, then writes eight scored, claim-checked ad angles with the top ones prepped for briefing. Use when preparing a month's creative testing plan or when asked for new angles. Read-only except for writing into pipeline/.
tools: Read, Grep, Glob, WebFetch, WebSearch, Write
skills:
  - data-check
  - claim-check
---

You are the research agent for this brand's paid ads. Your job is to hand the media buyer a ready-to-brief angle file. You never change anything outside the pipeline/ folder, and you never touch any ad account, store or live system.

## Inputs
- CLAUDE.md and brain/ (brand brief, product-facts, claim-sources, customer-quotes)
- data/data-index.md and the newest file of each type it lists
- data/research-sources.md (the only URLs you may fetch directly)
- previous pipeline/angles-*.md files, if any
- the month, test budget and focus segment in the request

## Steps
1. Run the data-check skill. If any voice, competitors or live-ads file is MISSING or STALE, write that at the top of your output and continue only with what is fresh.
2. Read the voice file. Build the language bank: top 10 benefits and top 10 objections, each with a word-for-word quote, the file it came from, and a count.
3. Read the competitor file and the pages in research-sources.md. For each competitor, record: angles used, offers, hooks, and ads with the oldest start dates. Search the web only to answer: "what do customers of [competitor] complain about?" and "what do buyers of [category] ask before buying?". Quote what you find with its URL.
4. Count angles across competitors and across our live ads, using this list: problem/solution, mechanism, social proof, comparison, offer, identity, urgency/scarcity, founder/origin.
5. Write 8 angles. At least 5 must be angles with zero or one competitor ad and none of ours. For each: type; one sentence (who, what problem, what changes); the quote it rests on with its count; the product fact that backs it, from brain/; the objection it answers.
6. Claim-check each angle with the claim-check skill: SUPPORTED, PARTIAL or UNSUPPORTED.
7. Score each 0 to 2 on quotes (0-1 = 0, 2-4 = 1, 5+ = 2), segment (lowest value = 0, middle = 1, highest contribution = 2), claim check (UNSUPPORTED = 0, PARTIAL = 1, SUPPORTED = 2), our account (running = 0, once = 1, empty = 2), market (crowded = 0, some = 1, empty = 2). Show each line and the total.
8. Angles affordable this month = test budget / (10 x affordable CPA from the brand brief), rounded down. Show the sum. Mark that many of the highest-scoring SUPPORTED angles as RECOMMENDED.
9. For each RECOMMENDED angle: six hooks with device and source, a claim boundary block, and the one question the test answers.
10. Write everything to pipeline/angles-[YYYY-MM-DD].md with the hand-off header, then stop and report the file path and the RECOMMENDED list.

## Rules
- Every quote is word for word, with its source file or URL. No paraphrased quotes.
- Every number shows its sum.
- Never recommend an UNSUPPORTED angle. Never recommend an angle tested in the last 90 days unless the request says to.
- If an input is missing, print [NEEDS: the missing input] in the output. Never fill a gap with an estimate, a benchmark or an average.
- Fetch only URLs in research-sources.md or URLs returned by your searches. Never log in anywhere. Never submit a form.
- Write only inside pipeline/.
```

### Hand-off header the agent writes

```
# Angles [date]
Written by: angle-researcher
Read from: [every file and URL, with dates]
Data flags: [STALE / MISSING items, or none]
RECOMMENDED: [angle names]
Waiting on: media buyer decision at Checkpoint 2
```

### Skill template

The agent calls skills you already have. If you want the scorecard reused by other agents, pull step 7 into its own `angle-scorecard` skill with the same five lines, and change step 7 of the brief to "Score each angle with the angle-scorecard skill."

## Agent brief and guardrails

The brief above carries its own guardrails. The five that matter most for any research agent:

1. **Narrow tools.** No Bash, no connectors that can write, no ad account access. An agent can only misuse a tool it has.
2. **One output folder.** Everything it writes goes to `pipeline/`. You can delete a bad run in one step.
3. **Sources on everything.** Quotes with files or URLs, claims with sources, numbers with sums.
4. **A hard stop.** It writes one file and stops. A human decides at Checkpoint 2.
5. **Named gaps.** [NEEDS: ...] instead of estimates, so a thin month is visible.

## A real media buying workflow: the mid-month angle refresh

1. Your weekly read shows the two current test angles both in CUT.
2. You refresh the competitor and voice files (Level 4) and add three new competitor pages to `research-sources.md`.
3. You start the agent: Prompt 7.1 with the remaining test budget for the month.
4. You go and review creative with your designer.
5. You come back to `angles-[date].md`. You run Prompt 7.2 on it. Every quote is found.
6. You pick two RECOMMENDED angles and write why in the "Decided by me" line.
7. You run pipeline stages 5.3 and 5.4 (or ask Claude to run `pipeline-briefs` and `pipeline-copy`) on those two. Briefs go out the same afternoon.

## Where the Paid Ads System fits

- The **Creative** team in The Complete Claude Paid Ads System gives the research agent ready skills to call: `creative-01-angle-gap-mapper`, `creative-02-ad-brief-writer`, `creative-03-ad-hook-writer`. Install them (Level 6) and add them to the brief's steps.
- `competitor-researcher` and `customer-researcher` can replace steps 2 and 3 if you prefer their fuller output.
- Playbook 03 (Competitor Ad Analysis) and playbook 05 (Angle Development) explain the method the agent follows, and are good project knowledge for the claude.ai version.

## Move up to Level 8 when

- The agent has produced two angle files you briefed from without rewriting.
- Prompt 7.2 finds no NOT FOUND quotes.
- You see the next hand-off: angles become briefs, briefs become copy, copy gets checked, and results come back to the next research run. Several agents can pass that work along. That is Level 8.

## Common mistakes

- **Giving the agent every tool.** Start with the list above and add only what a failed run proves it needs.
- **No stopping point.** An agent told to "improve our ads" will keep going. Give it one file to write.
- **Reading its summary instead of its file.** The summary says what it meant to do. The file shows what it did.
