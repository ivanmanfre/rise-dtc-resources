# Level 9: The Automated Workflows

**What you build:** the workflows run on a schedule, automatically.
**When:** Week 4, Days 25 to 27 of the 30-day plan.
**Time to set up:** about 3 hours, plus a week of watching the first runs.
**Where you run it:** Claude Code (Desktop app scheduled tasks, cloud routines, or the `claude -p` command on a scheduler), plus whatever you use to get exports into your data folder.

---

## What to build

Up to Level 8, every run started when you typed something. At Level 9 the runs start on their own: the Monday report is waiting when you open your laptop, the daily spend check has already flagged the ad that burned money overnight, and the research agent has already refreshed the angle file on the first Monday of the month.

Two things need to happen on a schedule:

1. **Fresh data arrives** in your `data/` folder (Level 4).
2. **Claude runs** a skill, an agent or the coordinator on that data and writes a file.

### Ways to schedule Claude

Claude Code offers three built-in ways to run work on a schedule, plus the command line for anything else. What follows is how Anthropic's Claude Code documentation describes them at the time of writing; check the docs for changes.

| Option | Runs on | Needs your computer on | Reads your local files | Good for |
|---|---|---|---|---|
| **Desktop scheduled tasks** (Claude Code Desktop app, Code tab, Routines, New routine, Local) | Your machine | Yes, with the app open and the computer awake | Yes | Everything in this course, if your data folder is on your computer |
| **Cloud routines** (claude.ai/code/routines, or `/schedule` in the Claude Code CLI; research preview, on Pro, Max, Team and Enterprise plans) | Anthropic's cloud | No | No. Each run starts from a fresh copy of a GitHub repository | Teams who keep the brand folder in a GitHub repository |
| **`/loop`** inside a Claude Code session | Your machine | Yes, with that session open | Yes | Checking something repeatedly during a working day |
| **`claude -p` from any scheduler** (cron, launchd, Windows Task Scheduler, GitHub Actions, or an automation tool such as n8n, Make or Zapier) | Wherever the scheduler runs | Depends on the scheduler | Yes, if run on your machine | People who already run a scheduler |

Things to know before you pick:

- **Desktop scheduled tasks** offer Manual, Hourly, Daily, Weekdays and Weekly schedules, and you can ask Claude for other intervals in plain language. If the computer is asleep at the scheduled time, the run is skipped, and when it wakes Desktop starts one catch-up run for the most recent missed time. Each task has its own permission mode. Click **Run now** once after creating it and approve the tools it needs, so later runs do not stall waiting for you.
- **Cloud routines** run even when your computer is off. The shortest interval is one hour, and there is a daily cap on routine runs per account. Skills in `~/.claude/skills/` on your computer are not available in the cloud: commit the skills and agents to the repository's `.claude/skills/` and `.claude/agents/` folders instead. Your data files must be in the repository too, or reachable through a connector.
- **`claude -p "your prompt"`** runs Claude Code once without the interactive screen and prints the result. Use `--allowedTools` to pre-approve only the tools the job needs.

If your data lives on your laptop, start with Desktop scheduled tasks. It is the simplest route with the fewest moving parts.

### Getting the data in on a schedule

Claude does not export from Ads Manager or Shopify by itself in this setup. Three common ways to get fresh files into `data/` without doing it by hand:

1. **Scheduled report emails.** Many ad platforms and store platforms can email a saved report on a schedule. An automation tool (n8n, Make, Zapier or similar) saves the attachment into your data folder or a synced drive with the right file name.
2. **An automation tool calling the platform's reporting API** on a schedule, writing a CSV with the same columns as your saved report.
3. **Ten minutes by hand on Monday morning,** with everything after that automated. Many teams stop here, and it works.

Whichever you pick, the file names and columns must match `data-index.md`, or the data check will flag them.

## Before you start

- Levels 4 to 8 working: data folder, skills, agents, coordinator.
- The Claude Code Desktop app (for local scheduled tasks), or a GitHub repository for your brand folder (for cloud routines).
- A way to be told a run finished: the Desktop app sends a notification when a scheduled task fires; for other schedulers, have the run write a file you check.

## Step-by-step setup

1. **List the runs you want** using the schedule below. Start with two: the daily spend check and the Monday report.
2. **Write each run's instructions** from the templates in this lesson. Each one names the skill or agent, the input files, the output file, and what to do when data is stale.
3. **Create the first scheduled task.** In the Desktop app's Code tab, open Routines, choose New routine, then Local. Fill in the name, a description, the instructions, the brand folder as the working folder, and the schedule. Pick a time a few minutes after the hour (for example 7:10), when your data refresh will already be done.
4. **Click Run now** and watch it. Approve the tools it asks for with "always allow" so the scheduled runs do not stall. Check the output file by hand.
5. **Add the second task** the same way.
6. **Watch a full week.** Read every output file. Look for runs that used stale data, skipped, or stalled on a permission prompt. When a run goes wrong, fix its instructions.
7. **Add the rest of the schedule** one run per day, so you can tell which new run caused a problem.
8. **Write the run log rule** into `CLAUDE.md` (below), so every scheduled run appends one line to `reports/run-log.md`.

## The schedule

| When | Run | Uses | Writes |
|---|---|---|---|
| Daily, 7:10 | Spend guard | `data-check`, ads-1d export | `reports/guard-[date].md` |
| Monday, 7:10 | Weekly report | `performance-analyst` agent | `reports/week-[date].md` |
| Wednesday, 7:10 | Winner check | `weekly-ad-read` on the last 3 weekly exports | `reports/winners-[date].md` |
| First Monday of the month, 9:10 | Angle refresh | `angle-researcher` agent | `pipeline/angles-[date].md` |
| First of the month, 8:10 | Monthly report | `weekly-report` across the month | `reports/month-[date].md` |

The times are an example. Put each run after the data it needs arrives.

The spend guard needs one new file: `ads-1d-[date].csv`, yesterday's ad-level rows with the same columns as your weekly export (add daily budget if your export can include it). Add it to `data-index.md` with a refresh period of 1 day.

## Copy-paste prompts (the scheduled task instructions)

### 9.1 Spend guard (daily)

```
Scheduled run: spend guard. Working folder: this brand folder.
1. Run data-check on the newest ads-1d file (yesterday's ad-level rows). If it is STALE or MISSING, write that to reports/guard-[today].md, append a line to reports/run-log.md, and stop.
2. List every ad where yesterday's spend is above the affordable CPA in the brand brief and purchases are 0. Show spend and the affordable CPA side by side.
3. List every ad set whose spend yesterday was more than its daily budget in the file, if budget is in the file.
4. Write reports/guard-[today].md with those two lists (print "none" for an empty list). Append one line to reports/run-log.md.
Do not change anything in any ad account. Recommend only.
```

### 9.2 Weekly report (Monday)

```
Scheduled run: weekly report. Use the performance-analyst agent on the newest ads-7d, ads-30d and store-7d files. If any is STALE or MISSING, the report must say so on its first line. When the agent finishes, confirm reports/week-[today].md exists with the hand-off header, and append one line to reports/run-log.md.
```

### 9.3 Winner check (Wednesday)

```
Scheduled run: winner check. Read the three newest ads-7d files. For every ad in all three:
- cost per purchase in each week, with sums (NOT ENOUGH SPEND where purchases are under 10)
- RISING if it went up two weeks in a row, FALLING if it went down two weeks in a row, else STEADY
- whether it is now above the affordable CPA
List RISING ads that were SCALE three weeks ago first: those are the winners wearing out. Write reports/winners-[today].md and append a line to reports/run-log.md. Recommend only.
```

### 9.4 Angle refresh (monthly)

```
Scheduled run: angle refresh. Run run-creative-cycle up to Checkpoint 2 with test budget $[ ] and segment ALL. Stop at Checkpoint 2 as always. Append a line to reports/run-log.md naming the angles file.
```

### 9.5 Monthly report

```
Scheduled run: monthly report. Read every reports/week-*.md from last month. Write reports/month-[month].md with: total spend, store net sales, contribution after ads (with sums, from the weekly files), MER each week, angles that produced a SCALE ad, angles that produced only CUT ads, and three decisions for next month, each tied to a figure. Append a line to reports/run-log.md.
```

## Project and skill templates

### Run log rule for `CLAUDE.md`

```
## Scheduled runs
- Every scheduled run appends one line to reports/run-log.md:
  date | run name | input files and their dates | output file | OK / STALE DATA / STOPPED: reason
- A scheduled run that finds stale or missing data writes what it found and stops. It never runs on old data.
- Scheduled runs recommend only. No scheduled run changes an ad account, a budget, a store or any live system.
```

### For cloud routines: repository layout

```
brand-repo/
  CLAUDE.md
  .claude/
    skills/        (every skill the routines use)
    agents/        (every agent the routines use)
  brain/
  data/            (updated by your export automation)
  pipeline/
  reports/
```

A cloud routine clones the repository at the start of each run and pushes its changes to a branch starting with `claude/`. Review those branches or pull requests the same way you read the output files.

### For `claude -p` on a scheduler

```
cd /path/to/brand-folder && claude -p "$(cat scheduled/weekly-report.md)" --allowedTools "Read,Grep,Glob,Write"
```

Put each run's instructions (9.1 to 9.5) in a `scheduled/` folder as a file, and point your scheduler at the matching command.

### Skill template

Each scheduled run can itself be a skill, so you can also start it by hand: for example `spend-guard/SKILL.md` holding the 9.1 instructions. The scheduled task instruction then becomes one line: "Run the spend-guard skill."

## Agent brief and guardrails

Unattended runs need stricter rules than the ones you watch:

- **Stale data stops the run.** Write what was found, then stop.
- **Recommend only.** Nothing scheduled in this course has a tool or connector that can change a budget, pause an ad or edit a store. Keep it that way.
- **Narrow permissions.** Approve only the tools each task needs (Read, Grep, Glob, Write for most). A permission prompt that appears in a later run is a sign the task is trying to do something new: read the run before approving.
- **A log line every run.** If a run is missing from `run-log.md`, it did not happen, whatever the notification said.
- **Checkpoints survive automation.** The monthly angle refresh still stops at Checkpoint 2 and waits for you.

## A real media buying workflow: the automated week

- **Every day, 7:10.** Spend guard runs. On most days it prints "none". On the day an ad spends past your affordable CPA with no purchases, you see it before your first coffee and pause it.
- **Monday, 7:10.** The weekly report is waiting: four verdict groups, budget steps for SCALE ad sets, platform versus store, contribution after ads. You spend 20 minutes acting on it in Ads Manager.
- **Wednesday, 7:10.** The winner check flags any former winner whose cost per purchase has risen two weeks in a row, so the next brief is already on its way before it goes into CUT.
- **First Monday of the month.** The angle file is ready. You decide at Checkpoint 2, then continue the cycle by hand (Level 8).
- **First of the month.** The monthly report is ready for the founder or the client.

## Where the Paid Ads System fits

- The **Decide** team agents in The Complete Claude Paid Ads System make good scheduled runs: `decide-01-scale-or-kill-judge` weekly, `decide-03-cpa-drift-reader` for the winner check, `decide-02-change-log-auditor` monthly.
- `spend-05-stock-cover-guard` as a weekly scheduled run warns you before a scaled ad sells out the product.
- Prompts P47 (Weekly Contribution Read), P49 (Weekly Margin and Profit Report) and P50 (Monthly Founder Report With Decisions) are strong templates for 9.2 and 9.5.

## Move up to Level 10 when

- Two scheduled runs have fired every time for a week, with a log line each and no stalls.
- You acted on a scheduled output (paused an ad from the spend guard, or stepped a budget from the weekly report) without re-running anything by hand.
- You want every piece, from data to research to launch to report, to run as one connected process. That is Level 10.

## Common mistakes

- **Scheduling before the data arrives.** A 7:00 run on a 7:30 export reads last week's file. Put runs after the refresh, and let the data check catch the rest.
- **Adding five scheduled runs on day one.** When something breaks, you will not know which run did it. Add one a day.
- **Letting a scheduled run act.** The moment a run can change a budget on its own, one bad export can cost a week of spend.
