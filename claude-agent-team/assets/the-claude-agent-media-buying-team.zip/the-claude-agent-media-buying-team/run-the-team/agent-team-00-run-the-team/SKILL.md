---
name: agent-team-00-run-the-team
description: "The run sheet for the Claude Agent Media Buying Team for DTC brands. Use when you want the whole team to build an ad set: it runs the eight agents in order, passes each one's output to the next, keeps three hooks per angle, and assembles the 24-ad set sheet, 8 angles x 3 hooks, each ad with its hook, primary text, headline, CTA and brief. Triggers on \"run the agent team\", \"build the 24-ad set\", \"run all eight agents\", \"build next month's ads from this research\", \"8 angles x 3 hooks\"."
---

# RISE DTC Claude Agent Team, the run sheet

## What this does

Runs the eight agents of the team in order and hands each one the output of the
ones before it. It does no research and writes no copy of its own. Its jobs are
the order, the handoffs, the rule that keeps three hooks per angle, and the ad
set sheet at the end.

Two stages. **Stage A is the afternoon build**, agents 1 to 6, before anything
is live: research, angles, hooks, briefs and copy for up to 24 ads. **Stage B
runs after launch**, agents 7 and 8, on the rows the ads produce. What comes out
of stage A is the words and the shot lists for each ad. Filming, design and
upload are yours.

**The line only this unit produces:** the ad set sheet, one row per ad, angle x
hook, each row carrying its hook, primary text, headline, CTA button and the
brief it is shot from, with the count against 24 printed and, for every missing
row, the exact input that would fill it.

## The team

| # | Agent | Folder | Stage | Hands on |
|---|---|---|---|---|
| 1 | ICP Finder | `agent-team-01-icp-finder` | A | the customer language bank to 3 and 6 |
| 2 | Ad Spy | `agent-team-02-ad-spy` | A | the competitor angle table to 3 |
| 3 | Angle Builder | `agent-team-03-angle-builder` | A | eight angle cards to 4, 5 and 6 |
| 4 | Hook Writer | `agent-team-04-hook-writer` | A | up to twelve hooks per angle, three kept, to 6 |
| 5 | Brief Writer | `agent-team-05-brief-writer` | A | one brief per angle and its claim boundary to 6 |
| 6 | Copywriter | `agent-team-06-copywriter` | A | primary text, headline and CTA per ad to the sheet |
| 7 | Scaling Master | `agent-team-07-scaling-master` | B | the next budget step, the hold and the revert date |
| 8 | Refresh | `agent-team-08-refresh` | B | the next six variants of a working ad |

Eight agents, this table is the whole team.

## Required input, gathered before you start

1. **15 or more customer items**: reviews, survey answers, return reasons,
   support tickets, ad comments. For agent 1.
2. **Competitor ad library listings and product page text**, 1 to 3
   competitors, with the date you read the library. For agent 2.
3. **Product facts, one per line, typed**: what it is, what it does, price,
   what is in the box, and for all eight angles also a guarantee, review or
   rating data, a founder detail, a stock or date fact and a described
   alternative. For agents 3, 4 and 5.
4. **The audience, in one sentence.**
5. **The format** you will make: UGC talking-to-camera video, static image or
   carousel. For agent 5.
6. **Where the ads send people**: a product page or elsewhere. For agent 6.
7. **Optional, your live ads' text**, if you want each angle card to say whether
   your account already runs it.

## What it refuses

**Refusal 1, stage A stops where an agent stops.** If agent 1 refuses (under 15
items) or agent 3 builds no card, nothing after it runs, and the sheet prints:

```
AD SET NOT BUILT
stopped at: agent <n>, <name>
reason: <that agent's refusal, verbatim>
[NEEDS: <what that agent asked for>]
```

**Refusal 2, no stage B before launch.** Agents 7 and 8 read live rows. Before
the ads have run there is nothing for them to read, and the run sheet says so
instead of guessing:

```
STAGE B NOT RUN
Agents 7 and 8 read rows from live ads. Run agent 7 when a campaign's 7-day row
has 10 purchases. Run agent 8 when one ad is working.
```

**Refusal 3, no padding to 24.** A missing angle is never filled with a second
card of another angle, and a missing hook is never filled with a reused device.
The count prints as it is.

## Method

**Step 1, agent 1.** Run the ICP Finder on the customer items. Keep blocks 1 to 4.

**Step 2, agent 2.** Run the Ad Spy on the competitor paste. Keep the angle table.

**Step 3, agent 3.** Run the Angle Builder on the language bank, the facts, the
audience sentence and the angle table. Print built n of 8.

**Step 4, agent 4, once per built card.** Run the Hook Writer with the card's
angle, the facts and the audience sentence. Keep three hooks by the rule below.

**Step 5, agent 5, once per built card.** Run the Brief Writer with the card's
angle, the facts and the format. One brief per angle. Each of the three kept
hooks takes a turn in slot 1, slots 2 to 5 held as written.

**Step 6, agent 6, once per built card.** Run the Copywriter with the card, the
three kept hooks, the brief's claim boundary and the ten ad phrases.

**Step 7, the sheet.** One row per ad. Count the rows and print the division
against 24.

**Step 8, stage B, after launch.** Agent 7 per campaign, agent 8 per working ad,
each on its own inputs.

## The three-hook rule

The Hook Writer's twelve devices fall into three groups. The run sheet keeps one
hook from each group, so every angle is tested with a line about the reader, a
line about the product and a line carrying proof.

| Group | Devices, in order |
|---|---|
| READER | 1 DIRECT QUESTION, 3 SECOND-PERSON RECOGNITION, 4 SCENE-SETTING OPENER, 9 AUDIENCE-DIRECT ADDRESS |
| PRODUCT | 2 NUMBER CALLOUT, 5 OBJECT/INGREDIENT CALLOUT, 6 PRICE-FIRST OPENER, 7 CONTENTS/UNBOX OPENER, 8 BLUNT CLAIM OPENER |
| PROOF | 10 GUARANTEE-FIRST OPENER, 11 FOUNDER-VOICE STATEMENT, 12 REVIEW CALLOUT |

**Rotation.** For the angle in position n (1 to 8), start each group at
position n - 1, counting the group's devices from zero and wrapping round to the
start of the group, then keep the first device from there that the Hook Writer
actually wrote. So the eight angles do
not all open on the same three devices. If a group has no written device, keep
the lowest numbered written device not yet kept, from any group. If the Hook
Writer wrote fewer than three for an angle, keep all of them and count the gap.

## Output format

```
# Ad set sheet
Built: <n> of 8 angles.  Hooks kept: <n>.  Ads: <n> of 24 = <n>/24 = <p>%.
Format: <format>.  Destination: <destination>.

| ad | angle | hook device | hook | primary text | headline | CTA | brief |
| 1.1 | PROBLEM/SOLUTION | DIRECT QUESTION | <hook> | Ad 1.1 in the copy | <headline> | <button> | brief 1 |

## Missing rows
- Angle <n> <ANGLE>: [NEEDS: <fact>]  (3 ads)
- Ad <n>.<k>: <reason>  [NEEDS: ...]
(or: "None. 24 of 24.")

## Stage B
<the Refusal 2 block, or the outputs of agents 7 and 8>
```

## Worked case

**Example data, invented for this file. Marrow & Ash is not a real brand.** The
facts, language bank and competitor table are the ones in the Angle Builder's
worked case: nine facts, 24 customer items, two competitors. Format: static
image. Destination: the product page.

Step 3 builds 8 of 8 cards. With all nine facts supplied, the Hook Writer has a
fact for every device, so it writes 12 of 12 for each angle, and the rotation
keeps:

| Angle (n) | READER | PRODUCT | PROOF |
|---|---|---|---|
| 1 PROBLEM/SOLUTION | 1 DIRECT QUESTION | 2 NUMBER CALLOUT | 10 GUARANTEE-FIRST |
| 2 MECHANISM | 3 SECOND-PERSON RECOGNITION | 5 OBJECT/INGREDIENT | 11 FOUNDER-VOICE |
| 3 SOCIAL PROOF | 4 SCENE-SETTING | 6 PRICE-FIRST | 12 REVIEW CALLOUT |
| 4 COMPARISON | 9 AUDIENCE-DIRECT | 7 CONTENTS/UNBOX | 10 GUARANTEE-FIRST |
| 5 OFFER | 1 DIRECT QUESTION | 8 BLUNT CLAIM | 11 FOUNDER-VOICE |
| 6 IDENTITY | 3 SECOND-PERSON RECOGNITION | 2 NUMBER CALLOUT | 12 REVIEW CALLOUT |
| 7 URGENCY/SCARCITY | 4 SCENE-SETTING | 5 OBJECT/INGREDIENT | 10 GUARANTEE-FIRST |
| 8 FOUNDER/ORIGIN | 9 AUDIENCE-DIRECT | 6 PRICE-FIRST | 11 FOUNDER-VOICE |

Angle 5 on PRODUCT: (5 - 1) = 4, and position 4 counted from zero in a group of
five is device 8. Angle 6 on PRODUCT: 5 wraps to position 0, device 2. Angle 4 on
PROOF: 3 wraps to position 0 in a group of three, device 10.

Step 5 writes 8 briefs, one per angle. Step 6 writes 8 bodies and 24 primary
texts. The first three rows of the sheet, from the Copywriter's worked case:

```
| 1.1 | PROBLEM/SOLUTION | DIRECT QUESTION | Awake at 3am again? What if nothing is holding your body still? | Ad 1.1 | Even pressure, less movement at night | Shop now | brief 1 |
| 1.2 | PROBLEM/SOLUTION | NUMBER CALLOUT  | 15 pounds of glass micro-beads, spread evenly across your body at 3am. | Ad 1.2 | Even pressure, less movement at night | Shop now | brief 1 |
| 1.3 | PROBLEM/SOLUTION | GUARANTEE-FIRST | 60 nights to try it, and a full refund if you send it back inside them. | Ad 1.3 | Even pressure, less movement at night | Shop now | brief 1 |
```

Rows 2.1 to 8.3 follow the same shape. Ads: 24 of 24 = 24/24 = 100%. Missing
rows: none. Stage B: not run, nothing is live yet.

**The same brand with F6, F7 and F8 removed** (no reviews, no founder line, no
date). The Angle Builder builds 5 of 8: SOCIAL PROOF, URGENCY/SCARCITY and
FOUNDER/ORIGIN cannot build. In the Hook Writer, devices 11 and 12 have no fact,
so the PROOF group holds only device 10, and every built angle keeps GUARANTEE-FIRST
as its proof hook. The sheet prints:

```
Built: 5 of 8 angles.  Hooks kept: 15.  Ads: 15 of 24 = 15/24 = 63%.
## Missing rows
- Angle 3 SOCIAL PROOF: [NEEDS: a review count or rating]  (3 ads)
- Angle 7 URGENCY/SCARCITY: [NEEDS: a stock level or a date]  (3 ads)
- Angle 8 FOUNDER/ORIGIN: [NEEDS: a founder detail]  (3 ads)
```

15 / 24 = 0.625, printed 63% half up. The three missing facts are the whole
distance to 24.

## Hard guardrails

- Never run an agent out of order in stage A, and never run stage B on made-up
  rows.
- Never fill a missing angle, hook or line with an invented fact to reach 24.
  Print the NEEDS line.
- Never call the sheet finished ads. It is the words and shot lists for each ad.
- Never predict what the ad set will do to a cost per purchase, a click rate or a
  return on ad spend.
- Never let an agent's refusal be skipped to keep the run going.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize, AI-powered,
  cutting-edge, holistic.

<!-- self-check: rotation re-derived for n = 1 to 8, READER size 4 starts
0,1,2,3,0,1,2,3 = devices 1,3,4,9,1,3,4,9; PRODUCT size 5 starts 0,1,2,3,4,0,1,2
= devices 2,5,6,7,8,2,5,6; PROOF size 3 starts 0,1,2,0,1,2,0,1 = devices
10,11,12,10,11,12,10,11. Matches the table. Counts: 8 x 3 = 24; 5 x 3 = 15,
15/24 = 0.625 -> 63%. Team table 8 rows, device groups 4 + 5 + 3 = 12. -->
