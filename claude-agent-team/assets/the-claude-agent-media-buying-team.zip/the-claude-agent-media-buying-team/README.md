# The Claude Agent Media Buying Team, built for DTC brands

Built by the team at RISE DTC.

Eight Claude agents, one job each, and a run sheet that runs them in order. In
one afternoon the first six turn your customer reviews, your competitors' ads and
your product facts into a 24-ad set: 8 angles x 3 hooks, each ad with its hook,
primary text, headline, CTA button and a shoot-ready brief. The last two run
after launch, to raise budget and to replace winners.

What comes out is the words and the shot lists for each ad. Filming, design and
upload are yours.

## The team

| # | Agent | What it returns | Folder |
|---|---|---|---|
| 1 | ICP Finder | your customers' benefits and objections, counted and quoted word for word, plus ten phrases for an ad | `agents/agent-team-01-icp-finder` |
| 2 | Ad Spy | every competitor claim word for word, their offer next to yours, and the angles nobody occupies | `agents/agent-team-02-ad-spy` |
| 3 | Angle Builder | eight angle cards, each tying a customer quote to a product fact | `agents/agent-team-03-angle-builder` |
| 4 | Hook Writer | up to twelve opening lines per angle, each tied to a fact | `agents/agent-team-04-hook-writer` |
| 5 | Brief Writer | a shot-by-shot brief per angle with a claim boundary block | `agents/agent-team-05-brief-writer` |
| 6 | Copywriter | primary text, headline and CTA for every hook, checked against ten ad-speak markers | `agents/agent-team-06-copywriter` |
| 7 | Scaling Master | the next daily budget, the days to hold it, and the date it goes back if the cost per purchase breaks | `agents/agent-team-07-scaling-master` |
| 8 | Refresh | the next six variants of a working ad, one change each, cheapest to shoot first | `agents/agent-team-08-refresh` |
| 0 | The run sheet | runs 1 to 8 in order, keeps three hooks per angle, and prints the 24-row ad set sheet | `run-the-team/agent-team-00-run-the-team` |

## The run order

**The afternoon, before anything is live:**

1. ICP Finder, on 15 or more reviews, survey answers or return reasons.
2. Ad Spy, on 1 to 3 competitors' ad library listings and product pages.
3. Angle Builder, on the output of 1 and 2 plus your product facts. Eight cards.
4. Hook Writer, once per angle. The run sheet keeps three: one about the reader,
   one about the product, one carrying proof. 8 x 3 = 24 hooks.
5. Brief Writer, once per angle. Eight briefs; each angle's three hooks take
   turns in the brief's first shot.
6. Copywriter, once per angle. 24 primary texts, eight headlines.

**After launch:**

7. Scaling Master, per campaign, once its 7-day row has 10 purchases.
8. Refresh, per ad, once one is working.

Run it all at once with the run sheet: install it, then ask Claude to "run the
agent team" and paste your inputs.

**To reach all 24,** the Angle Builder needs one fact for each of the eight
angles: what it does, what it is made of, review or rating data, a described
alternative, a price or guarantee, your audience in one sentence, a stock level
or a date, and a founder detail. With fewer facts you get fewer angles, 3 ads
each, and the sheet names the fact that would add the rest.

## Install

### Claude.ai (any plan with Projects)

1. Create a Project, for example "Ad team".
2. Upload all nine `SKILL.md` files as Project knowledge (the eight in `agents/`
   and the one in `run-the-team/`).
3. In a chat inside the Project, ask for the job by name ("run the agent team",
   or "run the angle builder on this") and paste your inputs under it.

For a one-off run with no setup: open any `SKILL.md`, paste the whole file into
a new chat, paste your inputs under it, and send.

### Claude Code

Agents install into `~/.claude/skills/`. Run these from this folder:

```
cp -R agents/* ~/.claude/skills/
cp -R run-the-team/* ~/.claude/skills/
```

Always use the `cp -R <dir>/*` form above. Never use `cp -r <dir>/*/` with a
trailing slash: on macOS that copies the contents of each folder instead of the
folder, so every `SKILL.md` lands on top of the last one in a single flat pile.

Check it worked: `ls ~/.claude/skills/ | grep agent-team` should list 9 folders,
each with its own `SKILL.md`. Claude Code picks them up on the next start. The
folder names do not clash with The Complete Claude Paid Ads System, so both can
live side by side.

## The one rule every agent follows

No invented numbers, facts or quotes. Every agent uses only what you paste and
prints `[NEEDS: the missing input]` where something is not there. The worked
examples inside each file use invented brands and made-up numbers, labelled as
examples. Replace them with your own.

## What this team will not do

- It does not connect to Meta, Google, Shopify or anything else. You paste,
  Claude reads.
- It does not film, design or upload an ad.
- It does not predict your CPA, ROAS or click rate.

## Questions

RISE DTC buys media for DTC brands and gets paid on the growth it adds. If you
want this team run on your account, that is what we do.

risedtc.com
